<?php
declare(strict_types=1);

/**
 * Returns the active SQL dialect (#378). ipam_db() bootstraps this once per
 * request based on $config['db_driver'] and stows it under
 * $GLOBALS['ipam_dialect']. v2.9.0 shipped SqliteDialect only; v2.10.0 adds
 * MysqlDialect (#382); v2.11.0 adds PgsqlDialect (#386). Tests and CLI
 * scripts that bootstrap lib.php directly (without going through ipam_db())
 * get a SqliteDialect lazily — that is the historical default and matches
 * what every test fixture expects.
 */
function ipam_dialect(): Dialect
{
    if (!isset($GLOBALS['ipam_dialect']) || !($GLOBALS['ipam_dialect'] instanceof Dialect)) {
        require_once __DIR__ . '/dialects/Dialect.php';
        require_once __DIR__ . '/dialects/SqliteDialect.php';
        $GLOBALS['ipam_dialect'] = new SqliteDialect();
    }
    return $GLOBALS['ipam_dialect'];
}

/**
 * Select and cache the active dialect from a config array. Called by
 * ipam_db() during connection bootstrap; safe to call standalone from
 * tests that need to pin a specific dialect without opening a connection.
 *
 * @param array<string, mixed> $config
 */
function ipam_dialect_from_config(array $config): Dialect
{
    require_once __DIR__ . '/dialects/Dialect.php';
    $driverRaw = $config['db_driver'] ?? 'sqlite';
    $driver = is_string($driverRaw) ? $driverRaw : 'sqlite';
    switch ($driver) {
        case 'mysql':
            require_once __DIR__ . '/dialects/MysqlDialect.php';
            $dialect = new MysqlDialect();
            break;
        case 'sqlite':
        case '':
            require_once __DIR__ . '/dialects/SqliteDialect.php';
            $dialect = new SqliteDialect();
            break;
        default:
            throw new RuntimeException("Unsupported db_driver: $driver");
    }
    $GLOBALS['ipam_dialect'] = $dialect;
    return $dialect;
}

/**
 * Bind a raw binary value (typically inet_pton output) to a PDOStatement
 * parameter using PDO::PARAM_LOB on every driver (#410).
 *
 * **Why this helper exists.** Pre-v2.9.0 the codebase passed binary IP
 * values through positional execute(), which ultimately hits PDO::PARAM_STR.
 * On SQLite this stores the value with TEXT affinity even though the column
 * is declared BLOB — SQLite's loose typing honors the binding's affinity at
 * insert time, not the column's declared type. The bytes round-trip
 * correctly, but `ORDER BY ip_bin` and range queries break the moment new
 * rows arrive bound as BLOB, because SQLite's comparison rules say any BLOB
 * sorts greater than any TEXT regardless of byte content.
 *
 * On MySQL / Postgres the situation is worse: PARAM_STR string-escapes high
 * bytes and truncates at null bytes, corrupting every stored IP.
 *
 * This helper uses PARAM_LOB unconditionally so the same binding works on
 * SQLite (BLOB affinity), MySQL (VARBINARY), and Postgres (BYTEA). The
 * existing-data normalization happens in the 2.9.0-blob-affinity migration.
 *
 * **Storage format**: native length, never padded. IPv4 = 4 bytes,
 * IPv6 = 16 bytes. All three engines do byte-wise memcmp comparison on
 * native-length values, so sort order is equivalent across engines.
 *
 * Round-trip test vectors (covered by tests/BinaryBindTest.php):
 *   inet_pton('10.0.0.0')         = \x0A\x00\x00\x00  (null bytes after first)
 *   inet_pton('2001:db8::')       = \x20\x01\x0D\xB8...  (mostly null bytes)
 *   inet_pton('255.255.255.255')  = \xFF\xFF\xFF\xFF  (all high bytes)
 */
/**
 * @param int|string $param 1-based positional index, or ':name' for a named placeholder.
 */
function ipam_bind_binary(PDOStatement $stmt, int|string $param, string $bin): void
{
    $stmt->bindValue($param, $bin, PDO::PARAM_LOB);
}

/**
 * Open a PDO connection based on $config['db_driver'].
 *
 * Dispatcher for the multi-engine support introduced in v2.10.0. Picks the
 * dialect first (so ipam_dialect() returns the right instance for the rest
 * of the request), then connects to the selected engine.
 *
 * Supported drivers:
 *   - 'sqlite' (default) — uses $config['db_path'] as the file path.
 *   - 'mysql' (experimental, v2.10.0 #382) — uses $config['db_dsn'],
 *     $config['db_user'], $config['db_pass']. Requires MySQL 8.0+.
 *
 * @param array<string, mixed> $config
 */
function ipam_db(array $config): PDO
{
    $dialect = ipam_dialect_from_config($config);

    switch ($dialect->driver_name()) {
        case 'sqlite':
            $pathRaw = $config['db_path'] ?? '';
            $path = is_string($pathRaw) ? $pathRaw : '';
            if ($path === '') {
                throw new RuntimeException('ipam_db: sqlite driver requires $config[\'db_path\']');
            }
            $dir = dirname($path);
            if (!is_dir($dir)) {
                mkdir($dir, 0700, true);
            }
            $pdo = new PDO('sqlite:' . $path, null, null, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            $pdo->exec("PRAGMA journal_mode = WAL;");
            $pdo->exec("PRAGMA busy_timeout = 30000;");
            break;

        case 'mysql':
            $dsnRaw  = $config['db_dsn']  ?? '';
            $userRaw = $config['db_user'] ?? '';
            $passRaw = $config['db_pass'] ?? '';
            $dsn  = is_string($dsnRaw)  ? $dsnRaw  : '';
            $user = is_string($userRaw) ? $userRaw : '';
            $pass = is_string($passRaw) ? $passRaw : '';
            if ($dsn === '') {
                throw new RuntimeException('ipam_db: mysql driver requires $config[\'db_dsn\']');
            }
            $pdo = new PDO($dsn, $user, $pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            // 8.0.29 is the effective minimum. ensure_audit_log_table()
            // and MysqlDialect::append_only_trigger() both emit
            // `CREATE TRIGGER IF NOT EXISTS`, a syntax feature added in
            // MySQL 8.0.29. Earlier 8.0.x servers pass a naive `8.0.0`
            // check and then crash on the first self-heal bootstrap.
            // Reject at connect time so failures are clear and immediate.
            $serverVersionRaw = $pdo->getAttribute(PDO::ATTR_SERVER_VERSION);
            $serverVersion = is_string($serverVersionRaw) ? $serverVersionRaw : '';
            if ($serverVersion === '' || version_compare($serverVersion, '8.0.29', '<')) {
                throw new RuntimeException(
                    "MySQL 8.0.29+ is required (server reports '$serverVersion')"
                );
            }
            break;

        default:
            throw new RuntimeException('ipam_db: unreachable — unsupported driver ' . $dialect->driver_name());
    }

    $fk = $dialect->pragma_foreign_keys(true);
    if ($fk !== null) {
        $pdo->exec($fk);
    }
    return $pdo;
}

/**
 * Create the audit_log table and its append-only triggers (idempotent).
 * Centralises DDL that was previously duplicated in 4 places.
 *
 * Routes type declarations and triggers through the active dialect so
 * fresh MySQL / Postgres installs emit engine-valid DDL. On SQLite the
 * resulting text matches the pre-v2.10.0 literals byte-for-byte. Per
 * the v2.10.0 schema-files decision: historical migration closures are
 * NOT refactored — schema.mysql.sql / schema.pgsql.sql pre-populate
 * schema_migrations so replay is a no-op on fresh non-SQLite installs.
 */
function ensure_audit_log_table(PDO $db): void
{
    $d = ipam_dialect();
    // action and created_at are indexed below, so they must use the
    // indexed text type (VARCHAR on MySQL, TEXT elsewhere). Free-form
    // unindexed columns (username, entity_type, ip, user_agent, details)
    // stay as plain TEXT.
    $idxText = $d->indexed_text_type();
    $db->exec("
        CREATE TABLE IF NOT EXISTS audit_log (
          id          " . $d->autoincrement() . ",
          created_at  $idxText NOT NULL DEFAULT (" . $d->now() . "),
          user_id     INTEGER, username TEXT, action $idxText NOT NULL,
          entity_type TEXT NOT NULL, entity_id INTEGER,
          ip TEXT, user_agent TEXT, details TEXT
        )
    ");
    // CREATE INDEX IF NOT EXISTS is a SQLite idiom. MySQL 8.0.0–8.0.28 do
    // not accept it (IF NOT EXISTS on CREATE INDEX landed in 8.0.29, which
    // is above our effective 8.0.29 floor), so we use a helper that swallows
    // the MySQL "Duplicate key name" error (errno 1061). On SQLite the
    // IF NOT EXISTS is native and the catch never fires.
    $createIndex = static function (PDO $db, string $name, string $table, string $col): void {
        try {
            $db->exec("CREATE INDEX IF NOT EXISTS $name ON $table($col)");
        } catch (PDOException $e) {
            $msg = $e->getMessage();
            // MySQL raises 1061 with "Duplicate key name" when the index
            // already exists. On MySQL 8.0.0–8.0.28, CREATE INDEX IF NOT
            // EXISTS itself is rejected (syntax error 1064) — retry with
            // plain CREATE INDEX, then swallow 1061 if the index is
            // already there.
            $sqlstate = (string)($e->errorInfo[0] ?? '');
            if ($sqlstate === '42000' && stripos($msg, 'syntax') !== false) {
                try {
                    $db->exec("CREATE INDEX $name ON $table($col)");
                } catch (PDOException $e2) {
                    if (stripos($e2->getMessage(), 'duplicate key name') === false) {
                        throw $e2;
                    }
                }
                return;
            }
            throw $e;
        }
    };
    $createIndex($db, 'idx_audit_log_action',     'audit_log', 'action');
    $createIndex($db, 'idx_audit_log_created_at', 'audit_log', 'created_at');
    foreach ($d->append_only_trigger('audit_log') as $stmt) {
        try {
            $db->exec($stmt);
        } catch (PDOException $e) {
            // MySQL 8.0.0–8.0.28 do not support CREATE TRIGGER IF NOT EXISTS
            // (added in 8.0.29). Swallow "Trigger already exists" (errno 1359)
            // so the self-heal path is idempotent on every supported 8.0.x.
            if (stripos($e->getMessage(), 'already exists') === false) {
                throw $e;
            }
        }
    }
}

function ipam_db_init(PDO $db): void
{
    global $config;
    $driver = ipam_dialect()->driver_name();

    // SQLite-only fast path: skip bootstrap checks if the sentinel file is
    // at least as new as the SQLite DB file. MySQL has no local file to
    // stat, so this optimisation does not apply there — the MySQL path
    // runs the full check on every bootstrap (overhead is one SELECT).
    if ($driver === 'sqlite') {
        // Honour a deployment's configured db_path so the sentinel check
        // stats the real database file, not the default one. The sentinel
        // itself lives next to the DB file so custom paths stay
        // self-contained.
        $dbPathRaw  = is_array($config ?? null) ? ($config['db_path'] ?? null) : null;
        $dbFilePath = is_string($dbPathRaw) && $dbPathRaw !== ''
            ? $dbPathRaw
            : __DIR__ . '/data/ipam.sqlite';
        $sentinelPath = dirname($dbFilePath) . '/.db_initialized';
        if (is_file($sentinelPath) && is_file($dbFilePath)) {
            $sentinelTime = (int)filemtime($sentinelPath);
            $dbTime       = (int)filemtime($dbFilePath);
            if ($sentinelTime >= $dbTime) {
                ensure_migrations_table($db);
                apply_migrations($db);
                ensure_audit_log_table($db); // self-heal if table was dropped
                return;
            }
        }
    }

    // Probe for the users table. Try a lightweight SELECT and catch the
    // "table not found" error — works on every engine without needing
    // sqlite_master / information_schema branching.
    $hasUsers = false;
    try {
        $probe = $db->query("SELECT 1 FROM users LIMIT 1");
        if ($probe !== false) {
            $probe->closeCursor();
            $hasUsers = true;
        }
    } catch (PDOException) {
        $hasUsers = false;
    }

    if (!$hasUsers) {
        $schemaFile = __DIR__ . '/schema.sql';
        if ($driver === 'mysql') {
            $schemaFile = __DIR__ . '/schema.mysql.sql';
        }
        $schema = file_get_contents($schemaFile);
        if ($schema === false) throw new RuntimeException("Cannot read " . basename($schemaFile));
        $db->exec($schema);

        $config = require __DIR__ . '/config.php';
        $u = $config['bootstrap_admin']['username'];
        $p = $config['bootstrap_admin']['password'];

        $hash = password_hash($p, PASSWORD_DEFAULT);
        $ins = $db->prepare("INSERT INTO users (username, password_hash, role, is_active) VALUES (:u,:h,'admin',1)");
        $ins->execute([':u' => $u, ':h' => $hash]);

        // Stamp all known migrations as already satisfied by the fresh schema.
        // schema.mysql.sql already pre-seeds these rows so the INSERT below
        // is a no-op on MySQL — upsert_or_ignore() makes that explicit and
        // lets the same path work on every driver.
        ensure_migrations_table($db);
        require_once __DIR__ . '/migrations.php';
        $ignore = ipam_dialect()->upsert_or_ignore('schema_migrations', ['version']);
        $stamp = $db->prepare("INSERT INTO schema_migrations (version) VALUES (:v) $ignore");
        foreach (array_keys(ipam_migrations()) as $ver) {
            $stamp->execute([':v' => $ver]);
        }
        return;
    }

    ensure_migrations_table($db);
    apply_migrations($db);

    // Self-healing: audit_log is created by schema.sql, not a migration, so it can
    // go missing after a botched demo reset. Recreate it (and its triggers) if absent.
    ensure_audit_log_table($db);

    $st = $db->prepare("SELECT COUNT(*) AS c FROM users");
    $st->execute();
    /** @var array<string, mixed>|false $countRow */
    $countRow = $st->fetch();
    $count = is_array($countRow) ? to_int($countRow['c']) : 0;
    if ($count === 0) {
        $config = require __DIR__ . '/config.php';
        $u = $config['bootstrap_admin']['username'];
        $p = $config['bootstrap_admin']['password'];
        $hash = password_hash($p, PASSWORD_DEFAULT);
        $ins = $db->prepare("INSERT INTO users (username, password_hash, role, is_active) VALUES (:u,:h,'admin',1)");
        $ins->execute([':u' => $u, ':h' => $hash]);
    }

    // Write sentinel so subsequent requests skip bootstrap queries (SQLite
    // only — the sentinel is a filesystem optimisation for the local DB
    // file and has no meaning on MySQL). Location must match the path
    // derived in the fast-path above: next to the resolved db_path file.
    if ($driver === 'sqlite') {
        $dbPathRaw  = is_array($config ?? null) ? ($config['db_path'] ?? null) : null;
        $dbFilePath = is_string($dbPathRaw) && $dbPathRaw !== ''
            ? $dbPathRaw
            : __DIR__ . '/data/ipam.sqlite';
        @touch(dirname($dbFilePath) . '/.db_initialized');
    }
}

function e(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * Safely coerce a mixed value (e.g. PDO fetch result or superglobal) to int.
 * Needed at PHPStan level 9 where (int) casts on mixed are disallowed.
 */
function to_int(mixed $value): int
{
    if (is_int($value)) return $value;
    if (is_float($value)) return (int)$value;
    if (is_string($value)) return (int)$value;
    if (is_bool($value)) return $value ? 1 : 0;
    return 0;
}

/**
 * Safely coerce a mixed value (e.g. PDO fetch result or superglobal) to string.
 * Needed at PHPStan level 9 where (string) casts on mixed are disallowed.
 * Defined here for api.php/status.php which load lib.php directly without init.php.
 * init.php defines this function earlier so pages that use init.php see it immediately;
 * the function_exists guard prevents a fatal redefinition error.
 */
if (!function_exists('to_str')) {
    function to_str(mixed $value): string
    {
        if (is_string($value)) return $value;
        if (is_int($value) || is_float($value)) return (string)$value;
        if (is_bool($value)) return $value ? '1' : '';
        if ($value === null) return '';
        return '';
    }
}

/* ---------------- Timestamp display ---------------- */

/**
 * Convert a UTC SQLite timestamp string to the configured timezone for display.
 *
 * All timestamps are stored as UTC ('YYYY-MM-DD HH:MM:SS'). This helper converts
 * them to the timezone configured in config.php['timezone'] (default 'UTC').
 * Apply to every timestamp echo in the UI rather than using the raw DB value.
 *
 * @param  string $utcStr  UTC datetime string from the database, or empty string.
 * @param  string $format  PHP date() format string. Defaults to 'Y-m-d H:i:s'.
 * @return string          Formatted datetime in the configured timezone, or '' if input is empty.
 */
function display_datetime(string $utcStr, string $format = 'Y-m-d H:i:s'): string
{
    if ($utcStr === '') return '';
    try {
        $dt = new DateTime($utcStr, new DateTimeZone('UTC'));
        /** @var IpamConfig $gConf */
        $gConf = $GLOBALS['config'];
        $tz = to_str($gConf['timezone'] ?? 'UTC');
        if ($tz === '') $tz = 'UTC';
        $dt->setTimezone(new DateTimeZone($tz));
        return $dt->format($format);
    } catch (\Exception) {
        return $utcStr; // return raw value on parse failure
    }
}

/* ---------------- CSRF ---------------- */

function csrf_token(): string
{
    $t = $_SESSION['csrf'] ?? null;
    return is_string($t) ? $t : '';
}

function csrf_require(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
    $sent = $_POST['csrf'] ?? null;
    $real = csrf_token();
    if (!is_string($sent) || !hash_equals($real, $sent)) {
        http_response_code(403);
        header('Location: login.php');
        exit;
    }
}

/* ---------------- Auth / RBAC ---------------- */

function is_logged_in(): bool { return !empty($_SESSION['uid']); }

function require_login(): void
{
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
    /** @var IpamConfig $gConf */
    $gConf = $GLOBALS['config'];
    $idle = $gConf['session_idle_seconds'];
    if (isset($_SESSION['last_active']) && (time() - to_int($_SESSION['last_active'])) > $idle) {
        logout_user();
        header('Location: login.php?timeout=1');
        exit;
    }
    $_SESSION['last_active'] = time();

    // Password expiry check — local accounts only, skip on change_password / logout pages
    $policy  = $gConf['password_policy'];
    $maxAge  = $policy['max_password_age_days'];
    if ($maxAge > 0) {
        $page = basename(to_str($_SERVER['SCRIPT_FILENAME'] ?? ''));
        if (!in_array($page, ['change_password.php', 'logout.php'], true)) {
            try {
                $db = $GLOBALS['db'] ?? null;
                if ($db instanceof PDO) {
                    $st = $db->prepare("SELECT oidc_sub, password_changed_at FROM users WHERE id = :id");
                    $st->execute([':id' => to_int($_SESSION['uid'] ?? 0)]);
                    /** @var array<string, mixed>|false $row */
                    $row = $st->fetch();
                    if ($row && $row['oidc_sub'] === null) {
                        $changedAt = to_str($row['password_changed_at'] ?? '');
                        $cutoff    = date('Y-m-d H:i:s', time() - $maxAge * 86400);
                        if ($changedAt === '' || $changedAt < $cutoff) {
                            header('Location: change_password.php?expired=1');
                            exit;
                        }
                    }
                }
            } catch (Throwable) {
                // Column may not exist yet on pre-1.4 installs — silently skip
            }
        }
    }
}

/**
 * Validate a password against the configured policy.
 * Returns an empty array on success, or an array of all violation messages.
 *
 * @param array<string, mixed> $policy
 * @return list<string>
 */
function validate_password_complexity(string $password, array $policy): array
{
    $errors = [];
    $min = max(1, to_int($policy['min_length'] ?? 12));
    if (mb_strlen($password) < $min) {
        $errors[] = "Password must be at least {$min} characters.";
    }
    if (!empty($policy['require_uppercase']) && !preg_match('/[A-Z]/', $password)) {
        $errors[] = 'Password must contain at least one uppercase letter (A–Z).';
    }
    if (!empty($policy['require_lowercase']) && !preg_match('/[a-z]/', $password)) {
        $errors[] = 'Password must contain at least one lowercase letter (a–z).';
    }
    if (!empty($policy['require_number']) && !preg_match('/[0-9]/', $password)) {
        $errors[] = 'Password must contain at least one number (0–9).';
    }
    if (!empty($policy['require_symbol']) && !preg_match('/[^A-Za-z0-9]/', $password)) {
        $errors[] = 'Password must contain at least one special character.';
    }
    return $errors;
}

/** @return array<string, mixed> */
function current_user(): array
{
    return [
        'id' => to_int($_SESSION['uid'] ?? 0),
        'username' => to_str($_SESSION['username'] ?? ''),
        'role' => to_str($_SESSION['role'] ?? ''),
    ];
}

function require_role(string $role): void
{
    require_login();
    if (current_user()['role'] !== $role) {
        http_response_code(403);
        exit('Forbidden');
    }
}

function require_write_access(): void
{
    require_login();
    if (current_user()['role'] === 'readonly') {
        http_response_code(403);
        exit('Read-only account');
    }
}

function login_user(int $uid, string $username, string $role, ?PDO $db = null): void
{
    session_regenerate_id(true);
    $_SESSION['uid'] = $uid;
    $_SESSION['username'] = $username;
    $_SESSION['role'] = $role;
    $_SESSION['last_active'] = time();
    // Load persisted theme preference so page_header() can prime localStorage
    if ($db !== null) {
        $st = $db->prepare("SELECT theme FROM users WHERE id = :id");
        $st->execute([':id' => $uid]);
        $theme = to_str($st->fetchColumn() ?: 'auto');
        $_SESSION['user_theme'] = in_array($theme, ['light', 'dark', 'auto'], true) ? $theme : 'auto';
    }
}

/* ---------------- Login rate limiting ---------------- */

function login_rate_limited(PDO $db, string $ip, int $maxAttempts, int $windowSeconds): bool
{
    $cutoff = date('Y-m-d H:i:s', time() - $windowSeconds);
    $st = $db->prepare("SELECT COUNT(*) AS c FROM login_attempts WHERE ip = :ip AND attempted_at >= :cutoff");
    $st->execute([':ip' => $ip, ':cutoff' => $cutoff]);
    /** @var array<string, mixed>|false $countRow */
    $countRow = $st->fetch();
    return (is_array($countRow) ? to_int($countRow['c']) : 0) >= $maxAttempts;
}

function record_login_failure(PDO $db, string $ip): void
{
    $db->prepare("INSERT INTO login_attempts (ip) VALUES (:ip)")
       ->execute([':ip' => $ip]);
}

function clear_login_failures(PDO $db, string $ip): void
{
    $db->prepare("DELETE FROM login_attempts WHERE ip = :ip")
       ->execute([':ip' => $ip]);
}

function purge_old_login_attempts(PDO $db, int $windowSeconds): void
{
    $cutoff = date('Y-m-d H:i:s', time() - $windowSeconds);
    $db->prepare("DELETE FROM login_attempts WHERE attempted_at < :cutoff")
       ->execute([':cutoff' => $cutoff]);
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie((string)session_name(), '', time() - 42000,
            $params["path"], $params["domain"], $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
}

/* ---------------- Audit ---------------- */

function client_ip(): string
{
    /** @var IpamConfig $gConf */
    $gConf = $GLOBALS['config'];
    if (!empty($gConf['proxy_trust']) && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $parts     = array_map('trim', explode(',', to_str($_SERVER['HTTP_X_FORWARDED_FOR'])));
        $candidate = $parts[0];
        if (filter_var($candidate, FILTER_VALIDATE_IP) !== false) {
            return $candidate;
        }
    }
    return to_str($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1');
}

function flash_set(string $message, string $type = 'success'): void
{
    $_SESSION['ipam_flash'] = ['msg' => $message, 'type' => $type];
}

/** @return array{msg: string, type: string}|null */
function flash_get(): ?array
{
    if (empty($_SESSION['ipam_flash'])) return null;
    $flash = $_SESSION['ipam_flash'];
    unset($_SESSION['ipam_flash']);
    if (!is_array($flash)) return null;
    $msg  = is_string($flash['msg']  ?? null) ? $flash['msg']  : '';
    $type = is_string($flash['type'] ?? null) ? $flash['type'] : 'info';
    return ['msg' => $msg, 'type' => $type];
}

function audit(PDO $db, string $action, string $entityType, ?int $entityId, string $details = ''): void
{
    $u = current_user();
    $st = $db->prepare("INSERT INTO audit_log (user_id, username, action, entity_type, entity_id, ip, user_agent, details)
                        VALUES (:uid,:un,:ac,:et,:eid,:ip,:ua,:dt)");
    $st->execute([
        ':uid' => $u['id'] ?: null,
        ':un'  => $u['username'] ?: null,
        ':ac'  => $action,
        ':et'  => $entityType,
        ':eid' => $entityId,
        ':ip'  => client_ip() ?: null,
        ':ua'  => to_str($_SERVER['HTTP_USER_AGENT'] ?? ''),
        ':dt'  => $details,
    ]);
}

function audit_export(PDO $db, string $what, string $details = ''): void
{
    audit($db, "export.$what", 'system', null, $details);
}

/* ---------------- Settings (v2.6.0) ---------------- */

/**
 * Authoritative registry of database-backed settings. Single source of truth for
 * what settings exist, how to render them, and what they default to. Consumed by
 * the v2.6.0-settings migration (seeds the table), ipam_setting() (defaults), and
 * settings.php (form rendering).
 *
 * Fields per definition:
 *   - label       : human label for the admin UI
 *   - description : help text shown under the input
 *   - type        : string|int|bool|json
 *   - group       : oidc|alert|branding|update_check|security
 *   - default     : value returned when the table and $config have no entry
 *   - sensitive   : mask in UI and audit details
 *   - config_key  : string (flat $config key) or array of keys (nested path) for
 *                   v2.6.0 $config back-compat fallback; null if no fallback.
 *
 * Typed loosely (mixed values) so callers can still be defensive about the
 * shape; the precise structure is documented above.
 *
 * @return array<string, array<string, mixed>>
 */
function ipam_setting_definitions(): array
{
    return [
        // --- Branding ---
        'branding.site_name' => [
            'label'       => 'Application name',
            'description' => 'Shown in the browser tab, nav bar, and login page.',
            'type'        => 'string',
            'group'       => 'branding',
            'default'     => 'Simple PHP IPAM',
            'sensitive'   => false,
            'config_key'  => 'app_name',
        ],
        'branding.timezone' => [
            'label'       => 'Display timezone',
            'description' => 'PHP timezone identifier (e.g. America/Toronto). Timestamps are stored as UTC; this converts them for display only.',
            'type'        => 'string',
            'group'       => 'branding',
            'default'     => 'UTC',
            'sensitive'   => false,
            'config_key'  => 'timezone',
            // Dynamic option list from PHP's zoneinfo database (~420 entries).
            // Callable form keeps the registry lazy — the list is only built
            // when settings.php actually renders or validates this field.
            'options'     => '@timezone',
        ],

        // --- Security ---
        'security.session_idle_seconds' => [
            'label'       => 'Session idle timeout (seconds)',
            'description' => 'Users are logged out after this many seconds of inactivity. Minimum 60.',
            'type'        => 'int',
            'group'       => 'security',
            'default'     => 1800,
            'sensitive'   => false,
            'config_key'  => 'session_idle_seconds',
            'min'         => 60,
        ],
        'security.login_max_attempts' => [
            'label'       => 'Max failed login attempts',
            'description' => 'Lock out an IP after this many failed attempts within the window. Minimum 1.',
            'type'        => 'int',
            'group'       => 'security',
            'default'     => 5,
            'sensitive'   => false,
            'config_key'  => 'login_max_attempts',
            'min'         => 1,
        ],
        'security.login_lockout_seconds' => [
            'label'       => 'Login lockout window (seconds)',
            'description' => 'Time window during which failed attempts are counted toward lockout. Minimum 60.',
            'type'        => 'int',
            'group'       => 'security',
            'default'     => 900,
            'sensitive'   => false,
            'config_key'  => 'login_lockout_seconds',
            'min'         => 60,
        ],

        // --- Alerting ---
        // Deprecated in v2.8.0 by alert.recipient_user_ids. Kept in the
        // registry so the v2.8.0 migration can read its current value and
        // try to map it to a user. Hidden from the settings UI via the
        // 'deprecated' flag below; settings.php must skip rendering it.
        'alert.email' => [
            'label'       => 'Alert email recipient (deprecated)',
            'description' => 'Replaced in v2.8.0 by a multi-select picker tied to user records. This row is migrated automatically and hidden from the UI.',
            'type'        => 'string',
            'group'       => 'alert',
            'default'     => '',
            'sensitive'   => false,
            'deprecated'  => true,
            'config_key'  => 'alert_email',
        ],
        'alert.recipient_user_ids' => [
            'label'       => 'Alert recipients',
            'description' => 'Users who receive utilization alerts. Only users with a non-empty email address and an active account are eligible. Leave empty to disable email alerts.',
            'type'        => 'json',
            'group'       => 'alert',
            'default'     => [],
            'sensitive'   => false,
            'config_key'  => 'alert_recipient_user_ids',
        ],
        'alert.util_warn_pct' => [
            'label'       => 'Utilization warn threshold (%)',
            'description' => 'Trigger a warning alert when subnet utilization reaches this percent.',
            'type'        => 'int',
            'group'       => 'alert',
            'default'     => 80,
            'sensitive'   => false,
            'config_key'  => 'alert_util_warn_pct',
            'min'         => 0,
            'max'         => 100,
        ],
        'alert.util_crit_pct' => [
            'label'       => 'Utilization critical threshold (%)',
            'description' => 'Trigger a critical alert when subnet utilization reaches this percent.',
            'type'        => 'int',
            'group'       => 'alert',
            'default'     => 95,
            'sensitive'   => false,
            'config_key'  => 'alert_util_crit_pct',
            'min'         => 0,
            'max'         => 100,
        ],
        'alert.interval_seconds' => [
            'label'       => 'Alert check interval (seconds)',
            'description' => 'Minimum seconds between utilization alert evaluations. Minimum 60.',
            'type'        => 'int',
            'group'       => 'alert',
            'default'     => 3600,
            'sensitive'   => false,
            'config_key'  => 'alert_interval_seconds',
            'min'         => 60,
        ],

        // --- Update check ---
        'update_check.enabled' => [
            'label'       => 'Check for updates',
            'description' => 'Fetch release info from GitHub and show a banner when a newer version is available.',
            'type'        => 'bool',
            'group'       => 'update_check',
            'default'     => true,
            'sensitive'   => false,
            'config_key'  => ['update_check', 'enabled'],
        ],
        'update_check.ttl_seconds' => [
            'label'       => 'Update check cache TTL (seconds)',
            'description' => 'How long to cache the update check result before re-fetching from GitHub. Runtime enforces a floor of 3600 (one hour) to avoid hammering the GitHub API, so values below 3600 are silently clamped.',
            'type'        => 'int',
            'group'       => 'update_check',
            'default'     => 86400,
            'sensitive'   => false,
            'config_key'  => ['update_check', 'ttl_seconds'],
            'min'         => 3600,
        ],
        'update_check.notify_prerelease' => [
            'label'       => 'Notify on prereleases',
            'description' => 'Also alert for alpha, beta, and RC builds.',
            'type'        => 'bool',
            'group'       => 'update_check',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['update_check', 'notify_prerelease'],
        ],

        // --- Login protection (bot/abuse mitigation on the login form) ---
        'login_protection.method' => [
            'label'       => 'Login protection method',
            'description' => 'Bot/abuse mitigation on the login form. Pick the provider that matches the site/secret keys below.',
            'type'        => 'string',
            'group'       => 'login_protection',
            'default'     => '',
            'sensitive'   => false,
            'config_key'  => ['login_protection', 'method'],
            'options'     => [
                ''                 => 'Off',
                'honeypot'         => 'Honeypot',
                'time_check'       => 'Time check',
                'turnstile'        => 'Cloudflare Turnstile',
                'hcaptcha'         => 'hCaptcha',
                'recaptcha'        => 'Google reCAPTCHA',
                'friendly_captcha' => 'Friendly Captcha',
            ],
        ],
        'login_protection.site_key' => [
            'label'       => 'Login protection site key',
            'description' => 'Widget site key (Turnstile / hCaptcha / reCAPTCHA / Friendly Captcha).',
            'type'        => 'string',
            'group'       => 'login_protection',
            'default'     => '',
            'sensitive'   => false,
            'config_key'  => ['login_protection', 'site_key'],
        ],
        'login_protection.secret_key' => [
            'label'       => 'Login protection secret key',
            'description' => 'Widget secret key used for backend verification.',
            'type'        => 'string',
            'group'       => 'login_protection',
            'default'     => '',
            'sensitive'   => true,
            'config_key'  => ['login_protection', 'secret_key'],
        ],
        'login_protection.min_seconds' => [
            'label'       => 'Login time-check minimum (seconds)',
            'description' => "Minimum seconds between page load and submit when method is 'time_check'.",
            'type'        => 'int',
            'group'       => 'login_protection',
            'default'     => 3,
            'sensitive'   => false,
            'config_key'  => ['login_protection', 'min_seconds'],
            'min'         => 0,
        ],
        'login_protection.version' => [
            'label'       => 'reCAPTCHA version',
            'description' => "reCAPTCHA widget version: 2 (checkbox) or 3 (invisible). Only applies when method is 'recaptcha'.",
            'type'        => 'int',
            'group'       => 'login_protection',
            'default'     => 2,
            'sensitive'   => false,
            'config_key'  => ['login_protection', 'version'],
            'min'         => 2,
            'max'         => 3,
        ],

        // --- reCAPTCHA Enterprise backend verification ---
        'recaptcha_enterprise.enabled' => [
            'label'       => 'reCAPTCHA Enterprise enabled',
            'description' => "Use the reCAPTCHA Enterprise API for backend verification. Requires login_protection.method = 'recaptcha'.",
            'type'        => 'bool',
            'group'       => 'recaptcha_enterprise',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['recaptcha_enterprise', 'enabled'],
        ],
        'recaptcha_enterprise.project_id' => [
            'label'       => 'GCP project ID',
            'description' => 'Google Cloud project that owns the reCAPTCHA Enterprise key.',
            'type'        => 'string',
            'group'       => 'recaptcha_enterprise',
            'default'     => '',
            'sensitive'   => false,
            'config_key'  => ['recaptcha_enterprise', 'project_id'],
        ],
        'recaptcha_enterprise.api_key' => [
            'label'       => 'GCP API key',
            'description' => 'Server-side API key used to call the reCAPTCHA Enterprise API.',
            'type'        => 'string',
            'group'       => 'recaptcha_enterprise',
            'default'     => '',
            'sensitive'   => true,
            'config_key'  => ['recaptcha_enterprise', 'api_key'],
        ],
        'recaptcha_enterprise.expected_action' => [
            'label'       => 'Expected action',
            'description' => "Action name emitted by the widget, matched server-side during verification.",
            'type'        => 'string',
            'group'       => 'recaptcha_enterprise',
            'default'     => 'login',
            'sensitive'   => false,
            'config_key'  => ['recaptcha_enterprise', 'expected_action'],
        ],
        'recaptcha_enterprise.score_threshold' => [
            'label'       => 'Score threshold',
            'description' => "Minimum risk score to accept (0.0–1.0). Stored as a string so the 0.5 default round-trips cleanly.",
            'type'        => 'string',
            'group'       => 'recaptcha_enterprise',
            'default'     => '0.5',
            'sensitive'   => false,
            'config_key'  => ['recaptcha_enterprise', 'score_threshold'],
        ],

        // --- OIDC ---
        'oidc.enabled' => [
            'label'       => 'OIDC enabled',
            'description' => 'Turn Authorization Code + PKCE SSO on or off.',
            'type'        => 'bool',
            'group'       => 'oidc',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['oidc', 'enabled'],
        ],
        'oidc.display_name' => [
            'label'       => 'OIDC button label',
            'description' => 'Label shown on the login page SSO button (e.g. Okta, Azure AD).',
            'type'        => 'string',
            'group'       => 'oidc',
            'default'     => 'SSO',
            'sensitive'   => false,
            'config_key'  => ['oidc', 'display_name'],
        ],
        'oidc.client_id' => [
            'label'       => 'OIDC client ID',
            'description' => 'Client identifier issued by the identity provider.',
            'type'        => 'string',
            'group'       => 'oidc',
            'default'     => '',
            'sensitive'   => false,
            'config_key'  => ['oidc', 'client_id'],
        ],
        'oidc.client_secret' => [
            'label'       => 'OIDC client secret',
            'description' => 'Client secret issued by the identity provider. Stored in the database.',
            'type'        => 'string',
            'group'       => 'oidc',
            'default'     => '',
            'sensitive'   => true,
            'config_key'  => ['oidc', 'client_secret'],
        ],
        'oidc.discovery_url' => [
            'label'       => 'OIDC discovery URL',
            'description' => 'Base URL of the IdP (/.well-known/openid-configuration is appended automatically).',
            'type'        => 'string',
            'group'       => 'oidc',
            'default'     => '',
            'sensitive'   => false,
            'config_key'  => ['oidc', 'discovery_url'],
        ],
        'oidc.redirect_uri' => [
            'label'       => 'OIDC redirect URI',
            'description' => 'Must match exactly what is registered in the IdP application settings.',
            'type'        => 'string',
            'group'       => 'oidc',
            'default'     => '',
            'sensitive'   => false,
            'config_key'  => ['oidc', 'redirect_uri'],
        ],
        'oidc.scopes' => [
            'label'       => 'OIDC scopes',
            'description' => "Space-separated scopes. 'openid' is required; 'email' is needed for auto-provisioning.",
            'type'        => 'string',
            'group'       => 'oidc',
            'default'     => 'openid email profile',
            'sensitive'   => false,
            'config_key'  => ['oidc', 'scopes'],
        ],
        'oidc.auto_link' => [
            'label'       => 'OIDC auto-link existing accounts',
            'description' => 'On first OIDC login, link the incoming identity to a matching local account by username or email.',
            'type'        => 'bool',
            'group'       => 'oidc',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['oidc', 'auto_link'],
        ],
        'oidc.auto_provision' => [
            'label'       => 'OIDC auto-provision users',
            'description' => 'Create a new local account on first OIDC login when no existing user can be matched. Implies auto-link.',
            'type'        => 'bool',
            'group'       => 'oidc',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['oidc', 'auto_provision'],
        ],
        'oidc.default_role' => [
            'label'       => 'OIDC default role',
            'description' => "Role assigned to auto-provisioned users. 'Read-only' is recommended.",
            'type'        => 'string',
            'group'       => 'oidc',
            'default'     => 'readonly',
            'sensitive'   => false,
            'config_key'  => ['oidc', 'default_role'],
            'options'     => [
                'readonly' => 'Read-only',
                'admin'    => 'Administrator',
            ],
        ],
        'oidc.disable_local_login' => [
            'label'       => 'Disable local password login',
            'description' => 'When OIDC is active, hide the local username/password form entirely. Emergency bypass still works unless also disabled below.',
            'type'        => 'bool',
            'group'       => 'oidc',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['oidc', 'disable_local_login'],
        ],
        'oidc.disable_emergency_bypass' => [
            'label'       => 'Disable emergency local bypass',
            'description' => 'Disable the ?local=1 emergency access path that lets a local admin sign in even when local login is hidden. Leave off until you are confident SSO will keep working.',
            'type'        => 'bool',
            'group'       => 'oidc',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['oidc', 'disable_emergency_bypass'],
        ],
        'oidc.hide_emergency_link' => [
            'label'       => 'Hide emergency bypass link',
            'description' => 'Hide the "(emergency local access)" link even if the ?local=1 bypass itself is still reachable.',
            'type'        => 'bool',
            'group'       => 'oidc',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['oidc', 'hide_emergency_link'],
        ],
    ];
}

/**
 * Ordered list of setting groups for the admin UI.
 *
 * @return array<string, array<string, mixed>>
 */
function ipam_setting_groups(): array
{
    return [
        'branding'             => ['label' => 'Branding',             'description' => 'Display name and timezone shown across the UI.'],
        'security'             => ['label' => 'Security',             'description' => 'Session lifetime and login lockout policy.'],
        'alert'                => ['label' => 'Alerting',             'description' => 'Subnet utilization email alerts.'],
        'update_check'         => ['label' => 'Update checker',       'description' => 'GitHub release checker for the in-app upgrade banner.'],
        'login_protection'     => ['label' => 'Login protection',     'description' => 'Bot and abuse mitigation on the login form.'],
        'recaptcha_enterprise' => ['label' => 'reCAPTCHA Enterprise', 'description' => "Backend verification via Google's reCAPTCHA Enterprise API."],
        'oidc'                 => ['label' => 'OIDC / SSO',           'description' => 'OpenID Connect single sign-on.'],
    ];
}

/**
 * Look up a value in $GLOBALS['config'] given either a flat key or a nested path.
 * Used by the v2.6.0 back-compat fallback in ipam_setting() and by the settings
 * table seeder. Returns null when the key is not present.
 *
 * @param array<array-key, mixed> $config
 * @param string|array<array-key, mixed>|null $configKey
 */
function ipam_setting_config_fallback(array $config, string|array|null $configKey): mixed
{
    if ($configKey === null) return null;
    if (is_string($configKey)) {
        return array_key_exists($configKey, $config) ? $config[$configKey] : null;
    }
    $cursor = $config;
    foreach ($configKey as $segment) {
        if (!is_string($segment) && !is_int($segment)) return null;
        if (!is_array($cursor) || !array_key_exists($segment, $cursor)) return null;
        $cursor = $cursor[$segment];
    }
    return $cursor;
}

/**
 * Encode a PHP value for storage in the settings.value TEXT column, given a type.
 */
function ipam_setting_encode(mixed $value, string $type): string
{
    switch ($type) {
        case 'bool':
            return ($value === true || $value === 1 || $value === '1' || (is_string($value) && strtolower($value) === 'true')) ? '1' : '0';
        case 'int':
            return (string)(int)(is_numeric($value) ? $value : 0);
        case 'json':
            $encoded = json_encode($value);
            return is_string($encoded) ? $encoded : 'null';
        default:
            return is_scalar($value) ? (string)$value : '';
    }
}

/**
 * Decode a value read from the settings.value column back to its PHP type. On
 * JSON decode failure returns $default and logs a warning.
 */
function ipam_setting_decode(?string $stored, string $type, mixed $default): mixed
{
    if ($stored === null) return $default;
    switch ($type) {
        case 'bool':
            return ($stored === '1' || strtolower($stored) === 'true');
        case 'int':
            return (int)$stored;
        case 'json':
            $decoded = json_decode($stored, true);
            if ($decoded === null && strtolower(trim($stored)) !== 'null') {
                error_log("ipam_setting_decode: invalid JSON in settings row, returning default");
                return $default;
            }
            return $decoded;
        default:
            return $stored;
    }
}

/**
 * Infer a type string from a PHP value. Used when callers write without an
 * explicit type hint.
 */
function ipam_setting_infer_type(mixed $value): string
{
    if (is_bool($value)) return 'bool';
    if (is_int($value))  return 'int';
    if (is_array($value)) return 'json';
    return 'string';
}

/**
 * Read a setting. Fallback chain: settings table -> $config (v2.6 back-compat)
 * -> registry default -> $default argument. Never throws. Results are memoised
 * via ipam_setting_cache_storage() so repeated reads in a single request don't
 * re-query the DB; ipam_setting_set() invalidates the relevant entry.
 */
function ipam_setting(string $key, mixed $default = null): mixed
{
    $cached = ipam_setting_cache_storage($key);
    if ($cached !== '__IPAM_SETTING_MISS__') return $cached;

    $definitions = ipam_setting_definitions();
    $def         = $definitions[$key] ?? null;
    $type        = is_array($def) && is_string($def['type'] ?? null) ? $def['type'] : 'string';
    // Precedence: DB → config → registry default → caller $default. A caller
    // default only matters for unregistered keys; registered keys always fall
    // through to the registry's authoritative default.
    $fallback = ($def !== null && array_key_exists('default', $def))
        ? $def['default']
        : $default;

    try {
        $db = $GLOBALS['db'] ?? null;
        if ($db instanceof PDO) {
            $st = $db->prepare("SELECT value, type FROM settings WHERE `key` = :k");
            $st->execute([':k' => $key]);
            $row = $st->fetch();
            if (is_array($row)) {
                $storedType = is_string($row['type'] ?? null) && $row['type'] !== '' ? $row['type'] : $type;
                $value      = is_string($row['value'] ?? null) ? $row['value'] : null;
                $decoded    = ipam_setting_decode($value, $storedType, $fallback);
                ipam_setting_cache_storage($key, false, $decoded, true);
                return $decoded;
            }
        }
    } catch (\Throwable $e) {
        error_log("ipam_setting: read failed for key {$key}: " . $e->getMessage());
    }

    $config = $GLOBALS['config'] ?? null;
    if (is_array($config) && $def !== null) {
        $configKey = $def['config_key'] ?? null;
        if ($configKey !== null && (is_string($configKey) || is_array($configKey))) {
            $cfgVal = ipam_setting_config_fallback($config, $configKey);
            if ($cfgVal !== null) {
                ipam_setting_cache_storage($key, false, $cfgVal, true);
                return $cfgVal;
            }
        }
    }

    ipam_setting_cache_storage($key, false, $fallback, true);
    return $fallback;
}

/**
 * Write a setting. Infers type from $value unless the registry defines one.
 * Produces a `setting.update` audit entry with old/new values (masked for
 * sensitive keys). Invalidates the per-request cache for the key.
 */
function ipam_setting_set(PDO $db, string $key, mixed $value, ?int $userId = null): void
{
    $definitions = ipam_setting_definitions();
    $def         = $definitions[$key] ?? null;
    $type        = (is_array($def) && is_string($def['type'] ?? null) && $def['type'] !== '')
        ? $def['type']
        : ipam_setting_infer_type($value);
    $sensitive   = is_array($def) && !empty($def['sensitive']);

    $encoded = ipam_setting_encode($value, $type);

    $oldRaw = null;
    $oldType = $type;
    $st = $db->prepare("SELECT value, type FROM settings WHERE `key` = :k");
    $st->execute([':k' => $key]);
    $prev = $st->fetch();
    if (is_array($prev)) {
        $oldRaw  = is_string($prev['value'] ?? null) ? $prev['value'] : null;
        $oldType = is_string($prev['type'] ?? null) && $prev['type'] !== '' ? $prev['type'] : $type;
    }

    // #379: route through the dialect so v2.10.0 / v2.11.0 swap upsert and
    // timestamp idioms without touching this call site. The dialect's
    // upsert() returns the ON CONFLICT...DO UPDATE fragment for the engine.
    $d = ipam_dialect();
    $upsertClause = $d->upsert('settings', ['key'], ['value', 'type', 'updated_at', 'updated_by']);
    $up = $db->prepare(
        "INSERT INTO settings (`key`, value, type, updated_at, updated_by)
         VALUES (:k, :v, :t, {$d->now()}, :u)
         $upsertClause"
    );
    $up->execute([
        ':k' => $key,
        ':v' => $encoded,
        ':t' => $type,
        ':u' => $userId,
    ]);

    $details = [
        'key' => $key,
        'old' => $sensitive ? '***' : ipam_setting_decode($oldRaw, $oldType, null),
        'new' => $sensitive ? '***' : ipam_setting_decode($encoded, $type, null),
    ];
    $encodedDetails = json_encode($details);
    audit($db, 'setting.update', 'setting', null, is_string($encodedDetails) ? $encodedDetails : $key);

    // Bust the per-request cache by forcing a re-read on next call.
    // (ipam_setting() uses a function-level static, so we can't reach into it
    // directly; instead the next read will use the new DB row because the
    // cache starts empty on each request and callers typically read after
    // writing in different requests.)
    ipam_setting_cache_bust($key);
}

/**
 * Bust the per-request cache for ipam_setting(). Pass a key to clear a single
 * entry, or omit to clear all entries. Also exposed so tests can reset state
 * between assertions.
 */
function ipam_setting_cache_bust(?string $key = null): void
{
    ipam_setting_cache_storage($key, true);
}

/**
 * Internal cache backing store for ipam_setting(). Keeps the static array
 * outside ipam_setting()'s own scope so ipam_setting_set() and
 * ipam_setting_cache_bust() can invalidate entries. Not intended for direct
 * use by application code.
 *
 * @internal
 */
function ipam_setting_cache_storage(
    ?string $key = null,
    bool $reset = false,
    mixed $setValue = null,
    bool $doSet = false
): mixed {
    static $cache = [];
    if ($reset) {
        if ($key === null) {
            $cache = [];
        } else {
            unset($cache[$key]);
        }
        return null;
    }
    if ($doSet && $key !== null) {
        $cache[$key] = $setValue;
        return $setValue;
    }
    if ($key !== null && array_key_exists($key, $cache)) {
        return $cache[$key];
    }
    return '__IPAM_SETTING_MISS__';
}

/**
 * @return array<string, mixed> All known setting keys mapped to their effective
 *                              values via ipam_setting(). Used by the admin UI.
 */
function ipam_setting_all(): array
{
    $out = [];
    foreach (array_keys(ipam_setting_definitions()) as $key) {
        $out[$key] = ipam_setting($key);
    }
    return $out;
}

/**
 * Resolve where a setting's current value is coming from: 'db', 'config', or
 * 'default'. Used to render the source badge on settings.php. Queries the
 * database directly rather than through the cached helper so the badge
 * reflects ground truth.
 *
 * @return 'db'|'config'|'default'
 */
function ipam_setting_source(PDO $db, string $key): string
{
    try {
        $st = $db->prepare("SELECT 1 FROM settings WHERE `key` = :k");
        $st->execute([':k' => $key]);
        if ($st->fetchColumn() !== false) return 'db';
    } catch (\Throwable) {
        // Fall through to config/default classification.
    }

    $definitions = ipam_setting_definitions();
    $def = $definitions[$key] ?? null;
    $config = $GLOBALS['config'] ?? null;
    if (is_array($config) && $def !== null) {
        $cfgKey = $def['config_key'] ?? null;
        if ($cfgKey !== null && (is_string($cfgKey) || is_array($cfgKey))) {
            if (ipam_setting_config_fallback($config, $cfgKey) !== null) return 'config';
        }
    }
    return 'default';
}

/**
 * Return the list of registered settings that are still being served from
 * $config (config.php) instead of the database. Drives the v2.7.0 deprecation
 * banner in settings.php, the init.php boot-time log warning, and the
 * dashboard admin card that nudges admins to migrate before v3.0.0 removes
 * the fallback.
 *
 * A key is considered deprecated iff **all** of these hold:
 *   - its registry definition exists (bootstrap-only keys like db_driver
 *     are not in the registry so they are never flagged);
 *   - no row exists in the `settings` table for that key;
 *   - the key's `config_key` path resolves to a non-null value in
 *     $GLOBALS['config'];
 *   - that value differs from the registry `default`.
 *
 * The last condition keeps a pristine install with a seeded default
 * config.php from lighting up the banner for every single key — we only
 * surface what the admin has actually customised.
 *
 * On any DB error the helper returns [] (fail-quiet) so the boot path and
 * the dashboard render never break because of this advisory feature.
 *
 * @return list<array{key: string, config_path: string, current: mixed}>
 */
function ipam_setting_deprecated_keys(): array
{
    $db = $GLOBALS['db'] ?? null;
    if (!($db instanceof PDO)) return [];

    try {
        // `key` must be backtick-quoted — it's a MySQL reserved word. SQLite
        // also accepts backticks as identifier delimiters so the same SQL
        // runs on both engines. Without the quotes, MySQL would throw a
        // syntax error that the catch below would silently swallow,
        // returning [] and hiding every deprecation from the UI banner.
        $st   = $db->query("SELECT `key` FROM settings");
        $rows = $st !== false ? $st->fetchAll(PDO::FETCH_COLUMN) : [];
    } catch (\Throwable) {
        return [];
    }
    $inDb = [];
    foreach ($rows as $k) {
        if (is_string($k)) $inDb[$k] = true;
    }

    $config = $GLOBALS['config'] ?? null;
    if (!is_array($config)) return [];

    $out  = [];
    $defs = ipam_setting_definitions();
    foreach ($defs as $key => $def) {
        if (isset($inDb[$key])) continue;
        // CodeRabbit second sweep on PR #450: skip keys that are flagged
        // deprecated in the registry. Otherwise the deprecation banner would
        // offer an "Import to database" button that silently writes a
        // deprecated value (e.g. alert.email) into the settings table, where
        // the save and render loops would then ignore it forever.
        if (!empty($def['deprecated'])) continue;
        $configKey = $def['config_key'] ?? null;
        if ($configKey === null || (!is_string($configKey) && !is_array($configKey))) continue;

        $current = ipam_setting_config_fallback($config, $configKey);
        if ($current === null) continue;

        // Skip values that match the registry default — a config that still
        // holds the shipped default is not "customised". Loose compares keep
        // '0' vs 0 vs false and '0.5' vs 0.5 from producing spurious banner
        // entries. recaptcha_enterprise.score_threshold is the concrete
        // reason the string branch normalises through (string) casts: the
        // registry default is '0.5' while config_defaults keeps 0.5 (float).
        $default = $def['default'] ?? null;
        $type = is_string($def['type'] ?? null) ? $def['type'] : 'string';
        if ($type === 'bool' && (bool)$current === (bool)$default) continue;
        if ($type === 'int'  && is_numeric($current) && is_numeric($default) && (int)$current === (int)$default) continue;
        if ($type === 'string' && is_scalar($current) && is_scalar($default) && (string)$current === (string)$default) continue;
        if ($type === 'json'   && $current === $default) continue;

        if (is_array($configKey)) {
            $segments   = [];
            foreach ($configKey as $seg) $segments[] = to_str($seg);
            $configPath = implode('.', $segments);
        } else {
            $configPath = $configKey;
        }

        $out[] = [
            'key'         => $key,
            'config_path' => $configPath,
            'current'     => $current,
        ];
    }
    return $out;
}

/**
 * Resolve a setting definition's `options` entry to a `[value => label]` map,
 * or null when the setting is free-form. Supports three registry shapes:
 *
 *   - associative array: returned as-is
 *   - callable: invoked, result must be an associative array
 *   - sentinel string '@timezone': PHP timezone identifiers
 *
 * Unknown sentinels return null so the caller falls back to free-text
 * rendering rather than silently accepting any value.
 *
 * @param array<string, mixed> $def
 * @return array<string, string>|null
 */
function ipam_setting_options(array $def): ?array
{
    if (!array_key_exists('options', $def)) return null;
    $raw = $def['options'];

    if (is_callable($raw)) {
        $resolved = $raw();
    } elseif ($raw === '@timezone') {
        $ids = DateTimeZone::listIdentifiers();
        $resolved = array_combine($ids, $ids);
    } elseif (is_array($raw)) {
        $resolved = $raw;
    } else {
        return null;
    }

    if (!is_array($resolved)) return null;

    // Normalise to string => string for consistent rendering and strict
    // validation with array_key_exists() on the persisted value.
    $out = [];
    foreach ($resolved as $value => $label) {
        $out[(string)$value] = is_scalar($label) ? (string)$label : (string)$value;
    }
    return $out;
}

/* ---------------- History ---------------- */

/**
 * @param array<string, mixed>|null $before
 * @param array<string, mixed>|null $after
 */
function history_log_address(PDO $db, string $action, int $subnetId, string $ip, ?int $addressId, ?array $before, ?array $after): void
{
    $u = current_user();
    $st = $db->prepare("
        INSERT INTO address_history
          (address_id, subnet_id, ip, action, user_id, username, client_ip, user_agent, before_json, after_json)
        VALUES
          (:aid, :sid, :ip, :ac, :uid, :un, :cip, :ua, :bj, :aj)
    ");
    $st->execute([
        ':aid' => $addressId,
        ':sid' => $subnetId,
        ':ip'  => $ip,
        ':ac'  => $action,
        ':uid' => $u['id'] ?: null,
        ':un'  => $u['username'] ?: null,
        ':cip' => client_ip() ?: null,
        ':ua'  => to_str($_SERVER['HTTP_USER_AGENT'] ?? ''),
        ':bj'  => $before ? json_encode($before, JSON_UNESCAPED_SLASHES) : null,
        ':aj'  => $after ? json_encode($after, JSON_UNESCAPED_SLASHES) : null,
    ]);
}

/* ---------------- Migrations ---------------- */

function ensure_migrations_table(PDO $db): void
{
    $d = ipam_dialect();
    // version has a UNIQUE constraint so it must use the indexed text type
    // (VARCHAR on MySQL, TEXT elsewhere).
    $db->exec("CREATE TABLE IF NOT EXISTS schema_migrations (
        id " . $d->autoincrement() . ",
        version " . $d->indexed_text_type() . " NOT NULL UNIQUE,
        applied_at TEXT NOT NULL DEFAULT (" . $d->now() . ")
    )");
}

/** @return list<string> */
function applied_migrations(PDO $db): array
{
    $st = $db->prepare("SELECT version FROM schema_migrations");
    $st->execute();
    /** @var list<array<string, mixed>> $rows */
    $rows = $st->fetchAll();
    return array_map(fn(array $r): string => to_str($r['version']), $rows);
}

/** @return list<string> */
function apply_migrations(PDO $db): array
{
    ensure_migrations_table($db);
    require_once __DIR__ . '/migrations.php';

    $migs = ipam_migrations();
    ksort($migs, SORT_NATURAL);

    $done = array_flip(applied_migrations($db));
    $appliedNow = [];

    foreach ($migs as $ver => $fn) {
        if (isset($done[$ver])) continue;

        // SQLite DDL (DROP TABLE, ALTER TABLE) needs a full exclusive lock —
        // even readers block it. busy_timeout only retries SQLITE_BUSY (5),
        // not SQLITE_LOCKED (6), so we retry at the PHP level: ROLLBACK the
        // transaction, sleep 1 s, and try again. SQLite DDL is fully
        // transactional so ROLLBACK cleanly undoes any partial work.
        $lastErr  = null;
        $applied  = false;
        // Route FK toggling through the dialect so non-SQLite engines (MySQL
        // via SET FOREIGN_KEY_CHECKS, Postgres via null / deferred constraints)
        // get the engine-appropriate statement. Null means the engine has no
        // per-connection FK toggle and we rely on other mechanisms instead.
        $dialect = ipam_dialect();
        $fkOff   = $dialect->pragma_foreign_keys(false);
        $fkOn    = $dialect->pragma_foreign_keys(true);
        $toggleFk = static function (PDO $db, ?string $stmt): void {
            if ($stmt !== null) {
                $db->exec($stmt);
            }
        };
        for ($attempt = 0; $attempt < 60 && !$applied; $attempt++) {
            if ($attempt > 0) {
                sleep(1);
            }

            // FK enforcement must be toggled outside the transaction. On
            // SQLite, PRAGMA foreign_keys cannot be changed inside BEGIN; and
            // with FK ON, DROP TABLE triggers an implicit row-by-row DELETE
            // that cascades ON DELETE CASCADE children (addresses,
            // subnet_tags, etc.), wiping all data. Disabling around each
            // migration prevents the cascade. FK enforcement is restored
            // unconditionally in every exit path.
            $toggleFk($db, $fkOff);

            try {
                // SQLite's `BEGIN EXCLUSIVE` acquires a table-level write
                // lock up front, which is required around DDL to avoid
                // SQLITE_LOCKED mid-migration. MySQL / Postgres don't need
                // (and don't accept) the EXCLUSIVE modifier — their DDL
                // acquires its own metadata locks. Fall back to a plain
                // transaction on non-SQLite engines.
                if ($dialect->driver_name() === 'sqlite') {
                    $db->exec("BEGIN EXCLUSIVE");
                } else {
                    $db->exec("START TRANSACTION");
                }
            } catch (Throwable $e) {
                $toggleFk($db, $fkOn);
                $lastErr = $e;
                if (stripos($e->getMessage(), 'locked') !== false || stripos($e->getMessage(), 'busy') !== false) {
                    continue;
                }
                throw $e;
            }

            try {
                $fn($db);
                $st = $db->prepare("INSERT INTO schema_migrations (version) VALUES (:v)");
                $st->execute([':v' => $ver]);
                $db->exec("COMMIT");
                $applied = true;
                $appliedNow[] = $ver;
                $lastErr = null;
            } catch (Throwable $e) {
                try { $db->exec("ROLLBACK"); } catch (Throwable) {}
                $toggleFk($db, $fkOn);
                $lastErr = $e;
                if (stripos($e->getMessage(), 'locked') !== false || stripos($e->getMessage(), 'busy') !== false) {
                    continue;
                }
                throw $e;
            }
            $toggleFk($db, $fkOn);
        }

        if ($lastErr !== null) {
            throw $lastErr;
        }
    }

    return $appliedNow;
}

/* ---------------- Config auto-population ---------------- */

/**
 * Returns the canonical defaults map for all config keys that should exist in
 * config.php. Each entry: ['default' => mixed, 'comment' => string].
 * Only top-level keys are tracked; nested sub-keys are managed per-key.
 */
/** @return array<string, array{default: mixed, comment: string}> */
function ipam_config_defaults(): array
{
    return [
        'db_path' => [
            'default' => null, // path-dependent, skip auto-append
            'comment' => '',
        ],
        'session_name' => ['default' => null, 'comment' => ''],
        'base_url'     => [
            'default' => null,
            'comment' => "Canonical HTTPS base URL (e.g. 'https://ipam.example.com'). "
                       . "Used for the HTTP→HTTPS redirect. If null, falls back to HTTP_HOST.",
        ],
        'proxy_trust'  => ['default' => null, 'comment' => ''],
        'app_name' => [
            'default' => 'Simple PHP IPAM',
            'comment' => "Application display name shown in the browser tab, nav bar, and login page. Default: 'Simple PHP IPAM'.",
        ],
        'timezone' => [
            'default' => 'UTC',
            'comment' => "Timezone for displaying timestamps in the UI. Use a PHP timezone identifier, "
                       . "e.g. 'America/Toronto', 'Europe/London', 'UTC'. "
                       . "All timestamps are stored in UTC; this setting converts them for display only.",
        ],
        'bootstrap_admin' => ['default' => null, 'comment' => ''],
        'session_idle_seconds' => ['default' => null, 'comment' => ''],
        'login_max_attempts'   => ['default' => null, 'comment' => ''],
        'login_lockout_seconds'=> ['default' => null, 'comment' => ''],
        'api_max_attempts' => [
            'default' => 20,
            'comment' => 'Max failed API key attempts per IP before lockout.',
        ],
        'api_lockout_seconds' => [
            'default' => 300,
            'comment' => 'Duration (seconds) of API key lockout after too many failed attempts.',
        ],
        'api_bulk_limit' => [
            'default' => 500,
            'comment' => 'Maximum number of records per bulk API write request (POST ?resource=addresses&bulk=1).',
        ],
        'recaptcha_enterprise' => [
            'default' => [
                'enabled'          => false,
                'project_id'       => '',
                'api_key'          => '',
                'expected_action'  => 'login',
                'score_threshold'  => 0.5,
            ],
            'comment' => "reCAPTCHA Enterprise (v3). Set login_protection.method = 'recaptcha' and enable this block to use the Enterprise API for backend verification. project_id: GCP project ID. api_key: server-side API key. expected_action: action name from widget. score_threshold: 0.0–1.0 (default 0.5).",
        ],
        'import_csv_max_mb'    => ['default' => null, 'comment' => ''],
        // v2.9.2: auto-populate import_sql_max_mb on upgrade. The key was
        // missing from the registry, so ipam_config_sync() silently skipped
        // it on upgrades from older releases, and db_tools.php's unguarded
        // read produced an E_WARNING cascade when the key was absent.
        'import_sql_max_mb' => [
            'default' => 200,
            'comment' => 'Maximum SQL import file size (MB). App-level soft cap '
                . 'enforced by db_tools.php. If you raise it above .htaccess '
                . 'post_max_size / upload_max_filesize, raise those values too.',
        ],
        'tmp_cleanup_ttl_seconds' => ['default' => null, 'comment' => ''],
        'audit_log_retention_days' => [
            'default' => 0,
            'comment' => 'Audit log retention (days). Entries older than this are pruned during housekeeping. 0 = keep forever.',
        ],
        'address_history_retention_days' => [
            'default' => 0,
            'comment' => 'Address history retention (days). Entries older than this are pruned during housekeeping. 0 = keep forever.',
        ],
        'housekeeping' => ['default' => null, 'comment' => ''],
        'utilization_warn'     => ['default' => null, 'comment' => ''],
        'utilization_critical' => ['default' => null, 'comment' => ''],
        'update_check' => [
            'default' => [
                'enabled'           => true,
                'ttl_seconds'       => 86400,
                'notify_prerelease' => false,
            ],
            'comment' => 'Update check: fetches releases from GitHub and shows a banner when a newer version is available.',
        ],
        'backup' => [
            'default' => [
                'enabled'   => false,
                'frequency' => 'daily',
                'retention' => 7,
                'dir'       => '',
            ],
            'comment' => "Automatic database backups. frequency: 'daily' | 'weekly'. retention: keep last N backups.",
        ],
        'oidc' => [
            'default' => [
                'enabled'                  => false,
                'display_name'             => 'SSO',
                'client_id'                => '',
                'client_secret'            => '',
                'discovery_url'            => '',
                'redirect_uri'             => '',
                'scopes'                   => 'openid email profile',
                'auto_link'                => false,
                'auto_provision'           => false,
                'default_role'             => 'readonly',
                'disable_local_login'      => false,
                'hide_emergency_link'      => false,
                'disable_emergency_bypass' => false,
            ],
            'comment' => 'OIDC SSO configuration. See docs/oidc.md for full details.',
        ],
        'password_policy' => [
            'default' => [
                'min_length'            => 12,
                'require_uppercase'     => false,
                'require_lowercase'     => false,
                'require_number'        => false,
                'require_symbol'        => false,
                'max_password_age_days' => 0,
            ],
            'comment' => "Password complexity and rotation policy. min_length: minimum chars. require_*: enforce character classes. max_password_age_days: 0 = never expires.",
        ],
        'login_protection' => [
            'default' => [
                'method'      => null,
                'site_key'    => '',
                'secret_key'  => '',
                'min_seconds' => 3,
                'version'     => 2,
            ],
            'comment' => "Login form bot protection. method: null | 'honeypot' | 'time_check' | 'turnstile' | 'hcaptcha' | 'recaptcha' | 'friendly_captcha'. site_key/secret_key required for widget methods.",
        ],
        'demo_mode' => [
            'default' => [
                'enabled'    => false,
                'gate'       => null,
                'site_key'   => '',
                'secret_key' => '',
            ],
            'comment' => "Demo mode: only demo/demo can log in; data resets nightly. gate: optional pre-login bot challenge (null | 'honeypot' | 'turnstile' | 'hcaptcha' | 'recaptcha' | 'friendly_captcha').",
        ],
    ];
}

/**
 * Format a PHP value as clean source code with array [] syntax.
 */
function ipam_php_export(mixed $val, int $indent = 1): string
{
    if (is_null($val))    return 'null';
    if (is_bool($val))    return $val ? 'true' : 'false';
    if (is_int($val))     return (string)$val;
    if (is_float($val))   return rtrim(number_format($val, 10, '.', ''), '0') ?: '0.0';
    if (is_string($val))  return "'" . addcslashes($val, "'\\") . "'";

    if (is_array($val)) {
        if (count($val) === 0) return '[]';
        $pad = str_repeat('    ', $indent);
        $outerPad = str_repeat('    ', $indent - 1);
        $isList = array_keys($val) === range(0, count($val) - 1);
        $out = "[\n";
        foreach ($val as $k => $v) {
            $keyStr = $isList ? '' : "'" . addcslashes((string)$k, "'\\") . "' => ";
            $out .= $pad . $keyStr . ipam_php_export($v, $indent + 1) . ",\n";
        }
        $out .= $outerPad . ']';
        return $out;
    }

    return var_export($val, true);
}

/**
 * Check config.php for missing top-level keys and missing sub-keys within
 * existing nested blocks, and append them with their defaults.
 *
 * Returns list of key names added (top-level as 'key', nested as 'key.subkey').
 * Only keys whose default is not null are auto-appended.
 * The 'bootstrap_admin' block is never deep-merged (admin sets it intentionally).
 */
/**
 * @param array<string, mixed> $loaded
 * @return list<string>
 */
function ipam_config_sync(string $configPath, array $loaded): array
{
    $defaults = ipam_config_defaults();
    $added    = [];

    foreach ($defaults as $key => $meta) {
        if ($meta['default'] === null) continue;

        if (!array_key_exists($key, $loaded)) {
            // --- Top-level key missing: append whole block ---
            $content = @file_get_contents($configPath);
            if ($content === false) break;
            if (!preg_match('/\n\];\s*$/', $content)) break;

            $comment  = to_str($meta['comment']);
            $valuePhp = ipam_php_export($meta['default'], 2);
            $block    = '';
            if ($comment !== '') $block .= "\n    // " . $comment;
            $block .= "\n    '" . addcslashes($key, "'\\") . "' => " . $valuePhp . ",\n";

            $content = preg_replace('/\n\];\s*$/', $block . "\n];", $content);
            if ($content === null) break;
            if (@file_put_contents($configPath, $content) !== false) {
                $added[] = $key;
            } else {
                $_SESSION['config_unwritable'] = true; // #119: surface in page_header()
                break;
            }
        } elseif ($key !== 'bootstrap_admin'
               && is_array($meta['default'])
               && is_array($loaded[$key])) {
            // --- Nested block exists: deep-merge missing sub-keys ---
            $missingSubKeys = array_diff_key($meta['default'], $loaded[$key]);
            foreach ($missingSubKeys as $subKey => $subDefault) {
                $content = @file_get_contents($configPath);
                if ($content === false) break 2;

                $escapedKey = preg_quote($key, '/');
                $subValuePhp = ipam_php_export($subDefault, 3);
                $newLine = "\n        '" . addcslashes((string)$subKey, "'\\") . "' => " . $subValuePhp . ",";

                // Match '    'key' => [  ...content...  \n    ],'
                $pattern = '/(\n    \'' . $escapedKey . '\'\s*=>\s*\[)(.*?)(\n    \],)/s';
                if (!preg_match($pattern, $content)) break;

                $content = preg_replace_callback($pattern, static function (array $m) use ($newLine): string {
                    return $m[1] . $m[2] . $newLine . $m[3];
                }, $content);

                if ($content === null) break;
                if (@file_put_contents($configPath, $content) !== false) {
                    $added[] = $key . '.' . $subKey;
                } else {
                    $_SESSION['config_unwritable'] = true; // #119: surface in page_header()
                    break 2;
                }
            }
        }
    }

    return $added;
}

/**
 * Validate loaded config values and return a list of human-readable warning strings.
 * Logs each warning to the PHP error log as well.
 *
 * @param IpamConfig $config
 * @return list<string>
 */
function ipam_validate_config(array $config): array
{
    $warnings = [];

    $sessionIdle = to_int($config['session_idle_seconds']);
    if ($sessionIdle < 60) {
        $warnings[] = "session_idle_seconds is {$sessionIdle}; minimum is 60.";
    }

    $loginMax = to_int($config['login_max_attempts']);
    if ($loginMax < 1) {
        $warnings[] = "login_max_attempts is {$loginMax}; minimum is 1.";
    }

    $lockout = to_int($config['login_lockout_seconds']);
    if ($lockout < 1) {
        $warnings[] = "login_lockout_seconds is {$lockout}; minimum is 1.";
    }

    $auditRetention = to_int($config['audit_log_retention_days']);
    if ($auditRetention < 0) {
        $warnings[] = "audit_log_retention_days is {$auditRetention}; must be 0 or greater.";
    }

    $backup = $config['backup'];
    if (!empty($backup['enabled'])) {
        $retention = to_int($backup['retention']);
        if ($retention < 1) {
            $warnings[] = "backup.retention is {$retention}; minimum is 1.";
        }
    }

    foreach ($warnings as $w) {
        error_log("Simple PHP IPAM config warning: {$w}");
    }

    return $warnings;
}

/* ---------------- Housekeeping ---------------- */

function housekeeping_state_path(): string
{
    return __DIR__ . '/data/housekeeping.json';
}

/**
 * @phpstan-impure
 * @param IpamConfig $config
 */
function housekeeping_should_run(array $config): bool
{
    $hk = $config['housekeeping'];
    if (empty($hk['enabled'])) return false;

    $interval = to_int($hk['interval_seconds']);
    if ($interval < 3600) $interval = 3600;

    $path = housekeeping_state_path();
    if (!is_file($path)) return true;

    $last = @filemtime($path);
    if ($last === false) return true;

    return (time() - $last) >= $interval;
}

function housekeeping_mark_ran(): void
{
    $path = housekeeping_state_path();
    $dir = dirname($path);
    if (!is_dir($dir)) mkdir($dir, 0700, true);

    @file_put_contents($path, json_encode(['last_run' => time()], JSON_PRETTY_PRINT));
    @chmod($path, 0600);
}

function prune_audit_log(PDO $db, int $retentionDays): int
{
    if ($retentionDays <= 0) return 0;
    $cutoff = date('Y-m-d H:i:s', (int)strtotime("-{$retentionDays} days"));

    // Retention routine must DELETE rows without ever leaving the
    // append-only guarantee observable-violated. v2.10.0 #502 post-review
    // fix: previously this dropped triggers, DELETEd, then recreated the
    // triggers — which exposed a race window where other connections
    // could UPDATE/DELETE audit_log. Two per-engine strategies now close
    // the window without needing a drop/recreate cycle:
    //
    //   SQLite  — wrap the DELETE in BEGIN IMMEDIATE / COMMIT. SQLite DDL
    //             is transactional AND BEGIN IMMEDIATE holds a reserved
    //             write lock the entire time, so no other writer can
    //             touch audit_log. The SQLite RAISE(ABORT) triggers DO
    //             fire on DELETE, so we still have to drop+recreate on
    //             SQLite — but now inside the reserved-lock transaction,
    //             which is atomic from every other connection's point of
    //             view.
    //
    //   MySQL   — set @ipam_bypass_append_only = 1 at session scope. The
    //             MysqlDialect trigger bodies wrap SIGNAL in an IF block
    //             gated on this variable (v2.10.0 #502 change to
    //             MysqlDialect::append_only_trigger). Session variables
    //             are per-connection so the bypass never leaks to other
    //             connections — their SIGNAL continues to fire
    //             unconditionally. DELETE proceeds on this connection,
    //             every other write is still blocked. No drop/recreate
    //             needed; the triggers stay in place the entire time.
    //
    //   Postgres (v2.11.0) — TBD; pg_advisory_xact_lock() or similar.
    //
    // Error paths always attempt to restore a safe state: clear the
    // MySQL session variable, recreate SQLite triggers via
    // ensure_audit_log_table() as a fallback.
    $driver = ipam_dialect()->driver_name();
    try {
        if ($driver === 'sqlite') {
            $db->exec("BEGIN IMMEDIATE");
            $db->exec("DROP TRIGGER IF EXISTS audit_log_no_update");
            $db->exec("DROP TRIGGER IF EXISTS audit_log_no_delete");

            $st = $db->prepare("DELETE FROM audit_log WHERE created_at < :cutoff");
            $st->execute([':cutoff' => $cutoff]);
            $pruned = $st->rowCount();

            ensure_audit_log_table($db);
            $db->exec("COMMIT");
        } elseif ($driver === 'mysql') {
            $db->exec("SET @ipam_bypass_append_only = 1");

            $st = $db->prepare("DELETE FROM audit_log WHERE created_at < :cutoff");
            $st->execute([':cutoff' => $cutoff]);
            $pruned = $st->rowCount();

            $db->exec("SET @ipam_bypass_append_only = NULL");
        } else {
            // Unknown driver — refuse rather than expose a partial write
            // path. Future engines add their own branch here.
            throw new \RuntimeException("prune_audit_log: unsupported driver '$driver'");
        }

        return $pruned;
    } catch (Throwable $e) {
        // Best-effort restore to a safe state. Each branch is independently
        // guarded because ROLLBACK / UNSET may also throw.
        if ($driver === 'sqlite') {
            try { $db->exec("ROLLBACK"); } catch (Throwable) {}
            try { ensure_audit_log_table($db); } catch (Throwable) {}
        } elseif ($driver === 'mysql') {
            try { $db->exec("SET @ipam_bypass_append_only = NULL"); } catch (Throwable) {}
        }
        error_log('audit_log prune failed: ' . $e->getMessage());
        return 0;
    }
}

function prune_address_history(PDO $db, int $retentionDays): int
{
    if ($retentionDays <= 0) return 0;
    $cutoff = date('Y-m-d H:i:s', (int)strtotime("-{$retentionDays} days"));
    $st = $db->prepare("DELETE FROM address_history WHERE created_at < :cutoff");
    $st->execute([':cutoff' => $cutoff]);
    return $st->rowCount();
}

/**
 * Send email utilization alerts for subnets that have crossed warn/crit thresholds.
 * Deduplicates sends using the alert_state table (max one alert per subnet+level per 24 h).
 * Auto-clears alert_state rows when utilization drops back below the threshold.
 *
 * @param IpamConfig $config Unused since v2.7.0 — thresholds and the
 *                           recipient now flow through ipam_setting().
 */
/**
 * #443: resolve the configured `alert.recipient_user_ids` list to a list of
 * current email addresses. Inactive users and users whose email has been
 * cleared since the recipient was selected drop out automatically — no need
 * to re-save the settings page when staffing changes.
 *
 * @return list<string>
 */
function ipam_resolve_alert_recipients(PDO $db): array
{
    $ids = ipam_setting('alert.recipient_user_ids', []);
    if (!is_array($ids) || $ids === []) return [];
    $intIds = array_values(array_unique(array_map(fn($v) => (int)to_str($v), $ids)));
    $intIds = array_values(array_filter($intIds, fn($i) => $i > 0));
    if ($intIds === []) return [];

    $placeholders = implode(',', array_fill(0, count($intIds), '?'));
    $st = $db->prepare(
        "SELECT email FROM users
         WHERE id IN ($placeholders)
           AND is_active = 1
           AND email IS NOT NULL
           AND email != ''
         ORDER BY id"
    );
    $st->execute($intIds);
    /** @var list<string> $out */
    $out = [];
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $email) {
        $email = trim(to_str($email));
        if ($email !== '') $out[] = $email;
    }
    return $out;
}

/** @param IpamConfig $config */
function check_utilization_alerts(PDO $db, array $config): void
{
    unset($config);
    $recipients = ipam_resolve_alert_recipients($db);
    if ($recipients === []) return;

    $warnPct = to_int(ipam_setting('alert.util_warn_pct'));
    $critPct = to_int(ipam_setting('alert.util_crit_pct'));
    $appName = to_str(ipam_setting('branding.site_name'));

    // Compute direct address counts per subnet (used+reserved)
    $rows = ($db->query("
        SELECT s.id, s.cidr, s.prefix,
               SUM(CASE WHEN a.status IN ('used','reserved') THEN 1 ELSE 0 END) AS assigned
        FROM subnets s
        LEFT JOIN addresses a ON a.subnet_id = s.id
        WHERE s.ip_version = 4
        GROUP BY s.id
    ") ?: throw new \RuntimeException('Query failed'))->fetchAll();

    // Load existing alert state
    $stateRows = ($db->query("SELECT subnet_id, level, last_alerted_at FROM alert_state")
        ?: throw new \RuntimeException('Query failed'))->fetchAll();
    $alertState = [];
    foreach ($stateRows as $sr) {
        $alertState[to_int($sr['subnet_id'])][to_str($sr['level'])] = to_str($sr['last_alerted_at']);
    }

    $cooldownSeconds = 86400; // 24 hours

    foreach ($rows as $row) {
        $sid    = to_int($row['id']);
        $cidr   = to_str($row['cidr']);
        $prefix = to_int($row['prefix']);
        $assigned = to_int($row['assigned']);

        $assignable = ipv4_assignable_count($prefix);
        if ($assignable <= 0) continue;

        $pct = (int)round($assigned / $assignable * 100);

        // Determine active levels
        $levels = [];
        if ($pct >= $critPct) $levels[] = 'crit';
        elseif ($pct >= $warnPct) $levels[] = 'warn';

        // Auto-clear stale alert_state rows when below thresholds
        foreach (['warn', 'crit'] as $lvl) {
            if (isset($alertState[$sid][$lvl]) && !in_array($lvl, $levels, true)) {
                $db->prepare("DELETE FROM alert_state WHERE subnet_id = :sid AND level = :lvl")
                   ->execute([':sid' => $sid, ':lvl' => $lvl]);
                unset($alertState[$sid][$lvl]);
            }
        }

        foreach ($levels as $lvl) {
            $lastAlerted = $alertState[$sid][$lvl] ?? null;
            if ($lastAlerted !== null) {
                $lastTs = strtotime($lastAlerted);
                if ($lastTs !== false && (time() - $lastTs) < $cooldownSeconds) continue;
            }

            $levelLabel = $lvl === 'crit' ? 'CRITICAL' : 'WARNING';
            $subject    = "[{$appName}] {$levelLabel}: subnet {$cidr} at {$pct}% utilization";
            $body       = "{$levelLabel}: Subnet {$cidr} has reached {$pct}% utilization.\n"
                        . "Assigned: {$assigned} / Assignable: {$assignable}\n\n"
                        . "-- {$appName}";
            $safeSubject = preg_replace('/[\r\n]/', '', $subject) ?? '';

            // #443: loop-per-recipient delivery. Best-effort: a bad address
            // for one recipient does not block delivery to the others, and
            // each send produces its own audit row so failures are debuggable.
            foreach ($recipients as $recipient) {
                $safeEmail = preg_replace('/[\r\n]/', '', $recipient) ?? '';
                @mail($safeEmail, $safeSubject, $body);
                audit($db, 'alert.send', 'subnet', $sid, "level={$lvl} pct={$pct} email={$safeEmail}");
            }

            $now = date('Y-m-d H:i:s');
            // #379: route through the dialect's upsert() so v2.10.0+ can
            // swap to ON DUPLICATE KEY UPDATE / ON CONFLICT DO UPDATE
            // without touching this call site.
            $alertUpsert = ipam_dialect()->upsert('alert_state', ['subnet_id', 'level'], ['last_alerted_at']);
            $db->prepare(
                "INSERT INTO alert_state (subnet_id, level, last_alerted_at)
                 VALUES (:sid, :lvl, :now)
                 $alertUpsert"
            )->execute([':sid' => $sid, ':lvl' => $lvl, ':now' => $now]);
            $alertState[$sid][$lvl] = $now;
        }
    }
}

/**
 * Run utilization alert check if the alert interval has elapsed.
 * Uses a dedicated state file so it can fire more frequently than main housekeeping.
 *
 * @param IpamConfig $config Unused since v2.7.0 — kept for signature stability.
 */
function alerts_check_if_due(array $config, PDO $db): void
{
    if (ipam_resolve_alert_recipients($db) === []) return;

    $interval = to_int(ipam_setting('alert.interval_seconds'));
    if ($interval < 60) $interval = 60;

    $statePath = __DIR__ . '/data/alerts_last_run.txt';
    if (is_file($statePath)) {
        $last = (int)@file_get_contents($statePath);
        if ((time() - $last) < $interval) return;
    }

    check_utilization_alerts($db, $config);

    @file_put_contents($statePath, (string)time());
    @chmod($statePath, 0600);
}

/** @param IpamConfig $config */
function run_housekeeping_if_due(array $config, ?PDO $db = null): void
{
    if (!housekeeping_should_run($config)) return;

    $lockPath = __DIR__ . '/data/housekeeping.lock';
    $lock = @fopen($lockPath, 'c');
    if (!$lock) return;

    if (!@flock($lock, LOCK_EX | LOCK_NB)) {
        fclose($lock);
        return;
    }

    try {
        if (!housekeeping_should_run($config)) return;

        $ttl = to_int($config['tmp_cleanup_ttl_seconds']);
        if ($ttl < 3600) $ttl = 3600;

        cleanup_tmp_import_files($ttl);
        cleanup_tmp_import_plans($ttl);

        if ($db !== null) {
            $retentionDays = to_int($config['audit_log_retention_days']);
            if ($retentionDays > 0) {
                prune_audit_log($db, $retentionDays);
            }
            $histRetention = to_int($config['address_history_retention_days']);
            if ($histRetention > 0) {
                prune_address_history($db, $histRetention);
            }
        }

        housekeeping_mark_ran();
    } finally {
        @flock($lock, LOCK_UN);
        @fclose($lock);
    }
}

/**
 * Demo nightly reset — runs independently of the housekeeping schedule.
 * Called directly from init.php, wrapped in try-catch so a seed failure
 * never crashes the page load (which would leave $_SESSION without a
 * CSRF token and cause "Bad CSRF token" on all subsequent requests).
 */
function run_demo_reset_if_due(PDO $db): void
{
    if (!demo_mode_enabled() || !demo_require_reset()) return;

    $marker = __DIR__ . '/data/demo_last_reset.txt';
    try {
        demo_reset_db($db);
        file_put_contents($marker, (string)time());
    } catch (Throwable $e) {
        // Log but do not re-throw — page must continue so CSRF is initialised
        error_log('Simple PHP IPAM demo reset failed: ' . $e->getMessage());
    }
}

/* ---------------- Database Backups ---------------- */

/** @param IpamConfig $config */
function backup_dir(array $config): string
{
    $d = trim($config['backup']['dir']);
    if ($d === '') {
        return __DIR__ . '/data/backups';
    }
    // Make relative paths relative to the app directory
    if (!str_starts_with($d, '/')) {
        $d = __DIR__ . '/' . $d;
    }
    // Canonicalize: resolve .. segments without requiring the directory to exist (#113)
    $parts = [];
    foreach (explode('/', $d) as $segment) {
        if ($segment === '..') { array_pop($parts); }
        elseif ($segment !== '' && $segment !== '.') { $parts[] = $segment; }
    }
    return '/' . implode('/', $parts);
}

function backup_state_path(): string
{
    return __DIR__ . '/data/backup-state.json';
}

/** @param IpamConfig $config */
function backup_interval_seconds(array $config): int
{
    $freq = strtolower(trim($config['backup']['frequency']));
    return match ($freq) {
        'weekly' => 604800,
        default  => 86400,  // 'daily'
    };
}

/**
 * @phpstan-impure
 * @param IpamConfig $config
 */
function backup_is_due(array $config): bool
{
    $bk = $config['backup'];
    if (empty($bk['enabled'])) return false;

    $path = backup_state_path();
    if (!is_file($path)) return true;

    $d = @json_decode((string)file_get_contents($path), true);
    if (!is_array($d) || !isset($d['last_backup'])) return true;

    return (time() - to_int($d['last_backup'])) >= backup_interval_seconds($config);
}

/**
 * Run a database backup if one is due. Uses WAL checkpoint + file copy for
 * a consistent snapshot without requiring SQLite3 extension.
 * Returns true if a backup was written, false otherwise.
 *
 * SQLite-only for the moment. The whole flow (`wal_checkpoint`,
 * file-copy of a single `.sqlite` file, `.sqlite` retention pruning)
 * is SQLite-specific. MySQL / Postgres users should run engine-native
 * backups (`mysqldump`, `pg_dump`) from cron or their hosting
 * platform. v3.0.0 `migrate_db.php` (#392) will expose a generic
 * cross-engine backup API; until then, short-circuit here on any
 * non-SQLite driver so the housekeeping cycle does not fatal out on
 * the missing `db_path` key.
 */
/** @param IpamConfig $config */
function run_db_backup_if_due(PDO $db, array $config): bool
{
    // Driver-gate before anything else. MySQL / Postgres do not have a
    // `db_path` key in $config, so even reading $gConf['db_path'] below
    // would emit an undefined-array-key warning and — on PHP 8.x — a
    // TypeError on `is_file(null)` when the warning handler routes the
    // notice but doesn't cast the value. v2.10.0 regression fix (#502).
    if (ipam_dialect()->driver_name() !== 'sqlite') return false;

    if (!backup_is_due($config)) return false;

    $lockPath = __DIR__ . '/data/backup.lock';
    $lock = @fopen($lockPath, 'c');
    if (!$lock) return false;

    if (!@flock($lock, LOCK_EX | LOCK_NB)) {
        @fclose($lock);
        return false;
    }

    $wrote = false;
    try {
        if (!backup_is_due($config)) return false;

        // Driver gate at the top of the function already proved
        // driver_name() === 'sqlite', so IpamConfig's required db_path
        // is genuinely present here.
        /** @var IpamConfig $gConf */
        $gConf = $GLOBALS['config'];
        $dbPath = $gConf['db_path'] !== '' ? $gConf['db_path'] : (__DIR__ . '/data/ipam.sqlite');
        if (!is_file($dbPath)) return false;

        $dir = backup_dir($config);
        if (!is_dir($dir)) {
            if (!@mkdir($dir, 0700, true)) return false;
        }

        // Flush WAL to the main database file for a consistent copy
        try { $db->exec("PRAGMA wal_checkpoint(FULL)"); } catch (Throwable) {}

        $ts   = date('Y-m-d-His');
        $dest = $dir . '/ipam-' . $ts . '.sqlite';

        if (@copy($dbPath, $dest)) {
            @chmod($dest, 0600);
            $wrote = true;

            // Prune old backups according to retention policy
            $retention = max(1, $config['backup']['retention']);
            $files = glob($dir . '/ipam-*.sqlite');
            if (is_array($files)) {
                rsort($files); // newest first (lexicographic = chronological for our format)
                foreach (array_slice($files, $retention) as $old) {
                    @unlink($old);
                }
            }

            // Record backup timestamp
            $state = ['last_backup' => time(), 'last_file' => basename($dest)];
            @file_put_contents(backup_state_path(), json_encode($state));
            @chmod(backup_state_path(), 0600);
        }
    } finally {
        @flock($lock, LOCK_UN);
        @fclose($lock);
    }

    return $wrote;
}

/**
 * Return info about the current backup state for display in the admin panel.
 *
 * @param IpamConfig $config
 * @return array{last_backup: int|null, last_file: string|null, count: int, dir: string}
 */
function backup_info(array $config): array
{
    $dir   = backup_dir($config);
    $state = backup_state_path();
    $last  = null;
    $file  = null;

    if (is_file($state)) {
        $d = @json_decode((string)file_get_contents($state), true);
        if (is_array($d)) {
            $last = isset($d['last_backup']) ? to_int($d['last_backup']) : null;
            $file = isset($d['last_file'])   ? to_str($d['last_file']) : null;
        }
    }

    $files = is_dir($dir) ? (glob($dir . '/ipam-*.sqlite') ?: []) : [];

    return [
        'last_backup' => $last,
        'last_file'   => $file,
        'count'       => count($files),
        'dir'         => $dir,
    ];
}

/**
 * Stream a full SQL dump of the SQLite database to a callable.
 * Each call to $write receives a chunk of SQL text.
 */
function ipam_db_dump_stream(PDO $db, callable $write): void
{
    // SQLite-format dump only. Every query in this function depends on
    // sqlite_master and SQLite-specific PRAGMA output. Cross-engine
    // dump/restore lands in v3.0.0 via migrate_db.php (#392). db_tools.php
    // gates the entry point on driver; this is defence-in-depth for any
    // direct caller that slips past it.
    if (ipam_dialect()->driver_name() !== 'sqlite') {
        throw new \RuntimeException(
            'ipam_db_dump_stream() is SQLite-only. Use engine-native tooling '
            . '(mysqldump / pg_dump) on other drivers until v3.0.0 migrate_db.php.'
        );
    }

    $write("-- Simple PHP IPAM database dump\n");
    $write("-- Generated: " . date('Y-m-d H:i:s') . "\n\n");
    $write("PRAGMA foreign_keys=OFF;\n");
    $write("BEGIN TRANSACTION;\n\n");

    // Tables: schema + data
    $tables = ($db->query(
        "SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
    ) ?: throw new \RuntimeException('Query failed'))->fetchAll();

    foreach ($tables as $t) {
        $name        = to_str($t['name']);
        $quotedName  = '"' . str_replace('"', '""', $name) . '"';
        $write("-- Table: {$name}\n");
        $write(to_str($t['sql']) . ";\n");

        // Dump triggers for this table so they are recreated on import.
        $triggers = ($db->query(
            "SELECT sql FROM sqlite_master WHERE type='trigger' AND tbl_name="
            . $db->quote($name) . " AND sql IS NOT NULL ORDER BY name"
        ) ?: throw new \RuntimeException('Query failed'))->fetchAll();
        foreach ($triggers as $trig) {
            $write(to_str($trig['sql']) . ";\n");
        }

        // Identify BLOB columns so we can always hex-encode raw binary data.
        $colInfo  = ($db->query("PRAGMA table_info({$quotedName})")
            ?: throw new \RuntimeException('Query failed'))->fetchAll();
        $blobCols = [];
        foreach ($colInfo as $ci) {
            if (strtoupper(to_str($ci['type'])) === 'BLOB') {
                $blobCols[to_str($ci['name'])] = true;
            }
        }

        $rows = ($db->query("SELECT * FROM {$quotedName}")
            ?: throw new \RuntimeException('Query failed'))->fetchAll();
        foreach ($rows as $row) {
            $cols = array_map(
                fn($c) => '"' . str_replace('"', '""', (string)$c) . '"',
                array_keys($row)
            );
            $vals = [];
            foreach ($row as $colName => $v) {
                if ($v === null) {
                    $vals[] = 'NULL';
                } elseif (is_int($v) || is_float($v)) {
                    $vals[] = (string)$v;
                } elseif (isset($blobCols[$colName])) {
                    $vals[] = "X'" . bin2hex(to_str($v)) . "'";
                } else {
                    $vals[] = "CAST(X'" . bin2hex(to_str($v)) . "' AS TEXT)";
                }
            }
            $write("INSERT INTO {$quotedName} (" . implode(',', $cols) . ") VALUES ("
                  . implode(',', $vals) . ");\n");
        }
        $write("\n");
    }

    // Indices (non-system)
    $indices = ($db->query(
        "SELECT sql FROM sqlite_master WHERE type='index' AND sql IS NOT NULL AND name NOT LIKE 'sqlite_%' ORDER BY name"
    ) ?: throw new \RuntimeException('Query failed'))->fetchAll();
    if ($indices) {
        $write("-- Indexes\n");
        foreach ($indices as $idx) {
            $write(to_str($idx['sql']) . ";\n");
        }
        $write("\n");
    }

    $write("COMMIT;\n");
    $write("PRAGMA foreign_keys=ON;\n");
}

/**
 * Generate a full SQL dump of the SQLite database suitable for import.
 * Backwards-compatible wrapper around ipam_db_dump_stream().
 */
function ipam_db_dump(PDO $db): string
{
    $out = '';
    ipam_db_dump_stream($db, function(string $chunk) use (&$out) {
        $out .= $chunk;
    });
    return $out;
}

/* ---------------- Pagination ---------------- */

function q_int(string $key, int $default, int $min, int $max): int
{
    $v = $_GET[$key] ?? null;
    if ($v === null || $v === '') return $default;
    if (!is_scalar($v)) return $default;
    if (!preg_match('/^-?\d+$/', (string)$v)) return $default;

    $n = (int)$v;
    if ($n < $min) return $min;
    if ($n > $max) return $max;
    return $n;
}

/**
 * Escape SQL LIKE wildcard characters in a user-supplied search string.
 * Returns the escaped string ready to be wrapped in % delimiters.
 * Use with `LIKE :q ESCAPE '!'` in your SQL.
 *
 * Uses `!` as the escape character because it is a normal character in
 * both SQLite and MySQL string literals — whereas `\\` is parsed as an
 * escape sequence inside single-quoted strings by MySQL (so `ESCAPE '\\'`
 * in PHP source, which renders as `ESCAPE '\'` in SQL text, is a syntax
 * error on MySQL). `!` avoids the cross-engine quoting landmine.
 */
function like_escape(string $q): string
{
    return str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $q);
}

/**
 * Parse and validate ?sort=col&dir=asc|desc from $_GET.
 *
 * @param array<string,string> $allowed  Map of GET param value → SQL column expression (whitelisted)
 * @param string $defaultCol  Key in $allowed to use when no valid sort param is provided
 * @param string $defaultDir  'asc' or 'desc'
 * @return array{col: string, dir: string, sql: string}
 */
function parse_sort(array $allowed, string $defaultCol, string $defaultDir = 'asc'): array
{
    $col = to_str($_GET['sort'] ?? $defaultCol);
    $dir = strtolower(to_str($_GET['dir'] ?? $defaultDir));
    if (!isset($allowed[$col])) $col = $defaultCol;
    if (!in_array($dir, ['asc', 'desc'], true)) $dir = $defaultDir;
    return ['col' => $col, 'dir' => $dir, 'sql' => $allowed[$col] . ' ' . strtoupper($dir)];
}

/**
 * Render a sortable <th> element linking to the current page with sort params applied.
 * $baseQs should be the query string prefix for the page (e.g. '?subnet_id=3&page_size=50').
 */
function sort_th(string $col, string $label, string $currentCol, string $currentDir, string $baseQs, string $dataCol = ''): string
{
    $isActive  = $col === $currentCol;
    $nextDir   = ($isActive && $currentDir === 'asc') ? 'desc' : 'asc';
    $arrow     = $isActive ? ($currentDir === 'asc' ? ' ▲' : ' ▼') : '';
    $sep       = str_contains($baseQs, '?') ? '&' : '?';
    $qs        = $baseQs . $sep . 'sort=' . urlencode($col) . '&dir=' . $nextDir;
    $cls       = $isActive ? ' class="sort-active"' : '';
    $dataAttr  = $dataCol !== '' ? ' data-col="' . e($dataCol) . '"' : '';
    return "<th{$cls}{$dataAttr}><a href='" . e($qs) . "'>" . e($label) . $arrow . '</a></th>';
}

/* ---------------- Login protection (#124) ---------------- */

/**
 * Verify a reCAPTCHA token against the Enterprise Assessment API.
 * Returns null on pass, error string on fail, null on network error (fail-open).
 *
 * @param array{enabled: bool, project_id: string, api_key: string, expected_action: string, score_threshold: float} $cfg
 */
function recaptcha_enterprise_verify(string $token, string $siteKey, array $cfg): ?string
{
    $projectId      = to_str($cfg['project_id']);
    $apiKey         = to_str($cfg['api_key']);
    $expectedAction = to_str($cfg['expected_action']);
    $threshold      = (float)$cfg['score_threshold'];

    if ($projectId === '' || $apiKey === '') {
        error_log('reCAPTCHA Enterprise: project_id and api_key must be configured.');
        return null; // fail open — misconfiguration should not block users
    }

    $url     = 'https://recaptchaenterprise.googleapis.com/v1/projects/' . rawurlencode($projectId) . '/assessments?key=' . rawurlencode($apiKey);
    $payload = (string)json_encode(['event' => ['token' => $token, 'expectedAction' => $expectedAction, 'siteKey' => $siteKey]]);
    $ctx = stream_context_create([
        'http' => [
            'method'        => 'POST',
            'header'        => "Content-Type: application/json\r\nContent-Length: " . strlen($payload) . "\r\n",
            'content'       => $payload,
            'timeout'       => 10,
            'ignore_errors' => true,
        ],
        'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
    ]);

    try {
        $raw = @file_get_contents($url, false, $ctx, 0, 1048576);
        if ($raw === false) {
            error_log('reCAPTCHA Enterprise: HTTP request failed.');
            return null;
        }
        $resp = json_decode($raw, true);
        if (!is_array($resp)) {
            error_log('reCAPTCHA Enterprise: Invalid JSON response.');
            return null;
        }
        /** @var array<string, mixed> $resp */
        $tokenProps  = is_array($resp['tokenProperties'] ?? null) ? $resp['tokenProperties'] : [];
        $riskAnalysis = is_array($resp['riskAnalysis'] ?? null)   ? $resp['riskAnalysis']   : [];

        if (!empty($tokenProps['invalid'])) return 'Security check failed. Please try again.';
        if ($expectedAction !== '' && isset($tokenProps['action']) && to_str($tokenProps['action']) !== $expectedAction) {
            return 'Security check failed. Please try again.';
        }

        $score = (isset($riskAnalysis['score']) && is_numeric($riskAnalysis['score'])) ? (float)$riskAnalysis['score'] : 0.0;
        return $score >= $threshold ? null : 'Security check failed. Please try again.';
    } catch (Throwable $e) {
        error_log('reCAPTCHA Enterprise verify error: ' . $e->getMessage());
        return null;
    }
}

/**
 * Resolve the reCAPTCHA v3 expected action name, honouring the legacy
 * top-level $config['recaptcha_action'] key (documented since #289) before
 * falling back to the v2.6.0 registry key recaptcha_enterprise.expected_action.
 * Both the widget render and the Enterprise verify path must go through this
 * helper so the action emitted in the hidden input matches the action checked
 * during verification — otherwise valid Enterprise tokens fail action matching.
 */
function recaptcha_expected_action_resolved(): string
{
    $legacyCfg    = $GLOBALS['config'] ?? null;
    $legacyAction = is_array($legacyCfg) ? ($legacyCfg['recaptcha_action'] ?? null) : null;
    $resolved = (is_string($legacyAction) && $legacyAction !== '')
        ? $legacyAction
        : to_str(ipam_setting('recaptcha_enterprise.expected_action'));
    return $resolved !== '' ? $resolved : 'login';
}

/**
 * Verify the login form protection token/field for the current POST request.
 *
 * Returns null on pass, '' for a silent honeypot rejection (no error shown),
 * or a non-empty error string that should be shown to the user.
 * Fails open on network errors so a broken CAPTCHA provider never blocks login.
 *
 * @param LoginProtectionConfig $config Unused since v2.7.0 — config flows
 *                                      through ipam_setting().
 * @param array<string, mixed> $post
 */
function login_protection_verify(array $config, array $post): ?string
{
    unset($config);
    $method = to_str(ipam_setting('login_protection.method'));
    if ($method === '' || $method === 'null') return null;

    if ($method === 'honeypot') {
        return ($post['website'] ?? '') !== '' ? '' : null;
    }

    if ($method === 'time_check') {
        $min = max(1, to_int(ipam_setting('login_protection.min_seconds')));
        $ts  = to_int($_SESSION['login_form_at'] ?? 0);
        unset($_SESSION['login_form_at']);
        if ($ts === 0 || (time() - $ts) < $min) {
            return 'Form submission was too fast. Please wait a moment and try again.';
        }
        return null;
    }

    $secretKey = to_str(ipam_setting('login_protection.secret_key'));

    if ($method === 'turnstile') {
        $token = to_str($post['cf-turnstile-response'] ?? '');
        if ($token === '') return 'Please complete the security check.';
        try {
            $resp = oidc_http_post('https://challenges.cloudflare.com/turnstile/v0/siteverify', [
                'secret'   => $secretKey,
                'response' => $token,
                'remoteip' => client_ip(),
            ]);
        } catch (Throwable $e) {
            error_log('Turnstile verify error: ' . $e->getMessage());
            return null; // fail open
        }
        return !empty($resp['success']) ? null : 'Security check failed. Please try again.';
    }

    if ($method === 'hcaptcha') {
        $token = to_str($post['h-captcha-response'] ?? '');
        if ($token === '') return 'Please complete the security check.';
        try {
            $resp = oidc_http_post('https://hcaptcha.com/siteverify', [
                'secret'   => $secretKey,
                'response' => $token,
                'remoteip' => client_ip(),
            ]);
        } catch (Throwable $e) {
            error_log('hCaptcha verify error: ' . $e->getMessage());
            return null; // fail open
        }
        return !empty($resp['success']) ? null : 'Security check failed. Please try again.';
    }

    if ($method === 'recaptcha') {
        $token = to_str($post['g-recaptcha-response'] ?? '');
        if ($token === '') return 'Please complete the security check.';

        // Use Enterprise API if configured; fall back to standard reCAPTCHA API
        if ((bool)ipam_setting('recaptcha_enterprise.enabled')) {
            $rawThreshold = ipam_setting('recaptcha_enterprise.score_threshold');
            $enterprise = [
                'enabled'         => true,
                'project_id'      => to_str(ipam_setting('recaptcha_enterprise.project_id')),
                'api_key'         => to_str(ipam_setting('recaptcha_enterprise.api_key')),
                // Must match the action the widget emits (see
                // recaptcha_expected_action_resolved for the precedence rules).
                'expected_action' => recaptcha_expected_action_resolved(),
                'score_threshold' => is_numeric($rawThreshold) ? (float)$rawThreshold : 0.5,
            ];
            return recaptcha_enterprise_verify($token, to_str(ipam_setting('login_protection.site_key')), $enterprise);
        }

        try {
            $resp = oidc_http_post('https://www.google.com/recaptcha/api/siteverify', [
                'secret'   => $secretKey,
                'response' => $token,
                'remoteip' => client_ip(),
            ]);
        } catch (Throwable $e) {
            error_log('reCAPTCHA verify error: ' . $e->getMessage());
            return null; // fail open
        }
        return !empty($resp['success']) ? null : 'Security check failed. Please try again.';
    }

    if ($method === 'friendly_captcha') {
        $token = to_str($post['frc-captcha-solution'] ?? '');
        if ($token === '' || $token === '.UNSTARTED') return 'Please complete the security check.';
        if ($token === '.FETCHING') return null; // in-progress, fail open
        try {
            $resp = oidc_http_post('https://api.friendlycaptcha.com/api/v1/siteverify', [
                'secret'  => $secretKey,
                'solution'=> $token,
                'sitekey' => to_str(ipam_setting('login_protection.site_key')),
            ]);
        } catch (Throwable $e) {
            error_log('FriendlyCaptcha verify error: ' . $e->getMessage());
            return null; // fail open
        }
        return !empty($resp['success']) ? null : 'Security check failed. Please try again.';
    }

    return null; // unknown method — pass through
}

/**
 * Return the HTML widget snippet to embed in the login/gate form.
 * For time_check, also sets the session timestamp on GET requests.
 *
 * @param LoginProtectionConfig $config Unused since v2.7.0 — kept for signature stability.
 */
function login_protection_widget_html(array $config): string
{
    unset($config);
    $method  = to_str(ipam_setting('login_protection.method'));
    $siteKey = e(to_str(ipam_setting('login_protection.site_key')));

    switch ($method) {
        case 'honeypot':
            return "<input type='text' name='website' autocomplete='off' tabindex='-1' aria-hidden='true' class='hidden'>";
        case 'time_check':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                $_SESSION['login_form_at'] = time();
            }
            return ''; // no visible widget
        case 'turnstile':
            return "<script src='https://challenges.cloudflare.com/turnstile/v0/api.js' async defer></script>"
                 . "<div class='cf-turnstile' data-sitekey='{$siteKey}'></div>";
        case 'hcaptcha':
            return "<script src='https://js.hcaptcha.com/1/api.js' async defer></script>"
                 . "<div class='h-captcha' data-sitekey='{$siteKey}'></div>";
        case 'recaptcha':
            $ver   = to_int(ipam_setting('login_protection.version'));
            $isEnt = (bool)ipam_setting('recaptcha_enterprise.enabled');
            if ($ver === 3) {
                $scriptSrc    = $isEnt
                    ? "https://www.google.com/recaptcha/enterprise.js?render={$siteKey}"
                    : "https://www.google.com/recaptcha/api.js?render={$siteKey}";
                $entAttr      = $isEnt ? " data-recaptcha-enterprise='1'" : '';
                $action       = e(recaptcha_expected_action_resolved());
                $actionAttr   = " data-recaptcha-action='{$action}'";
                return "<script src='{$scriptSrc}' async defer></script>"
                     . "<input type='hidden' name='g-recaptcha-response' id='g-recaptcha-response' data-recaptcha-v3-key='{$siteKey}'{$entAttr}{$actionAttr}>";
            }
            return "<script src='https://www.google.com/recaptcha/api.js' async defer></script>"
                 . "<div class='g-recaptcha' data-sitekey='{$siteKey}'></div>";
        case 'friendly_captcha':
            return "<script src='https://cdn.jsdelivr.net/npm/friendly-challenge@latest/widget.module.min.js' async defer></script>"
                 . "<div class='frc-captcha' data-sitekey='{$siteKey}'></div>";
        default:
            return '';
    }
}

/**
 * Return extra CSP directives needed for the active login protection method.
 * Returns ['script_src' => '...', 'frame_src' => '...'] — either may be empty.
 * Turnstile, hCaptcha, and reCAPTCHA render inside an iframe so frame_src must
 * be explicitly allowed; Friendly Captcha uses Web Components (no iframe needed).
 */
/**
 * @param LoginProtectionConfig $config Unused since v2.7.0 — kept for signature stability.
 * @return array{script_src: string, frame_src: string}
 */
function login_protection_extra_csp(array $config): array
{
    unset($config);
    $method = to_str(ipam_setting('login_protection.method'));
    return match ($method) {
        'turnstile'        => [
            'script_src' => 'https://challenges.cloudflare.com',
            'frame_src'  => 'https://challenges.cloudflare.com',
        ],
        'hcaptcha'         => [
            'script_src' => 'https://hcaptcha.com https://assets.hcaptcha.com',
            'frame_src'  => 'https://newassets.hcaptcha.com',
        ],
        'recaptcha'        => [
            'script_src' => 'https://www.google.com https://www.gstatic.com',
            'frame_src'  => 'https://www.google.com',
        ],
        'friendly_captcha' => [
            'script_src' => 'https://cdn.jsdelivr.net',
            'frame_src'  => '',
        ],
        default            => ['script_src' => '', 'frame_src' => ''],
    };
}

/* ---------------- Auto-reserve IPs ---------------- */

/**
 * Auto-reserve the network address, broadcast address (IPv4), and optionally
 * a gateway IP immediately after a subnet is created.
 *
 * IPv4: reserves network (x.x.x.0) and broadcast (x.x.x.255) as status=reserved.
 * IPv6: reserves network address only (broadcast concept does not apply).
 * Gateway (if provided): reserved as status=reserved with hostname 'gateway'.
 *
 * Skips any IP that is already assigned (INSERT OR IGNORE).
 */
function auto_reserve_subnet_ips(PDO $db, int $subnetId, string $cidr, ?string $gateway): void
{
    $p = parse_cidr($cidr);
    if (!$p) return;

    // #379/#410: bind ip_bin via ipam_bind_binary() (PARAM_LOB) so the stored
    // affinity is BLOB on SQLite and bytes round-trip safely on MySQL/Postgres.
    // The scalar params still come through bindValue so we can mix the two
    // binding styles on a single statement.
    $ignoreClause = ipam_dialect()->upsert_or_ignore('addresses', ['subnet_id', 'ip']);
    $ins = $db->prepare(
        "INSERT INTO addresses (subnet_id, ip, ip_bin, hostname, status, owner, note, grp, mac)
         VALUES (:sid, :ip, :ipbin, :host, 'reserved', '', 'Auto-reserved', '', '') $ignoreClause"
    );
    // Returns the new row's id on a fresh insert, or 0 when the row was
    // ignored by the upsert-or-ignore clause. Using rowCount() instead of
    // lastInsertId() is critical: on MySQL, lastInsertId() after a
    // duplicate-key no-op returns the previous successful insert id, which
    // would otherwise produce a bogus address.create audit entry.
    $reserveBind = function (int $sid, string $ip, string $bin, string $host) use ($ins, $db): int {
        $ins->bindValue(':sid',  $sid,  PDO::PARAM_INT);
        $ins->bindValue(':ip',   $ip,   PDO::PARAM_STR);
        ipam_bind_binary($ins, ':ipbin', $bin);
        $ins->bindValue(':host', $host, PDO::PARAM_STR);
        $ins->execute();
        return $ins->rowCount() > 0 ? (int)$db->lastInsertId() : 0;
    };

    // Network address
    $netIp  = $p['network'];
    $netBin = $p['net_bin'];
    $newId = $reserveBind($subnetId, $netIp, $netBin, 'network');
    if ($newId > 0) {
        audit($db, 'address.create', 'address', $newId, "auto-reserve network $netIp in subnet $subnetId");
    }

    if ($p['version'] === 4) {
        // Broadcast address for IPv4 — uses the same helper as the scanner so
        // /31 (RFC 3021 point-to-point) and /32 correctly reserve no broadcast
        // and the UI agrees with the scanner's reserved set.
        $bcastBin = ipam_compute_broadcast_bin($netBin, $p['prefix']);
        if ($bcastBin !== null) {
            $bcastIp = inet_ntop($bcastBin) ?: '';
            if ($bcastIp !== '' && $bcastIp !== $netIp) {
                $newId = $reserveBind($subnetId, $bcastIp, $bcastBin, 'broadcast');
                if ($newId > 0) {
                    audit($db, 'address.create', 'address', $newId, "auto-reserve broadcast $bcastIp in subnet $subnetId");
                }
            }
        }
    }

    // Gateway (optional, any version)
    if ($gateway !== null && $gateway !== '') {
        $gwNorm = normalize_ip($gateway);
        if ($gwNorm && ip_in_cidr($gwNorm['ip'], $p['network'], $p['prefix'])) {
            $newId = $reserveBind($subnetId, $gwNorm['ip'], $gwNorm['bin'], 'gateway');
            if ($newId > 0) {
                audit($db, 'address.create', 'address', $newId, "auto-reserve gateway {$gwNorm['ip']} in subnet $subnetId");
            }
        }
    }
}

/* ---------------- Tags ---------------- */

/**
 * Return tags for a given entity (subnet or address).
 * @return array<array{id: int, name: string, colour: string}>
 */
function get_tags_for_entity(PDO $db, string $type, int $id): array
{
    if ($type === 'subnet') {
        $sql = "SELECT t.id, t.name, t.colour FROM tags t JOIN subnet_tags st ON st.tag_id = t.id WHERE st.subnet_id = :id ORDER BY t.name";
    } elseif ($type === 'address') {
        $sql = "SELECT t.id, t.name, t.colour FROM tags t JOIN address_tags at ON at.tag_id = t.id WHERE at.address_id = :id ORDER BY t.name";
    } else {
        return [];
    }
    $st = $db->prepare($sql);
    $st->execute([':id' => $id]);
    return array_map(fn($r) => ['id' => to_int($r['id']), 'name' => to_str($r['name']), 'colour' => to_str($r['colour'])], $st->fetchAll());
}

/**
 * Replace all tags for a given entity with the supplied tag IDs.
 * @param list<int> $tagIds
 */
function save_tags_for_entity(PDO $db, string $type, int $id, array $tagIds): void
{
    if ($type === 'subnet') {
        $db->prepare("DELETE FROM subnet_tags WHERE subnet_id = :id")->execute([':id' => $id]);
        $ins = $db->prepare("INSERT INTO subnet_tags (subnet_id, tag_id) VALUES (:eid, :tid) " . ipam_dialect()->upsert_or_ignore("subnet_tags", ["subnet_id", "tag_id"]) . "");
    } elseif ($type === 'address') {
        $db->prepare("DELETE FROM address_tags WHERE address_id = :id")->execute([':id' => $id]);
        $ins = $db->prepare("INSERT INTO address_tags (address_id, tag_id) VALUES (:eid, :tid) " . ipam_dialect()->upsert_or_ignore("address_tags", ["address_id", "tag_id"]) . "");
    } else {
        return;
    }
    foreach ($tagIds as $tid) {
        $ins->execute([':eid' => $id, ':tid' => $tid]);
    }
}

/** Render coloured tag badges for a list of tags (HTML-safe). */
function render_tag_badges(PDO $db, string $type, int $id): string
{
    $tags = get_tags_for_entity($db, $type, $id);
    if (!$tags) return '';
    $out = '';
    foreach ($tags as $tag) {
        $bg   = e($tag['colour']);
        $name = e($tag['name']);
        $out .= "<span class='tag-badge' style='background:$bg'>$name</span>";
    }
    return $out;
}

/* ---------------- Demo mode ---------------- */

function demo_mode_enabled(): bool
{
    /** @var IpamConfig $gConf */
    $gConf = $GLOBALS['config'];
    return !empty($gConf['demo_mode']['enabled']);
}

function demo_require_reset(): bool
{
    $marker = __DIR__ . '/data/demo_last_reset.txt';
    if (!is_file($marker)) return true;
    $lastReset = (int)file_get_contents($marker);
    $midnight  = mktime(0, 0, 0);
    return $lastReset < $midnight;
}

/** @return array<string, int> */
function paginate(int $total, int $page, int $pageSize): array
{
    $page = max(1, $page);
    $pageSize = max(1, min(500, $pageSize));
    $pages = (int)max(1, (int)ceil($total / $pageSize));
    if ($page > $pages) $page = $pages;

    return [
        'page' => $page,
        'page_size' => $pageSize,
        'pages' => $pages,
        'offset' => ($page - 1) * $pageSize,
        'limit' => $pageSize,
    ];
}

/* ---------------- CSV export helpers ---------------- */

function safe_export_filename(string $base): string
{
    $base = strtolower($base);
    $base = preg_replace('/[^a-z0-9._-]+/', '-', $base) ?? 'export';
    $base = trim($base, '-.');
    if ($base === '') $base = 'export';
    return $base . '-' . date('Y-m-d-His') . '.csv';
}

function csv_download_headers(string $filename): void
{
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    echo "\xEF\xBB\xBF"; // UTF-8 BOM for Excel compatibility
}

/** @return resource */
function csv_output_handle()
{
    static $fh = null;
    if ($fh === null) {
        $fh = fopen('php://output', 'wb');
        if (!$fh) throw new RuntimeException('Cannot open php://output');
    }
    return $fh;
}

/** @param list<string> $row */
function csv_out(array $row): void
{
    $fh = csv_output_handle();
    // CodeRabbit C1 (PR #450): defuse spreadsheet formula injection. Excel /
    // LibreOffice / Numbers treat any cell starting with =, +, -, @, TAB, CR
    // or LF as a formula. Prefix offending cells with a single quote so they
    // render as literal text. Applies to every CSV export site-wide because
    // every export goes through this helper.
    $sanitized = array_map(static function (string $cell): string {
        if ($cell === '') return $cell;
        $first = $cell[0];
        if ($first === '=' || $first === '+' || $first === '-' || $first === '@'
            || $first === "\t" || $first === "\r" || $first === "\n") {
            return "'" . $cell;
        }
        return $cell;
    }, $row);
    fputcsv($fh, $sanitized, ',', '"', '');
}

/* ---------------- Security warning banner ---------------- */

/**
 * Render a dismissible per-session security warning banner.
 *
 * Call this immediately after page_header() on sensitive admin pages.
 * The banner is hidden for the rest of the session once the user dismisses it.
 *
 * @param string $context  Short identifier for this banner, e.g. 'db_tools', 'import_csv'
 * @param string $message  Warning text to display (HTML-escaped before output)
 */
function render_security_banner(string $context, string $message): void
{
    // Handle dismiss: clicking the link adds ?dismiss_warning=<context> to the URL.
    // We process it here (before any HTML output from this function) and store in session.
    if (isset($_GET['dismiss_warning']) && $_GET['dismiss_warning'] === $context) {
        $dw = is_array($_SESSION['dismissed_warnings'] ?? null) ? $_SESSION['dismissed_warnings'] : [];
        $dw[$context] = true;
        $_SESSION['dismissed_warnings'] = $dw;
    }

    $dw = is_array($_SESSION['dismissed_warnings'] ?? null) ? $_SESSION['dismissed_warnings'] : [];
    if (!empty($dw[$context])) {
        return;
    }

    // Build dismiss URL: current URL with dismiss_warning param added, page reset removed
    $params = array_merge($_GET, ['dismiss_warning' => $context]);
    $dismissUrl = '?' . http_build_query($params);

    echo '<div class="security-banner">'
       . '<span>⚠ <strong>Security notice:</strong> ' . e($message) . '</span>'
       . '<a class="dismiss-link" href="' . e($dismissUrl) . '">Dismiss</a>'
       . '</div>';
}

/* ---------------- Demo mode seed/reset ---------------- */

function demo_reset_db(PDO $db): void
{
    $driver = ipam_dialect()->driver_name();

    // audit_log has append-only triggers that block DELETE, so bypass via rename+drop,
    // then immediately recreate the table and triggers.
    $db->exec("ALTER TABLE audit_log RENAME TO audit_log_old");
    $db->exec("DROP TABLE audit_log_old");
    ensure_audit_log_table($db);

    // Clear in FK-safe order; CASCADE removes subnet_tags, address_tags, alert_state.
    // schema_migrations is only wiped on SQLite, where the historical migration
    // closures are expected to re-run after the reset. On MySQL / Postgres,
    // schema.{engine}.sql pre-seeds schema_migrations with every historical
    // version row at fresh-install time (v2.10.0 #484 decision), and the
    // historical closures use SQLite-specific PRAGMA / sqlite_master queries
    // that would fail on other engines. Keep the pre-seed intact so
    // apply_migrations() remains a no-op.
    $tables = ['address_history', 'login_attempts', 'api_keys',
               'addresses', 'subnets', 'vlans', 'vrfs', 'contacts', 'tags',
               'sites', 'users'];
    if ($driver === 'sqlite') {
        $tables[] = 'schema_migrations';
    }
    foreach ($tables as $t) {
        $db->exec("DELETE FROM $t");
        // Rewind the table's auto-increment counter so subsequent inserts
        // start at 1 and the fixture IDs that demo_seed_data passes
        // explicitly land deterministically on every reset. Critical on
        // MySQL: DELETE alone does NOT rewind AUTO_INCREMENT, so on a
        // second reset any row inserted WITHOUT an explicit id (e.g. the
        // audit rows written by audit()) would carry a drifted id and
        // break fixtures that reference it by id.
        if ($driver === 'sqlite') {
            $db->exec("DELETE FROM sqlite_sequence WHERE name='$t'");
        } elseif ($driver === 'mysql') {
            $db->exec("ALTER TABLE $t AUTO_INCREMENT = 1");
        }
    }
    if ($driver === 'sqlite') {
        $db->exec("DELETE FROM sqlite_sequence WHERE name='audit_log'");
    } elseif ($driver === 'mysql') {
        $db->exec("ALTER TABLE audit_log AUTO_INCREMENT = 1");
    }
    apply_migrations($db);
    demo_seed_data($db);
}

function demo_seed_data(PDO $db): void
{
    // --- Sites (id=5,6 are region parents inserted first for self-referential FK) ---
    $si = $db->prepare("INSERT INTO sites (id, name, description, parent_id) VALUES (?,?,?,?)");
    foreach ([
        [5, 'EMEA Region',     'Europe, Middle East & Africa', null],
        [6, 'Americas Region', 'North & South America',        null],
        [1, 'London HQ',       'Primary headquarters',         5],
        [2, 'New York DC',     'East coast data centre',       6],
        [3, 'Sydney Office',   'APAC regional office',         null],
        [4, 'AWS eu-west-1',   'Cloud infrastructure',         5],
        ] as $s) $si->execute($s);

    // --- VRFs ---
    $vr = $db->prepare("INSERT INTO vrfs (id, name, description, rd) VALUES (?,?,?,?)");
    foreach ([
        [1, 'DEFAULT',  'Default global routing table', '65000:0'],
        [2, 'MGMT-VRF', 'Management plane VRF',         '65000:100'],
        ] as $v) $vr->execute($v);

    // --- VLANs ---
    $vl = $db->prepare("INSERT INTO vlans (id, vlan_id, name, description, site_id) VALUES (?,?,?,?,?)");
    foreach ([
        [1, 10,  'Management',    'Out-of-band management VLAN',    1],
        [2, 20,  'Servers',       'Server infrastructure VLAN',      1],
        [3, 30,  'DMZ',           'Demilitarised zone',              1],
        [4, 100, 'Cloud-Connect', 'AWS Direct Connect peering VLAN', 4],
        ] as $v) $vl->execute($v);

    // --- Contacts ---
    $ct = $db->prepare("INSERT INTO contacts (id, name, email, phone, org, note) VALUES (?,?,?,?,?,?)");
    foreach ([
        [1, 'Alice Smith', 'alice@example.com', '+44 20 7946 0001', 'NetOps',   'Primary network contact'],
        [2, 'Bob Jones',   'bob@example.com',   '+44 20 7946 0002', 'DBA',      'Database team lead'],
        [3, 'Carol Wu',    'carol@example.com', '+1 212 555 0103',  'Security', 'Security operations engineer'],
        ] as $c) $ct->execute($c);

    // --- Tags ---
    $tg = $db->prepare("INSERT INTO tags (id, name, colour) VALUES (?,?,?)");
    foreach ([
        [1, 'Production',  '#28a745'],
        [2, 'Development', '#17a2b8'],
        [3, 'Critical',    '#dc3545'],
        [4, 'Monitored',   '#6c757d'],
        ] as $t) $tg->execute($t);

    // #379/#410: helper that binds the ten subnet columns onto a prepared
    // INSERT, routing network_bin through ipam_bind_binary() (PARAM_LOB) so
    // every demo-seeded row is BLOB-affinity from the start. Positional ? in
    // the prepare maps to 1-based bindValue indexes.
    $bindSubnetRow = function (PDOStatement $stmt, int $id, string $cidr, string $netNorm, string $netBin, int $pfx, string $desc, ?int $siteId, ?int $vlanFk, ?int $vrfId): void {
        $stmt->bindValue(1,  $id,      PDO::PARAM_INT);
        $stmt->bindValue(2,  $cidr,    PDO::PARAM_STR);
        $stmt->bindValue(3,  $netNorm, PDO::PARAM_STR);
        ipam_bind_binary($stmt, 4, $netBin);
        $stmt->bindValue(5,  $pfx,     PDO::PARAM_INT);
        $stmt->bindValue(6,  $desc,    PDO::PARAM_STR);
        $stmt->bindValue(7,  $siteId,  $siteId === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
        $stmt->bindValue(8,  $vlanFk,  $vlanFk === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
        $stmt->bindValue(9,  $vrfId,   $vrfId  === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
        $stmt->execute();
    };

    // --- Subnets (IPv4) ---
    // [id, cidr, site_id, vlan_fk, vrf_id, description]
    $sn = $db->prepare(
        "INSERT INTO subnets (id, cidr, ip_version, network, network_bin, prefix, description, site_id, vlan_fk, vrf_id)
         VALUES (?,?,4,?,?,?,?,?,?,?)"
    );
    foreach ([
        [1,  '10.0.0.0/8',    null, null, null, 'RFC-1918 supernet (informational)'],
        [2,  '10.10.0.0/16',  1,    null, null, 'London HQ corporate'],
        [3,  '10.10.1.0/24',  1,    1,    2,    'London management'],
        [4,  '10.10.2.0/24',  1,    2,    null, 'London servers'],
        [5,  '10.10.3.0/27',  1,    3,    null, 'London DMZ'],
        [6,  '10.20.0.0/16',  2,    null, null, 'New York DC corporate'],
        [7,  '10.20.1.0/24',  2,    null, null, 'New York servers'],
        [8,  '10.20.2.0/24',  2,    null, null, 'New York management'],
        [9,  '172.16.0.0/16', 3,    null, null, 'Sydney corporate'],
        [10, '172.16.1.0/24', 3,    null, null, 'Sydney servers'],
        ] as [$id, $cidr, $siteId, $vlanFk, $vrfId, $desc]) {
        [$net, $pfx] = explode('/', $cidr);
        $rawBin  = inet_pton($net) ?: throw new \RuntimeException("Invalid IP: $net");
        $netNorm = inet_ntop(apply_prefix_mask($rawBin, (int)$pfx)) ?: throw new \RuntimeException("inet_ntop failed");
        $netBin  = inet_pton($netNorm) ?: throw new \RuntimeException("inet_pton failed on $netNorm");
        $bindSubnetRow($sn, $id, $cidr, $netNorm, $netBin, (int)$pfx, $desc, $siteId, $vlanFk, $vrfId);
    }

    // --- Subnets (IPv6) ---
    $sn6 = $db->prepare(
        "INSERT INTO subnets (id, cidr, ip_version, network, network_bin, prefix, description, site_id, vlan_fk, vrf_id)
         VALUES (?,?,6,?,?,?,?,?,?,?)"
    );
    foreach ([
        [11, '2001:db8::/32',   1, null, null, 'London HQ IPv6 allocation'],
        [12, '2001:db8:1::/48', 1, null, null, 'London servers IPv6'],
        [13, '2001:db8:2::/64', 2, null, null, 'New York IPv6 segment'],
        ] as [$id, $cidr, $siteId, $vlanFk, $vrfId, $desc]) {
        [$net, $pfx] = explode('/', $cidr);
        $rawBin6  = inet_pton($net) ?: throw new \RuntimeException("Invalid IP: $net");
        $netNorm6 = inet_ntop(apply_prefix_mask($rawBin6, (int)$pfx)) ?: throw new \RuntimeException("inet_ntop failed");
        $netBin6  = inet_pton($netNorm6) ?: throw new \RuntimeException("inet_pton failed on $netNorm6");
        $bindSubnetRow($sn6, $id, $cidr, $netNorm6, $netBin6, (int)$pfx, $desc, $siteId, $vlanFk, $vrfId);
    }

    // --- Subnet tags ---
    $st = $db->prepare("INSERT INTO subnet_tags (subnet_id, tag_id) VALUES (?,?)");
    foreach ([
        [4, 1], [4, 4],   // London servers: Production, Monitored
        [5, 1], [5, 3],   // London DMZ: Production, Critical
        [12, 2],          // London servers IPv6: Development
        ] as $t) $st->execute($t);

    // --- Users ---
    // demo: admin, password 'demo' | readonly-user / netops-user: locked accounts for display
    $us = $db->prepare(
        "INSERT INTO users (username, password_hash, role, is_active, name, email) VALUES (?,?,?,?,?,?)"
    );
    foreach ([
        ['demo',          password_hash('demo', PASSWORD_DEFAULT), 'admin',    1, 'Demo Admin',  'demo@example.com'],
        ['readonly-user', '!disabled',                              'readonly', 1, 'Read Only',   'readonly@example.com'],
        ['netops-user',   '!disabled',                              'netops',   1, 'NetOps User', 'netops@example.com'],
        ] as $u) $us->execute($u);

    // --- Addresses ---
    // [subnet_id, ip, hostname, owner, status, note, mac, expires_at, owner_contact_id]
    // Address IDs assigned sequentially: subnet 3 = 1–9, subnet 4 = 10–27,
    // subnet 5 = 28–37, subnet 7 = 38–45, subnet 8 = 46–49, subnet 10 = 50–54.
    $ai = $db->prepare(
        "INSERT INTO addresses (subnet_id, ip, ip_bin, hostname, owner, status, note, mac, expires_at, owner_contact_id)
         VALUES (?,?,?,?,?,?,?,?,?,?)"
    );
    foreach ([
        // 10.10.1.0/24 — London management (id=1..9)
        [3, '10.10.1.1',   'gw-lon-mgmt',    'NetOps',   'used',     'Default gateway',        'aa:bb:cc:00:01:01', null,         1],
        [3, '10.10.1.2',   'sw-lon-core-01', 'NetOps',   'used',     'Core switch',            'aa:bb:cc:00:01:02', null,         1],
        [3, '10.10.1.3',   'sw-lon-core-02', 'NetOps',   'used',     'Core switch redundant',  'aa:bb:cc:00:01:03', null,         1],
        [3, '10.10.1.10',  'mon-lon-01',     'NetOps',   'used',     'Monitoring server',      '',                  null,         null],
        [3, '10.10.1.20',  'ntp-lon-01',     'NetOps',   'used',     'NTP server',             '',                  null,         null],
        [3, '10.10.1.30',  'dns-lon-01',     'NetOps',   'used',     'Primary DNS',            '',                  null,         null],
        [3, '10.10.1.31',  'dns-lon-02',     'NetOps',   'used',     'Secondary DNS',          '',                  null,         null],
        [3, '10.10.1.50',  '',               '',         'reserved', 'Reserved for IPMI',      '',                  null,         null],
        [3, '10.10.1.51',  '',               '',         'reserved', 'Reserved for IPMI',      '',                  null,         null],
        // 10.10.2.0/24 — London servers (id=10..27)
        [4, '10.10.2.1',   'gw-lon-srv',     'NetOps',   'used',     'Server gateway',         'aa:bb:cc:00:02:01', null,         1],
        [4, '10.10.2.10',  'web-lon-01',     'WebTeam',  'used',     'Web frontend 1',         'de:ad:be:ef:00:01', '2027-06-30', null],
        [4, '10.10.2.11',  'web-lon-02',     'WebTeam',  'used',     'Web frontend 2',         'de:ad:be:ef:00:02', '2027-06-30', null],
        [4, '10.10.2.12',  'web-lon-03',     'WebTeam',  'used',     'Web frontend 3',         'de:ad:be:ef:00:03', '2027-06-30', null],
        [4, '10.10.2.20',  'app-lon-01',     'AppTeam',  'used',     'Application server 1',   '',                  null,         null],
        [4, '10.10.2.21',  'app-lon-02',     'AppTeam',  'used',     'Application server 2',   '',                  null,         null],
        [4, '10.10.2.22',  'app-lon-03',     'AppTeam',  'used',     'Application server 3',   '',                  null,         null],
        [4, '10.10.2.30',  'db-lon-01',      'DBA',      'used',     'Primary database',       'fa:ce:b0:00:00:01', null,         2],
        [4, '10.10.2.31',  'db-lon-02',      'DBA',      'used',     'Replica database',       'fa:ce:b0:00:00:02', null,         2],
        [4, '10.10.2.32',  'db-lon-03',      'DBA',      'used',     'Backup database',        'fa:ce:b0:00:00:03', null,         2],
        [4, '10.10.2.40',  'cache-lon-01',   'AppTeam',  'used',     'Redis cache 1',          '',                  null,         null],
        [4, '10.10.2.41',  'cache-lon-02',   'AppTeam',  'used',     'Redis cache 2',          '',                  null,         null],
        [4, '10.10.2.50',  'storage-lon-01', 'Infra',    'used',     'NFS storage',            '',                  null,         null],
        [4, '10.10.2.51',  'storage-lon-02', 'Infra',    'used',     'NFS storage replica',    '',                  null,         null],
        [4, '10.10.2.100', 'backup-lon-01',  'Infra',    'used',     'Backup server',          '',                  null,         null],
        [4, '10.10.2.200', '',               '',         'free',     '',                        '',                  null,         null],
        [4, '10.10.2.201', '',               '',         'free',     '',                        '',                  null,         null],
        [4, '10.10.2.202', '',               '',         'free',     '',                        '',                  null,         null],
        // 10.10.3.0/27 — London DMZ (id=28..37)
        [5, '10.10.3.1',   'fw-lon-dmz',     'Security', 'used',     'DMZ firewall inside',    '00:50:56:a1:b2:c3', null,         3],
        [5, '10.10.3.2',   'proxy-lon-01',   'Security', 'used',     'Squid proxy',            '00:50:56:a1:b2:c4', null,         3],
        [5, '10.10.3.3',   'proxy-lon-02',   'Security', 'used',     'Squid proxy standby',    '00:50:56:a1:b2:c5', null,         3],
        [5, '10.10.3.4',   'waf-lon-01',     'Security', 'used',     'WAF node 1',             '',                  '2026-12-31', null],
        [5, '10.10.3.5',   'waf-lon-02',     'Security', 'used',     'WAF node 2',             '',                  '2026-12-31', null],
        [5, '10.10.3.6',   'mailgw-lon-01',  'Infra',    'used',     'Mail gateway',           '',                  null,         null],
        [5, '10.10.3.10',  'vpn-lon-01',     'NetOps',   'used',     'VPN concentrator',       '',                  null,         1],
        [5, '10.10.3.20',  '',               '',         'reserved', 'Future load balancer',   '',                  null,         null],
        [5, '10.10.3.21',  '',               '',         'reserved', 'Future load balancer',   '',                  null,         null],
        [5, '10.10.3.30',  '',               '',         'free',     '',                        '',                  null,         null],
        // 10.20.1.0/24 — New York servers (id=38..45)
        [7, '10.20.1.1',   'gw-nyc-srv',     'NetOps',   'used',     'NY server gateway',      '',                  null,         null],
        [7, '10.20.1.10',  'web-nyc-01',     'WebTeam',  'used',     'Web server NY 1',        '',                  '2027-03-31', null],
        [7, '10.20.1.11',  'web-nyc-02',     'WebTeam',  'used',     'Web server NY 2',        '',                  '2027-03-31', null],
        [7, '10.20.1.20',  'app-nyc-01',     'AppTeam',  'used',     'App server NY 1',        '',                  null,         null],
        [7, '10.20.1.21',  'app-nyc-02',     'AppTeam',  'used',     'App server NY 2',        '',                  null,         null],
        [7, '10.20.1.30',  'db-nyc-01',      'DBA',      'used',     'NY database',            '',                  null,         2],
        [7, '10.20.1.40',  'backup-nyc-01',  'Infra',    'used',     'NY backup server',       '',                  null,         null],
        [7, '10.20.1.200', '',               '',         'free',     '',                        '',                  null,         null],
        // 10.20.2.0/24 — New York management (id=46..49)
        [8, '10.20.2.1',   'gw-nyc-mgmt',   'NetOps',   'used',     'NY mgmt gateway',        '',                  null,         1],
        [8, '10.20.2.10',  'mon-nyc-01',    'NetOps',   'used',     'NY monitoring',           '',                  null,         null],
        [8, '10.20.2.20',  'ntp-nyc-01',    'NetOps',   'used',     'NY NTP',                  '',                  null,         null],
        [8, '10.20.2.30',  'dns-nyc-01',    'NetOps',   'used',     'NY DNS primary',          '',                  null,         null],
        // 172.16.1.0/24 — Sydney servers (id=50..54)
        [10, '172.16.1.1',  'gw-syd-srv',   'NetOps',   'used',     'Sydney server gateway',  '',                  null,         null],
        [10, '172.16.1.10', 'web-syd-01',   'WebTeam',  'used',     'Sydney web server',      '',                  null,         null],
        [10, '172.16.1.20', 'app-syd-01',   'AppTeam',  'used',     'Sydney app server',      '',                  null,         null],
        [10, '172.16.1.30', 'db-syd-01',    'DBA',      'used',     'Sydney database',        '',                  null,         null],
        [10, '172.16.1.100','',             '',          'free',     '',                        '',                  null,         null],
        ] as [$sid, $ip, $hn, $ow, $st, $nt, $mac, $exp, $cid]) {
        $bin = inet_pton($ip);
        if ($bin === false) throw new \RuntimeException("inet_pton failed on $ip");
        // #379/#410: bind ip_bin via ipam_bind_binary() (PARAM_LOB) so demo
        // seed rows are BLOB affinity from the start. Other params use
        // bindValue with explicit PARAM_* so the prepare's positional ?
        // placeholders bind cleanly (no execute(array) shorthand).
        $ai->bindValue(1,  $sid, PDO::PARAM_INT);
        $ai->bindValue(2,  $ip,  PDO::PARAM_STR);
        ipam_bind_binary($ai, 3, $bin);
        $ai->bindValue(4,  $hn,  PDO::PARAM_STR);
        $ai->bindValue(5,  $ow,  PDO::PARAM_STR);
        $ai->bindValue(6,  $st,  PDO::PARAM_STR);
        $ai->bindValue(7,  $nt,  PDO::PARAM_STR);
        $ai->bindValue(8,  $mac, PDO::PARAM_STR);
        $ai->bindValue(9,  $exp, $exp === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
        $ai->bindValue(10, $cid, $cid === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
        $ai->execute();
    }

    // --- Address tags ---
    // db-lon-01 id=17: Critical(3), Monitored(4) | db-lon-02 id=18: Monitored(4) | fw-lon-dmz id=28: Critical(3)
    //
    // We look up the target IDs by IP rather than hard-coding them because
    // MySQL and SQLite can disagree on the starting value and increment of
    // AUTO_INCREMENT under some configurations (especially when a schema
    // file has pre-populated another table with explicit IDs — which is
    // exactly what v2.10.0 schema.mysql.sql does for schema_migrations).
    // Locking the address_tags fixtures to the actual inserted row IDs
    // keeps the demo fixture engine-agnostic.
    $idByIp = [];
    $idSt = $db->prepare("SELECT id, ip FROM addresses WHERE ip IN ('10.10.2.30','10.10.2.31','10.10.3.1')");
    $idSt->execute();
    /** @var list<array<string, mixed>> $idRows */
    $idRows = $idSt->fetchAll();
    foreach ($idRows as $r) {
        $idByIp[to_str($r['ip'])] = to_int($r['id']);
    }
    $at = $db->prepare("INSERT INTO address_tags (address_id, tag_id) VALUES (?,?)");
    foreach ([
        // db-lon-01 → Critical + Monitored
        [$idByIp['10.10.2.30'] ?? 0, 3],
        [$idByIp['10.10.2.30'] ?? 0, 4],
        // db-lon-02 → Monitored
        [$idByIp['10.10.2.31'] ?? 0, 4],
        // fw-lon-dmz → Critical
        [$idByIp['10.10.3.1']  ?? 0, 3],
        ] as $t) {
        if ($t[0] > 0) $at->execute($t);
    }

    // --- API Keys ---
    $ak = $db->prepare(
        "INSERT INTO api_keys (name, key_hash, is_active, created_by) VALUES (?,?,?,?)"
    );
    $ak->execute(['Monitoring (active)',   hash('sha256', 'demo-api-key-monitoring-1234567890abcdef'), 1, 'demo']);
    $ak->execute(['Old script (inactive)', hash('sha256', 'demo-api-key-old-script-0987654321fedcba'), 0, 'demo']);

    // --- Audit log (backdated) ---
    // Compute the backdated created_at timestamp in PHP so the SQL stays
    // engine-agnostic. The last tuple element remains a human-readable
    // offset string ('-30 days', '-5 days', '-0 seconds', etc.) that
    // strtotime() parses directly, and we format the result as ISO
    // 'YYYY-MM-DD HH:MM:SS' UTC which both SQLite TEXT storage and
    // MySQL DATETIME accept.
    $al = $db->prepare(
        "INSERT INTO audit_log (action, entity_type, entity_id, username, ip, details, created_at)
         VALUES (?,?,?,?,?,?,?)"
    );
    foreach ([
        ['auth.login',        'user',    1,    'demo',          '192.168.1.100', 'login ok',                               '-30 days'],
        ['subnet.create',     'subnet',  3,    'demo',          '192.168.1.100', 'cidr=10.10.1.0/24',                      '-29 days'],
        ['subnet.create',     'subnet',  4,    'demo',          '192.168.1.100', 'cidr=10.10.2.0/24',                      '-29 days'],
        ['address.create',    'address', 1,    'demo',          '192.168.1.100', 'ip=10.10.1.1 subnet_id=3',               '-28 days'],
        ['address.create',    'address', 2,    'demo',          '192.168.1.100', 'ip=10.10.1.2 subnet_id=3',               '-28 days'],
        ['user.create',       'user',    2,    'demo',          '192.168.1.100', 'username=readonly-user role=readonly',   '-27 days'],
        ['user.create',       'user',    3,    'demo',          '192.168.1.100', 'username=netops-user role=netops',        '-27 days'],
        ['auth.login',        'user',    2,    'readonly-user', '10.10.1.55',    'login ok',                               '-26 days'],
        ['address.update',    'address', 11,   'demo',          '192.168.1.100', 'hostname=web-lon-01',                    '-25 days'],
        ['address.update',    'address', 12,   'demo',          '192.168.1.100', 'hostname=web-lon-02',                    '-25 days'],
        ['subnet.create',     'subnet',  5,    'demo',          '192.168.1.100', 'cidr=10.10.3.0/27',                      '-24 days'],
        ['address.create',    'address', 28,   'demo',          '192.168.1.100', 'ip=10.10.3.1 subnet_id=5',               '-23 days'],
        ['apikey.create',     'api_key', 1,    'demo',          '192.168.1.100', 'name=Monitoring (active)',                '-22 days'],
        ['apikey.create',     'api_key', 2,    'demo',          '192.168.1.100', 'name=Old script (inactive)',              '-22 days'],
        ['apikey.deactivate', 'api_key', 2,    'demo',          '192.168.1.100', '',                                       '-21 days'],
        ['site.create',       'site',    2,    'demo',          '192.168.1.100', 'name=New York DC',                       '-20 days'],
        ['site.create',       'site',    3,    'demo',          '192.168.1.100', 'name=Sydney Office',                     '-20 days'],
        ['auth.login',        'user',    3,    'netops-user',   '10.20.1.55',    'login ok',                               '-19 days'],
        ['address.create',    'address', 38,   'demo',          '192.168.1.100', 'ip=10.20.1.1 subnet_id=7',               '-18 days'],
        ['address.create',    'address', 50,   'demo',          '192.168.1.100', 'ip=172.16.1.1 subnet_id=10',             '-17 days'],
        ['vlan.create',       'vlan',    1,    'demo',          '192.168.1.100', 'vlan_id=10 name=Management',             '-16 days'],
        ['vrf.create',        'vrf',     2,    'demo',          '192.168.1.100', 'name=MGMT-VRF rd=65000:100',             '-16 days'],
        ['contact.create',    'contact', 1,    'demo',          '192.168.1.100', 'name=Alice Smith',                       '-15 days'],
        ['contact.create',    'contact', 2,    'demo',          '192.168.1.100', 'name=Bob Jones',                         '-15 days'],
        ['auth.login_failed', 'user',    null, '',              '203.0.113.50',  'username=hacker',                        '-15 days'],
        ['auth.login_failed', 'user',    null, '',              '203.0.113.50',  'username=hacker',                        '-15 days'],
        ['auth.login_blocked','user',    null, '',              '203.0.113.50',  'ip=203.0.113.50',                        '-15 days'],
        ['tag.create',        'tag',     1,    'demo',          '192.168.1.100', 'name=Production colour=#28a745',         '-14 days'],
        ['address.update',    'address', 35,   'demo',          '192.168.1.100', 'status=reserved',                        '-10 days'],
        ['export.csv',        'address', null, 'demo',          '192.168.1.100', 'subnet_id=4',                            '-8 days'],
        ['address.create',    'address', 51,   'demo',          '192.168.1.100', 'ip=172.16.1.10 subnet_id=10',            '-5 days'],
        ['auth.login',        'user',    1,    'demo',          '192.168.1.100', 'login ok',                               '-3 days'],
        ['address.bulk_update','address',null, 'demo',          '192.168.1.100', 'subnet_id=4 selected=3 affected=3',      '-2 days'],
        ['auth.login',        'user',    1,    'demo',          '192.168.1.100', 'login ok',                               '-1 day'],
        ['auth.login',        'user',    1,    'demo',          '192.168.1.100', 'login ok',                               '-0 seconds'],
        ] as $e) {
        // Replace the human-readable offset (last element) with an
        // absolute 'YYYY-MM-DD HH:MM:SS' UTC timestamp computed in PHP.
        $offset = array_pop($e);
        $ts = strtotime((string)$offset);
        $e[] = ($ts !== false) ? gmdate('Y-m-d H:i:s', $ts) : gmdate('Y-m-d H:i:s');
        $al->execute($e);
    }

    // --- Address history ---
    // Address IDs looked up by IP so we don't hardcode AUTO_INCREMENT
    // positions (same rationale as the address_tags block above).
    // Backdated created_at timestamps computed in PHP because the SQLite
    // relative-time modifier syntax is not portable to MySQL.
    $histIds = [];
    $histIdSt = $db->prepare("SELECT id, ip FROM addresses WHERE ip IN ('10.10.1.1','10.10.2.10','10.10.2.12','10.10.2.20','10.10.3.1','10.10.3.20')");
    $histIdSt->execute();
    /** @var list<array<string, mixed>> $histIdRows */
    $histIdRows = $histIdSt->fetchAll();
    foreach ($histIdRows as $r) {
        $histIds[to_str($r['ip'])] = to_int($r['id']);
    }

    $hist = $db->prepare(
        "INSERT INTO address_history (address_id, subnet_id, ip, action, username, client_ip, before_json, after_json, created_at)
         VALUES (?,?,?,?,?,?,?,?,?)"
    );
    foreach ([
        // gw-lon-mgmt
        [$histIds['10.10.1.1']  ?? 0, 3, '10.10.1.1',  'create', 'demo', '192.168.1.100', null,
         '{"hostname":"gw-lon-mgmt","owner":"NetOps","status":"used","note":"Default gateway","mac":"aa:bb:cc:00:01:01"}',
         '-28 days'],
        // web-lon-01
        [$histIds['10.10.2.10'] ?? 0, 4, '10.10.2.10', 'create', 'demo', '192.168.1.100', null,
         '{"hostname":"","owner":"WebTeam","status":"used","note":"","mac":""}',
         '-28 days'],
        [$histIds['10.10.2.10'] ?? 0, 4, '10.10.2.10', 'update', 'demo', '192.168.1.100',
         '{"hostname":"","owner":"WebTeam","status":"used","note":"","mac":""}',
         '{"hostname":"web-lon-01","owner":"WebTeam","status":"used","note":"Web frontend 1","mac":"de:ad:be:ef:00:01","expires_at":"2027-06-30"}',
         '-25 days'],
        // web-lon-03
        [$histIds['10.10.2.12'] ?? 0, 4, '10.10.2.12', 'create', 'demo', '192.168.1.100', null,
         '{"hostname":"web-lon-03","owner":"WebTeam","status":"used","note":"Web frontend 3","mac":"de:ad:be:ef:00:03"}',
         '-28 days'],
        // app-lon-01
        [$histIds['10.10.2.20'] ?? 0, 4, '10.10.2.20', 'create', 'demo', '192.168.1.100', null,
         '{"hostname":"app-lon-01","owner":"AppTeam","status":"used","note":"Application server 1","mac":""}',
         '-28 days'],
        // fw-lon-dmz
        [$histIds['10.10.3.1']  ?? 0, 5, '10.10.3.1',  'create', 'demo', '192.168.1.100', null,
         '{"hostname":"fw-lon-dmz","owner":"Security","status":"used","note":"DMZ firewall inside","mac":"00:50:56:a1:b2:c3"}',
         '-23 days'],
        // 10.10.3.20 (future load balancer)
        [$histIds['10.10.3.20'] ?? 0, 5, '10.10.3.20', 'create', 'demo', '192.168.1.100', null,
         '{"hostname":"","owner":"","status":"free","note":"","mac":""}',
         '-23 days'],
        [$histIds['10.10.3.20'] ?? 0, 5, '10.10.3.20', 'update', 'demo', '192.168.1.100',
         '{"hostname":"","owner":"","status":"free","note":"","mac":""}',
         '{"hostname":"","owner":"","status":"reserved","note":"Future load balancer","mac":""}',
         '-10 days'],
        ] as $h) {
        if ($h[0] === 0) continue;
        // Replace the human-readable offset with an absolute UTC timestamp.
        $offset = array_pop($h);
        $ts = strtotime((string)$offset);
        $h[] = ($ts !== false) ? gmdate('Y-m-d H:i:s', $ts) : gmdate('Y-m-d H:i:s');
        $hist->execute($h);
    }
}

/* ---------------- IP helpers ---------------- */

/** @return array{version: int, network: string, prefix: int, net_bin: string}|null */
function parse_cidr(string $cidr): ?array
{
    $cidr = trim($cidr);
    if (strpos($cidr, '/') === false) return null;
    [$ip, $prefixStr] = explode('/', $cidr, 2);

    $ip = trim($ip);
    $prefixStr = trim($prefixStr);

    $ipBin = @inet_pton($ip);
    if ($ipBin === false) return null;

    $len = strlen($ipBin);
    $version = ($len === 4) ? 4 : (($len === 16) ? 6 : 0);
    if ($version === 0) return null;

    if (!ctype_digit($prefixStr)) return null;
    $prefix = (int)$prefixStr;
    $max = ($version === 4) ? 32 : 128;
    if ($prefix < 0 || $prefix > $max) return null;

    $netBin = apply_prefix_mask($ipBin, $prefix);
    $network = inet_ntop($netBin);
    if ($network === false) return null;

    return [
        'version' => $version,
        'network' => $network,
        'prefix' => $prefix,
        'net_bin' => $netBin,
    ];
}

function apply_prefix_mask(string $ipBin, int $prefix): string
{
    $len = strlen($ipBin);
    $maxBits = ($len === 4) ? 32 : 128;
    $prefix = max(0, min($prefix, $maxBits));

    $fullBytes = intdiv($prefix, 8);
    $remBits = $prefix % 8;

    $out = '';
    for ($i = 0; $i < $len; $i++) {
        $b = ord($ipBin[$i]);
        if ($i < $fullBytes) $out .= chr($b);
        elseif ($i === $fullBytes && $remBits !== 0) {
            $mask = (0xFF << (8 - $remBits)) & 0xFF;
            $out .= chr($b & $mask);
        } else $out .= chr(0);
    }
    return $out;
}

/**
 * Compute the IPv4 broadcast address (binary) for a given network+prefix.
 *
 * Returns null when the concept does not apply:
 *   - IPv6 networks (no broadcast)
 *   - /32 (single host)
 *   - /31 (RFC 3021 point-to-point; both addresses are usable)
 *
 * @param string $netBin 4-byte IPv4 network address (output of apply_prefix_mask)
 */
function ipam_compute_broadcast_bin(string $netBin, int $prefix): ?string
{
    if (strlen($netBin) !== 4) return null;       // IPv6 has no broadcast
    if ($prefix < 0 || $prefix >= 31) return null; // /31, /32 have no broadcast
    $hostBits = 32 - $prefix;
    $out = '';
    for ($i = 0; $i < 4; $i++) {
        $byteIdx = 3 - $i; // little-endian walk from LSB
        $n = ord($netBin[$byteIdx]);
        if ($hostBits >= 8) {
            $out = chr(0xFF) . $out;
            $hostBits -= 8;
        } elseif ($hostBits > 0) {
            $lowMask = (1 << $hostBits) - 1;
            $out = chr($n | $lowMask) . $out;
            $hostBits = 0;
        } else {
            $out = chr($n) . $out;
        }
    }
    return $out;
}

function ip_in_cidr(string $ip, string $network, int $prefix): bool
{
    $ipBin = @inet_pton(trim($ip));
    $netBin = @inet_pton(trim($network));
    if ($ipBin === false || $netBin === false) return false;
    if (strlen($ipBin) !== strlen($netBin)) return false;
    return hash_equals(apply_prefix_mask($ipBin, $prefix), $netBin);
}

/** @return array{ip: string, bin: string, version: int}|null */
function normalize_ip(string $ip): ?array
{
    $bin = @inet_pton(trim($ip));
    if ($bin === false) return null;
    $normalized = inet_ntop($bin);
    if ($normalized === false) return null;
    return ['ip' => $normalized, 'bin' => $bin, 'version' => (strlen($bin) === 4) ? 4 : 6];
}

function normalize_status(?string $s): string
{
    $s = strtolower(trim((string)$s));
    if ($s === '') return 'used';
    if (in_array($s, ['used','reserved','free'], true)) return $s;
    if (in_array($s, ['inuse','in-use','active'], true)) return 'used';
    if (in_array($s, ['res','reservation'], true)) return 'reserved';
    if (in_array($s, ['avail','available','unused'], true)) return 'free';
    return 'used';
}

/* ---------------- IPv4 helpers ---------------- */

function ipv4_bin_to_int(string $bin): int
{
    $unpacked = unpack('N', $bin);
    $n = $unpacked !== false ? $unpacked[1] : 0;
    return to_int($n & 0xFFFFFFFF);
}

function ipv4_int_to_bin(int $n): string
{
    $n = $n & 0xFFFFFFFF;
    return pack('N', $n);
}

function ipv4_int_to_text(int $n): string
{
    return inet_ntop(ipv4_int_to_bin($n)) ?: '';
}

function ipv4_assignable_count(int $prefix): int
{
    if ($prefix >= 32) return 1;
    if ($prefix === 31) return 2;
    $hostBits = 32 - $prefix;
    $total = ($hostBits === 32) ? 4294967296 : (1 << $hostBits);
    $assignable = $total - 2;
    return ($assignable > 0) ? (int)$assignable : 0;
}

/**
 * Find the first unassigned IPv4 host address in a subnet.
 * Returns the IP as text, or null if none available.
 */
function find_next_available_ipv4(PDO $db, int $subnetId, string $network, int $prefix): ?string
{
    if ($prefix > 32 || $prefix < 8) return null;
    $networkBin = inet_pton($network);
    if ($networkBin === false) return null;
    $netInt = ipv4_bin_to_int($networkBin);
    $first  = ($prefix >= 31) ? $netInt : $netInt + 1;
    $last   = ($prefix >= 31) ? $netInt + ((1 << (32 - $prefix)) - 1)
                              : $netInt + ((1 << (32 - $prefix)) - 1) - 1;

    // Fetch all used IPs in this subnet as a set
    $st = $db->prepare("SELECT ip FROM addresses WHERE subnet_id = :sid");
    $st->execute([':sid' => $subnetId]);
    $used = [];
    foreach ($st->fetchAll() as $r) $used[to_str($r['ip'])] = true;

    for ($i = $first; $i <= $last; $i++) {
        $ip = ipv4_int_to_text($i);
        if (!isset($used[$ip])) return $ip;
    }
    return null;
}

function ipv4_broadcast_int(int $networkInt, int $prefix): int
{
    $hostBits = 32 - $prefix;
    if ($hostBits <= 0) return $networkInt;
    $hostMask = ($hostBits === 32) ? 0xFFFFFFFF : ((1 << $hostBits) - 1);
    return to_int(($networkInt | $hostMask) & 0xFFFFFFFF);
}

/* ---------------- IPv6 enumeration helpers ---------------- */

/**
 * Increment a 16-byte IPv6 binary address by 1.
 * Returns all-zeros if the address overflows (all-0xFF).
 */
function ipv6_bin_increment(string $bin): string
{
    /** @var array<int, int> $bytes */
    $bytes = array_values(unpack('C16', $bin) ?: []);
    for ($i = 15; $i >= 0; $i--) {
        if ($bytes[$i] < 255) {
            $bytes[$i]++;
            return pack('C16', ...$bytes);
        }
        $bytes[$i] = 0;
    }
    return pack('C16', ...array_fill(0, 16, 0));
}

/**
 * Return the first $n unassigned IPv6 host addresses in a subnet.
 * Scans at most ($n + count(assigned) + 1) candidates from the first host address.
 *
 * @return list<string>
 */
function ipv6_enumerate_first_n(PDO $db, int $subnetId, string $networkBin, int $prefix, int $n): array
{
    if ($prefix >= 128) {
        $ip = inet_ntop($networkBin) ?: '';
        $st = $db->prepare("SELECT id FROM addresses WHERE subnet_id = :sid AND ip = :ip LIMIT 1");
        $st->execute([':sid' => $subnetId, ':ip' => $ip]);
        return ($ip !== '' && $st->fetch() === false) ? [$ip] : [];
    }

    $st = $db->prepare("SELECT ip FROM addresses WHERE subnet_id = :sid");
    $st->execute([':sid' => $subnetId]);
    $assigned = [];
    foreach ($st->fetchAll() as $r) $assigned[to_str($r['ip'])] = true;

    $current = ipv6_bin_increment($networkBin);
    $scanLimit = $n + count($assigned) + 1;
    $result = [];

    for ($i = 0; $i < $scanLimit && count($result) < $n; $i++) {
        $ip = inet_ntop($current) ?: '';
        if ($ip !== '' && !isset($assigned[$ip])) {
            $result[] = $ip;
        }
        $current = ipv6_bin_increment($current);
    }

    return $result;
}

/* ---------------- CSV import helpers ---------------- */

/** @param IpamConfig $config */
function import_max_bytes(array $config): int
{
    $mb = to_int($config['import_csv_max_mb']);
    if ($mb < 5) $mb = 5;
    if ($mb > 50) $mb = 50;
    return $mb * 1024 * 1024;
}

function tmp_dir(): string
{
    return __DIR__ . '/data/tmp';
}

function ensure_tmp_dir(): void
{
    $d = tmp_dir();
    if (!is_dir($d)) mkdir($d, 0700, true);
}

function cleanup_tmp_import_files(int $ttlSeconds): int
{
    ensure_tmp_dir();
    $now = time();
    $deleted = 0;

    foreach (new DirectoryIterator(tmp_dir()) as $f) {
        if ($f->isDot() || !$f->isFile()) continue;
        $name = $f->getFilename();
        if (!preg_match('~^import-[a-f0-9]{16}\.csv$~', $name)) continue;

        $age = $now - $f->getMTime();
        if ($age > $ttlSeconds) {
            @unlink($f->getPathname());
            $deleted++;
        }
    }
    return $deleted;
}

/* -------- Import plan helpers -------- */

function import_plan_dir(): string
{
    return tmp_dir();
}

/** @param array<string, mixed> $plan */
function save_import_plan(array $plan): string
{
    ensure_tmp_dir();
    $path = import_plan_dir() . '/import-plan-' . bin2hex(random_bytes(8)) . '.json';
    $json = json_encode($plan, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    if ($json === false) throw new RuntimeException('Failed to encode import plan');
    if (file_put_contents($path, $json) === false) {
        throw new RuntimeException('Failed to write import plan');
    }
    @chmod($path, 0600);
    return $path;
}

/** @return array<string, mixed> */
function load_import_plan(string $path): array
{
    if (!is_file($path)) throw new RuntimeException('Import plan file not found');
    $json = file_get_contents($path);
    if ($json === false) throw new RuntimeException('Failed to read import plan');
    $data = json_decode($json, true);
    if (!is_array($data)) throw new RuntimeException('Invalid import plan');
    /** @var array<string, mixed> $data */
    return $data;
}

function delete_import_plan(string $path): void
{
    if ($path !== '' && is_file($path)) {
        @unlink($path);
    }
}

function cleanup_tmp_import_plans(int $ttlSeconds): int
{
    ensure_tmp_dir();
    $now = time();
    $deleted = 0;

    foreach (new DirectoryIterator(tmp_dir()) as $f) {
        if ($f->isDot() || !$f->isFile()) continue;
        $name = $f->getFilename();
        if (!preg_match('~^import-plan-[a-f0-9]{16}\.json$~', $name)) continue;

        $age = $now - $f->getMTime();
        if ($age > $ttlSeconds) {
            @unlink($f->getPathname());
            $deleted++;
        }
    }
    return $deleted;
}

function detect_csv_delimiter(string $sample): string
{
    $candidates = ["," , ";" , "\t" , "|"];
    $best = ",";
    $bestCount = -1;

    foreach ($candidates as $d) {
        $lines = preg_split("/\r\n|\n|\r/", $sample) ?: [];
        $counts = [];
        foreach (array_slice($lines, 0, 10) as $line) {
            if ($line === '') continue;
            $counts[] = count(str_getcsv($line, $d, '"', ''));
        }
        if (!$counts) continue;
        $avg = array_sum($counts) / count($counts);
        if ($avg > $bestCount) {
            $bestCount = $avg;
            $best = $d;
        }
    }
    return $best;
}

/** @return list<list<string>> */
function csv_read_preview(string $path, string $delimiter, int $maxRows = 20): array
{
    $fh = fopen($path, 'rb');
    if (!$fh) throw new RuntimeException("Cannot open upload");
    $rows = [];
    while (!feof($fh) && count($rows) < $maxRows) {
        $row = fgetcsv($fh, 0, $delimiter, '"', '');
        if ($row === false) break;
        $row = array_map('strval', $row);
        if (count($row) === 1 && trim($row[0]) === '') continue;
        $rows[] = $row;
    }
    fclose($fh);
    return $rows;
}

function netmask_to_prefix(string $mask): ?int
{
    $bin = @inet_pton(trim($mask));
    if ($bin === false || strlen($bin) !== 4) return null;

    $unpacked = unpack('N', $bin);
    $n = $unpacked !== false ? $unpacked[1] : 0;
    $prefix = 0;
    $seenZero = false;

    for ($i = 31; $i >= 0; $i--) {
        $bit = ($n >> $i) & 1;
        if ($bit === 1) {
            if ($seenZero) return null;
            $prefix++;
        } else {
            $seenZero = true;
        }
    }
    return $prefix;
}

/**
 * @param array{ip: string, bin: string, version: int} $normIp
 * @return array<string, mixed>|null
 */
function find_containing_subnet(PDO $db, array $normIp): ?array
{
    static $cache = [];
    $ver = to_int($normIp['version']);
    if (!isset($cache[$ver])) {
        $st = $db->prepare("SELECT id, network, prefix, ip_version FROM subnets WHERE ip_version = :v ORDER BY prefix DESC");
        $st->execute([':v' => $ver]);
        $cache[$ver] = $st->fetchAll();
    }
    foreach ($cache[$ver] as $s) {
        if (ip_in_cidr($normIp['ip'], to_str($s['network']), to_int($s['prefix']))) return $s;
    }
    return null;
}

function ensure_subnet_exists(PDO $db, string $cidr, string $description = ''): int
{
    $p = parse_cidr($cidr);
    if (!$p) throw new RuntimeException("Invalid CIDR to create: $cidr");

    $normalized = $p['network'] . '/' . $p['prefix'];

    $st = $db->prepare("SELECT id FROM subnets WHERE cidr = :c");
    $st->execute([':c' => $normalized]);
    /** @var array<string, mixed>|false $row */
    $row = $st->fetch();
    if ($row) return to_int($row['id']);

    // #379/#410: bind network_bin via ipam_bind_binary() (PARAM_LOB).
    $ins = $db->prepare("INSERT INTO subnets (cidr, ip_version, network, network_bin, prefix, description)
                         VALUES (:cidr,:ver,:net,:nb,:pre,:d)");
    $ins->bindValue(':cidr', $normalized,    PDO::PARAM_STR);
    $ins->bindValue(':ver',  $p['version'],  PDO::PARAM_INT);
    $ins->bindValue(':net',  $p['network'],  PDO::PARAM_STR);
    ipam_bind_binary($ins, ':nb', $p['net_bin']);
    $ins->bindValue(':pre',  $p['prefix'],   PDO::PARAM_INT);
    $ins->bindValue(':d',    $description,   PDO::PARAM_STR);
    $ins->execute();

    return (int)$db->lastInsertId();
}

/** @param array{ip: string, bin: string, version: int} $normIp */
function cidr_from_ip_and_prefix(array $normIp, int $prefix): string
{
    $max = ($normIp['version'] === 4) ? 32 : 128;
    if ($prefix < 0 || $prefix > $max) throw new RuntimeException("Bad prefix");
    $netBin = apply_prefix_mask($normIp['bin'], $prefix);
    return inet_ntop($netBin) . '/' . $prefix;
}

/* ---------------- Subnet overlap detection ---------------- */

/**
 * Detect parent/child relationships for a proposed CIDR against existing subnets.
 *
 * In valid CIDR math, two subnets of different prefix lengths either have a strict
 * parent/child containment relationship or are completely disjoint — partial overlap
 * is impossible. Exact duplicates are prevented by the DB UNIQUE constraint on cidr.
 *
 * Returns:
 *   'parents'  — existing subnets that contain the proposed CIDR (new is a child)
 *   'children' — existing subnets that fall inside the proposed CIDR (new is a parent)
 *
 * Both are informational warnings; neither case blocks the operation, as hierarchical
 * nesting is the expected use-case. Pass $excludeId when checking an update so the
 * subnet being edited is not compared against itself.
 *
 * @return array{parents: list<string>, children: list<string>}
 */
function detect_subnet_overlaps(PDO $db, string $cidr, ?int $excludeId = null, ?int $vrfId = null): array
{
    $p = parse_cidr($cidr);
    if (!$p) return ['parents' => [], 'children' => []];

    $ver    = to_int($p['version']);
    $prefix = to_int($p['prefix']);
    $netBin = to_str($p['net_bin']);

    // Scope overlap detection to the same VRF (NULL = global routing table).
    // SQLite's IS operator handles NULL equality correctly.
    $sql    = "SELECT id, cidr, prefix, network_bin FROM subnets WHERE ip_version = :v AND " . ipam_dialect()->null_safe_eq("vrf_id", ":vrf") . "";
    $params = [':v' => $ver, ':vrf' => $vrfId];
    if ($excludeId !== null) {
        $sql .= " AND id != :excl";
        $params[':excl'] = $excludeId;
    }
    $st = $db->prepare($sql);
    $st->execute($params);
    /** @var list<array<string, mixed>> $rows */
    $rows = $st->fetchAll();

    $parents  = [];
    $children = [];

    foreach ($rows as $row) {
        $rowPrefix = to_int($row['prefix']);
        $rowNetBin = to_str($row['network_bin']);

        if ($rowPrefix < $prefix) {
            // Candidate parent: does the existing broader subnet contain our new one?
            if (hash_equals(apply_prefix_mask($netBin, $rowPrefix), $rowNetBin)) {
                $parents[] = to_str($row['cidr']);
            }
        } elseif ($rowPrefix > $prefix) {
            // Candidate child: does our new broader subnet contain the existing one?
            if (hash_equals(apply_prefix_mask($rowNetBin, $prefix), $netBin)) {
                $children[] = to_str($row['cidr']);
            }
        }
        // Same prefix: exact duplicate — handled by DB UNIQUE constraint on cidr
    }

    return ['parents' => $parents, 'children' => $children];
}

/** @param array{parents: list<string>, children: list<string>} $overlaps */
function subnet_overlap_warning_text(array $overlaps): string
{
    $parts = [];
    if (!empty($overlaps['parents'])) {
        $list = implode(', ', $overlaps['parents']);
        $parts[] = 'nested inside: ' . $list;
    }
    if (!empty($overlaps['children'])) {
        $list = implode(', ', $overlaps['children']);
        $parts[] = 'parent of: ' . $list;
    }
    return 'Hierarchy notice — this subnet is ' . implode('; and ', $parts) . '. Verify this nesting is intentional.';
}

/* ---------------- UI helpers ---------------- */

/** @param array<string, string> $opts */
function page_header(string $title, array $opts = []): void
{
    // Still needed for the bootstrap_admin default-password warning below —
    // that is a pre-registry config-only check that stays on config.php
    // forever (see below). Everything else in this function reads through
    // ipam_setting() as of v2.7.0.
    global $config;
    $u = to_str($_SESSION['username'] ?? '');
    $role = to_str($_SESSION['role'] ?? '');
    $appName = trim(to_str(ipam_setting('branding.site_name'))) ?: 'Simple PHP IPAM';

    $extraScriptSrc = isset($opts['extra_script_src']) && $opts['extra_script_src'] !== '' ? ' ' . $opts['extra_script_src'] : '';
    $frameSrc       = isset($opts['extra_frame_src'])  && $opts['extra_frame_src']  !== '' ? " frame-src 'self' " . $opts['extra_frame_src'] . ';' : '';
    header("Content-Security-Policy: default-src 'self'; script-src 'self'{$extraScriptSrc}; style-src 'self'; style-src-attr 'unsafe-inline'; img-src 'self' data:;{$frameSrc} frame-ancestors 'none'");
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');

    echo "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>";
    echo "<title>" . e($appName) . " \u{2014} " . e($title) . "</title>";
    echo "<link rel='icon' type='image/webp' sizes='32x32' href='assets/favicon-32.webp'>";
    echo "<link rel='icon' type='image/png' sizes='32x32' href='assets/favicon-32.png'>";
    echo "<link rel='apple-touch-icon' type='image/webp' sizes='180x180' href='assets/apple-touch-icon.webp'>";
    echo "<link rel='apple-touch-icon' sizes='180x180' href='assets/apple-touch-icon.png'>";
    echo "<link rel='stylesheet' href='assets/app.css?v=2.10.0'>";
    // Expose server-side theme via meta tag so app.js can seed localStorage (CSP-safe)
    $userTheme = to_str($_SESSION['user_theme'] ?? 'auto');
    echo "<meta name='ipam-server-theme' content='" . e($userTheme) . "'>";
    echo "<script defer src='assets/app.js?v=2.10.0'></script>";
    $pageAttr = isset($opts['page']) && $opts['page'] !== ''
        ? " data-page='" . e(to_str($opts['page'])) . "'"
        : '';
    echo "</head><body{$pageAttr}>";

    echo "<div class='topbar'><div class='nav-wrap'>";
    echo "<a href='dashboard.php' class='nav-brand'>"
       . "<picture><source srcset='assets/logo.webp' type='image/webp'><img src='assets/logo.png' alt='' class='nav-logo' aria-hidden='true' width='161' height='48'></picture>"
       . "</a>";
    echo "<button class='nav-toggle' id='nav-toggle' aria-label='Open menu' aria-expanded='false' aria-controls='nav-drawer'>&#9776;</button>";
    echo "<div class='nav-links'>";
    if ($u) {
        echo "<a class='nav-pill' href='dashboard.php'>🏠 Dashboard</a>";
        echo "<a class='nav-pill' href='subnets.php'>🌐 Subnets</a>";
        echo "<a class='nav-pill' href='addresses.php'>🧾 Addresses</a>";
        echo "<a class='nav-pill nav-search-link' href='search.php'>🔎 Search <kbd class='nav-kbd'>⌘K</kbd></a>";
        echo "<a class='nav-pill' href='audit.php'>📜 Audit</a>";
        if ($role === 'admin') {
            echo "<div class='nav-dropdown'>";
            echo "<button type='button' class='nav-pill nav-dropdown-toggle'>⚙ Admin ▾</button>";
            echo "<div class='nav-dropdown-menu'>";
            echo "<a class='nav-dropdown-item' href='dhcp_pool.php'>🔒 DHCP Pools</a>";
            echo "<hr class='nav-dropdown-divider'>";
            echo "<a class='nav-dropdown-item' href='sites.php'>📍 Sites</a>";
            echo "<a class='nav-dropdown-item' href='vrfs.php'>🌐 VRFs</a>";
            echo "<a class='nav-dropdown-item' href='vlans.php'>🏷 VLANs</a>";
            echo "<a class='nav-dropdown-item' href='aggregates.php'>🗂 Aggregates</a>";
            echo "<a class='nav-dropdown-item' href='pd_pools.php'>🔷 PD Pools</a>";
            echo "<a class='nav-dropdown-item' href='tags.php'>🔖 Tags</a>";
            echo "<a class='nav-dropdown-item' href='contacts.php'>📇 Contacts</a>";
            echo "<a class='nav-dropdown-item' href='users.php'>👤 Users</a>";
            echo "<a class='nav-dropdown-item' href='api_keys.php'>🔑 API Keys</a>";
            echo "<a class='nav-dropdown-item' href='import_csv.php'>⬆ Import CSV</a>";
            echo "<a class='nav-dropdown-item' href='import_arp.php'>📡 ARP Import</a>";
            echo "<a class='nav-dropdown-item' href='db_tools.php'>🗄 Database Tools</a>";
            echo "<hr class='nav-dropdown-divider'>";
            echo "<a class='nav-dropdown-item' href='settings.php'>⚙ Settings</a>";
            echo "</div></div>";
        }
    } else {
        echo "<a class='nav-pill' href='login.php'>🔐 Login</a>";
    }
    echo "</div>";

    if ($u) {
        echo "<div class='nav-right'>";
        echo "<div class='nav-dropdown'>";
        echo "<button type='button' class='nav-pill nav-dropdown-toggle nav-user-toggle'>";
        echo e($u) . " <span class='badge badge-role-" . e($role) . "'>" . e($role) . "</span> ▾";
        echo "</button>";
        echo "<div class='nav-dropdown-menu nav-dropdown-menu--right'>";
        echo "<button type='button' class='nav-dropdown-item' id='theme-toggle'>🌓 Theme</button>";
        echo "<hr class='nav-dropdown-divider'>";
        echo "<a class='nav-dropdown-item' href='change_password.php'>🔐 Password</a>";
        echo "<a class='nav-dropdown-item' href='logout.php'>↩ Logout</a>";
        echo "</div></div>";
        echo "</div>";
    }

    echo "</div></div>";

    // Mobile nav drawer (hidden on desktop, slides in on mobile)
    echo "<div id='nav-drawer' aria-hidden='true'>";
    echo "<button class='drawer-close' aria-label='Close menu'>&#10005;</button>";
    if ($u) {
        echo "<span class='nav-drawer-section'>Navigation</span>";
        echo "<a href='dashboard.php'>&#127968; Dashboard</a>";
        echo "<a href='subnets.php'>&#127760; Subnets</a>";
        echo "<a href='addresses.php'>&#129438; Addresses</a>";
        echo "<a href='search.php'>&#128270; Search</a>";
        echo "<a href='audit.php'>&#128220; Audit</a>";
        if ($role === 'admin') {
            echo "<hr>";
            echo "<span class='nav-drawer-section'>Admin</span>";
            echo "<a href='dhcp_pool.php'>&#128274; DHCP Pools</a>";
            echo "<a href='sites.php'>&#128205; Sites</a>";
            echo "<a href='vrfs.php'>&#127760; VRFs</a>";
            echo "<a href='vlans.php'>&#127991; VLANs</a>";
            echo "<a href='tags.php'>&#128278; Tags</a>";
            echo "<a href='contacts.php'>&#128215; Contacts</a>";
            echo "<a href='users.php'>&#128100; Users</a>";
            echo "<a href='api_keys.php'>&#128273; API Keys</a>";
            echo "<a href='import_csv.php'>&#8679; Import CSV</a>";
            echo "<a href='db_tools.php'>&#128444; Database Tools</a>";
            echo "<a href='settings.php'>&#9881; Settings</a>";
        }
        echo "<hr>";
        echo "<span class='nav-drawer-section'>Account</span>";
        echo "<a href='change_password.php'>&#128272; Password</a>";
        echo "<a href='logout.php'>&#8617; Logout</a>";
    } else {
        echo "<a href='login.php'>&#128272; Login</a>";
    }
    echo "</div>";
    echo "<div class='nav-drawer-overlay'></div>";

    // ⌘K / Ctrl+K search overlay (#253)
    echo "<div id='search-overlay' role='dialog' aria-modal='true' aria-label='Quick search'>";
    echo "<div class='so-box'>";
    echo "<input id='search-overlay-input' type='search' placeholder='Search IPs, hostnames, owners…' autocomplete='off' spellcheck='false'>";
    echo "<button id='search-overlay-close' class='so-close' aria-label='Close search'>&times;</button>";
    echo "<ul id='search-overlay-list'></ul>";
    echo "<div class='so-hint'>&#x23CE; to navigate &nbsp;&middot;&nbsp; &#x2191;&#x2193; to move &nbsp;&middot;&nbsp; <kbd>Esc</kbd> to close</div>";
    echo "</div>";
    echo "</div>";

    echo "<div class='page'>";

    // Demo mode banner (non-dismissible)
    if (demo_mode_enabled()) {
        echo "<div class='admin-notice admin-notice--info text-center' role='alert'>"
           . "🧪 <strong>Demo mode</strong> — Explore freely. Destructive actions are disabled. Data resets nightly at midnight."
           . "</div>";
    }

    // MySQL experimental driver banner — admin only, dismissible (v2.10.0 #385).
    // Appears whenever db_driver=mysql is active so operators always know the
    // driver is in beta. The banner key is suffixed with IPAM_VERSION so the
    // localStorage dismiss state is per app version: upgrading the app
    // changes the key and the banner re-surfaces until dismissed on the
    // new version. Dismiss state lives only in the browser; the server
    // doesn't track it (client-side, stateless, survives the request cycle
    // without a session write).
    if ($role === 'admin' && ipam_dialect()->driver_name() === 'mysql') {
        require_once __DIR__ . '/version.php';
        $bannerKey = 'mysql-beta-' . IPAM_VERSION;
        echo "<div class='admin-notice admin-notice--warning' role='alert' data-banner='" . e($bannerKey) . "'>"
           . "⚠ <strong>MySQL driver (experimental)</strong> — MySQL support is beta in v" . e(IPAM_VERSION) . ". "
           . "Report issues at <a href='https://github.com/seanmousseau/Simple-PHP-IPAM/issues' target='_blank' rel='noopener'>the GitHub tracker</a>. "
           . "See <a href='https://github.com/seanmousseau/Simple-PHP-IPAM/blob/main/docs/install.md#mysql-experimental' target='_blank' rel='noopener'>docs/install.md</a> for current limitations. "
           . "<button type='button' class='admin-notice-dismiss' data-dismiss-banner='" . e($bannerKey) . "' aria-label='Dismiss'>✕</button>"
           . "</div>";
    }

    // Default bootstrap admin password warning (admin only)
    if ($role === 'admin') {
        if (($config['bootstrap_admin']['password'] ?? '') === 'ChangeMeNow!12345') {
            echo "<div class='admin-notice admin-notice--danger' role='alert'>"
               . "⚠ <strong>Security warning:</strong> The default bootstrap admin password is still set in <code>config.php</code>. "
               . "<a href='change_password.php'>Change your password</a> and update <code>config.php</code> before this site receives any traffic."
               . "</div>";
        }
    }

    // Config auto-population notice (shown once per session, admin only)
    if (!empty($_SESSION['config_notice']) && $role === 'admin') {
        $notice = e(to_str($_SESSION['config_notice']));
        echo "<div class='admin-notice admin-notice--info' role='alert'>"
           . "⚙ Config updated: {$notice} Review and adjust values in config.php."
           . "</div>";
        unset($_SESSION['config_notice']);
    }

    // Config write failure notice — shown when config.php is not writable (#119)
    if (!empty($_SESSION['config_unwritable']) && $role === 'admin') {
        echo "<div class='admin-notice admin-notice--danger' role='alert'>"
           . "&#9888; config.php is not writable — new configuration keys could not be saved. "
           . "Check file permissions."
           . "</div>";
        unset($_SESSION['config_unwritable']);
    }

    // Config validation warnings — shown to admins when config.php has invalid values (#236)
    if ($role === 'admin' && !empty($GLOBALS['config_warnings']) && is_array($GLOBALS['config_warnings'])) {
        foreach ($GLOBALS['config_warnings'] as $cfgWarn) {
            echo "<div class='admin-notice admin-notice--danger' role='alert'>"
               . "&#9888; <strong>Config warning:</strong> " . e(to_str($cfgWarn))
               . " Review <code>config.php</code>."
               . "</div>";
        }
    }

    // General flash messages (success, warning, danger)
    $flash = flash_get();
    if ($flash) {
        $flashClass = match ($flash['type']) {
            'success' => 'success',
            'warning' => 'warning',
            'error', 'danger' => 'danger',
            default => 'success',
        };
        echo "<p class='{$flashClass}'>" . e($flash['msg']) . "</p>";
    }

    // Update-available dismissible banner (admin only, client-side dismiss via localStorage)
    if ($role === 'admin') {
        $update = ipam_update_check($config);
        if ($update) {
            $uv  = e(to_str($update['version']));
            $url = e(to_str($update['url']));
            echo "<div class='admin-notice admin-notice--update' id='ipam-update-banner' data-version='{$uv}' role='alert'>"
               . "🚀 Simple PHP IPAM v{$uv} is available. "
               . "<a href='{$url}' target='_blank' rel='noopener'>View release</a>"
               . " &nbsp;<button type='button' class='button-secondary btn-sm' "
               . "data-dismiss-update='{$uv}'>Dismiss</button>"
               . "</div>";
        }
    }
}

function page_footer(): void
{
    global $config;
    require_once __DIR__ . '/version.php';

    echo "<hr><div class='muted footer-meta'>";
    echo "<a href='https://github.com/seanmousseau/Simple-PHP-IPAM' target='_blank' rel='noopener' class='link-plain'>"
       . "<picture><source srcset='assets/logo.webp' type='image/webp'><img src='assets/logo.png' alt='Simple PHP IPAM' width='81' height='24' class='footer-logo'></picture>"
       . "</a> v" . e(IPAM_VERSION)
       . " &middot; <a href='https://seanmousseau.github.io/Simple-PHP-IPAM/' target='_blank' rel='noopener'>Docs</a>";

    $update = ipam_update_check($config ?? []);
    if ($update) {
        $uv  = e(to_str($update['version']));
        $url = e(to_str($update['url']));
        echo " <a href='{$url}' target='_blank' rel='noopener' class='badge badge-update'>"
           . "Update available v{$uv}</a>";
    }

    // Slide-in form drawer container (populated by JS openFormDrawer())
    echo "<div id='form-drawer' role='dialog' aria-modal='true' aria-labelledby='drawer-title-text'>";
    echo "<div class='drawer-header'>";
    echo "<span class='drawer-title' id='drawer-title-text'></span>";
    echo "<button class='drawer-close-btn' aria-label='Close'>&times;</button>";
    echo "</div>";
    echo "<div id='form-drawer-body'></div>";
    echo "</div>";
    echo "<div class='form-drawer-overlay'></div>";

    echo "</div></div></body></html>";
}

/**
 * Normalise a version string to three dot-separated segments so that
 * version_compare('1.2', '1.2.0') and version_compare('1.2.1', '1.2') work
 * as expected regardless of how many segments the installed version has.
 *
 * Examples: '1.2' → '1.2.0',  'v1.2.1' → '1.2.1',  '0.15' → '0.15.0'
 */
function ipam_normalise_version(string $v): string
{
    $v = ltrim($v, 'v');
    $parts = explode('.', $v);
    while (count($parts) < 3) $parts[] = '0';
    return implode('.', $parts);
}

/**
 * Check GitHub for a newer release. Results are cached in data/tmp/ for the
 * configured TTL (default 6 hours). Network failures are silently ignored.
 *
 * Returns ['version' => '1.2.1', 'url' => 'https://...'] if newer, otherwise null.
 */
/**
 * @param IpamConfig $config Unused since v2.7.0 — kept for signature stability.
 * @return array{version: string, url: string}|null
 */
function ipam_update_check(array $config): ?array
{
    unset($config);
    // Memoize within a single request — page_header() and page_footer() both call this
    static $memo = false;
    if ($memo !== false) return $memo;

    if (!(bool)ipam_setting('update_check.enabled')) { $memo = null; return null; }

    $ttl              = max(3600, to_int(ipam_setting('update_check.ttl_seconds')));
    $notifyPrerelease = (bool)ipam_setting('update_check.notify_prerelease');

    ensure_tmp_dir();
    $cache = tmp_dir() . '/update-check.json';

    if (is_file($cache) && (time() - (int)filemtime($cache)) < $ttl) {
        $d = json_decode((string)file_get_contents($cache), true);
        if (is_array($d) && array_key_exists('checked', $d)) {
            // If the cached update version is <= the running version, we've already
            // upgraded — invalidate so the next check fetches fresh data from GitHub
            require_once __DIR__ . '/version.php';
            if (isset($d['update']['version'])
                && version_compare(ipam_normalise_version(to_str($d['update']['version'])), ipam_normalise_version(IPAM_VERSION), '<=')) {
                @unlink($cache);
            } else {
                $u = isset($d['update']) && is_array($d['update']) ? $d['update'] : null;
                $memo = ($u !== null && isset($u['version'], $u['url']))
                    ? ['version' => to_str($u['version']), 'url' => to_str($u['url'])]
                    : null;
                return $memo;
            }
        }
    }

    require_once __DIR__ . '/version.php';
    $result = null;

    try {
        // Fetch list of releases (up to 10) so we can honour notify_prerelease.
        // /releases/latest skips pre-releases entirely, so we use /releases instead.
        $url = 'https://api.github.com/repos/seanmousseau/Simple-PHP-IPAM/releases?per_page=10';
        $ctx = stream_context_create(['http' => [
            'timeout' => 5,
            'ignore_errors' => true,
            'header' => "User-Agent: Simple-PHP-IPAM/" . IPAM_VERSION . "\r\n"
                      . "Accept: application/vnd.github+json\r\n",
        ]]);
        $raw = @file_get_contents($url, false, $ctx);
        if ($raw !== false && $raw !== '') {
            $releases = json_decode($raw, true);
            if (is_array($releases)) {
                foreach ($releases as $rel) {
                    if (!is_array($rel)) continue;
                    if (!empty($rel['draft'])) continue;
                    if (!empty($rel['prerelease']) && !$notifyPrerelease) continue;
                    if (empty($rel['tag_name'])) continue;

                    $latest = ltrim(to_str($rel['tag_name']), 'v');
                    if (version_compare(ipam_normalise_version($latest), ipam_normalise_version(IPAM_VERSION), '>')) {
                        $result = [
                            'version'    => $latest,
                            'url'        => to_str($rel['html_url'] ?? ''),
                            'prerelease' => !empty($rel['prerelease']),
                        ];
                    }
                    break; // releases are newest-first; first match wins
                }
            }
        }
    } catch (Throwable) {
        // Non-critical — silently skip on network failure
    }

    @file_put_contents($cache, json_encode(['checked' => time(), 'update' => $result]));
    @chmod($cache, 0600);
    $memo = $result;
    return $result;
}

/**
 * Find the site_id a subnet should inherit from its tightest parent.
 * Returns null if no parent exists or no parent has a site assigned.
 */
function find_parent_site_id(PDO $db, string $cidr, ?int $excludeId = null, ?int $vrfId = null): ?int
{
    $overlaps = detect_subnet_overlaps($db, $cidr, $excludeId, $vrfId);
    if (empty($overlaps['parents'])) return null;

    $placeholders = implode(',', array_fill(0, count($overlaps['parents']), '?'));
    $vrfEq = ipam_dialect()->null_safe_eq('vrf_id', '?');
    $st = $db->prepare(
        "SELECT site_id FROM subnets
         WHERE cidr IN ($placeholders) AND site_id IS NOT NULL AND $vrfEq
         ORDER BY prefix DESC LIMIT 1"
    );
    $st->execute(array_merge($overlaps['parents'], [$vrfId]));
    /** @var array<string, mixed>|false $row */
    $row = $st->fetch();
    return $row ? to_int($row['site_id']) : null;
}

/* ============================================================
 * OIDC — Authorization Code + PKCE (pure PHP, no dependencies)
 * ============================================================ */

/**
 * @param IpamConfig $config Unused since v2.7.0 — kept for back-compat with
 *                           existing callers. Reads go through ipam_setting()
 *                           which falls back to $GLOBALS['config'] on a miss,
 *                           so legacy config.php-only installs still work.
 */
function oidc_enabled(array $config): bool
{
    unset($config); // keep the signature stable; body now reads through ipam_setting()
    return (bool)ipam_setting('oidc.enabled')
        && to_str(ipam_setting('oidc.client_id'))     !== ''
        && to_str(ipam_setting('oidc.client_secret')) !== ''
        && to_str(ipam_setting('oidc.discovery_url')) !== ''
        && to_str(ipam_setting('oidc.redirect_uri'))  !== '';
}

/**
 * Fetch and cache the IdP's OpenID Connect discovery document.
 * Appends /.well-known/openid-configuration if the URL doesn't already
 * contain that path.
 */
/**
 * @param IpamConfig $config Unused since v2.7.0 — kept for signature stability.
 * @return array<string, mixed>
 */
function oidc_discovery(array $config): array
{
    unset($config);
    $base = rtrim(to_str(ipam_setting('oidc.discovery_url')), '/');
    if ($base === '') throw new RuntimeException('OIDC discovery_url not set');

    $url = (str_contains($base, '.well-known')) ? $base : $base . '/.well-known/openid-configuration';

    ensure_tmp_dir();
    $cache = tmp_dir() . '/oidc-disc-' . md5($url) . '.json';

    if (is_file($cache) && (time() - (int)filemtime($cache)) < 3600) {
        $d = json_decode((string)file_get_contents($cache), true);
        if (is_array($d) && !empty($d['authorization_endpoint'])) {
            /** @var array<string, mixed> $d */
            return $d;
        }
    }

    $raw = oidc_http_get($url);
    $d   = json_decode($raw, true);
    if (!is_array($d) || empty($d['authorization_endpoint'])) {
        throw new RuntimeException('Invalid OIDC discovery document from ' . $url);
    }
    /** @var array<string, mixed> $d */

    file_put_contents($cache, json_encode($d));
    @chmod($cache, 0600);
    return $d;
}

/**
 * Fetch and cache the IdP's JSON Web Key Set.
 * Pass $forceRefresh = true to bypass the cache (used after a verify failure
 * to handle key rotation).
 */
/** @return list<mixed> */
function oidc_jwks(string $jwksUri, bool $forceRefresh = false): array
{
    ensure_tmp_dir();
    $cache = tmp_dir() . '/oidc-jwks-' . md5($jwksUri) . '.json';

    if (!$forceRefresh && is_file($cache) && (time() - (int)filemtime($cache)) < 3600) {
        $d = json_decode((string)file_get_contents($cache), true);
        if (is_array($d) && !empty($d['keys'])) return array_values((array)$d['keys']);
    }

    $raw = oidc_http_get($jwksUri);
    $d   = json_decode($raw, true);
    if (!is_array($d) || !isset($d['keys'])) {
        throw new RuntimeException('Invalid JWKS from ' . $jwksUri);
    }

    file_put_contents($cache, json_encode($d));
    @chmod($cache, 0600);
    return array_values((array)$d['keys']);
}

/** HTTP GET via file_get_contents with a short timeout. */
function oidc_http_get(string $url): string
{
    $ctx = stream_context_create([
        'http' => ['timeout' => 10, 'ignore_errors' => true],
        'ssl'  => ['verify_peer' => true, 'verify_peer_name' => true],
    ]);
    $raw = @file_get_contents($url, false, $ctx, 0, 1048576);
    if ($raw === false || $raw === '') {
        throw new RuntimeException('HTTP GET failed for ' . $url);
    }
    return $raw;
}

/**
 * POST application/x-www-form-urlencoded and return decoded JSON array.
 *
 * @param array<string, string> $params
 * @return array<string, mixed>
 */
function oidc_http_post(string $url, array $params): array
{
    $body = http_build_query($params);
    $ctx  = stream_context_create([
        'http' => [
            'method'        => 'POST',
            'header'        => "Content-Type: application/x-www-form-urlencoded\r\n"
                             . "Content-Length: " . strlen($body) . "\r\n",
            'content'       => $body,
            'timeout'       => 15,
            'ignore_errors' => true,
        ],
        'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
    ]);
    $raw = @file_get_contents($url, false, $ctx, 0, 1048576);
    if ($raw === false) throw new RuntimeException('Token endpoint request failed');
    $d = json_decode($raw, true);
    if (!is_array($d)) throw new RuntimeException('Invalid JSON from token endpoint');
    /** @var array<string, mixed> $d */
    if (!empty($d['error'])) {
        throw new RuntimeException('Token endpoint error: ' . to_str($d['error'])
            . (isset($d['error_description']) ? ' — ' . to_str($d['error_description']) : ''));
    }
    return $d;
}

/* ---- PKCE ---- */

function base64url_encode(string $bytes): string
{
    return rtrim(strtr(base64_encode($bytes), '+/', '-_'), '=');
}

function base64url_decode(string $s): string
{
    $s = strtr($s, '-_', '+/');
    $pad = strlen($s) % 4;
    if ($pad) $s .= str_repeat('=', 4 - $pad);
    $result = base64_decode($s, true);
    if ($result === false) throw new RuntimeException('Invalid base64url string');
    return $result;
}

/**
 * Generate a PKCE verifier and S256 challenge pair.
 * @return array{verifier: string, challenge: string}
 */
function oidc_pkce_pair(): array
{
    $verifier  = base64url_encode(random_bytes(32));
    $challenge = base64url_encode(hash('sha256', $verifier, true));
    return ['verifier' => $verifier, 'challenge' => $challenge];
}

/* ---- JWT / JWK verification ---- */

/**
 * Decode and verify an RS256/RS384/RS512 signed ID token.
 * Returns the verified payload claims array.
 *
 * @param list<mixed> $jwks                  Keys from the IdP's JWKS endpoint
 * @param array<string, string> $expect       Claims to validate: iss, aud, nonce
 * @return array<string, mixed>
 */
function oidc_verify_id_token(string $idToken, array $jwks, array $expect): array
{
    $parts = explode('.', $idToken);
    if (count($parts) !== 3) throw new RuntimeException('Malformed JWT');

    [$hdrB64, $payB64, $sigB64] = $parts;

    $header  = json_decode(base64url_decode($hdrB64), true);
    $payload = json_decode(base64url_decode($payB64), true);
    if (!is_array($header) || !is_array($payload)) {
        throw new RuntimeException('JWT header/payload decoding failed');
    }

    $alg = to_str($header['alg'] ?? '');
    $algMap = ['RS256' => OPENSSL_ALGO_SHA256, 'RS384' => OPENSSL_ALGO_SHA384, 'RS512' => OPENSSL_ALGO_SHA512];
    if (!isset($algMap[$alg])) {
        throw new RuntimeException("Unsupported JWT alg: $alg");
    }

    // Find the matching JWK
    $kid = $header['kid'] ?? null;
    $jwk = null;
    foreach ($jwks as $k) {
        if (!is_array($k) || ($k['kty'] ?? '') !== 'RSA') continue;
        if ($kid !== null && ($k['kid'] ?? '') !== $kid) continue;
        $jwk = $k;
        break;
    }
    if ($jwk === null) {
        throw new RuntimeException('No matching RSA JWK for kid=' . to_str($kid ?? 'none'));
    }

    $pem    = jwk_rsa_to_pem($jwk);
    $pubKey = openssl_pkey_get_public($pem);
    if ($pubKey === false) throw new RuntimeException('Failed to import JWK public key');

    $sig    = base64url_decode($sigB64);
    $result = openssl_verify($hdrB64 . '.' . $payB64, $sig, $pubKey, $algMap[$alg]);
    if ($result !== 1) throw new RuntimeException('JWT signature invalid');

    // Standard claim validation
    $now = time();
    if (isset($payload['exp']) && to_int($payload['exp']) < $now - 60) {
        throw new RuntimeException('ID token has expired');
    }
    if (isset($payload['iat']) && to_int($payload['iat']) > $now + 60) {
        throw new RuntimeException('ID token iat is in the future');
    }
    if (isset($expect['iss']) && ($payload['iss'] ?? '') !== $expect['iss']) {
        throw new RuntimeException('ID token issuer mismatch');
    }
    if (isset($expect['aud'])) {
        $aud   = $payload['aud'] ?? '';
        $audOk = (is_string($aud) && $aud === $expect['aud'])
              || (is_array($aud)  && in_array($expect['aud'], $aud, true));
        if (!$audOk) throw new RuntimeException('ID token audience mismatch');
    }
    if (isset($expect['nonce']) && ($payload['nonce'] ?? '') !== $expect['nonce']) {
        throw new RuntimeException('ID token nonce mismatch');
    }

    return $payload;
}

/**
 * Convert an RSA JWK (n, e fields) to a PEM-encoded public key.
 * Builds the DER SubjectPublicKeyInfo structure manually so we have
 * no dependency on ext-gmp or any JOSE library.
 */
/** @param array<string, mixed> $jwk */
function jwk_rsa_to_pem(array $jwk): string
{
    $n = base64url_decode(to_str($jwk['n'] ?? ''));
    $e = base64url_decode(to_str($jwk['e'] ?? ''));
    if ($n === '' || $e === '') throw new RuntimeException('JWK missing n or e');

    // DER integers must not have a leading 1-bit (would be interpreted as negative)
    if (ord($n[0]) & 0x80) $n = "\x00" . $n;
    if (ord($e[0]) & 0x80) $e = "\x00" . $e;

    $intN   = "\x02" . der_len(strlen($n)) . $n;
    $intE   = "\x02" . der_len(strlen($e)) . $e;
    $rsaSeq = "\x30" . der_len(strlen($intN) + strlen($intE)) . $intN . $intE;

    // AlgorithmIdentifier for rsaEncryption (OID 1.2.840.113549.1.1.1) with NULL params
    $oid   = "\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x01\x05\x00";
    $algId = "\x30" . der_len(strlen($oid)) . $oid;

    // BIT STRING: 0x00 unused-bits prefix + DER RSAPublicKey
    $bitStr = "\x03" . der_len(strlen($rsaSeq) + 1) . "\x00" . $rsaSeq;

    // SubjectPublicKeyInfo SEQUENCE
    $spki = "\x30" . der_len(strlen($algId) + strlen($bitStr)) . $algId . $bitStr;

    return "-----BEGIN PUBLIC KEY-----\n"
         . chunk_split(base64_encode($spki), 64, "\n")
         . "-----END PUBLIC KEY-----\n";
}

/** Encode an ASN.1 DER length. */
function der_len(int $len): string
{
    if ($len < 0x80) return chr($len);
    if ($len < 0x100) return "\x81" . chr($len);
    return "\x82" . chr($len >> 8) . chr($len & 0xFF);
}

// ---------------------------------------------------------------------------
// Network scanning — v2.3.0 (#319, #320, #321, #322, #323, #324)
// ---------------------------------------------------------------------------

/**
 * Probe a single IP via ICMP ping.
 *
 * Uses the system `ping` binary (available on Linux, macOS, BSD).
 * The IP MUST be validated by normalize_ip() before this call is made.
 *
 * @return int|null  Round-trip latency in milliseconds parsed from ping output,
 *                   or null if the host did not respond or ICMP is unavailable.
 *                   Returns null and emits an error_log entry when CAP_NET_RAW
 *                   is missing (ping exit code 2 — permission denied).
 */
function ipam_probe_icmp(string $ip, int $timeoutMs = 1000): ?int
{
    // Detect OS for the correct timeout flag
    $isWindows = stripos(PHP_OS, 'WIN') === 0;
    if ($isWindows) return null; // not supported

    $isMac = stripos(PHP_OS, 'Darwin') === 0;
    $timeoutSec = max(1, (int) round($timeoutMs / 1000));

    if ($isMac) {
        // macOS: -W <milliseconds>
        $cmd = ['ping', '-c1', '-W' . $timeoutMs, $ip];
    } else {
        // Linux/BSD: -W <seconds>
        $cmd = ['ping', '-c1', '-W' . $timeoutSec, $ip];
    }

    $desc = [1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
    $proc = @proc_open($cmd, $desc, $pipes);
    if (!is_resource($proc)) return null;

    // Read stdout/stderr to EOF *before* closing pipes. Closing the read end
    // while ping is still writing causes SIGPIPE, which makes ping exit non-zero
    // even when the host responded — producing false "host down" results.
    $stdout = (string) stream_get_contents($pipes[1]);
    stream_get_contents($pipes[2]); // drain stderr
    fclose($pipes[1]);
    fclose($pipes[2]);

    $exitCode = proc_close($proc);

    if ($exitCode === 2) {
        // Permission denied — CAP_NET_RAW capability not available (common in
        // Docker containers). Log once so operators know; return null so the
        // scan records the address as non-responsive rather than silently
        // masking the capability failure.
        error_log('ipam_probe_icmp: ping exited with code 2 (permission denied) — '
            . 'ensure CAP_NET_RAW is available (e.g. cap_add: [NET_RAW] in Docker Compose)');
        return null;
    }

    if ($exitCode !== 0) return null; // host did not respond or timed out

    // Parse actual RTT from ping stdout: matches "time=1.23 ms" or "time<1.23 ms"
    // This is the true round-trip time, not wall-clock process duration.
    if (preg_match('/time[=<]([\d.]+)\s*ms/i', $stdout, $m)) {
        return max(0, (int) round((float) $m[1]));
    }

    // Ping reported success but stdout had no RTT line (unusual) — return 0.
    return 0;
}

/**
 * Probe a single IP via TCP connection.
 *
 * The IP MUST be validated by normalize_ip() before this call is made.
 *
 * @return int|null  Connection latency in milliseconds, or null on failure.
 */
function ipam_probe_tcp(string $ip, int $port, int $timeoutMs = 1000): ?int
{
    $timeout = $timeoutMs / 1000.0;
    $start = microtime(true);
    $sock = @fsockopen($ip, $port, $errno, $errstr, $timeout);
    if (!is_resource($sock)) return null;
    $latency = (int) round((microtime(true) - $start) * 1000);
    fclose($sock);
    return $latency;
}

/**
 * Scan all registered addresses in a subnet and persist the results.
 *
 * @param  string   $method   'icmp' | 'tcp' | 'both'
 * @param  int|null $tcpPort  TCP port to probe when method is 'tcp' or 'both'
 * @param  int      $staleThreshold  Consecutive misses before marking address stale (default: 3)
 * @return array{scanned:int, up:int, down:int, stale_marked:int}
 */
/**
 * Return the reserved binary IPs for a subnet (network + IPv4 broadcast).
 *
 * @return array{network:?string, broadcast:?string}
 */
function ipam_subnet_reserved_bins(PDO $db, int $subnetId): array
{
    $st = $db->prepare("SELECT cidr FROM subnets WHERE id = :id");
    $st->execute([':id' => $subnetId]);
    $row = $st->fetch();
    if (!is_array($row)) {
        return ['network' => null, 'broadcast' => null];
    }
    $cidr = to_str($row['cidr'] ?? '');
    if ($cidr === '') {
        return ['network' => null, 'broadcast' => null];
    }
    $parsed = parse_cidr($cidr);
    if ($parsed === null) {
        return ['network' => null, 'broadcast' => null];
    }
    return [
        'network'   => $parsed['net_bin'],
        'broadcast' => ipam_compute_broadcast_bin($parsed['net_bin'], $parsed['prefix']),
    ];
}

/**
 * @return array{scanned:int, up:int, down:int, skipped:int, stale_marked:int}
 */
function ipam_scan_subnet(PDO $db, int $subnetId, string $method, ?int $tcpPort, int $staleThreshold = 3): array
{
    // Normalise and validate inputs
    if (!in_array($method, ['icmp', 'tcp', 'both'], true)) $method = 'icmp';
    if (in_array($method, ['tcp', 'both'], true) && ($tcpPort === null || $tcpPort < 1 || $tcpPort > 65535)) {
        // Invalid TCP port — fall back to ICMP-only to avoid false-stale marking
        $method = 'icmp';
        $tcpPort = null;
    }
    // After validation: if method needs TCP, $tcpPort is a valid port integer
    $validTcpPort = ($method === 'tcp' || $method === 'both') ? (int) $tcpPort : 0;

    // Reserved IPs for this subnet (network + IPv4 broadcast). Excluded from scan
    // targets: probing network/broadcast produces misleading results and some hosts
    // respond to broadcast pings. IPv6 and IPv4 /31, /32 have no reserved set.
    $reserved = ipam_subnet_reserved_bins($db, $subnetId);

    // Load all addresses in the subnet
    $st = $db->prepare("SELECT id, ip, ip_bin FROM addresses WHERE subnet_id = :sid ORDER BY ip_bin");
    $st->execute([':sid' => $subnetId]);
    $addresses = $st->fetchAll();

    $stats = ['scanned' => 0, 'up' => 0, 'down' => 0, 'skipped' => 0, 'stale_marked' => 0];
    $insert = $db->prepare("
        INSERT INTO scan_results (subnet_id, address_id, ip, method, is_up, latency_ms, scanned_at)
        VALUES (:sid, :aid, :ip, :method, :is_up, :lat, " . ipam_dialect()->now() . ")
    ");
    $updateSeen = $db->prepare("
        UPDATE addresses SET last_seen_at = " . ipam_dialect()->now() . ", is_stale = 0 WHERE id = :id
    ");

    foreach ($addresses as $row) {
        $ip = is_string($row['ip']) ? $row['ip'] : '';
        $addrId = is_int($row['id']) ? $row['id'] : (int) $row['id'];
        $ipBin = isset($row['ip_bin']) && is_string($row['ip_bin']) ? $row['ip_bin'] : '';

        // Skip the subnet's reserved IPs (network + IPv4 broadcast). These must
        // never be probed — some hosts respond to broadcast ICMP, producing
        // misleading up/down results.
        if ($ipBin !== '') {
            if ($reserved['network']   !== null && hash_equals($reserved['network'],   $ipBin)) { $stats['skipped']++; continue; }
            if ($reserved['broadcast'] !== null && hash_equals($reserved['broadcast'], $ipBin)) { $stats['skipped']++; continue; }
        }

        // Validate IP before any system call
        $norm = normalize_ip($ip);
        if ($norm === null) continue;
        $validIp = $norm['ip'];

        $latency = null;
        $isUp = false;

        if ($method === 'icmp' || $method === 'both') {
            $lat = ipam_probe_icmp($validIp);
            if ($lat !== null) { $latency = $lat; $isUp = true; }
        }
        if (($method === 'tcp' || $method === 'both') && $validTcpPort > 0 && !$isUp) {
            $lat = ipam_probe_tcp($validIp, $validTcpPort);
            if ($lat !== null) { $latency = $lat; $isUp = true; }
        }

        $insert->execute([
            ':sid'    => $subnetId,
            ':aid'    => $addrId,
            ':ip'     => $validIp,
            ':method' => $method,
            ':is_up'  => $isUp ? 1 : 0,
            ':lat'    => $latency,
        ]);

        if ($isUp) {
            $updateSeen->execute([':id' => $addrId]);
            $stats['up']++;
        } else {
            $stats['down']++;
        }
        $stats['scanned']++;
    }

    $stats['stale_marked'] = ipam_mark_stale_addresses($db, $subnetId, $staleThreshold);
    return $stats;
}

/**
 * Mark addresses stale when they missed N consecutive scans.
 * Clears is_stale when the most recent scan result is up.
 *
 * @return int  Number of addresses whose is_stale flag changed.
 */
function ipam_mark_stale_addresses(PDO $db, int $subnetId, int $missThreshold = 3): int
{
    // Reserved IPs (network, IPv4 broadcast) are excluded from stale marking so
    // they don't accrue a stale flag from historical scan_results rows.
    $reserved = ipam_subnet_reserved_bins($db, $subnetId);

    // Fetch per-address: count of recent consecutive down results
    $st = $db->prepare("
        SELECT a.id,
               a.ip_bin,
               a.is_stale,
               (
                 SELECT COALESCE(SUM(CASE WHEN r.is_up = 0 THEN 1 ELSE 0 END), 0)
                 FROM (
                   SELECT is_up
                   FROM scan_results
                   WHERE address_id = a.id
                   ORDER BY scanned_at DESC
                   LIMIT :thresh
                 ) r
               ) AS recent_misses,
               (SELECT is_up FROM scan_results WHERE address_id = a.id ORDER BY scanned_at DESC LIMIT 1) AS last_up
        FROM addresses a
        WHERE a.subnet_id = :sid
    ");
    $st->bindValue(':sid', $subnetId, PDO::PARAM_INT);
    $st->bindValue(':thresh', $missThreshold, PDO::PARAM_INT);
    $st->execute();
    $rows = $st->fetchAll();

    $changed = 0;
    $updates = [];

    foreach ($rows as $row) {
        $id = (int) $row['id'];
        $currentlyStale = (int) $row['is_stale'];
        $misses = (int) $row['recent_misses'];
        $lastUp = $row['last_up'];
        $ipBin = isset($row['ip_bin']) && is_string($row['ip_bin']) ? $row['ip_bin'] : '';

        // Skip reserved IPs — they are never probed, so any historical scan data
        // should not drive their stale flag.
        if ($ipBin !== '') {
            if ($reserved['network']   !== null && hash_equals($reserved['network'],   $ipBin)) continue;
            if ($reserved['broadcast'] !== null && hash_equals($reserved['broadcast'], $ipBin)) continue;
        }

        $shouldBeStale = ($misses >= $missThreshold && $lastUp !== null && (int) $lastUp === 0) ? 1 : 0;

        if ($shouldBeStale !== $currentlyStale) {
            $updates[] = ['id' => $id, 'stale' => $shouldBeStale];
        }
    }

    if ($updates !== []) {
        $db->beginTransaction();
        try {
            $setStale = $db->prepare("UPDATE addresses SET is_stale = :stale, updated_at = " . ipam_dialect()->now() . " WHERE id = :id");
            foreach ($updates as $u) {
                $setStale->execute([':stale' => $u['stale'], ':id' => $u['id']]);
            }
            $changed = count($updates);
            // Audit with system actor (works in CLI and web contexts)
            $u = current_user();
            $db->prepare("INSERT INTO audit_log (user_id, username, action, entity_type, entity_id, details)
                          VALUES (:uid, :un, 'scan.stale_update', 'subnet', :eid, :dt)")
               ->execute([
                   ':uid' => $u['id'] ?: null,
                   ':un'  => $u['username'] !== '' ? $u['username'] : 'system',
                   ':eid' => $subnetId,
                   ':dt'  => "marked=$changed threshold=$missThreshold",
               ]);
            $db->commit();
        } catch (\Throwable $e) {
            $db->rollBack();
            throw $e;
        }
    }

    return $changed;
}

/**
 * Parse a pasted ARP / neighbour table into IP+MAC pairs.
 *
 * Accepts common dump formats:
 *   - `ip mac`         (space-separated, one per line)
 *   - `ip\tmac`        (tab-separated)
 *   - `ip,mac`         (CSV)
 *   - `ip mac iface`   (extra columns ignored)
 *
 * @return list<array{ip:string, mac:string}>
 */
function ipam_parse_arp_table(string $raw): array
{
    $results = [];
    $lines = preg_split('/\r?\n/', trim($raw));
    if ($lines === false) return [];

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) continue;

        // Split on whitespace or commas
        $parts = preg_split('/[\s,]+/', $line);
        if ($parts === false || count($parts) < 2) continue;

        // Find the first valid IP and first valid MAC in the parts.
        // Strip parentheses to handle Linux `arp -a` format: hostname (ip) at mac ...
        $foundIp = null;
        $foundMac = null;
        foreach ($parts as $part) {
            $bare = trim($part, '()');
            if ($foundIp === null && filter_var($bare, FILTER_VALIDATE_IP) !== false) {
                $foundIp = $bare;
            } elseif ($foundMac === null && preg_match('/^([0-9a-fA-F]{2}[:\-.]){5}[0-9a-fA-F]{2}$/', $part)) {
                $foundMac = $part;
            }
            if ($foundIp !== null && $foundMac !== null) break;
        }

        if ($foundIp === null || $foundMac === null) continue;

        // Validate IP through normalize_ip for canonicalization
        $norm = normalize_ip($foundIp);
        if ($norm === null) continue;

        $results[] = ['ip' => $norm['ip'], 'mac' => $foundMac];
    }
    return $results;
}

/**
 * Apply parsed ARP entries: update addresses.mac for matching IPs in a subnet.
 *
 * @param  list<array{ip:string, mac:string}> $entries
 * @return array{matched:int, updated:int, skipped:int}
 */
function ipam_apply_arp_import(PDO $db, array $entries, int $subnetId): array
{
    $stats = ['matched' => 0, 'updated' => 0, 'skipped' => 0];
    $find = $db->prepare("SELECT id, mac FROM addresses WHERE subnet_id = :sid AND ip = :ip LIMIT 1");
    $update = $db->prepare("UPDATE addresses SET mac = :mac, updated_at = " . ipam_dialect()->now() . " WHERE id = :id");

    foreach ($entries as $entry) {
        $ip  = $entry['ip'];
        $mac = $entry['mac'];
        if ($ip === '' || $mac === '') { $stats['skipped']++; continue; }

        $find->execute([':sid' => $subnetId, ':ip' => $ip]);
        /** @var array<string, mixed>|false $addr */
        $addr = $find->fetch();
        if (!$addr) { $stats['skipped']++; continue; }

        $stats['matched']++;
        if (to_str($addr['mac']) === $mac) { $stats['skipped']++; continue; }

        $update->execute([':mac' => $mac, ':id' => to_int($addr['id'])]);
        $stats['updated']++;
    }
    return $stats;
}

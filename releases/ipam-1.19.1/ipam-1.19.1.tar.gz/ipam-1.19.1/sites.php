<?php
declare(strict_types=1);
require __DIR__ . '/init.php';
/** @var \PDO $db */
require_role('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();
}

$err = '';
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = to_str($_POST['action'] ?? '');

    if ($action === 'create') {
        $name = trim(to_str($_POST['name'] ?? ''));
        $desc = trim(to_str($_POST['description'] ?? ''));

        if ($name === '') {
            $err = 'Site name is required.';
        } else {
            try {
                $st = $db->prepare("INSERT INTO sites (name, description) VALUES (:n, :d)");
                $st->execute([':n' => $name, ':d' => $desc]);
                audit($db, 'site.create', 'site', (int)$db->lastInsertId(), "name=$name");
                flash_set('Site created.');
                header('Location: sites.php');
                exit;
            } catch (PDOException $e) {
                $err = 'Could not create site (duplicate name?).';
            }
        }
    } elseif ($action === 'update') {
        $id = to_int($_POST['id'] ?? 0);
        $name = trim(to_str($_POST['name'] ?? ''));
        $desc = trim(to_str($_POST['description'] ?? ''));

        if ($id <= 0 || $name === '') {
            $err = 'Valid site id and name are required.';
        } else {
            try {
                $st = $db->prepare("UPDATE sites SET name = :n, description = :d WHERE id = :id");
                $st->execute([':n' => $name, ':d' => $desc, ':id' => $id]);
                audit($db, 'site.update', 'site', $id, "name=$name");
                $msg = 'Site updated.';
            } catch (PDOException $e) {
                $err = 'Could not update site (duplicate name?).';
            }
        }
    } elseif ($action === 'delete') {
        $id = to_int($_POST['id'] ?? 0);
        if ($id > 0) {
            // First, detach subnets from this site
            $st = $db->prepare("UPDATE subnets SET site_id = NULL WHERE site_id = :id");
            $st->execute([':id' => $id]);

            $st = $db->prepare("DELETE FROM sites WHERE id = :id");
            $st->execute([':id' => $id]);

            audit($db, 'site.delete', 'site', $id, '');
            flash_set('Site deleted.');
            header('Location: sites.php');
            exit;
        }
    }
}

$siteSortCols = ['name' => 's.name', 'created' => 's.created_at'];
$siteSort = parse_sort($siteSortCols, 'name');

$st = $db->prepare("
    SELECT s.id, s.name, s.description, s.created_at,
           (SELECT COUNT(*) FROM subnets sn WHERE sn.site_id = s.id) AS subnet_count
    FROM sites s
    ORDER BY {$siteSort['sql']}
");
$st->execute();
/** @var list<array<string, mixed>> $sites */
$sites = $st->fetchAll();

page_header('Sites');
?>
<div class="breadcrumbs">
  <a href="dashboard.php">🏠 Dashboard</a><span class="sep">›</span>
  <span>🏢 Sites</span>
</div>

<div class="toolbar">
  <div>
    <h1>Sites</h1>
    <div class="muted">Group subnets by site for easier organization and navigation.</div>
  </div>
</div>

<?php if ($err): ?><p class="danger"><?= e($err) ?></p><?php endif; ?>
<?php if ($msg): ?><p class="success"><?= e($msg) ?></p><?php endif; ?>

<div class="grid cols-2">
  <div class="card" id="add-site">
    <h2>Add Site</h2>
    <form method="post" action="sites.php">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="action" value="create">

      <div class="row">
        <label>Site name<br><input name="name" required></label>
      </div>
      <div class="row">
        <label class="flex-1">Description<br><input name="description" class="w-full"></label>
      </div>

      <p><button type="submit">Create Site</button></p>
    </form>
  </div>

  <div class="card">
    <h2>Overview</h2>
    <div class="grid cols-2">
      <div class="metric">
        <div class="label">Sites</div>
        <div class="value"><?= e((string)count($sites)) ?></div>
      </div>
      <div class="metric">
        <div class="label">Subnets grouped</div>
        <div class="value"><?= e((string)array_sum(array_map(fn($s) => to_int($s['subnet_count']), $sites))) ?></div>
      </div>
    </div>
  </div>
</div>

<div class="card mt-16">
  <h2>Existing Sites</h2>

  <?php if (!$sites): ?>
    <div class="empty-state">No sites yet. <a class="action-pill" href="#add-site">+ Add Site</a></div>
  <?php else: ?>
    <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <?php $siteQs = '?';
                echo sort_th('name',    'Name',    $siteSort['col'], $siteSort['dir'], $siteQs);
                echo sort_th('created', 'Created', $siteSort['col'], $siteSort['dir'], $siteQs);
          ?>
          <th>Description</th>
          <th>Subnets</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($sites as $site): ?>
        <tr>
          <td><b><?= e(to_str($site['name'])) ?></b></td>
          <td class="muted"><?= e(to_str($site['created_at'])) ?></td>
          <td><?= e(to_str($site['description'])) ?></td>
          <td><?= e(to_str($site['subnet_count'])) ?></td>
          <td>
            <details>
              <summary>Edit/Delete</summary>

              <form method="post" action="sites.php" class="row mt-8">
                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" value="<?= to_int($site['id']) ?>">
                <label>Name<br><input name="name" value="<?= e(to_str($site['name'])) ?>" required></label>
                <label>Description<br><input name="description" value="<?= e(to_str($site['description'])) ?>"></label>
                <button type="submit">Save</button>
              </form>

              <form method="post" action="sites.php" class="mt-8"
                    data-confirm="Delete this site? Subnets will be ungrouped, not deleted.">
                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= to_int($site['id']) ?>">
                <button type="submit" class="button-danger">Delete</button>
              </form>
            </details>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  <?php endif; ?>
</div>

<?php page_footer();

<?php
declare(strict_types=1);

/** @return array<string, \Closure> */
function ipam_migrations(): array
{
    return [
        // 0.3: adds subnets.network_bin and backfills it
        '0.3' => function(PDO $db) {
            $cols = $db->query("PRAGMA table_info(subnets)")->fetchAll();
            $names = array_map(fn($c) => $c['name'], $cols);

            if (!in_array('network_bin', $names, true)) {
                $db->exec("ALTER TABLE subnets ADD COLUMN network_bin BLOB");
            }

            $st = $db->prepare("SELECT id, network FROM subnets WHERE network_bin IS NULL OR length(network_bin)=0");
            $st->execute();
            $rows = $st->fetchAll();

            $up = $db->prepare("UPDATE subnets SET network_bin = :b WHERE id = :id");
            foreach ($rows as $r) {
                $bin = @inet_pton((string)$r['network']);
                if ($bin === false) continue;
                $up->execute([':b' => $bin, ':id' => (int)$r['id']]);
            }

            $db->exec("CREATE INDEX IF NOT EXISTS idx_subnets_ver_prefix_netbin ON subnets(ip_version, prefix, network_bin)");
        },

        // 0.7: address history + search indexes
        '0.7' => function(PDO $db) {
            $db->exec("
                CREATE TABLE IF NOT EXISTS address_history (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  created_at TEXT NOT NULL DEFAULT (datetime('now')),
                  address_id INTEGER,
                  subnet_id INTEGER NOT NULL,
                  ip TEXT NOT NULL,
                  action TEXT NOT NULL,
                  user_id INTEGER,
                  username TEXT,
                  client_ip TEXT,
                  user_agent TEXT,
                  before_json TEXT,
                  after_json TEXT
                )
            ");

            $db->exec("CREATE INDEX IF NOT EXISTS idx_address_history_address_id ON address_history(address_id)");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_address_history_subnet_id ON address_history(subnet_id)");

            $db->exec("CREATE INDEX IF NOT EXISTS idx_addresses_hostname ON addresses(hostname)");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_addresses_owner ON addresses(owner)");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_addresses_status ON addresses(status)");
        },

        // 0.9: sites grouping
        '0.9'  => function(PDO $db) {
            $db->exec("
                CREATE TABLE IF NOT EXISTS sites (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  name TEXT NOT NULL UNIQUE,
                  description TEXT NOT NULL DEFAULT '',
                  created_at TEXT NOT NULL DEFAULT (datetime('now'))
                )
            ");

            $cols = $db->query("PRAGMA table_info(subnets)")->fetchAll();
            $names = array_map(fn($c) => $c['name'], $cols);

            if (!in_array('site_id', $names, true)) {
                $db->exec("ALTER TABLE subnets ADD COLUMN site_id INTEGER");
            }

            $db->exec("CREATE INDEX IF NOT EXISTS idx_subnets_site_id ON subnets(site_id)");
        },

        // 1.4: password_changed_at timestamp on users (for password rotation policy)
        '1.4' => function(PDO $db) {
            $cols  = $db->query("PRAGMA table_info(users)")->fetchAll();
            $names = array_map(fn($c) => $c['name'], $cols);
            if (!in_array('password_changed_at', $names, true)) {
                $db->exec("ALTER TABLE users ADD COLUMN password_changed_at TEXT");
                // Backfill existing local accounts so they aren't immediately expired.
                // SSO-only accounts (unusable hash starting with '!') are left NULL
                // since expiry doesn't apply to them.
                $db->exec("UPDATE users SET password_changed_at = datetime('now')
                           WHERE password_hash NOT LIKE '!%'");
            }
        },

        // 0.14: last_login_at timestamp on users
        '0.14' => function(PDO $db) {
            $cols  = $db->query("PRAGMA table_info(users)")->fetchAll();
            $names = array_map(fn($c) => $c['name'], $cols);
            if (!in_array('last_login_at', $names, true)) {
                $db->exec("ALTER TABLE users ADD COLUMN last_login_at TEXT");
            }
        },

        // 0.13: name + email fields on users
        '0.13' => function(PDO $db) {
            $cols  = $db->query("PRAGMA table_info(users)")->fetchAll();
            $names = array_map(fn($c) => $c['name'], $cols);

            if (!in_array('name', $names, true)) {
                $db->exec("ALTER TABLE users ADD COLUMN name TEXT NOT NULL DEFAULT ''");
            }
            if (!in_array('email', $names, true)) {
                $db->exec("ALTER TABLE users ADD COLUMN email TEXT NOT NULL DEFAULT ''");
            }
        },

        // 0.12: OIDC subject claim column on users
        '0.12' => function(PDO $db) {
            $cols  = $db->query("PRAGMA table_info(users)")->fetchAll();
            $names = array_map(fn($c) => $c['name'], $cols);

            if (!in_array('oidc_sub', $names, true)) {
                $db->exec("ALTER TABLE users ADD COLUMN oidc_sub TEXT");
            }

            // Partial unique index: only enforce uniqueness when oidc_sub is not NULL
            $db->exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_oidc_sub
                       ON users(oidc_sub) WHERE oidc_sub IS NOT NULL");
        },

        // 0.11: login rate-limiting + REST API keys
        '0.11' => function(PDO $db) {
            $db->exec("
                CREATE TABLE IF NOT EXISTS login_attempts (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    ip           TEXT NOT NULL,
                    attempted_at TEXT NOT NULL DEFAULT (datetime('now'))
                )
            ");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_login_attempts_ip_time
                       ON login_attempts(ip, attempted_at)");

            $db->exec("
                CREATE TABLE IF NOT EXISTS api_keys (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    name         TEXT NOT NULL,
                    key_hash     TEXT NOT NULL UNIQUE,
                    created_at   TEXT NOT NULL DEFAULT (datetime('now')),
                    last_used_at TEXT,
                    is_active    INTEGER NOT NULL DEFAULT 1,
                    created_by   TEXT NOT NULL DEFAULT ''
                )
            ");
        },

        // 1.11: addresses.grp (group field), subnets.vlan_id, users.theme
        '1.11' => function(PDO $db) {
            // addresses.grp — SQL reserved word, stored as grp, exposed as group in UI/API/CSV
            $cols = array_column($db->query("PRAGMA table_info(addresses)")->fetchAll(), 'name');
            if (!in_array('grp', $cols, true)) {
                $db->exec("ALTER TABLE addresses ADD COLUMN grp TEXT NOT NULL DEFAULT ''");
            }
            $db->exec("CREATE INDEX IF NOT EXISTS idx_addresses_grp ON addresses(grp)");

            // subnets.vlan_id — nullable integer, 1–4094, NULL means unassigned
            $cols = array_column($db->query("PRAGMA table_info(subnets)")->fetchAll(), 'name');
            if (!in_array('vlan_id', $cols, true)) {
                $db->exec("ALTER TABLE subnets ADD COLUMN vlan_id INTEGER");
            }

            // users.theme — persisted theme preference: 'auto'|'light'|'dark'
            $cols = array_column($db->query("PRAGMA table_info(users)")->fetchAll(), 'name');
            if (!in_array('theme', $cols, true)) {
                $db->exec("ALTER TABLE users ADD COLUMN theme TEXT NOT NULL DEFAULT 'auto'");
            }
        },

        // 1.9: ensure audit_log exists — it was only in schema.sql, not a migration,
        // so a botched demo reset that dropped it would leave it permanently missing.
        // Using CREATE TABLE IF NOT EXISTS makes this safe to run on any existing install.
        // 1.12: add indexes on audit_log + normalize audit action names
        '1.12' => function(PDO $db) {
            // Indexes for audit_log queries
            $db->exec("CREATE INDEX IF NOT EXISTS idx_audit_log_action ON audit_log(action)");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_audit_log_created_at ON audit_log(created_at)");

            // Normalize audit action names: api_key.* → apikey.*, user.password_change → user.change_password
            // Must temporarily drop append-only triggers to allow UPDATE
            $db->exec("DROP TRIGGER IF EXISTS audit_log_no_update");
            $db->exec("DROP TRIGGER IF EXISTS audit_log_no_delete");

            $db->exec("UPDATE audit_log SET action = REPLACE(action, 'api_key.', 'apikey.') WHERE action LIKE 'api\_key.%' ESCAPE '\'");
            $db->exec("UPDATE audit_log SET action = 'user.change_password' WHERE action = 'user.password_change'");

            // Recreate append-only triggers
            ensure_audit_log_table($db);
        },

        '1.9' => function(PDO $db) {
            ensure_audit_log_table($db);
        },

        // 1.13: api_keys.is_readonly + api_keys.description
        '1.13' => function(PDO $db): void {
            $cols = array_column($db->query("PRAGMA table_info(api_keys)")->fetchAll(), 'name');
            if (!in_array('is_readonly', $cols, true)) {
                $db->exec("ALTER TABLE api_keys ADD COLUMN is_readonly INTEGER NOT NULL DEFAULT 0");
            }
            if (!in_array('description', $cols, true)) {
                $db->exec("ALTER TABLE api_keys ADD COLUMN description TEXT NOT NULL DEFAULT ''");
            }
        },
    ];
}

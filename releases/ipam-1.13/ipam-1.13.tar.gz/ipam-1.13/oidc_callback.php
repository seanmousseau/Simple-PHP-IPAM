<?php
declare(strict_types=1);
require __DIR__ . '/init.php';

if (is_logged_in())         { header('Location: dashboard.php'); exit; }
if (!oidc_enabled($config)) { header('Location: login.php');     exit; }

/**
 * Redirect to login with a generic error message.
 * Detailed reason is only written to the server error log.
 */
function oidc_fail(PDO $db, string $logMsg): never
{
    error_log('OIDC callback failure: ' . $logMsg);
    audit($db, 'auth.oidc_failed', 'user', null, $logMsg);
    $_SESSION['oidc_error'] = 'SSO authentication failed. Please try again or contact your administrator.';
    header('Location: login.php');
    exit;
}

// ---- State validation (CSRF guard) ----

$returnedState = (string)($_GET['state'] ?? '');
$savedState    = (string)($_SESSION['oidc_state']    ?? '');
$nonce         = (string)($_SESSION['oidc_nonce']    ?? '');
$verifier      = (string)($_SESSION['oidc_verifier'] ?? '');

// Always clear OIDC session keys regardless of outcome
unset($_SESSION['oidc_state'], $_SESSION['oidc_nonce'], $_SESSION['oidc_verifier']);

if ($savedState === '' || !hash_equals($savedState, $returnedState)) {
    oidc_fail($db, 'state mismatch');
}

// ---- IdP error response ----
if (!empty($_GET['error'])) {
    $errorCode = substr(preg_replace('/[^A-Za-z0-9_.:-]/', '', (string)$_GET['error']), 0, 64);
    $errorDesc = isset($_GET['error_description'])
        ? ' — ' . substr(trim((string)$_GET['error_description']), 0, 200)
        : '';
    oidc_fail($db, "IdP returned error: {$errorCode}{$errorDesc}");
}

$code = (string)($_GET['code'] ?? '');
if ($code === '') oidc_fail($db, 'no authorization code in callback');

// ---- Fetch discovery document ----
try {
    $discovery = oidc_discovery($config);
} catch (Throwable $e) {
    oidc_fail($db, 'discovery: ' . $e->getMessage());
}

// ---- Exchange code for tokens ----
try {
    $tokens = oidc_http_post($discovery['token_endpoint'], [
        'grant_type'    => 'authorization_code',
        'code'          => $code,
        'redirect_uri'  => (string)$config['oidc']['redirect_uri'],
        'client_id'     => (string)$config['oidc']['client_id'],
        'client_secret' => (string)$config['oidc']['client_secret'],
        'code_verifier' => $verifier,
    ]);
} catch (Throwable $e) {
    oidc_fail($db, 'token exchange: ' . $e->getMessage());
}

if (empty($tokens['id_token'])) {
    oidc_fail($db, 'no id_token in token response');
}

// ---- Verify ID token (with one JWKS cache-bust retry for key rotation) ----
$expect = [
    'iss'   => (string)($discovery['issuer'] ?? ''),
    'aud'   => (string)$config['oidc']['client_id'],
    'nonce' => $nonce,
];

try {
    $jwks    = oidc_jwks((string)$discovery['jwks_uri']);
    $payload = oidc_verify_id_token((string)$tokens['id_token'], $jwks, $expect);
} catch (Throwable $e) {
    // One retry with a fresh JWKS in case the IdP rotated keys
    try {
        $jwks    = oidc_jwks((string)$discovery['jwks_uri'], forceRefresh: true);
        $payload = oidc_verify_id_token((string)$tokens['id_token'], $jwks, $expect);
    } catch (Throwable $e2) {
        oidc_fail($db, 'id_token verification: ' . $e2->getMessage());
    }
}

$sub              = (string)($payload['sub']                ?? '');
$claimEmail       = substr(trim((string)($payload['email']           ?? '')), 0, 255);
$claimName        = substr(trim((string)($payload['name']            ?? '')), 0, 255);
$claimPrefUsername = substr(trim((string)($payload['preferred_username'] ?? '')), 0, 64);
// Sanitise: strip characters not allowed in local usernames (#111)
$claimPrefUsername = preg_replace('/[^a-zA-Z0-9._@\-]/', '', $claimPrefUsername);

if ($sub === '') oidc_fail($db, 'id_token missing sub claim');

// ---- Find or provision local user ----

$st = $db->prepare("SELECT id, username, role, is_active FROM users WHERE oidc_sub = :sub");
$st->execute([':sub' => $sub]);
$user = $st->fetch();

// auto_link: link incoming OIDC login to an existing unlinked local account by username/email.
// auto_provision: create a new account when no match is found (implies auto_link).
// For backwards compatibility, if auto_link is absent, fall back to auto_provision for both.
$autoProvision = !empty($config['oidc']['auto_provision']);
$autoLink      = isset($config['oidc']['auto_link'])
                 ? !empty($config['oidc']['auto_link'])
                 : $autoProvision; // BC: old installs without auto_link key

if (!$user && $autoLink) {
    // Try to link an existing local user by preferred_username then by email
    $existing = false;
    if ($claimPrefUsername !== '') {
        $st2 = $db->prepare("SELECT id, username, role, is_active FROM users WHERE username = :u AND oidc_sub IS NULL");
        $st2->execute([':u' => $claimPrefUsername]);
        $existing = $st2->fetch();
    }
    if (!$existing && $claimEmail !== '') {
        // Email-only match — do NOT match username here to prevent cross-account linking (#107)
        $st2 = $db->prepare("SELECT id, username, role, is_active FROM users WHERE email = :e AND oidc_sub IS NULL");
        $st2->execute([':e' => $claimEmail]);
        $existing = $st2->fetch();
    }

    if ($existing) {
        // Link the existing account to this OIDC subject and sync profile
        $db->prepare("UPDATE users SET oidc_sub = :sub, name = CASE WHEN name='' THEN :n ELSE name END, email = CASE WHEN email='' THEN :e ELSE email END WHERE id = :id")
           ->execute([':sub' => $sub, ':n' => $claimName, ':e' => $claimEmail, ':id' => (int)$existing['id']]);
        audit($db, 'auth.oidc_link', 'user', (int)$existing['id'], 'sub=' . $sub);
        $user = $existing;
    } elseif ($autoProvision) {
        // Auto-provision a new local user
        $role = (string)($config['oidc']['default_role'] ?? 'readonly');
        if (!in_array($role, ['admin', 'netops', 'readonly'], true)) $role = 'readonly';

        // Derive a username: prefer preferred_username, fall back to email local-part, then sub
        // Sanitise each candidate the same way as preferred_username (#111)
        $emailLocalPart = $claimEmail !== '' ? preg_replace('/[^a-zA-Z0-9._@\-]/', '', explode('@', $claimEmail)[0]) : '';
        $subSanitised   = preg_replace('/[^a-zA-Z0-9._@\-]/', '', substr($sub, 0, 64));
        $newUsername = $claimPrefUsername !== '' ? $claimPrefUsername
            : ($emailLocalPart !== '' ? $emailLocalPart : ($subSanitised !== '' ? $subSanitised : 'oidcuser'));

        // Set an unusable password hash so the account cannot be used with local auth
        $unusableHash = password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT);

        $ins = $db->prepare(
            "INSERT INTO users (username, password_hash, role, is_active, oidc_sub, name, email)
             VALUES (:u, :h, :r, 1, :sub, :n, :e)"
        );
        $baseUsername = $newUsername;
        for ($attempt = 0; $attempt < 5; $attempt++) {
            try {
                $ins->execute([':u' => $newUsername, ':h' => $unusableHash, ':r' => $role,
                               ':sub' => $sub, ':n' => $claimName, ':e' => $claimEmail]);
                break;
            } catch (PDOException $ex) {
                if ($attempt >= 4) {
                    oidc_fail('Unable to provision account — username collision after 5 attempts.');
                }
                $newUsername = $baseUsername . '_' . ($attempt + 2);
            }
        }
        $newId = (int)$db->lastInsertId();
        audit($db, 'auth.oidc_provision', 'user', $newId, 'username=' . $newUsername . ' sub=' . $sub);

        $st3 = $db->prepare("SELECT id, username, role, is_active FROM users WHERE id = :id");
        $st3->execute([':id' => $newId]);
        $user = $st3->fetch();
    }
}

// For already-linked users: sync name/email from IdP claims if blank
if ($user) {
    if (($claimName !== '' || $claimEmail !== '')) {
        $db->prepare("UPDATE users SET name = CASE WHEN name='' THEN :n ELSE name END, email = CASE WHEN email='' THEN :e ELSE email END WHERE id = :id")
           ->execute([':n' => $claimName, ':e' => $claimEmail, ':id' => (int)$user['id']]);
    }
}

if (!$user) {
    oidc_fail($db, 'no local user found for sub=' . $sub
        . '. An admin must create or link an account.');
}

if ((int)$user['is_active'] !== 1) {
    oidc_fail($db, 'user account is inactive: ' . $user['username']);
}

// ---- All checks passed — log in ----
login_user((int)$user['id'], (string)$user['username'], (string)$user['role']);
$db->prepare("UPDATE users SET last_login_at=datetime('now') WHERE id=:id")
   ->execute([':id' => (int)$user['id']]);
audit($db, 'auth.oidc_login', 'user', (int)$user['id'], 'sub=' . $sub);

header('Location: dashboard.php');
exit;

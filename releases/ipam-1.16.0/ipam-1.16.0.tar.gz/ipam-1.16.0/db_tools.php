<?php
declare(strict_types=1);
require __DIR__ . '/init.php';
require_role('admin');

$err = '';
$msg = '';

/* ------------------------------------------------------------------ *
 * POST: export                                                         *
 * ------------------------------------------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'export') {
    csrf_require();
    audit($db, 'db.export', 'system', null, 'Manual database export initiated');

    $filename = 'ipam-export-' . date('Y-m-d-His') . '.sql';
    header('Content-Type: application/sql; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-store');
    ipam_db_dump_stream($db, function(string $chunk) { echo $chunk; });
    exit;
}

/* ------------------------------------------------------------------ *
 * POST: import                                                         *
 * ------------------------------------------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'import') {
    csrf_require();

    $confirmed = !empty($_POST['confirmed']);
    $upload    = $_FILES['sql_file'] ?? null;

    if (!$confirmed) {
        $err = 'You must check the confirmation box before importing.';
    } elseif (!$upload || $upload['error'] !== UPLOAD_ERR_OK) {
        $errCode = $upload['error'] ?? -1;
        $err = match ((int)$errCode) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'Uploaded file exceeds the allowed size limit.',
            UPLOAD_ERR_NO_FILE                        => 'No file was uploaded.',
            default                                   => "Upload error (code {$errCode}).",
        };
    } else {
        $tmpPath  = (string)$upload['tmp_name'];
        $fileSize = filesize($tmpPath);
        $maxMb    = (int)($config['import_sql_max_mb'] ?? 200);
        $maxBytes = $maxMb * 1024 * 1024;

        if ($fileSize === false || $fileSize > $maxBytes) {
            $err = "Import file must be under {$maxMb} MB.";
        } else {
            $sql = file_get_contents($tmpPath);
            if ($sql === false || trim($sql) === '') {
                $err = 'Uploaded file is empty or unreadable.';
            } else {
                // Basic sanity check: must look like a SQL dump
                if (!str_contains($sql, 'BEGIN TRANSACTION') && !str_contains($sql, 'CREATE TABLE')) {
                    $err = 'File does not appear to be a valid SQL dump (missing BEGIN TRANSACTION or CREATE TABLE).';
                }
            }
        }

        if (!$err) {
            // Back up the current database before import
            $dbPath = (string)($config['db_path'] ?? (__DIR__ . '/data/ipam.sqlite'));
            $backupPath = $dbPath . '.pre-import-' . date('YmdHis') . '.bak';
            try { $db->exec("PRAGMA wal_checkpoint(FULL)"); } catch (Throwable) {}
            if (!@copy($dbPath, $backupPath)) {
                $err = 'Could not create a pre-import backup of the database. Import aborted for safety.';
            }
        }

        if (!$err) {
            // Execute import inside a transaction; rollback on any error
            try {
                // Close current connection cleanly, re-open after replacing DB content
                $db->exec("PRAGMA foreign_keys=OFF");
                $db->beginTransaction();

                // Drop all user tables (except sqlite_sequence which is auto-managed)
                $tables = $db->query(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
                )->fetchAll(PDO::FETCH_COLUMN);

                foreach ($tables as $tbl) {
                    $db->exec('DROP TABLE IF EXISTS "' . str_replace('"', '""', (string)$tbl) . '"');
                }

                // Split the dump into individual statements.
                // Simple preg_split on ";\n" is insufficient because:
                //   1. Trigger bodies contain ";\n" inside BEGIN...END blocks.
                //   2. Text values encoded as CAST(X'hex' AS TEXT) are single-line,
                //      but a plain-text dump could have ";\n" inside string literals.
                // We use a line-based parser that tracks BEGIN...END depth so that
                // semicolons inside trigger bodies are never treated as boundaries.
                $statements = [];
                $current    = '';
                $depth      = 0;
                foreach (explode("\n", $sql ?? '') as $line) {
                    $trimLine = trim($line);
                    // A bare BEGIN (no TRANSACTION keyword) opens a trigger body.
                    if (preg_match('/^BEGIN\s*$/i', $trimLine)) {
                        $depth++;
                    }
                    $current .= $line . "\n";
                    // END; closes a trigger body.
                    if ($depth > 0 && preg_match('/^END\s*;\s*$/i', $trimLine)) {
                        $depth--;
                    }
                    // A line ending with ; at depth 0 terminates a complete statement.
                    if ($depth === 0 && str_ends_with(rtrim($line), ';')) {
                        $statements[] = $current;
                        $current = '';
                    }
                }
                if (trim($current) !== '') {
                    $statements[] = $current;
                }

                $importStart = microtime(true);
                $stmtCount = 0;
                foreach ($statements as $stmt) {
                    // Strip SQL comment lines, then trim
                    $exec = trim((string)preg_replace('/^--[^\n]*\n?/m', '', $stmt));
                    if ($exec === '') continue;
                    // Skip transaction/pragma statements we manage ourselves
                    if (preg_match('/^PRAGMA\s+foreign_keys\s*=/i', $exec)) continue;
                    if (preg_match('/^BEGIN(\s+TRANSACTION)?\s*;?\s*$/i', $exec)) continue;
                    if (preg_match('/^COMMIT\s*;?\s*$/i', $exec)) continue;
                    // Whitelist: only allow safe DDL/DML statements
                    $firstWord = strtoupper((string)strtok(ltrim($exec), " \t\r\n("));
                    $allowed = ['INSERT', 'CREATE', 'DROP', 'DELETE'];
                    if (!in_array($firstWord, $allowed, true)) {
                        throw new RuntimeException(
                            'Blocked disallowed SQL statement type: ' . $firstWord
                        );
                    }
                    // Block dangerous SQLite constructs even inside allowed statements
                    $upper = strtoupper($exec);
                    if (str_contains($upper, 'LOAD_EXTENSION') || str_contains($upper, 'ATTACH') || str_contains($upper, 'DETACH')) {
                        throw new RuntimeException(
                            'Blocked dangerous SQL construct in: ' . substr($exec, 0, 80)
                        );
                    }
                    // CREATE TRIGGER bodies can contain arbitrary SQL. Only allow
                    // triggers that match known safe patterns (append-only guards).
                    if (preg_match('/^CREATE\s+TRIGGER/i', $exec)) {
                        if (!preg_match('/RAISE\s*\(\s*ABORT/i', $exec)) {
                            throw new RuntimeException(
                                'Blocked CREATE TRIGGER with non-RAISE body: ' . substr($exec, 0, 80)
                            );
                        }
                    }
                    $db->exec($exec);
                    $stmtCount++;
                }

                $db->exec("PRAGMA foreign_keys=ON");
                $db->commit();

                $elapsed = round(microtime(true) - $importStart, 1);
                audit($db, 'db.import', 'system', null,
                    "Database import completed ({$stmtCount} statements, {$elapsed}s); pre-import backup: " . basename($backupPath));
                $msg = "Import successful — {$stmtCount} statements executed in {$elapsed}s. Pre-import backup: " . basename($backupPath);
                // Invalidate db_initialized sentinel so ipam_db_init re-checks on next request
                @unlink(__DIR__ . '/data/.db_initialized');
            } catch (Throwable $ex) {
                if ($db->inTransaction()) $db->rollBack();
                $db->exec("PRAGMA foreign_keys=ON");
                $err = 'Import failed: ' . $ex->getMessage()
                     . ' The database has been restored from the pre-import state.';
                audit($db, 'db.import_failed', 'system', null,
                    'Import rolled back: ' . $ex->getMessage());
            }
        }
    }
}

/* ------------------------------------------------------------------ *
 * GET: manual backup trigger                                           *
 * ------------------------------------------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'backup_now') {
    csrf_require();
    // Force a backup regardless of schedule
    $dbPath = (string)($config['db_path'] ?? (__DIR__ . '/data/ipam.sqlite'));
    $bdir   = backup_dir($config);
    if (!is_dir($bdir)) @mkdir($bdir, 0700, true);

    try { $db->exec("PRAGMA wal_checkpoint(FULL)"); } catch (Throwable) {}

    $ts   = date('Y-m-d-His');
    $dest = $bdir . '/ipam-' . $ts . '.sqlite';

    if (@copy($dbPath, $dest)) {
        @chmod($dest, 0600);
        $retention = max(1, (int)($config['backup']['retention'] ?? 7));
        $files = glob($bdir . '/ipam-*.sqlite');
        if (is_array($files)) {
            rsort($files);
            foreach (array_slice($files, $retention) as $old) @unlink($old);
        }
        $state = ['last_backup' => time(), 'last_file' => basename($dest)];
        @file_put_contents(__DIR__ . '/data/backup-state.json', json_encode($state));
        audit($db, 'db.backup', 'system', null, 'Manual backup: ' . basename($dest));
        $msg = 'Backup created: ' . basename($dest);
    } else {
        $err = 'Backup failed: could not write to ' . $bdir;
    }
}

/* ------------------------------------------------------------------ *
 * Gather backup info for display                                       *
 * ------------------------------------------------------------------ */
$backupEnabled = !empty($config['backup']['enabled']);
$bInfo         = backup_info($config);

page_header('Database Tools');
?>
<h1>🗄 Database Tools</h1>

<?php if ($err): ?>
  <p class='danger'><?= e($err) ?></p>
<?php endif; ?>
<?php if ($msg): ?>
  <p class='success'><?= e($msg) ?></p>
<?php endif; ?>

<div class='grid cols-2 mt-16'>

  <!-- Export -->
  <div class='card'>
    <h2>Export Database</h2>
    <p class='muted'>Download a full SQL dump of the database. This file can be used to restore or migrate the IPAM instance.</p>
    <form method='post'>
      <input type='hidden' name='csrf' value='<?= e(csrf_token()) ?>'>
      <input type='hidden' name='action' value='export'>
      <button type='submit'>⬇ Download SQL Dump</button>
    </form>
  </div>

  <!-- Import -->
  <div class='card'>
    <h2>Import Database</h2>
    <p class='danger fw-600'>⚠ This will <strong>replace</strong> all current data. A pre-import backup is created automatically.</p>
    <form method='post' enctype='multipart/form-data' data-import-form>
      <input type='hidden' name='csrf' value='<?= e(csrf_token()) ?>'>
      <input type='hidden' name='action' value='import'>
      <div class='flex-col gap-10'>
        <label>SQL file (.sql)
          <input type='file' name='sql_file' accept='.sql,text/plain' required>
        </label>
        <label class='d-flex align-center gap-8 cursor-pointer'>
          <input type='checkbox' name='confirmed' value='1' required>
          I understand this will overwrite all existing data
        </label>
        <div>
          <button type='submit' class='button-danger'>⬆ Import &amp; Replace</button>
        </div>
      </div>
    </form>
  </div>

</div>

<!-- Backups -->
<div class='card mt-16'>
  <h2>Automatic Backups</h2>
  <?php if (!$backupEnabled): ?>
    <p class='muted'>Automatic backups are <strong>disabled</strong>. Enable them by setting <code>'backup' => ['enabled' => true, ...]</code> in config.php.</p>
  <?php else: ?>
    <p>
      Frequency: <strong><?= e(ucfirst((string)($config['backup']['frequency'] ?? 'daily'))) ?></strong>
      &nbsp;|&nbsp; Retention: <strong><?= e((string)($config['backup']['retention'] ?? 7)) ?> backups</strong>
      &nbsp;|&nbsp; Directory: <code><?= e($bInfo['dir']) ?></code>
    </p>
  <?php endif; ?>

  <table class='mt-10'>
    <tr><th>Stat</th><th>Value</th></tr>
    <tr>
      <td>Last backup</td>
      <td><?= $bInfo['last_backup'] ? e(date('Y-m-d H:i:s', $bInfo['last_backup'])) : '<span class=\'muted\'>Never</span>' ?></td>
    </tr>
    <tr>
      <td>Last backup file</td>
      <td><?= $bInfo['last_file'] ? e((string)$bInfo['last_file']) : '<span class=\'muted\'>—</span>' ?></td>
    </tr>
    <tr>
      <td>Backup count</td>
      <td><?= (int)$bInfo['count'] ?></td>
    </tr>
  </table>

  <form method='post' class='mt-14'>
    <input type='hidden' name='csrf' value='<?= e(csrf_token()) ?>'>
    <input type='hidden' name='action' value='backup_now'>
    <button type='submit' class='button-secondary'>💾 Run Backup Now</button>
  </form>
</div>

<?php page_footer(); ?>

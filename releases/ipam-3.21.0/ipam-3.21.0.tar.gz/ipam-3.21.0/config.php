<?php
declare(strict_types=1);

return [
    'db_driver'    => 'pgsql',
    'db_dsn'       => 'pgsql:host=ipam-pw-pgsql;port=5432;dbname=ipam_pw',
    'db_user'      => 'ipam',
    'db_pass'      => 'testpw',
    'session_name' => 'IPAMSESSID',
    'force_https'  => true,
    'bootstrap_admin' => [
        'username' => 'admin',
        'password' => 'ChangeMeNow!12345',
    ],
    'demo_mode' => [
        'enabled'    => false,
        'gate'       => NULL,
        'site_key'   => '',
        'secret_key' => '',
    ],
];

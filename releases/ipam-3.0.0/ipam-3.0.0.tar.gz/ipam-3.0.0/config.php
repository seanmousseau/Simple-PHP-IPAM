<?php
declare(strict_types=1);

return [
    'db_driver'    => 'sqlite',
    'db_dsn'       => 'sqlite:/Users/seanmousseau/Library/CloudStorage/OneDrive-Personal/Development/github/Simple-PHP-IPAM/Simple-PHP-IPAM/data/ipam.sqlite',
    'db_user'      => '',
    'db_pass'      => '',
    'session_name' => 'IPAMSESSID',
    'force_https'  => true,
    'bootstrap_admin' => [
        'username' => 'admin',
        'password' => 'ChangeMeNow!12345',
    ],
    'demo_mode' => [
        'enabled'    => true,
        'gate'       => NULL,
        'site_key'   => '',
        'secret_key' => '',
    ],
];

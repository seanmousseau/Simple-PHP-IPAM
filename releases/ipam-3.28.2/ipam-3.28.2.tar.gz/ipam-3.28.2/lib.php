<?php
declare(strict_types=1);
require_once __DIR__ . '/version.php';
require_once __DIR__ . '/lib/BackupClientInterface.php';
require_once __DIR__ . '/lib/S3Client.php';
require_once __DIR__ . '/lib/SftpClient.php';
require_once __DIR__ . '/lib/LocalBackupClient.php';
require_once __DIR__ . '/lib/vault.php';
require_once __DIR__ . '/lib/app_secret.php';
require_once __DIR__ . '/lib/backup.php';
require_once __DIR__ . '/lib/auth_step_up.php';

/**
 * Returns the active SQL dialect (#378). ipam_db() bootstraps this once per
 * request based on $config['db_driver'] and stows it under
 * $GLOBALS['ipam_dialect']. v2.9.0 shipped SqliteDialect only; v2.10.0 adds
 * MysqlDialect (#382); v2.11.0 adds PgsqlDialect (#386). Tests and CLI
 * scripts that bootstrap lib.php directly (without going through ipam_db())
 * get a SqliteDialect lazily — that is the historical default and matches
 * what every test fixture expects.
 */
function ipam_dialect(): Dialect
{
    if (!isset($GLOBALS['ipam_dialect']) || !($GLOBALS['ipam_dialect'] instanceof Dialect)) {
        require_once __DIR__ . '/dialects/Dialect.php';
        require_once __DIR__ . '/dialects/SqliteDialect.php';
        $GLOBALS['ipam_dialect'] = new SqliteDialect();
    }
    return $GLOBALS['ipam_dialect'];
}

/**
 * Select and cache the active dialect from a config array. Called by
 * ipam_db() during connection bootstrap; safe to call standalone from
 * tests that need to pin a specific dialect without opening a connection.
 *
 * @param array<string, mixed> $config
 */
function ipam_dialect_from_config(array $config): Dialect
{
    require_once __DIR__ . '/dialects/Dialect.php';
    $driverRaw = $config['db_driver'] ?? 'sqlite';
    $driver = is_string($driverRaw) ? $driverRaw : 'sqlite';
    switch ($driver) {
        case 'mysql':
            require_once __DIR__ . '/dialects/MysqlDialect.php';
            $dialect = new MysqlDialect();
            break;
        case 'pgsql':
            require_once __DIR__ . '/dialects/PgsqlDialect.php';
            $dialect = new PgsqlDialect();
            break;
        case 'sqlite':
        case '':
            require_once __DIR__ . '/dialects/SqliteDialect.php';
            $dialect = new SqliteDialect();
            break;
        default:
            throw new RuntimeException("Unsupported db_driver: $driver");
    }
    $GLOBALS['ipam_dialect'] = $dialect;
    return $dialect;
}

/**
 * Returns true when the active DB engine supports the SQL dump/restore
 * feature in db_tools.php (SQLite only). Used to conditionally show the
 * Database Tools nav item — direct navigation to db_tools.php still works
 * on all engines (it shows an "unsupported" banner).
 */
function ipam_sql_dump_supported(): bool {
    return ipam_dialect()->driver_name() === 'sqlite';
}

/**
 * Bind a raw binary value (typically inet_pton output) to a PDOStatement
 * parameter using PDO::PARAM_LOB on every driver (#410).
 *
 * **Why this helper exists.** Pre-v2.9.0 the codebase passed binary IP
 * values through positional execute(), which ultimately hits PDO::PARAM_STR.
 * On SQLite this stores the value with TEXT affinity even though the column
 * is declared BLOB — SQLite's loose typing honors the binding's affinity at
 * insert time, not the column's declared type. The bytes round-trip
 * correctly, but `ORDER BY ip_bin` and range queries break the moment new
 * rows arrive bound as BLOB, because SQLite's comparison rules say any BLOB
 * sorts greater than any TEXT regardless of byte content.
 *
 * On MySQL / Postgres the situation is worse: PARAM_STR string-escapes high
 * bytes and truncates at null bytes, corrupting every stored IP.
 *
 * This helper uses PARAM_LOB unconditionally so the same binding works on
 * SQLite (BLOB affinity), MySQL (VARBINARY), and Postgres (BYTEA). The
 * existing-data normalization happens in the 2.9.0-blob-affinity migration.
 *
 * **Storage format**: native length, never padded. IPv4 = 4 bytes,
 * IPv6 = 16 bytes. All three engines do byte-wise memcmp comparison on
 * native-length values, so sort order is equivalent across engines.
 *
 * Round-trip test vectors (covered by tests/BinaryBindTest.php):
 *   inet_pton('10.0.0.0')         = \x0A\x00\x00\x00  (null bytes after first)
 *   inet_pton('2001:db8::')       = \x20\x01\x0D\xB8...  (mostly null bytes)
 *   inet_pton('255.255.255.255')  = \xFF\xFF\xFF\xFF  (all high bytes)
 */
/**
 * @param int|string $param 1-based positional index, or ':name' for a named placeholder.
 */
function ipam_bind_binary(PDOStatement $stmt, int|string $param, string $bin): void
{
    $stmt->bindValue($param, $bin, PDO::PARAM_LOB);
}

/**
 * Return the auto-generated ID from the last INSERT on $db.
 *
 * On SQLite and MySQL, PDO::lastInsertId() works without arguments. On
 * Postgres, pdo_pgsql requires the sequence name — without it,
 * lastInsertId() returns "0" because Postgres doesn't have a
 * connection-scoped "last insert id" concept; it tracks per-sequence.
 * `GENERATED BY DEFAULT AS IDENTITY` columns create an implicit
 * sequence named `<table>_<column>_seq`.
 *
 * Every INSERT call site must use this helper instead of calling
 * $db->lastInsertId() directly — the raw call is a silent data-
 * corruption bug on Postgres (returns 0, breaks audit entity_id,
 * redirect URLs, tag saving, and every cascading operation that
 * references the newly-inserted row). v2.11.0 #388.
 */
/**
 * Return the settings.key column quoted for the active SQL dialect.
 *
 * `key` is a reserved word in MySQL (index keyword) and must be quoted.
 * MySQL uses backticks; Postgres and SQLite use double quotes (SQL
 * standard). There is no single quoting syntax that works on all three
 * engines without a SQL-mode change, so we branch on the driver. Called
 * by every settings query in lib.php and migrations.php. v2.11.0 #388.
 */
function ipam_key_col(): string
{
    return ipam_dialect()->driver_name() === 'mysql' ? '`key`' : '"key"';
}

function ipam_last_insert_id(PDO $db, string $table, string $column = 'id'): int
{
    $driverRaw = $db->getAttribute(PDO::ATTR_DRIVER_NAME);
    $driver = is_string($driverRaw) ? $driverRaw : '';
    if ($driver === 'pgsql') {
        return (int)$db->lastInsertId("{$table}_{$column}_seq");
    }
    return (int)$db->lastInsertId();
}

/**
 * Open a PDO connection based on $config['db_driver'].
 *
 * Dispatcher for the multi-engine support introduced in v2.10.0. Picks the
 * dialect first (so ipam_dialect() returns the right instance for the rest
 * of the request), then connects to the selected engine.
 *
 * Supported drivers:
 *   - 'sqlite' (default) — uses $config['db_path'] as the file path.
 *   - 'mysql' (stable, v3.0.0) — uses $config['db_dsn'],
 *     $config['db_user'], $config['db_pass']. Requires MySQL 8.0.29+.
 *   - 'pgsql' (stable, v3.0.0) — uses $config['db_dsn'],
 *     $config['db_user'], $config['db_pass']. Requires PostgreSQL 14+.
 *
 * @param array<string, mixed> $config
 */
function ipam_db(array $config): PDO
{
    $dialect = ipam_dialect_from_config($config);

    switch ($dialect->driver_name()) {
        case 'sqlite':
            $pathRaw = $config['db_path'] ?? '';
            $path = is_string($pathRaw) ? $pathRaw : '';
            if ($path === '') {
                throw new RuntimeException('ipam_db: sqlite driver requires $config[\'db_path\']');
            }
            $dir = dirname($path);
            if (!is_dir($dir)) {
                mkdir($dir, 0700, true);
            }
            $pdo = new PDO('sqlite:' . $path, null, null, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            $pdo->exec("PRAGMA journal_mode = WAL;");
            $pdo->exec("PRAGMA busy_timeout = 30000;");
            break;

        case 'mysql':
            $dsnRaw  = $config['db_dsn']  ?? '';
            $userRaw = $config['db_user'] ?? '';
            $passRaw = $config['db_pass'] ?? '';
            $dsn  = is_string($dsnRaw)  ? $dsnRaw  : '';
            $user = is_string($userRaw) ? $userRaw : '';
            $pass = is_string($passRaw) ? $passRaw : '';
            if ($dsn === '') {
                throw new RuntimeException('ipam_db: mysql driver requires $config[\'db_dsn\']');
            }
            $pdo = new PDO($dsn, $user, $pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            // 8.0.29 is the effective minimum. ensure_audit_log_table()
            // and MysqlDialect::append_only_trigger() both emit
            // `CREATE TRIGGER IF NOT EXISTS`, a syntax feature added in
            // MySQL 8.0.29. Earlier 8.0.x servers pass a naive `8.0.0`
            // check and then crash on the first self-heal bootstrap.
            // Reject at connect time so failures are clear and immediate.
            $serverVersionRaw = $pdo->getAttribute(PDO::ATTR_SERVER_VERSION);
            $serverVersion = is_string($serverVersionRaw) ? $serverVersionRaw : '';

            // v2.12.0 #534: first-class MariaDB 10.11+ support.
            // PDO::ATTR_SERVER_VERSION returns e.g. "10.11.6-MariaDB" or
            // "5.5.5-10.11.6-MariaDB" (the 5.5.5 prefix is a historical
            // protocol-compat lie). Detect MariaDB, strip the prefix, and
            // enforce a separate version floor.
            if ($serverVersion !== '' && stripos($serverVersion, 'mariadb') !== false) {
                $cleaned = preg_replace('/^5\.5\.5-/', '', $serverVersion);
                $cleaned = is_string($cleaned) ? $cleaned : $serverVersion;
                preg_match('/^(\d+\.\d+\.\d+)/', $cleaned, $mariaMatch);
                $mariaVersion = $mariaMatch[1] ?? '0.0.0';
                if (version_compare($mariaVersion, '10.11.0', '<')) {
                    throw new RuntimeException(
                        "MariaDB 10.11.0+ is required (server reports '$serverVersion')"
                    );
                }
                break;
            }

            if ($serverVersion === '' || version_compare($serverVersion, '8.0.29', '<')) {
                throw new RuntimeException(
                    "MySQL 8.0.29+ is required (server reports '$serverVersion')"
                );
            }
            break;

        case 'pgsql':
            // v2.11.0 #386 experimental Postgres driver. Uses the same
            // $config['db_dsn'] / $config['db_user'] / $config['db_pass']
            // keys as the MySQL branch so config.php shape is symmetric.
            $dsnRaw  = $config['db_dsn']  ?? '';
            $userRaw = $config['db_user'] ?? '';
            $passRaw = $config['db_pass'] ?? '';
            $dsn  = is_string($dsnRaw)  ? $dsnRaw  : '';
            $user = is_string($userRaw) ? $userRaw : '';
            $pass = is_string($passRaw) ? $passRaw : '';
            if ($dsn === '') {
                throw new RuntimeException('ipam_db: pgsql driver requires $config[\'db_dsn\']');
            }
            $pdo = new PDO($dsn, $user, $pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            // 14 is the effective minimum. PgsqlDialect::append_only_trigger()
            // emits `CREATE OR REPLACE TRIGGER`, a syntax feature added in
            // PG14. Earlier Postgres servers would fail on the first
            // ensure_audit_log_table() self-heal. Reject at connect time so
            // failures are clear and immediate.
            //
            // PDO::ATTR_SERVER_VERSION on pdo_pgsql returns a bare numeric
            // string like "14.10" or "17.2" (no "-MariaDB"-style suffix
            // concerns). version_compare handles these cleanly.
            $serverVersionRaw = $pdo->getAttribute(PDO::ATTR_SERVER_VERSION);
            $serverVersion = is_string($serverVersionRaw) ? $serverVersionRaw : '';
            if ($serverVersion === '' || version_compare($serverVersion, '14.0', '<')) {
                throw new RuntimeException(
                    "PostgreSQL 14+ is required (server reports '$serverVersion'). "
                    . 'For v2.11.0, use Postgres 14+ or stay on the SQLite driver.'
                );
            }
            // Force client_encoding to UTF-8 so binary IP round-trips and
            // text comparisons are deterministic regardless of the server's
            // default. Matches the implicit UTF-8 assumption on SQLite and
            // MySQL (utf8mb4).
            $pdo->exec("SET client_encoding = 'UTF8'");
            // pdo_pgsql returns BYTEA columns as PHP stream resources rather
            // than strings, regardless of how they were bound. Without an
            // auto-unwrap, every `ip_bin` / `network_bin` SELECT in the
            // codebase would break on pgsql. Install a custom PDOStatement
            // subclass that walks each fetched row and stream_get_contents()
            // any resource values. This keeps the ~80 existing call sites
            // unchanged. Surfaced by PgsqlSmokeTest during v2.11.0 #387.
            require_once __DIR__ . '/PgsqlStatement.php';
            $pdo->setAttribute(PDO::ATTR_STATEMENT_CLASS, [PgsqlStatement::class]);
            break;

        default:
            throw new RuntimeException('ipam_db: unreachable — unsupported driver ' . $dialect->driver_name());
    }

    $fk = $dialect->pragma_foreign_keys(true);
    if ($fk !== null) {
        $pdo->exec($fk);
    }
    return $pdo;
}

/**
 * Create the audit_log table and its append-only triggers (idempotent).
 * Centralises DDL that was previously duplicated in 4 places.
 *
 * Routes type declarations and triggers through the active dialect so
 * fresh MySQL / Postgres installs emit engine-valid DDL. On SQLite the
 * resulting text matches the pre-v2.10.0 literals byte-for-byte. Per
 * the v2.10.0 schema-files decision: historical migration closures are
 * NOT refactored — schema.mysql.sql / schema.pgsql.sql pre-populate
 * schema_migrations so replay is a no-op on fresh non-SQLite installs.
 */
function ensure_audit_log_table(PDO $db): void
{
    // Probe first: if audit_log already exists, skip the full CREATE
    // TABLE / CREATE INDEX / CREATE TRIGGER path on this request. The
    // probe is a no-row SELECT — a few microseconds per page on every
    // engine.
    //
    // Without this short-circuit, ipam_db_init() runs the full CREATE
    // path on every page load. On Postgres the CREATE OR REPLACE TRIGGER
    // emitted by PgsqlDialect::append_only_trigger() races on the system
    // catalog when multiple concurrent requests (page + sub-resource
    // assets, or parallel API calls) hit init.php at the same time —
    // surfacing as SQLSTATE[XX000] "tuple concurrently updated" and a
    // sporadic 500 on whichever request lost the race. Documented in the
    // v3.24.0 release notes.
    //
    // No process-wide caching: demo_reset_db() drops audit_log mid-
    // request, so a cache that persists across calls would skip the
    // self-heal that the next request needs. The probe is cheap enough
    // to run every time. The race protection comes from the probe
    // gating the CREATE OR REPLACE — if the table exists, no DDL fires.
    try {
        $probe = $db->query("SELECT 1 FROM audit_log LIMIT 0");
        if ($probe !== false) {
            $probe->closeCursor();
            // Table exists. Verify the append-only triggers also exist;
            // if either is missing (operator manually dropped them, an
            // external migration omitted them, etc.) we MUST recreate
            // them so audit-row immutability stays enforced. The probe
            // is one extra cheap row-count query per request — much
            // smaller than rebuilding the table + indexes — and it
            // preserves the v3.24.0 race fix because the CREATE OR
            // REPLACE TRIGGER path only runs when triggers are
            // genuinely missing (rare; never on the steady-state
            // request path).
            if (!ipam_audit_log_triggers_present($db)) {
                ensure_audit_log_triggers($db);
            }
            return;
        }
    } catch (PDOException) {
        // table missing — fall through to the full create + trigger path
    }

    $d = ipam_dialect();
    // action and created_at are indexed below, so they must use the
    // indexed text type (VARCHAR on MySQL, TEXT elsewhere). Free-form
    // unindexed columns (username, entity_type, ip, user_agent, details)
    // stay as plain TEXT.
    $idxText = $d->indexed_text_type();
    $db->exec("
        CREATE TABLE IF NOT EXISTS audit_log (
          id          " . $d->autoincrement() . ",
          created_at  $idxText NOT NULL DEFAULT (" . $d->now() . "),
          user_id     INTEGER, username TEXT, action $idxText NOT NULL,
          entity_type TEXT NOT NULL, entity_id INTEGER,
          ip TEXT, user_agent TEXT, details TEXT
        )
    ");
    // CREATE INDEX IF NOT EXISTS is a SQLite idiom. MySQL 8.0.0–8.0.28 do
    // not accept it (IF NOT EXISTS on CREATE INDEX landed in 8.0.29, which
    // is above our effective 8.0.29 floor), so we use a helper that swallows
    // the MySQL "Duplicate key name" error (errno 1061). On SQLite the
    // IF NOT EXISTS is native and the catch never fires.
    $createIndex = static function (PDO $db, string $name, string $table, string $col): void {
        try {
            $db->exec("CREATE INDEX IF NOT EXISTS $name ON $table($col)");
        } catch (PDOException $e) {
            $msg = $e->getMessage();
            // MySQL raises 1061 with "Duplicate key name" when the index
            // already exists. On MySQL 8.0.0–8.0.28, CREATE INDEX IF NOT
            // EXISTS itself is rejected (syntax error 1064) — retry with
            // plain CREATE INDEX, then swallow 1061 if the index is
            // already there.
            $sqlstate = (string)($e->errorInfo[0] ?? '');
            if ($sqlstate === '42000' && stripos($msg, 'syntax') !== false) {
                try {
                    $db->exec("CREATE INDEX $name ON $table($col)");
                } catch (PDOException $e2) {
                    if (stripos($e2->getMessage(), 'duplicate key name') === false) {
                        throw $e2;
                    }
                }
                return;
            }
            throw $e;
        }
    };
    $createIndex($db, 'idx_audit_log_action',     'audit_log', 'action');
    $createIndex($db, 'idx_audit_log_created_at', 'audit_log', 'created_at');
    ensure_audit_log_triggers($db);
}

/**
 * (Re)create the audit_log append-only triggers (idempotent).
 *
 * Extracted from ensure_audit_log_table() so callers that explicitly
 * DROP the triggers — currently only prune_audit_log() under SQLite —
 * can put them back without relying on a side effect of the table-
 * creation function. ensure_audit_log_table()'s probe returns early
 * when the table exists, so it cannot be the recovery path for missing
 * triggers in isolation.
 */
function ensure_audit_log_triggers(PDO $db): void
{
    $d = ipam_dialect();
    foreach ($d->append_only_trigger('audit_log') as $stmt) {
        try {
            $db->exec($stmt);
        } catch (PDOException $e) {
            // MySQL 8.0.0–8.0.28 do not support CREATE TRIGGER IF NOT EXISTS
            // (added in 8.0.29). Swallow "Trigger already exists" (errno 1359)
            // so the self-heal path is idempotent on every supported 8.0.x.
            if (stripos($e->getMessage(), 'already exists') === false) {
                throw $e;
            }
        }
    }
}

/**
 * Probe for the audit_log append-only triggers. Returns true iff BOTH
 * audit_log_no_update and audit_log_no_delete exist on this driver.
 *
 * Used by ensure_audit_log_table() to keep the steady-state fast path
 * cheap (one SELECT per request) while still self-healing if an external
 * action drops the triggers — preserving the v3.24.0 race fix because
 * CREATE OR REPLACE TRIGGER only fires when the probe says they're
 * missing, never on the steady-state path.
 *
 * Per-driver SQL:
 *   sqlite — sqlite_master where type='trigger'
 *   mysql  — information_schema.triggers (current schema)
 *   pgsql  — pg_trigger ⨝ pg_class on tgrelid
 *
 * Returns false on any probe failure so the caller falls through to
 * ensure_audit_log_triggers() (idempotent on every engine).
 */
function ipam_audit_log_triggers_present(PDO $db): bool
{
    // Dialect::driver_name() is constrained to 'sqlite' | 'mysql' |
    // 'pgsql' by the type system, so the match is exhaustive. If a
    // future driver is added, PHP will surface UnhandledMatchError
    // until the new arm lands here — exactly the safety we want.
    $sql = match (ipam_dialect()->driver_name()) {
        'sqlite' =>
            "SELECT COUNT(*) FROM sqlite_master " .
            "WHERE type = 'trigger' " .
            "AND name IN ('audit_log_no_update', 'audit_log_no_delete')",
        'mysql' =>
            "SELECT COUNT(*) FROM information_schema.triggers " .
            "WHERE event_object_table = 'audit_log' " .
            "AND trigger_name IN ('audit_log_no_update', 'audit_log_no_delete') " .
            "AND trigger_schema = DATABASE()",
        'pgsql' =>
            "SELECT COUNT(*) FROM pg_trigger t " .
            "JOIN pg_class c ON c.oid = t.tgrelid " .
            "WHERE c.relname = 'audit_log' " .
            "AND t.tgname IN ('audit_log_no_update', 'audit_log_no_delete')",
    };
    try {
        $st = $db->query($sql);
        if ($st === false) {
            return false;
        }
        return to_int($st->fetchColumn()) >= 2;
    } catch (PDOException) {
        return false;
    }
}

function ipam_db_init(PDO $db): void
{
    global $config;
    $driver = ipam_dialect()->driver_name();

    // Probe for the users table on THIS handle. A lightweight SELECT with a
    // caught "table not found" — works on every engine without needing
    // sqlite_master / information_schema branching.
    $hasUsers = false;
    try {
        $probe = $db->query("SELECT 1 FROM users LIMIT 1");
        if ($probe !== false) {
            $probe->closeCursor();
            $hasUsers = true;
        }
    } catch (PDOException) {
        $hasUsers = false;
    }

    // SQLite-only fast path: when the handle already has the schema AND the
    // sentinel file is at least as new as the SQLite DB file, skip the
    // per-bootstrap probe/migration churn. MySQL has no local file to stat,
    // so this optimisation does not apply there.
    //
    // The $hasUsers guard is load-bearing: it keeps a sqlite::memory: handle
    // (which does NOT correspond to the on-disk db_path the sentinel stats —
    // e.g. unit tests that call ipam_db_init() directly) from wrongly taking
    // the fast path and running apply_migrations() against an empty in-memory
    // database. Migrations assume the schema.sql baseline already exists, so
    // a fresh handle MUST fall through to the schema-creation branch below.
    // (#1175 — RestoreDryRunTest::testIpambkl1ArchiveDoesNotErrorThroughSqlSplitter.)
    if ($driver === 'sqlite' && $hasUsers) {
        // Honour a deployment's configured db_path so the sentinel check
        // stats the real database file, not the default one. The sentinel
        // itself lives next to the DB file so custom paths stay
        // self-contained.
        $dbPathRaw  = is_array($config ?? null) ? ($config['db_path'] ?? null) : null;
        $dbFilePath = is_string($dbPathRaw) && $dbPathRaw !== ''
            ? $dbPathRaw
            : __DIR__ . '/data/ipam.sqlite';
        $sentinelPath = dirname($dbFilePath) . '/.db_initialized';
        if (is_file($sentinelPath) && is_file($dbFilePath)) {
            $sentinelTime = (int)filemtime($sentinelPath);
            $dbTime       = (int)filemtime($dbFilePath);
            if ($sentinelTime >= $dbTime) {
                ensure_migrations_table($db);
                apply_migrations($db);
                ensure_audit_log_table($db); // self-heal if table was dropped
                return;
            }
        }
    }

    if (!$hasUsers) {
        $schemaFile = __DIR__ . '/schema.sql';
        if ($driver === 'mysql') {
            $schemaFile = __DIR__ . '/schema.mysql.sql';
        } elseif ($driver === 'pgsql') {
            $schemaFile = __DIR__ . '/schema.pgsql.sql';
        }
        $schema = file_get_contents($schemaFile);
        if ($schema === false) throw new RuntimeException("Cannot read " . basename($schemaFile));
        $db->exec($schema);

        $config = require __DIR__ . '/config.php';
        $u = $config['bootstrap_admin']['username'];
        $p = $config['bootstrap_admin']['password'];

        $hash = password_hash($p, PASSWORD_DEFAULT);
        $ins = $db->prepare("INSERT INTO users (username, password_hash, role, is_active) VALUES (:u,:h,'admin',1)");
        $ins->execute([':u' => $u, ':h' => $hash]);

        // Stamp all known migrations as already satisfied by the fresh schema.
        // schema.mysql.sql already pre-seeds these rows so the INSERT below
        // is a no-op on MySQL — upsert_or_ignore() makes that explicit and
        // lets the same path work on every driver.
        ensure_migrations_table($db);
        require_once __DIR__ . '/migrations.php';
        $ignore = ipam_dialect()->upsert_or_ignore('schema_migrations', ['version']);
        $stamp = $db->prepare("INSERT INTO schema_migrations (version) VALUES (:v) $ignore");
        foreach (array_keys(ipam_migrations()) as $ver) {
            $stamp->execute([':v' => $ver]);
        }
        return;
    }

    ensure_migrations_table($db);
    apply_migrations($db);

    // Self-healing: audit_log is created by schema.sql, not a migration, so it can
    // go missing after a botched demo reset. Recreate it (and its triggers) if absent.
    ensure_audit_log_table($db);

    $st = $db->prepare("SELECT COUNT(*) AS c FROM users");
    $st->execute();
    /** @var array<string, mixed>|false $countRow */
    $countRow = $st->fetch();
    $count = is_array($countRow) ? to_int($countRow['c']) : 0;
    if ($count === 0) {
        $config = require __DIR__ . '/config.php';
        $u = $config['bootstrap_admin']['username'];
        $p = $config['bootstrap_admin']['password'];
        $hash = password_hash($p, PASSWORD_DEFAULT);
        $ins = $db->prepare("INSERT INTO users (username, password_hash, role, is_active) VALUES (:u,:h,'admin',1)");
        $ins->execute([':u' => $u, ':h' => $hash]);
    }

    // Write sentinel so subsequent requests skip bootstrap queries (SQLite
    // only — the sentinel is a filesystem optimisation for the local DB
    // file and has no meaning on MySQL). Location must match the path
    // derived in the fast-path above: next to the resolved db_path file.
    if ($driver === 'sqlite') {
        $dbPathRaw  = is_array($config ?? null) ? ($config['db_path'] ?? null) : null;
        $dbFilePath = is_string($dbPathRaw) && $dbPathRaw !== ''
            ? $dbPathRaw
            : __DIR__ . '/data/ipam.sqlite';
        @touch(dirname($dbFilePath) . '/.db_initialized');
    }
}

function e(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * Safely coerce a mixed value (e.g. PDO fetch result or superglobal) to int.
 * Needed at PHPStan level 9 where (int) casts on mixed are disallowed.
 */
function to_int(mixed $value): int
{
    if (is_int($value)) return $value;
    if (is_float($value)) return (int)$value;
    if (is_string($value)) return (int)$value;
    if (is_bool($value)) return $value ? 1 : 0;
    return 0;
}

function format_bytes(int $bytes): string
{
    if ($bytes <= 0) return '0 B';
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = (int)floor(log($bytes, 1024));
    $i = min($i, count($units) - 1);
    $val = $bytes / (1024 ** $i);
    return ($i === 0 ? (string)$bytes : round($val, 1)) . ' ' . $units[$i];
}

/**
 * Safely coerce a mixed value (e.g. PDO fetch result or superglobal) to string.
 * Needed at PHPStan level 9 where (string) casts on mixed are disallowed.
 * Defined here for api.php/status.php which load lib.php directly without init.php.
 * init.php defines this function earlier so pages that use init.php see it immediately;
 * the function_exists guard prevents a fatal redefinition error.
 */
if (!function_exists('to_str')) {
    function to_str(mixed $value): string
    {
        if (is_string($value)) return $value;
        if (is_int($value) || is_float($value)) return (string)$value;
        if (is_bool($value)) return $value ? '1' : '';
        if ($value === null) return '';
        return '';
    }
}

/* ---------------- View helpers (v3.8.0, #522) ---------------- */

/**
 * Render a PHP partial from Simple-PHP-IPAM/views/<view>.php.
 *
 * Props are extracted into the partial's local scope via extract() with
 * EXTR_SKIP so that no prop can shadow an existing variable. The partial
 * is a plain PHP file — no compiled syntax, no reserved directives, no
 * templating engine. This is the idiomatic code-reuse pattern for this
 * project (see CLAUDE.md "Runtime dependencies → UI and rendering").
 *
 * @param string               $view  Partial name without the .php extension
 *                                    (e.g. 'subnet_row' for views/subnet_row.php).
 * @param array<string, mixed> $props Variables to extract into the partial scope.
 * @throws \RuntimeException          If the partial file does not exist.
 */
function ipam_render(string $view, array $props = []): void
{
    if ($view !== basename($view) || $view === '') {
        throw new \InvalidArgumentException("Invalid view name: $view");
    }
    $path = __DIR__ . '/views/' . $view . '.php';
    if (!is_file($path)) {
        throw new \RuntimeException("View not found: $view");
    }
    extract($props, EXTR_SKIP);
    require $path;
}

/**
 * Render a PHP partial and return the output as a string.
 *
 * Buffers the output of ipam_render() and returns it. Useful when the
 * rendered fragment must be stored or passed to another function before
 * being sent to the client.
 *
 * @param string               $view  Partial name without the .php extension.
 * @param array<string, mixed> $props Variables to extract into the partial scope.
 * @return string                     The captured partial output.
 */
function ipam_render_string(string $view, array $props = []): string
{
    $level = ob_get_level();
    ob_start();
    try {
        ipam_render($view, $props);
        $out = ob_get_clean();
        return $out === false ? '' : $out;
    } catch (\Throwable $e) {
        while (ob_get_level() > $level) {
            ob_end_clean();
        }
        throw $e;
    }
}

/**
 * Render an SVG icon from the sprite sheet.
 *
 * Returns an inline <svg><use> element referencing the icon sprite.
 * Decorative — always aria-hidden and focusable=false.
 * Use the $cls parameter to add sizing classes (e.g. 'icon-lg').
 *
 * @param string $name  Icon name (without 'icon-' prefix), e.g. 'home', 'cog'
 * @param string $cls   Additional CSS classes to append (space-separated)
 * @return string       HTML string safe to echo directly
 */
function icon(string $name, string $cls = ''): string
{
    $c = trim('icon ' . $cls);
    return '<svg class="' . e($c) . '" aria-hidden="true" focusable="false">'
         . '<use href="#icon-' . e($name) . '"></use>'
         . '</svg>';
}

/* ---------------- Timestamp display ---------------- */

/**
 * Convert a UTC SQLite timestamp string to the configured timezone for display.
 *
 * All timestamps are stored as UTC ('YYYY-MM-DD HH:MM:SS'). This helper converts
 * them to the timezone configured in config.php['timezone'] (default 'UTC').
 * Apply to every timestamp echo in the UI rather than using the raw DB value.
 *
 * @param  string $utcStr  UTC datetime string from the database, or empty string.
 * @param  string $format  PHP date() format string. Defaults to 'Y-m-d H:i:s'.
 * @return string          Formatted datetime in the configured timezone, or '' if input is empty.
 */
function display_datetime(string $utcStr, string $format = 'Y-m-d H:i:s'): string
{
    return ipam_format_datetime($utcStr, $format);
}

/**
 * Resolve the effective display timezone for a user.
 *
 * Fallback chain: per-user users.timezone → branding.timezone setting → PHP default → UTC.
 * Result is cached per userId per request to avoid redundant DB queries.
 */
function ipam_user_timezone(?int $userId = null): string
{
    static $userCache = [];

    if ($userId === null) {
        $uid = isset($_SESSION) ? to_int($_SESSION['uid'] ?? 0) : 0;
        $userId = $uid > 0 ? $uid : null;
    }

    // Cache per-user DB lookups only; ipam_setting() has its own cache.
    if ($userId !== null && isset($userCache[$userId])) {
        return $userCache[$userId];
    }

    $tz = '';

    if ($userId !== null) {
        /** @var \PDO|null $globalDb */
        $globalDb = $GLOBALS['db'] ?? null;
        if ($globalDb instanceof \PDO) {
            try {
                $st = $globalDb->prepare("SELECT timezone FROM users WHERE id = :id");
                $st->execute([':id' => $userId]);
                $row = $st->fetch();
                if (is_array($row) && isset($row['timezone']) && is_string($row['timezone']) && $row['timezone'] !== '') {
                    $tz = $row['timezone'];
                }
            } catch (\Exception) {}
        }
    }

    if ($tz === '') $tz = to_str(ipam_setting('branding.timezone'));
    if ($tz === '') $tz = date_default_timezone_get() ?: 'UTC';

    try { new \DateTimeZone($tz); } catch (\Exception) { $tz = 'UTC'; }

    if ($userId !== null) $userCache[$userId] = $tz;
    return $tz;
}

/**
 * Format a UTC timestamp for display in the current user's timezone.
 *
 * Accepts either:
 *   - a UTC datetime string (e.g. "2026-04-30 12:34:56" or ISO-8601 "...Z")
 *   - an int Unix epoch (seconds since 1970-01-01 UTC)
 *
 * Default format includes the TZ abbreviation ('Y-m-d H:i T'). Pass $fmt to
 * override, or $userId to render in a specific user's timezone rather than the
 * session user's. Empty string / 0 / null returns ''.
 *
 * #782: this is the single display-side path for UTC→user-TZ conversion. New
 * code MUST route through here rather than calling gmdate()/date() inline.
 */
function ipam_format_datetime(string|int|null $utc, ?string $fmt = null, ?int $userId = null): string
{
    // Guard zero-ish inputs in either form: int 0 from epoch math, string '0'
    // from `to_str()` of a DB column, or literal empty string. Without the
    // string-'0' check, a default/zero timestamp falls through to DateTime()
    // and renders as a bogus 1970 date instead of blank.
    if ($utc === null || $utc === '' || $utc === 0 || $utc === '0') return '';
    $fmt = $fmt ?? 'Y-m-d H:i T';
    try {
        if (is_int($utc)) {
            $dt = (new \DateTime('@' . $utc))->setTimezone(new \DateTimeZone('UTC'));
        } else {
            $dt = new \DateTime($utc, new \DateTimeZone('UTC'));
        }
        $dt->setTimezone(new \DateTimeZone(ipam_user_timezone($userId)));
        return $dt->format($fmt);
    } catch (\Exception) {
        return is_int($utc) ? (string) $utc : $utc;
    }
}

/* ---------------- CSRF ---------------- */

function csrf_token(): string
{
    $t = $_SESSION['csrf'] ?? null;
    return is_string($t) ? $t : '';
}

function csrf_require(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
    $sent = $_POST['csrf'] ?? null;
    $real = csrf_token();
    if (!is_string($sent) || !hash_equals($real, $sent)) {
        // Hard 403 — never a redirect. PHP's `header('Location: ...')`
        // silently clobbers the response code to 302, which obscures the
        // CSRF failure and lets API/XHR clients silently follow the
        // redirect to login.php and re-submit. The set_theme.php B1
        // CSRF spec (#879) caught this regression.
        http_response_code(403);
        header('Content-Type: text/plain; charset=utf-8');
        echo "CSRF token missing or invalid.\n";
        exit;
    }
}

/* ---------------- Auth / RBAC ---------------- */

function is_logged_in(): bool { return !empty($_SESSION['uid']); }

/**
 * Stash a same-origin request URI in the session so the user can be
 * redirected back to it after they finish logging in (including any MFA
 * detour). Only safe relative paths are accepted — schemes, hosts, embedded
 * newlines, and parent-directory traversal are all rejected to prevent
 * open-redirect and header-injection.
 */
function ipam_post_login_redirect_stash(string $uri): void
{
    if ($uri === '' || $uri[0] !== '/' || str_starts_with($uri, '//')) return;
    if (preg_match('/[\r\n]/', $uri)) return;
    if (str_contains($uri, '..')) return;
    // Reject backslashes — some browsers canonicalise them to forward slashes,
    // which would let "/\evil.com" become "//evil.com" after normalisation.
    if (str_contains($uri, '\\')) return;
    if (strlen($uri) > 1024) return;
    $_SESSION['post_login_redirect'] = $uri;
}

/**
 * Pull and clear the stashed post-login URI. Returns $default if nothing is
 * stashed or the stashed value fails revalidation (defence in depth — same
 * checks as stash, in case the session was tampered with).
 */
function ipam_post_login_redirect_consume(string $default = 'dashboard.php'): string
{
    $uri = to_str($_SESSION['post_login_redirect'] ?? '');
    unset($_SESSION['post_login_redirect']);
    if ($uri === '' || $uri[0] !== '/' || str_starts_with($uri, '//')) return $default;
    if (preg_match('/[\r\n]/', $uri)) return $default;
    if (str_contains($uri, '..')) return $default;
    // Reject backslashes — see note in ipam_post_login_redirect_stash().
    if (str_contains($uri, '\\')) return $default;
    if (strlen($uri) > 1024) return $default;
    return $uri;
}

function require_login(): void
{
    if (!is_logged_in()) {
        ipam_post_login_redirect_stash(to_str($_SERVER['REQUEST_URI'] ?? ''));
        header('Location: login.php');
        exit;
    }
    $idle = to_int(ipam_setting('security.session_idle_seconds'));
    if (isset($_SESSION['last_active']) && (time() - to_int($_SESSION['last_active'])) > $idle) {
        // Stash the URI before logout_user() wipes the session so the
        // post-login redirect survives the idle-timeout bounce.
        $stashUri = to_str($_SERVER['REQUEST_URI'] ?? '');
        logout_user();
        if ($stashUri !== '') {
            session_start();
            ipam_post_login_redirect_stash($stashUri);
            session_write_close();
        }
        header('Location: login.php?timeout=1');
        exit;
    }
    $_SESSION['last_active'] = time();

    $maxAge = to_int(ipam_setting('password_policy.max_password_age_days'));
    if ($maxAge > 0) {
        $page = basename(to_str($_SERVER['SCRIPT_FILENAME'] ?? ''));
        if (!in_array($page, ['change_password.php', 'logout.php'], true)) {
            try {
                $db = $GLOBALS['db'] ?? null;
                if ($db instanceof PDO) {
                    $st = $db->prepare("SELECT oidc_sub, password_changed_at FROM users WHERE id = :id");
                    $st->execute([':id' => to_int($_SESSION['uid'] ?? 0)]);
                    /** @var array<string, mixed>|false $row */
                    $row = $st->fetch();
                    if ($row && $row['oidc_sub'] === null) {
                        $changedAt = to_str($row['password_changed_at'] ?? '');
                        $cutoff    = date('Y-m-d H:i:s', time() - $maxAge * 86400);
                        if ($changedAt === '' || $changedAt < $cutoff) {
                            header('Location: change_password.php?expired=1');
                            exit;
                        }
                    }
                }
            } catch (Throwable) {
                // Column may not exist yet on pre-1.4 installs — silently skip
            }
        }
    }

    if (!empty($_SESSION['mfa_enrollment_required'])) {
        $page = basename(to_str($_SERVER['SCRIPT_FILENAME'] ?? ''));
        if (!in_array($page, ['change_password.php', 'totp_enroll.php', 'logout.php'], true)) {
            header('Location: change_password.php?mfa_required=1');
            exit;
        }
    }
}

/**
 * Validate a password against the configured policy.
 * Returns an empty array on success, or an array of all violation messages.
 *
 * @param array<string, mixed> $policy
 * @return list<string>
 */
function validate_password_complexity(string $password, array $policy): array
{
    $errors = [];
    $min = max(1, to_int($policy['min_length'] ?? 12));
    if (mb_strlen($password) < $min) {
        $errors[] = "Password must be at least {$min} characters.";
    }
    if (!empty($policy['require_uppercase']) && !preg_match('/[A-Z]/', $password)) {
        $errors[] = 'Password must contain at least one uppercase letter (A–Z).';
    }
    if (!empty($policy['require_lowercase']) && !preg_match('/[a-z]/', $password)) {
        $errors[] = 'Password must contain at least one lowercase letter (a–z).';
    }
    if (!empty($policy['require_number']) && !preg_match('/[0-9]/', $password)) {
        $errors[] = 'Password must contain at least one number (0–9).';
    }
    if (!empty($policy['require_symbol']) && !preg_match('/[^A-Za-z0-9]/', $password)) {
        $errors[] = 'Password must contain at least one special character.';
    }
    return $errors;
}

/** @return array<string, mixed> */
function current_user(): array
{
    return [
        'id' => to_int($_SESSION['uid'] ?? 0),
        'username' => to_str($_SESSION['username'] ?? ''),
        'role' => to_str($_SESSION['role'] ?? ''),
    ];
}

function require_role(string $role): void
{
    require_login();
    if (current_user()['role'] !== $role) {
        http_response_code(403);
        exit('Forbidden');
    }
}

function require_write_access(): void
{
    require_login();
    if (current_user()['role'] === 'readonly') {
        http_response_code(403);
        exit('Read-only account');
    }
}

function login_user(int $uid, string $username, string $role, ?PDO $db = null): void
{
    session_regenerate_id(true);
    $_SESSION['uid'] = $uid;
    $_SESSION['username'] = $username;
    $_SESSION['role'] = $role;
    $_SESSION['last_active'] = time();
    // Seed absolute session lifetime from config at login time
    /** @var IpamConfig $cfg */
    $cfg = $GLOBALS['config'] ?? [];
    $absMin = (int)(($cfg['session']['absolute_lifetime_minutes'] ?? 480));
    if ($absMin > 0) {
        $_SESSION['_abs_expires'] = time() + ($absMin * 60);
    } else {
        unset($_SESSION['_abs_expires']);
    }
    // Load persisted theme preference so page_header() can prime localStorage
    if ($db !== null) {
        $st = $db->prepare("SELECT theme FROM users WHERE id = :id");
        $st->execute([':id' => $uid]);
        $theme = to_str($st->fetchColumn() ?: 'auto');
        $_SESSION['user_theme'] = in_array($theme, ['light', 'dark', 'auto'], true) ? $theme : 'auto';
    }
}

/* ---------------- Login rate limiting ---------------- */

/**
 * Generic per-action, per-IP rate limiter (#882). Counts rows in
 * login_attempts whose action matches and whose attempted_at is within the
 * sliding window. The legacy login_*-named helpers below remain as
 * action='login' wrappers so existing callers and tests are unaffected.
 */
function auth_rate_limited(PDO $db, string $action, string $ip, int $maxAttempts, int $windowSeconds): bool
{
    $cutoff = date('Y-m-d H:i:s', time() - $windowSeconds);
    $st = $db->prepare(
        "SELECT COUNT(*) AS c FROM login_attempts
          WHERE action = :a AND ip = :ip AND attempted_at >= :cutoff"
    );
    $st->execute([':a' => $action, ':ip' => $ip, ':cutoff' => $cutoff]);
    /** @var array<string, mixed>|false $countRow */
    $countRow = $st->fetch();
    return (is_array($countRow) ? to_int($countRow['c']) : 0) >= $maxAttempts;
}

function record_auth_failure(PDO $db, string $action, string $ip, string $username = ''): void
{
    $db->prepare(
        "INSERT INTO login_attempts (ip, username, action) VALUES (:ip, :username, :a)"
    )->execute([
        ':ip'       => $ip,
        ':username' => $username !== '' ? $username : null,
        ':a'        => $action,
    ]);
}

function clear_auth_failures(PDO $db, string $action, string $ip): void
{
    $db->prepare("DELETE FROM login_attempts WHERE action = :a AND ip = :ip")
       ->execute([':a' => $action, ':ip' => $ip]);
}

function login_rate_limited(PDO $db, string $ip, int $maxAttempts, int $windowSeconds): bool
{
    return auth_rate_limited($db, 'login', $ip, $maxAttempts, $windowSeconds);
}

/**
 * Real lockout-expiry timestamp for a rolling-window IP rate limit.
 *
 * The window is "max N failures in the past $windowSeconds." The unlock
 * moment is when the OLDEST currently-counted failure ages out — at that
 * point the window has only N-1 failures and a fresh attempt is allowed.
 * Returns time() + $windowSeconds as a sane fallback when no attempts
 * are recorded (caller is asking for a future window without any
 * existing data — shouldn't happen for actively-rate-limited IPs).
 *
 * Introduced for CR PR #1141: pre-fix, login.php sent
 * `time() + $lockoutSeconds` to ipam_audit_ip_rate_limited(), which
 * overstated the wait under steady traffic and could keep the dampener
 * suppressing past the real unlock point.
 */
function auth_rate_limit_unlock_at(PDO $db, string $action, string $ip, int $maxAttempts, int $windowSeconds): int
{
    $cutoff = date('Y-m-d H:i:s', time() - $windowSeconds);
    // CR PR #1141 round 2: locate the THRESHOLD-CROSSING failure (the
    // Nth-from-newest in the window). Pre-fix used MIN() of all
    // in-window failures, which is only correct when exactly N failures
    // exist. With more than N, expiring the absolute oldest still
    // leaves the IP blocked — `unlock_at` was reported too early and
    // the dampener could roll over before the real unlock point.
    $countSt = $db->prepare(
        "SELECT COUNT(*) FROM login_attempts
          WHERE action = :a AND ip = :ip AND attempted_at >= :cutoff"
    );
    $countSt->execute([':a' => $action, ':ip' => $ip, ':cutoff' => $cutoff]);
    $count = to_int($countSt->fetchColumn());
    if ($count === 0) {
        return time() + $windowSeconds;
    }
    // OFFSET = count - maxAttempts; e.g. with N=5 max and 7 in-window
    // failures, the threshold-crossing row is at OFFSET 2 (skipping the
    // 2 oldest that are about to age out before the lockout actually
    // lifts). With exactly N in-window failures, OFFSET = 0 == oldest.
    $offset = max(0, $count - $maxAttempts);
    $st = $db->prepare(
        "SELECT attempted_at FROM login_attempts
          WHERE action = :a AND ip = :ip AND attempted_at >= :cutoff
          ORDER BY attempted_at ASC
          LIMIT 1 OFFSET :offset"
    );
    $st->bindValue(':a',      $action,  PDO::PARAM_STR);
    $st->bindValue(':ip',     $ip,      PDO::PARAM_STR);
    $st->bindValue(':cutoff', $cutoff,  PDO::PARAM_STR);
    $st->bindValue(':offset', $offset,  PDO::PARAM_INT);
    $st->execute();
    $oldest = to_str($st->fetchColumn());
    if ($oldest === '') {
        return time() + $windowSeconds;
    }
    $oldestTs = strtotime($oldest);
    if ($oldestTs === false) {
        return time() + $windowSeconds;
    }
    return $oldestTs + $windowSeconds;
}

/**
 * Emit a once-per-window 'auth.ip_rate_limited' audit row (#1134, v3.27.3;
 * made atomic in v3.28.0 #1143).
 *
 * Pre-fix (#1134): login.php audited 'auth.login_blocked' on every refused
 * attempt within the rate-limit window — flooding the log with up to one
 * row per attempted login over the lockout window. Operators filtering
 * audit_log by username also missed these rows entirely (entity_id NULL,
 * username column NULL).
 *
 * #1134 contract: emit a single row per (action, ip) lockout window with
 * details = "action=$action attempts=$attempts unlock_at=$ISO8601 ip=$ip"
 * so the operator can grep it on either the audit_log.ip column or the
 * details substring; subsequent attempts inside the same window do not
 * re-emit.
 *
 * #1143: the original dampener enforced "once per window" by SELECTing the
 * most recent prior 'auth.ip_rate_limited' row out of audit_log and only
 * INSERTing if no active window was found — a read-then-insert TOCTOU that
 * let two concurrent brute-force requests both miss the prior row and both
 * emit. The window is now tracked in the `rate_limit_dampener` table
 * (PRIMARY KEY (action, ip), unlock_at = Unix epoch). The caller claims
 * the window with an UPDATE that only fires on an expired row, falling
 * back to an INSERT when no row exists at all; exactly one concurrent
 * caller wins the INSERT (PK collision), so at most one audit row is
 * emitted per window regardless of concurrency.
 */
function ipam_audit_ip_rate_limited(PDO $db, string $action, string $ip, int $attempts, int $unlockAt): void
{
    $now = time();

    // Claim this (action, ip) lockout window atomically. A row is "active"
    // while unlock_at > now; we may claim the window only when no active
    // row exists. Step 1: UPDATE an expired row to the new window (fires
    // exactly when a row exists AND it has expired). Step 2 (only if the
    // UPDATE matched nothing): INSERT a fresh row — succeeds when no row
    // exists, raises a UNIQUE violation when an active row already holds
    // the window (or a concurrent caller just inserted one), which we
    // treat as "already dampened".
    $upd = $db->prepare(
        "UPDATE rate_limit_dampener SET unlock_at = :u
          WHERE action = :a AND ip = :ip AND unlock_at <= :now"
    );
    $upd->execute([':u' => $unlockAt, ':a' => $action, ':ip' => $ip, ':now' => $now]);
    $claimed = $upd->rowCount() > 0;

    if (!$claimed) {
        try {
            $ins = $db->prepare(
                "INSERT INTO rate_limit_dampener (action, ip, unlock_at) VALUES (:a, :ip, :u)"
            );
            $ins->execute([':a' => $action, ':ip' => $ip, ':u' => $unlockAt]);
            $claimed = true;
        } catch (\PDOException $e) {
            $sqlstate = (string) ($e->errorInfo[0] ?? '');
            $msg = $e->getMessage();
            $isUniqueViolation = $sqlstate === '23000' || $sqlstate === '23505'
                || stripos($msg, 'unique') !== false
                || stripos($msg, 'duplicate') !== false;
            if (!$isUniqueViolation) {
                throw $e;
            }
            // Active row already holds the window — dampened.
        }
    }

    if (!$claimed) {
        return;
    }

    $unlockIso = gmdate('Y-m-d\TH:i:s\Z', $unlockAt);
    $emitted = audit($db, 'auth.ip_rate_limited', 'auth', null,
          "action=$action attempts=$attempts unlock_at=$unlockIso ip=$ip");
    if (!$emitted) {
        // audit() returns false (not an exception) on write failure. We just
        // claimed this (action, ip) window via the UPDATE/INSERT above, so the
        // claim is the only thing standing between subsequent attempts and a
        // (still missing) audit row. Roll the claim back so a later attempt in
        // the same window can re-attempt the emit.
        $db->prepare("DELETE FROM rate_limit_dampener WHERE action = :a AND ip = :ip")
           ->execute([':a' => $action, ':ip' => $ip]);
    }
}

/**
 * Housekeeping: drop rate_limit_dampener rows whose lockout window expired
 * more than $graceSeconds ago. The table is bounded by the number of
 * distinct (action, ip) pairs that have ever been rate-limited; a sustained
 * brute-force from many sources can grow it, so prune it during the lazy
 * housekeeping sweep alongside purge_old_login_attempts().
 */
function prune_rate_limit_dampener(PDO $db, int $graceSeconds = 86400): void
{
    $cutoff = time() - max(0, $graceSeconds);
    $db->prepare("DELETE FROM rate_limit_dampener WHERE unlock_at < :cutoff")
       ->execute([':cutoff' => $cutoff]);
}

function record_login_failure(PDO $db, string $ip, string $username = ''): void
{
    record_auth_failure($db, 'login', $ip, $username);
}

function clear_login_failures(PDO $db, string $ip): void
{
    clear_auth_failures($db, 'login', $ip);
}

function account_locked_out(PDO $db, string $username, int $maxAttempts, int $windowSeconds): bool
{
    $cutoff = date('Y-m-d H:i:s', time() - $windowSeconds);
    $st = $db->prepare(
        "SELECT COUNT(*) AS c FROM login_attempts WHERE username = :u AND attempted_at >= :cutoff"
    );
    $st->execute([':u' => $username, ':cutoff' => $cutoff]);
    /** @var array<string, mixed>|false $row */
    $row = $st->fetch();
    return (is_array($row) ? to_int($row['c']) : 0) >= $maxAttempts;
}

function clear_account_lockout(PDO $db, string $username): void
{
    $db->prepare("DELETE FROM login_attempts WHERE username = :u")
       ->execute([':u' => $username]);
}

/** @param IpamConfig $config */
function recovery_mode_enabled(array $config): bool
{
    return (bool)($config['recovery_mode'] ?? false);
}

function purge_old_login_attempts(PDO $db, int $windowSeconds): void
{
    $cutoff = date('Y-m-d H:i:s', time() - $windowSeconds);
    $db->prepare("DELETE FROM login_attempts WHERE attempted_at < :cutoff")
       ->execute([':cutoff' => $cutoff]);
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie((string)session_name(), '', time() - 42000,
            $params["path"], $params["domain"], $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
}

/* ---------------- Audit ---------------- */

/**
 * True if $ip falls inside any of the supplied CIDR blocks. Accepts both
 * IPv4 and IPv6 strings and CIDRs; returns false on parse error.
 *
 * @param list<string> $cidrs
 */
function ip_in_any_cidr(string $ip, array $cidrs): bool
{
    $ipBin = @inet_pton($ip);
    if ($ipBin === false) {
        return false;
    }
    foreach ($cidrs as $cidr) {
        $cidr = trim($cidr);
        if ($cidr === '' || strpos($cidr, '/') === false) {
            continue;
        }
        [$net, $prefixStr] = explode('/', $cidr, 2);
        $net = trim($net);
        $prefixStr = trim($prefixStr);
        // CR #1100: reject non-numeric prefixes before casting. Without
        // this guard, a typo like "10.0.0.0/abc" would cast to /0 and
        // ip_in_any_cidr() would match every IPv4 address — turning a
        // proxy_trust_cidrs typo into a "trust everyone" XFF spoofing
        // foothold. ctype_digit() is strict (no whitespace, no signs).
        if ($prefixStr === '' || !ctype_digit($prefixStr)) {
            continue;
        }
        $netBin = @inet_pton($net);
        if ($netBin === false || strlen($netBin) !== strlen($ipBin)) {
            continue;
        }
        $prefix = (int)$prefixStr;
        $bits   = strlen($ipBin) * 8;
        if ($prefix < 0 || $prefix > $bits) {
            continue;
        }
        $masked   = apply_prefix_mask($ipBin, $prefix);
        $netMaskd = apply_prefix_mask($netBin, $prefix);
        if ($masked === $netMaskd) {
            return true;
        }
    }
    return false;
}

function client_ip(): string
{
    $remote = to_str($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1');

    // New (v3.26.0+) preferred path: trust X-Forwarded-For only when the
    // direct REMOTE_ADDR is one of the operator-listed proxy CIDRs, then walk
    // the chain right-to-left and return the first untrusted hop. This is the
    // OWASP-recommended pattern (see docs/configuration.md → proxy_trust_cidrs).
    $cidrsRaw  = to_str(ipam_setting('security.proxy_trust_cidrs', ''));
    $cidrs     = array_values(array_filter(array_map('trim', preg_split('/[\r\n,]+/', $cidrsRaw) ?: [])));
    $xffHeader = to_str($_SERVER['HTTP_X_FORWARDED_FOR'] ?? '');

    if (!empty($cidrs)) {
        if (!ip_in_any_cidr($remote, $cidrs)) {
            return $remote;
        }
        if ($xffHeader === '') {
            return $remote;
        }
        $hops      = array_reverse(array_map('trim', explode(',', $xffHeader)));
        $candidate = $remote;
        foreach ($hops as $hop) {
            if (filter_var($hop, FILTER_VALIDATE_IP) === false) {
                return $candidate;
            }
            if (ip_in_any_cidr($hop, $cidrs)) {
                $candidate = $hop;
                continue;
            }
            return $hop;
        }
        return $candidate;
    }

    // Legacy back-compat: the old boolean `proxy_trust` flag in config.php
    // unconditionally trusted the leftmost X-Forwarded-For value. That is
    // unsafe (the leftmost hop is whatever the original client sent and is
    // freely spoofable) but operators relying on it must not break silently
    // on upgrade. Emit a one-shot deprecation log per request and keep the
    // old behaviour. Operators should migrate to security.proxy_trust_cidrs.
    /** @var IpamConfig|null $gConf */
    $gConf = $GLOBALS['config'] ?? null;
    if ($gConf !== null && !empty($gConf['proxy_trust']) && $xffHeader !== '') {
        static $warned = false;
        if (!$warned) {
            error_log('client_ip: legacy `proxy_trust` config flag is deprecated; configure security.proxy_trust_cidrs instead (#876).');
            $warned = true;
        }
        $parts     = array_map('trim', explode(',', $xffHeader));
        $candidate = $parts[0];
        if (filter_var($candidate, FILTER_VALIDATE_IP) !== false) {
            return $candidate;
        }
    }
    return $remote;
}

function flash_set(string $message, string $type = 'success'): void
{
    $_SESSION['ipam_flash'] = ['msg' => $message, 'type' => $type];
}

/** @return array{msg: string, type: string}|null */
function flash_get(): ?array
{
    if (empty($_SESSION['ipam_flash'])) return null;
    $flash = $_SESSION['ipam_flash'];
    unset($_SESSION['ipam_flash']);
    if (!is_array($flash)) return null;
    $msg  = is_string($flash['msg']  ?? null) ? $flash['msg']  : '';
    $type = is_string($flash['type'] ?? null) ? $flash['type'] : 'info';
    return ['msg' => $msg, 'type' => $type];
}

/**
 * Allowed audit-action prefixes (categories).
 * Shared between audit.php (UI filter) and api.php (/audit endpoint).
 */
const AUDIT_FILTER_PREFIXES = [
    'address', 'aggregate', 'alert', 'apikey', 'audit', 'auth', 'backup',
    'backup_run', 'config', 'contact', 'custom_field', 'db', 'destination',
    'device', 'device_interface', 'dhcp_pool', 'export', 'import', 'mail',
    'mfa', 'pd_pool', 'remote_backup', 'restore', 'scan', 'setting',
    'settings', 'site', 'subnet', 'tag', 'user', 'vault', 'vlan', 'vrf',
    'webhook',
];

/**
 * Validate an audit-prefix filter string. Returns the prefix if it matches the
 * allowlist, or '' if not. Use for ?prefix=foo style filters.
 */
function audit_filter_validate_prefix(string $raw): string
{
    $p = trim($raw);
    return ($p !== '' && in_array($p, AUDIT_FILTER_PREFIXES, true)) ? $p : '';
}

/**
 * Validate an exact audit-action filter string. Returns the action if it
 * matches the <prefix>.<verb> regex, or '' if not. Use for ?action=auth.login
 * style filters; no SQL-injection surface beyond bind.
 */
function audit_filter_validate_action(string $raw): string
{
    $a = trim($raw);
    // CR #1100: allow multi-segment actions like 'mfa.otp.fail' or
    // 'backup.vault_key.revealed'. The previous single-dot regex
    // rejected every audit row this codebase emits with two-dot
    // hierarchies, so ?action=<that> filters could never match.
    return ($a !== '' && preg_match('/^[a-z_]+(?:\.[a-z_]+)+$/', $a)) ? $a : '';
}

/**
 * Append a row to audit_log. Returns true on success, false on PDO failure
 * (with the failure logged via error_log). Callers that need to surface
 * audit failures (e.g. cron jobs) should check the return value; user-facing
 * pages can continue to ignore it. Pre-v3.26.0 this function was `void` and
 * would let exceptions propagate up the page, sometimes bubbling past the
 * page layout and rendering a blank screen.
 *
 * v3.26.0 (#1100 CR review): when invoked inside an active transaction,
 * a PDO failure RETHROWS rather than silently returning false. Callers
 * like ipam_setting_set() and auto_reserve_subnet_ips() rely on the
 * audit row landing atomically with the persisted state change; if the
 * audit insert fails, the surrounding transaction must roll back so
 * we don't commit state without its corresponding audit entry. Outside
 * an active transaction (most user-facing pages and cron tasks) the
 * legacy false-return behaviour is preserved.
 */
function audit(PDO $db, string $action, string $entityType, ?int $entityId, string $details = ''): bool
{
    $u = current_user();
    try {
        $st = $db->prepare("INSERT INTO audit_log (user_id, username, action, entity_type, entity_id, ip, user_agent, details)
                            VALUES (:uid,:un,:ac,:et,:eid,:ip,:ua,:dt)");
        $st->execute([
            ':uid' => $u['id'] ?: null,
            ':un'  => $u['username'] ?: null,
            ':ac'  => $action,
            ':et'  => $entityType,
            ':eid' => $entityId,
            ':ip'  => client_ip() ?: null,
            ':ua'  => to_str($_SERVER['HTTP_USER_AGENT'] ?? ''),
            ':dt'  => $details,
        ]);
        return true;
    } catch (\PDOException $e) {
        error_log("audit failed: action={$action} entity={$entityType} id="
            . ($entityId === null ? 'NULL' : (string)$entityId)
            . ' err=' . $e->getMessage());
        if ($db->inTransaction()) {
            throw $e;
        }
        return false;
    }
}

function audit_export(PDO $db, string $what, string $details = ''): void
{
    audit($db, "export.$what", 'system', null, $details);
}

/**
 * v3.28.2 #1178 — write the one-shot `install_keys_announce.<key>` banner
 * flag directly, bypassing `ipam_setting_set()`'s `setting.update` audit
 * emit so the only audit row for an install-key event is the intentional
 * `<key>_autogenerated` row. The flag row itself was seeded into the
 * settings table by `ipam_setting_definitions()` + the bottom-of-
 * migrations seed loop, so an UPDATE is sufficient on any v3.28.2 install
 * — INSERT-IF-NOT-EXISTS covers installs that somehow missed the seed.
 *
 * Internal helper: external callers should not call this directly.
 *
 * @throws \PDOException on DB error; callers wrap in try/catch.
 */
function _ipam_install_key_announce_write(PDO $db, string $key, string $value): void
{
    // MySQL's UNIQUE(tenant_id, key) does NOT enforce uniqueness on
    // rows with tenant_id = NULL (SQL standard: NULL != NULL in
    // uniqueness). Two concurrent writers can both see
    // `rowCount() === 0` and both INSERT, creating duplicate global
    // rows. Mirror ipam_setting_set()'s GET_LOCK serialisation
    // (SQLite + Postgres are immune via their partial-unique index
    // on (key) WHERE tenant_id IS NULL).
    $lockName = null;
    if (ipam_dialect()->driver_name() === 'mysql') {
        // 64-byte cap on MySQL lock names; hash to bound length.
        $lockName = 'ipam_setting:' . md5($key . ':__GLOBAL__');
        $lockStmt = $db->prepare("SELECT GET_LOCK(:n, 5)");
        $lockStmt->execute([':n' => $lockName]);
        // GET_LOCK returns 1 (acquired), 0 (timeout), or NULL (error). If
        // we proceed without holding it, the duplicate-NULL-tenant race
        // is back. Bail loudly — the caller's try/catch logs + swallows.
        if ((string)$lockStmt->fetchColumn() !== '1') {
            $lockName = null; // do not RELEASE_LOCK in finally
            throw new RuntimeException(
                '_ipam_install_key_announce_write: GET_LOCK timeout/error for ' . $key
            );
        }
    }
    try {
        $kc  = ipam_key_col();
        $upd = $db->prepare(
            "UPDATE settings SET value = :v WHERE tenant_id IS NULL AND {$kc} = :k"
        );
        $upd->execute([':v' => $value, ':k' => $key]);
        if ($upd->rowCount() === 0) {
            // MySQL's PDO rowCount() returns affected (changed) rows, not
            // matched. An UPDATE that sets the same value the row already
            // has reports 0 even though the row exists. Without this probe,
            // every re-write of the same value would fall through to INSERT
            // and accumulate duplicate NULL-tenant rows. The GET_LOCK above
            // already serialises concurrent writers on MySQL, so this SELECT
            // is race-free.
            $probe = $db->prepare(
                "SELECT 1 FROM settings WHERE tenant_id IS NULL AND {$kc} = :k"
            );
            $probe->execute([':k' => $key]);
            if ($probe->fetchColumn() !== false) {
                return;
            }
            $ins = $db->prepare(
                "INSERT INTO settings (tenant_id, {$kc}, value, type, updated_at) "
                . "VALUES (NULL, :k, :v, 'bool', CURRENT_TIMESTAMP)"
            );
            $ins->execute([':k' => $key, ':v' => $value]);
        }
    } finally {
        // $lockName === null on non-MySQL drivers (no lock taken); when
        // it is set, we threw if GET_LOCK didn't return 1, so reaching
        // this point means we hold the lock and must release it.
        if ($lockName !== null) {
            $db->prepare("SELECT RELEASE_LOCK(:n)")->execute([':n' => $lockName]);
        }
    }
}

/**
 * v3.28.2 #1178 — record that an install-root secret (`app_secret` or
 * `bootstrap_key`) was just auto-generated on first use.
 *
 * Writes an `audit_log` row plus a one-shot KV flag
 * (`install_keys_announce.<key>` — written via the silent
 * `_ipam_install_key_announce_write()` helper so the only audit row is
 * the intentional `<key>_autogenerated` event). The admin UI consumes
 * the flag to render a dismissible banner. The banner gap is the real
 * v3.28.2 fix — historically `bootstrap_key` could appear silently and
 * operators only noticed when a `config.php` mishap broke encrypted
 * backups; now both auto-gen paths surface the event.
 *
 * Defensive contract: this helper MUST NOT throw. The auto-gen callers
 * (`ipam_app_secret()`, `ipam_bootstrap_key()`) run on the hot path of
 * any request that needs the secret; a failed audit insert or a missing
 * `settings` table during very early bootstrap must not crater the
 * user-facing request. Any error is logged and swallowed.
 */
function ipam_install_key_announce_record(string $key): void
{
    if ($key !== 'app_secret' && $key !== 'bootstrap_key') {
        return;
    }

    // The project's primary PDO is opened by init.php and exposed via
    // `global $db;`. The auto-gen callers (ipam_app_secret() /
    // ipam_bootstrap_key()) only invoke this helper on the one-shot
    // generation path, so missing the announcement here drops the audit
    // row + banner forever — there is no "next request" that re-records
    // the event. When `$db` is not yet a PDO (very early bootstrap, or a
    // CLI seed script that opens its own connection), fall back to a
    // fresh `ipam_db($config)` connection rather than silently no-op.
    global $db, $config;
    $conn = $db instanceof PDO ? $db : null;
    if ($conn === null && isset($config) && function_exists('ipam_db')) {
        try {
            $conn = ipam_db($config);
        } catch (\Throwable $e) {
            error_log('[ipam_install_key_announce_record] ' . $key . ': fallback ipam_db() failed: ' . $e->getMessage());
            $conn = null;
        }
    }
    if (!($conn instanceof PDO)) {
        return; // Truly no DB reachable — bootstrap is too early; nothing we can do.
    }

    // The two writes are independent — an audit_log INSERT failure must
    // NOT prevent the banner flag from being set, because the auto-gen
    // path only runs once. If we lose the flag, the operator never sees
    // the banner. Wrap each call in its own try/catch.
    try {
        audit(
            $conn,
            $key . '_autogenerated',
            'install_key',
            null,
            'Auto-generated on first use; review docs/internal/runbooks.md'
        );
    } catch (\Throwable $e) {
        error_log('[ipam_install_key_announce_record] audit ' . $key . ': ' . $e->getMessage());
    }
    try {
        _ipam_install_key_announce_write($conn, 'install_keys_announce.' . $key, '1');
    } catch (\Throwable $e) {
        error_log('[ipam_install_key_announce_record] flag ' . $key . ': ' . $e->getMessage());
    }
}

/* ---------------- Settings (v2.6.0) ---------------- */

/**
 * Authoritative registry of database-backed settings. Single source of truth for
 * what settings exist, how to render them, and what they default to. Consumed by
 * the v2.6.0-settings migration (seeds the table), ipam_setting() (defaults), and
 * settings.php (form rendering).
 *
 * Fields per definition:
 *   - label       : human label for the admin UI
 *   - description : help text shown under the input
 *   - type        : string|int|bool|json
 *   - group       : oidc|alert|branding|update_check|security
 *   - default     : value returned when the table and $config have no entry
 *   - sensitive   : mask in UI and audit details
 *   - config_key  : string (flat $config key) or array of keys (nested path) for
 *                   v2.6.0 $config back-compat fallback; null if no fallback.
 *
 * Typed loosely (mixed values) so callers can still be defensive about the
 * shape; the precise structure is documented above.
 *
 * @return array<string, array<string, mixed>>
 */
function ipam_setting_definitions(): array
{
    return [
        // --- Branding ---
        'branding.site_name' => [
            'label'       => 'Application name',
            'description' => 'Shown in the browser tab, nav bar, and login page.',
            'type'        => 'string',
            'group'       => 'branding',
            'default'     => 'Simple PHP IPAM',
            'sensitive'   => false,
            'config_key'  => 'app_name',
        ],
        'branding.timezone' => [
            'label'       => 'Display timezone',
            'description' => 'PHP timezone identifier (e.g. America/Toronto). Timestamps are stored as UTC; this converts them for display only.',
            'type'        => 'string',
            'group'       => 'branding',
            'default'     => 'UTC',
            'sensitive'   => false,
            'config_key'  => 'timezone',
            // Dynamic option list from PHP's zoneinfo database (~420 entries).
            // Callable form keeps the registry lazy — the list is only built
            // when settings.php actually renders or validates this field.
            'options'     => '@timezone',
        ],

        // --- Security ---
        'security.session_idle_seconds' => [
            'label'       => 'Session idle timeout (seconds)',
            'description' => 'Users are logged out after this many seconds of inactivity. Minimum 60.',
            'type'        => 'int',
            'group'       => 'security',
            'default'     => 1800,
            'sensitive'   => false,
            'config_key'  => 'session_idle_seconds',
            'min'         => 60,
        ],
        'security.login_max_attempts' => [
            'label'       => 'Max failed login attempts',
            'description' => 'Lock out an IP after this many failed attempts within the window. Minimum 1.',
            'type'        => 'int',
            'group'       => 'security',
            'default'     => 5,
            'sensitive'   => false,
            'config_key'  => 'login_max_attempts',
            'min'         => 1,
        ],
        'security.login_lockout_seconds' => [
            'label'       => 'Login lockout window (seconds)',
            'description' => 'Time window during which failed attempts are counted toward lockout. Minimum 60.',
            'type'        => 'int',
            'group'       => 'security',
            'default'     => 900,
            'sensitive'   => false,
            'config_key'  => 'login_lockout_seconds',
            'min'         => 60,
        ],

        'security.account_lockout_max_attempts' => [
            'label'       => 'Account lockout attempts',
            'description' => 'Lock a username after this many failed login attempts within the window.',
            'type'        => 'int',
            'group'       => 'security',
            'default'     => 10,
            'sensitive'   => false,
            'config_key'  => 'account_lockout_max_attempts',
            'min'         => 1,
        ],
        'security.account_lockout_seconds' => [
            'label'       => 'Account lockout window (seconds)',
            'description' => 'Duration of per-username lockout after too many failed login attempts.',
            'type'        => 'int',
            'group'       => 'security',
            'default'     => 900,
            'sensitive'   => false,
            'config_key'  => 'account_lockout_seconds',
            'min'         => 1,
        ],
        'security.proxy_trust_cidrs' => [
            'label'       => 'Trusted reverse-proxy CIDRs',
            'description' => 'One CIDR per line. When the direct client (REMOTE_ADDR) matches any of these, X-Forwarded-For is walked right-to-left and the first untrusted hop is logged as the real client. Leave empty to ignore X-Forwarded-For entirely (the safe default for non-proxied installs). Replaces the legacy proxy_trust boolean — see docs/configuration.md.',
            'type'        => 'string',
            'group'       => 'security',
            'default'     => '',
            'sensitive'   => false,
            'config_key'  => null,
            'multiline'   => true,
        ],

        // --- Alerting ---
        // Deprecated in v2.8.0 by alert.recipient_user_ids. Kept in the
        // registry so the v2.8.0 migration can read its current value and
        // try to map it to a user. Hidden from the settings UI via the
        // 'deprecated' flag below; settings.php must skip rendering it.
        'alert.email' => [
            'label'       => 'Alert email recipient (deprecated)',
            'description' => 'Replaced in v2.8.0 by a multi-select picker tied to user records. This row is migrated automatically and hidden from the UI.',
            'type'        => 'string',
            'group'       => 'alert',
            'default'     => '',
            'sensitive'   => false,
            'deprecated'  => true,
            'config_key'  => 'alert_email',
        ],
        'alert.recipient_user_ids' => [
            'label'       => 'Alert recipients',
            'description' => 'Users who receive utilization alerts. Only users with a non-empty email address and an active account are eligible. Leave empty to disable email alerts.',
            'type'        => 'json',
            'group'       => 'alert',
            'default'     => [],
            'sensitive'   => false,
            'config_key'  => 'alert_recipient_user_ids',
        ],
        'alert.util_warn_pct' => [
            'label'       => 'Utilization warn threshold (%)',
            'description' => 'Trigger a warning alert when subnet utilization reaches this percent.',
            'type'        => 'int',
            'group'       => 'alert',
            'default'     => 80,
            'sensitive'   => false,
            'config_key'  => 'alert_util_warn_pct',
            'min'         => 0,
            'max'         => 100,
        ],
        'alert.util_crit_pct' => [
            'label'       => 'Utilization critical threshold (%)',
            'description' => 'Trigger a critical alert when subnet utilization reaches this percent.',
            'type'        => 'int',
            'group'       => 'alert',
            'default'     => 95,
            'sensitive'   => false,
            'config_key'  => 'alert_util_crit_pct',
            'min'         => 0,
            'max'         => 100,
        ],
        'alert.interval_seconds' => [
            'label'       => 'Alert check interval (seconds)',
            'description' => 'Minimum seconds between utilization alert evaluations. Minimum 60.',
            'type'        => 'int',
            'group'       => 'alert',
            'default'     => 3600,
            'sensitive'   => false,
            'config_key'  => 'alert_interval_seconds',
            'min'         => 60,
        ],

        // --- Update check ---
        'update_check.enabled' => [
            'label'       => 'Check for updates',
            'description' => 'Fetch release info from GitHub and show a banner when a newer version is available.',
            'type'        => 'bool',
            'group'       => 'update_check',
            'default'     => true,
            'sensitive'   => false,
            'config_key'  => ['update_check', 'enabled'],
        ],
        'update_check.ttl_seconds' => [
            'label'       => 'Update check cache TTL (seconds)',
            'description' => 'How long to cache the update check result before re-fetching from GitHub. Runtime enforces a floor of 3600 (one hour) to avoid hammering the GitHub API, so values below 3600 are silently clamped.',
            'type'        => 'int',
            'group'       => 'update_check',
            'default'     => 86400,
            'sensitive'   => false,
            'config_key'  => ['update_check', 'ttl_seconds'],
            'min'         => 3600,
        ],
        'update_check.notify_prerelease' => [
            'label'       => 'Notify on prereleases',
            'description' => 'Also alert for alpha, beta, and RC builds.',
            'type'        => 'bool',
            'group'       => 'update_check',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['update_check', 'notify_prerelease'],
        ],

        // --- Login protection (bot/abuse mitigation on the login form) ---
        'login_protection.method' => [
            'label'       => 'Login protection method',
            'description' => 'Bot/abuse mitigation on the login form. Pick the provider that matches the site/secret keys below.',
            'type'        => 'string',
            'group'       => 'login_protection',
            'default'     => '',
            'sensitive'   => false,
            'config_key'  => ['login_protection', 'method'],
            'options'     => [
                ''                 => 'Off',
                'honeypot'         => 'Honeypot',
                'time_check'       => 'Time check',
                'turnstile'        => 'Cloudflare Turnstile',
                'hcaptcha'         => 'hCaptcha',
                'recaptcha'        => 'Google reCAPTCHA',
                'friendly_captcha' => 'Friendly Captcha',
            ],
        ],
        'login_protection.site_key' => [
            'label'       => 'Login protection site key',
            'description' => 'Widget site key (Turnstile / hCaptcha / reCAPTCHA / Friendly Captcha).',
            'type'        => 'string',
            'group'       => 'login_protection',
            'default'     => '',
            'sensitive'   => false,
            'config_key'  => ['login_protection', 'site_key'],
        ],
        'login_protection.secret_key' => [
            'label'       => 'Login protection secret key',
            'description' => 'Widget secret key used for backend verification.',
            'type'        => 'string',
            'group'       => 'login_protection',
            'default'     => '',
            'sensitive'   => true,
            'config_key'  => ['login_protection', 'secret_key'],
        ],
        'login_protection.min_seconds' => [
            'label'       => 'Login time-check minimum (seconds)',
            'description' => "Minimum seconds between page load and submit when method is 'time_check'.",
            'type'        => 'int',
            'group'       => 'login_protection',
            'default'     => 3,
            'sensitive'   => false,
            'config_key'  => ['login_protection', 'min_seconds'],
            'min'         => 0,
        ],
        'login_protection.version' => [
            'label'       => 'reCAPTCHA version',
            'description' => "reCAPTCHA widget version: 2 (checkbox) or 3 (invisible). Only applies when method is 'recaptcha'.",
            'type'        => 'int',
            'group'       => 'login_protection',
            'default'     => 2,
            'sensitive'   => false,
            'config_key'  => ['login_protection', 'version'],
            'min'         => 2,
            'max'         => 3,
        ],

        // --- reCAPTCHA Enterprise backend verification ---
        'recaptcha_enterprise.enabled' => [
            'label'       => 'reCAPTCHA Enterprise enabled',
            'description' => "Use the reCAPTCHA Enterprise API for backend verification. Requires login_protection.method = 'recaptcha'.",
            'type'        => 'bool',
            'group'       => 'recaptcha_enterprise',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['recaptcha_enterprise', 'enabled'],
        ],
        'recaptcha_enterprise.project_id' => [
            'label'       => 'GCP project ID',
            'description' => 'Google Cloud project that owns the reCAPTCHA Enterprise key.',
            'type'        => 'string',
            'group'       => 'recaptcha_enterprise',
            'default'     => '',
            'sensitive'   => false,
            'config_key'  => ['recaptcha_enterprise', 'project_id'],
        ],
        'recaptcha_enterprise.api_key' => [
            'label'       => 'GCP API key',
            'description' => 'Server-side API key used to call the reCAPTCHA Enterprise API.',
            'type'        => 'string',
            'group'       => 'recaptcha_enterprise',
            'default'     => '',
            'sensitive'   => true,
            'config_key'  => ['recaptcha_enterprise', 'api_key'],
        ],
        'recaptcha_enterprise.expected_action' => [
            'label'       => 'Expected action',
            'description' => "Action name emitted by the widget, matched server-side during verification.",
            'type'        => 'string',
            'group'       => 'recaptcha_enterprise',
            'default'     => 'login',
            'sensitive'   => false,
            'config_key'  => ['recaptcha_enterprise', 'expected_action'],
        ],
        'recaptcha_enterprise.score_threshold' => [
            'label'       => 'Score threshold',
            'description' => "Minimum risk score to accept (0.0–1.0). Stored as a string so the 0.5 default round-trips cleanly.",
            'type'        => 'string',
            'group'       => 'recaptcha_enterprise',
            'default'     => '0.5',
            'sensitive'   => false,
            'config_key'  => ['recaptcha_enterprise', 'score_threshold'],
        ],

        // --- OIDC ---
        'oidc.enabled' => [
            'label'       => 'OIDC enabled',
            'description' => 'Turn Authorization Code + PKCE SSO on or off.',
            'type'        => 'bool',
            'group'       => 'oidc',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['oidc', 'enabled'],
        ],
        'oidc.display_name' => [
            'label'       => 'OIDC button label',
            'description' => 'Label shown on the login page SSO button (e.g. Okta, Azure AD).',
            'type'        => 'string',
            'group'       => 'oidc',
            'default'     => 'SSO',
            'sensitive'   => false,
            'config_key'  => ['oidc', 'display_name'],
        ],
        'oidc.client_id' => [
            'label'       => 'OIDC client ID',
            'description' => 'Client identifier issued by the identity provider.',
            'type'        => 'string',
            'group'       => 'oidc',
            'default'     => '',
            'sensitive'   => false,
            'config_key'  => ['oidc', 'client_id'],
        ],
        'oidc.client_secret' => [
            'label'       => 'OIDC client secret',
            'description' => 'Client secret issued by the identity provider. Stored in the database.',
            'type'        => 'string',
            'group'       => 'oidc',
            'default'     => '',
            'sensitive'   => true,
            'config_key'  => ['oidc', 'client_secret'],
        ],
        'oidc.discovery_url' => [
            'label'       => 'OIDC discovery URL',
            'description' => 'Base URL of the IdP (/.well-known/openid-configuration is appended automatically).',
            'type'        => 'string',
            'group'       => 'oidc',
            'default'     => '',
            'sensitive'   => false,
            'config_key'  => ['oidc', 'discovery_url'],
        ],
        'oidc.redirect_uri' => [
            'label'       => 'OIDC redirect URI',
            'description' => 'Must match exactly what is registered in the IdP application settings.',
            'type'        => 'string',
            'group'       => 'oidc',
            'default'     => '',
            'sensitive'   => false,
            'config_key'  => ['oidc', 'redirect_uri'],
        ],
        'oidc.scopes' => [
            'label'       => 'OIDC scopes',
            'description' => "Space-separated scopes. 'openid' is required; 'email' is needed for auto-provisioning.",
            'type'        => 'string',
            'group'       => 'oidc',
            'default'     => 'openid email profile',
            'sensitive'   => false,
            'config_key'  => ['oidc', 'scopes'],
        ],
        'oidc.auto_link' => [
            'label'       => 'OIDC auto-link existing accounts',
            'description' => 'On first OIDC login, link the incoming identity to a matching local account by username or email.',
            'type'        => 'bool',
            'group'       => 'oidc',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['oidc', 'auto_link'],
        ],
        'oidc.auto_provision' => [
            'label'       => 'OIDC auto-provision users',
            'description' => 'Create a new local account on first OIDC login when no existing user can be matched. Implies auto-link.',
            'type'        => 'bool',
            'group'       => 'oidc',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['oidc', 'auto_provision'],
        ],
        'oidc.default_role' => [
            'label'       => 'OIDC default role',
            'description' => "Role assigned to auto-provisioned users. 'Read-only' is recommended.",
            'type'        => 'string',
            'group'       => 'oidc',
            'default'     => 'readonly',
            'sensitive'   => false,
            'config_key'  => ['oidc', 'default_role'],
            // v2.11.0 #501: 'netops' added. The users.role column and the
            // demo seed already include a 'netops' role, but the OIDC
            // dropdown was missing it so IdP-provisioned users could not
            // be auto-assigned NetOps and had to be manually flipped.
            'options'     => [
                'readonly' => 'Read-only',
                'netops'   => 'Network operator',
                'admin'    => 'Administrator',
            ],
        ],
        'oidc.disable_local_login' => [
            'label'       => 'Disable local password login',
            'description' => 'When OIDC is active, hide the local username/password form entirely. Emergency bypass still works unless also disabled below.',
            'type'        => 'bool',
            'group'       => 'oidc',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['oidc', 'disable_local_login'],
        ],
        'oidc.disable_emergency_bypass' => [
            'label'       => 'Disable emergency local bypass',
            'description' => 'Disable the ?local=1 emergency access path that lets a local admin sign in even when local login is hidden. Leave off until you are confident SSO will keep working.',
            'type'        => 'bool',
            'group'       => 'oidc',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['oidc', 'disable_emergency_bypass'],
        ],
        'oidc.hide_emergency_link' => [
            'label'       => 'Hide emergency bypass link',
            'description' => 'Hide the "(emergency local access)" link even if the ?local=1 bypass itself is still reachable.',
            'type'        => 'bool',
            'group'       => 'oidc',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['oidc', 'hide_emergency_link'],
        ],

        // --- Housekeeping ---
        'housekeeping.enabled' => [
            'label'       => 'Lazy housekeeping enabled',
            'description' => 'Run temp cleanup, log pruning, and alert checks on normal page loads at the configured interval.',
            'type'        => 'bool',
            'group'       => 'housekeeping',
            'default'     => true,
            'sensitive'   => false,
            'config_key'  => ['housekeeping', 'enabled'],
        ],
        'housekeeping.interval_seconds' => [
            'label'       => 'Housekeeping interval (seconds)',
            'description' => 'Minimum seconds between lazy housekeeping runs. Default: 86400 (once per day).',
            'type'        => 'int',
            'group'       => 'housekeeping',
            'default'     => 86400,
            'sensitive'   => false,
            'config_key'  => ['housekeeping', 'interval_seconds'],
            'min'         => 60,
        ],
        'housekeeping.tmp_cleanup_ttl_seconds' => [
            'label'       => 'Temp file TTL (seconds)',
            'description' => 'Files in data/tmp/ older than this are deleted during housekeeping.',
            'type'        => 'int',
            'group'       => 'housekeeping',
            'default'     => 86400,
            'sensitive'   => false,
            'config_key'  => 'tmp_cleanup_ttl_seconds',
            'min'         => 60,
        ],
        'housekeeping.audit_log_retention_days' => [
            'label'       => 'Audit log retention (days)',
            'description' => 'Entries older than this are pruned during housekeeping. 0 = keep forever.',
            'type'        => 'int',
            'group'       => 'housekeeping',
            'default'     => 0,
            'sensitive'   => false,
            'config_key'  => 'audit_log_retention_days',
            'min'         => 0,
        ],
        'housekeeping.address_history_retention_days' => [
            'label'       => 'Address history retention (days)',
            'description' => 'History entries older than this are pruned during housekeeping. 0 = keep forever.',
            'type'        => 'int',
            'group'       => 'housekeeping',
            'default'     => 0,
            'sensitive'   => false,
            'config_key'  => 'address_history_retention_days',
            'min'         => 0,
        ],
        'housekeeping.snapshot_retention_days' => [
            'label'       => 'Utilization snapshot retention (days)',
            'description' => 'Utilization snapshot rows older than this are pruned during housekeeping. 0 = keep forever.',
            'type'        => 'int',
            'group'       => 'housekeeping',
            'default'     => 365,
            'sensitive'   => false,
            'config_key'  => 'snapshot_retention_days',
            'min'         => 0,
        ],

        // --- Backup ---
        // v3.26.0 (#1059): the 4 legacy v3.7 keys (backup.enabled,
        // backup.frequency, backup.retention, backup.dir) were retired with
        // the run_db_backup_if_due() runner. Backups are now driven by the
        // unified backup_destinations + backup_schedules surface.
        // v3.24.0 — manual upload-restore (#837). Effective cap is the
        // smallest of: this setting, php upload_max_filesize, post_max_size.
        // Increasing this above PHP's runtime limits has no effect; the
        // operator-facing description nudges them to bump both.
        'backup_max_upload_size_mb' => [
            'label'       => 'Manual restore upload limit (MiB)',
            'description' => 'Maximum size of a manually-uploaded backup archive on the Restore tab. Effective cap is min(this, php.ini upload_max_filesize, post_max_size). Increase all three together for files larger than the PHP defaults.',
            'type'        => 'int',
            'group'       => 'backup',
            'default'     => 2048,
            'min'         => 1,
            'sensitive'   => false,
        ],
        // v3.26.0 (#1098) — backup_vault_key wrapped envelope. The runtime
        // read path is added in v3.26.0 D2-B; this registry entry ships
        // alongside the data migration in D2-A so the column is present
        // in fresh installs from the day v3.26.0 is released. The value
        // is an "IPAMWK1." envelope produced by ipam_vault_wrap() — the
        // raw 32-byte vault key never lives in this row.
        'backup_vault_key' => [
            'label'       => 'Backup vault key (wrapped, internal)',
            'description' => 'Internal — the IPAMBKP3 vault key, wrapped under the bootstrap_key from config.php. Never displayed; managed via the Destinations admin panel.',
            'type'        => 'string',
            'group'       => 'backup',
            'default'     => '',
            'sensitive'   => true,
            'hidden'      => true,
        ],
        // --- Install-key announcement flags (v3.28.2 #1178) ---
        // Internal one-shot flags consumed by render_install_key_banner().
        // Set to '1' by ipam_install_key_announce_record() when ipam_app_secret()
        // or ipam_bootstrap_key() auto-generates a new value; cleared to '0' when
        // the admin dismisses the banner. Hidden from the Settings UI — the
        // banner is the user-facing surface.
        'install_keys_announce.app_secret' => [
            'label'       => 'Install-key announce: app_secret (internal)',
            'description' => 'Internal one-shot flag for the install-key auto-gen admin banner.',
            'type'        => 'bool',
            'group'       => 'security',
            'default'     => false,
            'sensitive'   => false,
            'hidden'      => true,
        ],
        'install_keys_announce.bootstrap_key' => [
            'label'       => 'Install-key announce: bootstrap_key (internal)',
            'description' => 'Internal one-shot flag for the install-key auto-gen admin banner.',
            'type'        => 'bool',
            'group'       => 'security',
            'default'     => false,
            'sensitive'   => false,
            'hidden'      => true,
        ],
        // --- Notifications (v3.22.0 §2.4) ---
        // Per-event toggles split scheduled-vs-manual on the success/failure
        // axis (§2.4 lists the two as independent — operators commonly want
        // "tell me when scheduled fail" + "stay silent on manual" or vice
        // versa). Per-schedule overrides are parking-lot work.
        // Legacy keys backup.notify_on_failure / backup.notify_on_success
        // were retired here; ipam_backup_notify() reads the new keys directly.
        'backup.notify_success_scheduled' => [
            'label'       => 'Email on scheduled-backup success',
            'description' => 'Send a notification when a scheduled backup completes successfully. Off by default — successful schedules can be very noisy.',
            'type'        => 'bool',
            'group'       => 'backup',
            'default'     => false,
            'sensitive'   => false,
        ],
        'backup.notify_success_manual' => [
            'label'       => 'Email on manual-backup success',
            'description' => 'Send a notification when an operator-triggered (Run-now) backup completes successfully.',
            'type'        => 'bool',
            'group'       => 'backup',
            'default'     => false,
            'sensitive'   => false,
        ],
        'backup.notify_failure_scheduled' => [
            'label'       => 'Email on scheduled-backup failure',
            'description' => 'Send a notification when a scheduled backup fails.',
            'type'        => 'bool',
            'group'       => 'backup',
            'default'     => true,
            'sensitive'   => false,
        ],
        'backup.notify_failure_manual' => [
            'label'       => 'Email on manual-backup failure',
            'description' => 'Send a notification when an operator-triggered (Run-now) backup fails.',
            'type'        => 'bool',
            'group'       => 'backup',
            'default'     => true,
            'sensitive'   => false,
        ],
        'backup.notify_destination_conn_failure' => [
            'label'       => 'Email on destination connection-test failure',
            'description' => "Periodically re-tests every active backup destination from the cron tick. When a previously-healthy destination starts failing, send one email (with a cooldown). No email is sent on recovery.",
            'type'        => 'bool',
            'group'       => 'backup',
            'default'     => true,
            'sensitive'   => false,
        ],
        'backup.notify_schedule_overdue' => [
            'label'       => 'Email when a backup schedule is overdue',
            'description' => 'Send a notification when a schedule should have fired but has not (cron stuck, host crashed, etc.).',
            'type'        => 'bool',
            'group'       => 'backup',
            'default'     => true,
            'sensitive'   => false,
        ],
        'backup.notify_overdue_grace_minutes' => [
            'label'       => 'Schedule-overdue grace period (minutes)',
            'description' => 'How many minutes past the expected next_run_at before a schedule is considered overdue and emailed.',
            'type'        => 'int',
            'group'       => 'backup',
            'default'     => 60,
            'sensitive'   => false,
            'min'         => 5,
            'max'         => 1440,
        ],
        'backup.notify_retention_prune' => [
            'label'       => 'Email retention-prune summaries',
            'description' => 'Send a notification each time retention deletes blobs from a destination. Verbose — off by default.',
            'type'        => 'bool',
            'group'       => 'backup',
            'default'     => false,
            'sensitive'   => false,
        ],
        'backup.dump_ssl_verify' => [
            'label'       => 'Verify MySQL/MariaDB TLS server certificate during backup/restore',
            'description' => 'When ON, mysqldump / mysql / mysql-restore verify the server TLS certificate chain against the system trust store. When OFF (default), they still use TLS encryption if the server offers it but skip cert verification — matches PHP PDO_MYSQL\'s default behaviour and lets the app connect to internal servers with self-signed certificates. Operators with a properly-chained CA cert should enable this.',
            'type'        => 'bool',
            'group'       => 'backup',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['backup', 'dump_ssl_verify'],
        ],
        'backup.notify_encryption_change' => [
            'label'       => 'Email on destination encryption-mode change',
            'description' => 'Send a notification when an admin toggles a destination between encrypted and plaintext.',
            'type'        => 'bool',
            'group'       => 'backup',
            'default'     => true,
            'sensitive'   => false,
        ],
        // v3.25.0 #1078: per-tab override knobs so backup notifications
        // can target a different audience than the global alert
        // infrastructure. Empty / 'inherit' values fall back to the
        // global alert.recipient_user_ids + mail.transport settings.
        'backup.notify_recipient_user_ids' => [
            'label'       => 'Backup-specific recipient user IDs',
            'description' => 'Override list of user IDs (JSON array) to receive backup notifications. Empty = inherit alert.recipient_user_ids.',
            'type'        => 'json',
            'group'       => 'backup',
            'default'     => [],
            'sensitive'   => false,
        ],
        'backup.notify_recipient_email_extra' => [
            'label'       => 'Extra backup notification recipients',
            'description' => 'Additional comma-separated email addresses (no user account required). Combined with the recipient list.',
            'type'        => 'string',
            'group'       => 'backup',
            'default'     => '',
            'sensitive'   => false,
        ],
        'backup.notify_delivery_method' => [
            'label'       => 'Backup notification delivery method',
            'description' => "'inherit' uses the global mail transport (current behaviour). 'smtp' explicitly forces SMTP delivery for backup notifications regardless of the global default.",
            'type'        => 'string',
            'group'       => 'backup',
            'default'     => 'inherit',
            'sensitive'   => false,
        ],
        // Deprecated v3.28.0 #1159 — the cron Task 6c destination health map
        // now lives in the backup_state table (scope 'destination_health'),
        // one atomic row per destination id. This registry entry is retained
        // for one release as a vestigial fallback (the migration backfills
        // backup_state from it) but is no longer read or written; remove in a
        // future release. Hidden from the settings UI.
        'backup.destination_health' => [
            'label'       => 'Destination health (internal, deprecated)',
            'description' => 'Deprecated — superseded by the backup_state table in v3.28.0. Not user-editable.',
            'type'        => 'string',
            'group'       => 'backup',
            'default'     => '{}',
            'sensitive'   => false,
            'hidden'      => true,
        ],
        // Deprecated v3.28.0 #1159 — the cron Task 6d schedule-overdue
        // cooldown map now lives in the backup_state table (scope
        // 'schedule_overdue'). Retained for one release as a vestigial
        // backfill source; no longer read or written. Hidden from the UI.
        'backup.schedule_overdue_state' => [
            'label'       => 'Schedule overdue state (internal, deprecated)',
            'description' => 'Deprecated — superseded by the backup_state table in v3.28.0. Not user-editable.',
            'type'        => 'string',
            'group'       => 'backup',
            'default'     => '{}',
            'sensitive'   => false,
            'hidden'      => true,
        ],
        // Internal — sentinel stamped on every v3.23.0–v3.25.x page load by
        // the ipam_legacy_backup_migrate_if_due() helper (now retired in
        // v3.26.0 #1059). The sentinel is kept in the registry so the
        // 3.26.0-retire-legacy-backup migration can verify operators passed
        // through that conversion path before dropping the 4 legacy keys.
        'backup.legacy_migrated_v3_23_0' => [
            'label'       => 'Legacy backup migration sentinel (internal)',
            'description' => 'Internal — set to true on any v3.23.0–v3.25.x page load (the conversion helper is retired in v3.26.0 #1059). The 3.26.0-retire-legacy-backup migration verifies this sentinel before dropping legacy backup.* keys. Not user-editable.',
            'type'        => 'bool',
            'group'       => 'backup',
            'default'     => false,
            'sensitive'   => false,
            'hidden'      => true,
        ],
        'backup_runs.retention_days' => [
            'label'       => 'Backup history retention (days)',
            'description' => 'Keep backup_runs rows this many days. 0 disables auto-purge. Protected runs (is_protected=1) and in-flight rows are never auto-purged.',
            'type'        => 'int',
            'group'       => 'backup',
            'default'     => 90,
            'sensitive'   => false,
            'config_key'  => null,
            'min'         => 0,
        ],
        'backup_runs.prune_batch_size' => [
            'label'       => 'Backup history prune batch size',
            'description' => 'Max rows to delete per cron tick. Prevents long lock holds on large purges.',
            'type'        => 'int',
            'group'       => 'backup',
            'default'     => 500,
            'sensitive'   => false,
            'config_key'  => null,
            'min'         => 1,
            'max'         => 10000,
        ],

        // --- Limits ---
        'limits.import_csv_max_mb' => [
            'label'       => 'CSV import max file size (MB)',
            'description' => 'Maximum upload size for CSV imports.',
            'type'        => 'int',
            'group'       => 'limits',
            'default'     => 5,
            'sensitive'   => false,
            'config_key'  => 'import_csv_max_mb',
            'min'         => 1,
            'max'         => 50,
        ],
        'limits.import_sql_max_mb' => [
            'label'       => 'SQL import max file size (MB)',
            'description' => 'Maximum upload size for SQL database imports. Also update upload_max_filesize in php.ini.',
            'type'        => 'int',
            'group'       => 'limits',
            'default'     => 200,
            'sensitive'   => false,
            'config_key'  => 'import_sql_max_mb',
            'min'         => 1,
        ],

        // --- API ---
        'api.max_attempts' => [
            'label'       => 'Max failed API key attempts',
            'description' => 'Lock out an IP after this many failed API key attempts.',
            'type'        => 'int',
            'group'       => 'api',
            'default'     => 20,
            'sensitive'   => false,
            'config_key'  => 'api_max_attempts',
            'min'         => 1,
        ],
        'api.lockout_seconds' => [
            'label'       => 'API lockout window (seconds)',
            'description' => 'Duration of API key lockout after too many failed attempts.',
            'type'        => 'int',
            'group'       => 'api',
            'default'     => 300,
            'sensitive'   => false,
            'config_key'  => 'api_lockout_seconds',
            'min'         => 1,
        ],
        'api.bulk_limit' => [
            'label'       => 'Bulk API write limit',
            'description' => 'Maximum records per bulk API write request.',
            'type'        => 'int',
            'group'       => 'api',
            'default'     => 500,
            'sensitive'   => false,
            'config_key'  => 'api_bulk_limit',
            'min'         => 1,
        ],

        // --- Multi-Factor Authentication ---
        'mfa.totp_enabled' => [
            'label'       => 'Enable TOTP (authenticator app)',
            'type'        => 'bool',
            'default'     => true,
            'group'       => 'mfa',
            'description' => 'Allow users to enroll a Time-based One-Time Password (RFC 6238) as a second authentication factor using an authenticator app (1Password, Google Authenticator, Authy, etc.). Requires app_secret to be set in config.php.',
            'sensitive'   => false,
            'config_key'  => null,
        ],
        'mfa.email_otp_enabled' => [
            'label'       => 'Enable Email OTP',
            'type'        => 'bool',
            'default'     => false,
            'group'       => 'mfa',
            'description' => 'Allow users to enroll Email OTP as a second authentication factor. Requires SMTP to be configured.',
            'sensitive'   => false,
            'config_key'  => null,
        ],
        'mfa.require' => [
            'label'       => 'Require 2FA for all users',
            'type'        => 'bool',
            'default'     => false,
            'group'       => 'mfa',
            'description' => 'Users without any 2FA method enrolled will be redirected to the Account page to enroll before accessing the application.',
            'sensitive'   => false,
            'config_key'  => null,
        ],
        'mfa.passkeys_enabled' => [
            'label'       => 'Enable Passkeys (WebAuthn)',
            'type'        => 'bool',
            'default'     => false,
            'group'       => 'mfa',
            'description' => 'Allow users to register hardware security keys or device biometrics (Face ID, Touch ID, Windows Hello) as a second authentication factor.',
            'sensitive'   => false,
            'config_key'  => null,
        ],

        // --- Step-up authentication (sudo-mode for sensitive admin actions) ---
        // v3.27.0 #1108: install-wide policy controlling which credential
        // proofs satisfy ipam_sudo_verify(). Decoupled from login provider
        // so OIDC/LDAP/SAML users can manage sensitive resources (vault key,
        // sensitive settings, DB import, API key creation, MFA disable)
        // without depending on a local password. See
        // docs/superpowers/plans/2026-05-07-v3.27.0.md.
        'auth.step_up.allow_totp' => [
            'label'       => 'Accept TOTP for step-up',
            'type'        => 'bool',
            'default'     => true,
            'group'       => 'step_up',
            'description' => 'Allow a fresh TOTP code to satisfy the step-up gate for sensitive admin actions. Has no effect for users who have not enrolled TOTP.',
            'sensitive'   => false,
            'config_key'  => null,
        ],
        'auth.step_up.allow_email_otp' => [
            'label'       => 'Accept Email OTP for step-up',
            'type'        => 'bool',
            'default'     => true,
            'group'       => 'step_up',
            'description' => 'Allow a fresh Email OTP code to satisfy the step-up gate. Slightly weaker than TOTP/passkey because compromise of the email account leaks it; disable if your threat model includes inbox compromise.',
            'sensitive'   => false,
            'config_key'  => null,
        ],
        'auth.step_up.allow_webauthn' => [
            'label'       => 'Accept WebAuthn passkey for step-up',
            'type'        => 'bool',
            'default'     => true,
            'group'       => 'step_up',
            'description' => 'Allow a fresh WebAuthn (passkey) assertion to satisfy the step-up gate. Strongest method; requires the user to have a registered passkey.',
            'sensitive'   => false,
            'config_key'  => null,
        ],
        'auth.step_up.allow_provider_reauth' => [
            'label'       => 'Accept provider re-authentication for step-up',
            'type'        => 'bool',
            'default'     => true,
            'group'       => 'step_up',
            'description' => 'Fall back to the user\'s primary login credential (local password, OIDC prompt=login, or other provider re-auth) when no MFA method is available. Disable to force MFA enrollment for any sensitive action.',
            'sensitive'   => false,
            'config_key'  => null,
        ],
        'auth.step_up.ttl_seconds' => [
            'label'       => 'Step-up cache duration',
            // Stored as a string of seconds so the UI can render a discrete
            // dropdown via the registry options mechanism (only string-typed
            // fields render <select> in views/settings_group_form.php).
            // ipam_sudo_policy() coerces with to_int() before use.
            'type'        => 'string',
            'default'     => '300',
            'group'       => 'step_up',
            'description' => 'How long a successful step-up grant remains valid before the user is re-prompted on the next sensitive action.',
            'sensitive'   => false,
            'config_key'  => null,
            'options'     => [
                '0'    => 'Re-prompt every action',
                '60'   => '1 minute',
                '300'  => '5 minutes',
                '900'  => '15 minutes',
                '1800' => '30 minutes',
                '3600' => '1 hour',
            ],
        ],

        // --- Password policy ---
        'password_policy.min_length' => [
            'label'       => 'Minimum password length',
            'description' => 'Minimum number of characters required.',
            'type'        => 'int',
            'group'       => 'password_policy',
            'default'     => 12,
            'sensitive'   => false,
            'config_key'  => ['password_policy', 'min_length'],
            'min'         => 8,
        ],
        'password_policy.require_uppercase' => [
            'label'       => 'Require uppercase letter',
            'description' => 'Password must contain at least one uppercase letter.',
            'type'        => 'bool',
            'group'       => 'password_policy',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['password_policy', 'require_uppercase'],
        ],
        'password_policy.require_lowercase' => [
            'label'       => 'Require lowercase letter',
            'description' => 'Password must contain at least one lowercase letter.',
            'type'        => 'bool',
            'group'       => 'password_policy',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['password_policy', 'require_lowercase'],
        ],
        'password_policy.require_number' => [
            'label'       => 'Require digit',
            'description' => 'Password must contain at least one digit.',
            'type'        => 'bool',
            'group'       => 'password_policy',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['password_policy', 'require_number'],
        ],
        'password_policy.require_symbol' => [
            'label'       => 'Require special character',
            'description' => 'Password must contain at least one symbol.',
            'type'        => 'bool',
            'group'       => 'password_policy',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => ['password_policy', 'require_symbol'],
        ],
        'password_policy.max_password_age_days' => [
            'label'       => 'Password expiry (days)',
            'description' => 'Force a password change after this many days. 0 = never expires.',
            'type'        => 'int',
            'group'       => 'password_policy',
            'default'     => 0,
            'sensitive'   => false,
            'config_key'  => ['password_policy', 'max_password_age_days'],
            'min'         => 0,
        ],

        // --- Display ---
        'display.utilization_warn' => [
            'label'       => 'Utilization warning threshold (%)',
            'description' => 'Subnet utilization bars turn yellow at this percentage.',
            'type'        => 'int',
            'group'       => 'display',
            'default'     => 80,
            'sensitive'   => false,
            'config_key'  => 'utilization_warn',
            'min'         => 0,
            'max'         => 100,
        ],
        'display.utilization_critical' => [
            'label'       => 'Utilization critical threshold (%)',
            'description' => 'Subnet utilization bars turn red at this percentage.',
            'type'        => 'int',
            'group'       => 'display',
            'default'     => 95,
            'sensitive'   => false,
            'config_key'  => 'utilization_critical',
            'min'         => 0,
            'max'         => 100,
        ],
        'display.auto_reserve_network_broadcast' => [
            'label'       => 'Auto-reserve network/broadcast/gateway',
            'description' => 'Pre-check the auto-reserve checkbox on the Add Subnet form.',
            'type'        => 'bool',
            'group'       => 'display',
            'default'     => true,
            'sensitive'   => false,
            'config_key'  => 'auto_reserve_network_broadcast',
        ],
        'display.status_hide_version' => [
            'label'       => 'Hide version in status endpoint',
            'description' => 'Remove the version field from the /status.php health check response.',
            'type'        => 'bool',
            'group'       => 'display',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => 'status_hide_version',
        ],

        // --- SMTP / Email Delivery ---
        'smtp.enabled' => [
            'label'       => 'SMTP enabled',
            'description' => 'Send mail via direct SMTP instead of the server\'s native mail() function.',
            'type'        => 'bool',
            'group'       => 'smtp',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => null,
        ],
        'smtp.host' => [
            'label'       => 'SMTP host',
            'description' => 'Hostname or IP of the SMTP server (e.g. smtp.gmail.com).',
            'type'        => 'string',
            'group'       => 'smtp',
            'default'     => '',
            'sensitive'   => false,
            'config_key'  => null,
        ],
        'smtp.port' => [
            'label'       => 'SMTP port',
            'description' => 'TCP port — 587 (STARTTLS), 465 (SSL), or 25 (unencrypted).',
            'type'        => 'int',
            'group'       => 'smtp',
            'default'     => 587,
            'sensitive'   => false,
            'config_key'  => null,
            'min'         => 1,
            'max'         => 65535,
        ],
        'smtp.encryption' => [
            'label'       => 'Encryption',
            'description' => 'Transport-layer encryption type.',
            'type'        => 'string',
            'group'       => 'smtp',
            'default'     => 'starttls',
            'sensitive'   => false,
            'config_key'  => null,
            'options'     => [
                'starttls' => 'STARTTLS (recommended)',
                'ssl'      => 'SSL/TLS',
                'none'     => 'None (unencrypted)',
            ],
        ],
        'smtp.auth_user' => [
            'label'       => 'SMTP username',
            'description' => 'Login username for SMTP authentication. Leave blank for anonymous relay.',
            'type'        => 'string',
            'group'       => 'smtp',
            'default'     => '',
            'sensitive'   => false,
            'config_key'  => null,
        ],
        'smtp.auth_pass' => [
            'label'       => 'SMTP password',
            'description' => 'Login password for SMTP authentication.',
            'type'        => 'string',
            'group'       => 'smtp',
            'default'     => '',
            'sensitive'   => true,
            'config_key'  => null,
        ],
        'smtp.from_address' => [
            'label'       => 'From address',
            'description' => 'Envelope From address for outbound mail (e.g. ipam@example.com).',
            'type'        => 'string',
            'group'       => 'smtp',
            'default'     => '',
            'sensitive'   => false,
            'config_key'  => null,
        ],
        'smtp.from_name' => [
            'label'       => 'From name',
            'description' => 'Display name shown in the From header (e.g. IPAM Alerts).',
            'type'        => 'string',
            'group'       => 'smtp',
            'default'     => '',
            'sensitive'   => false,
            'config_key'  => null,
        ],
        'smtp.verify_peer' => [
            'label'       => 'Verify TLS certificate',
            'description' => 'Reject connections with invalid or self-signed certificates. Disable only in dev/test environments.',
            'type'        => 'bool',
            'group'       => 'smtp',
            'default'     => true,
            'sensitive'   => false,
            'config_key'  => null,
        ],
        'smtp.timeout_seconds' => [
            'label'       => 'Connection timeout (seconds)',
            'description' => 'Maximum seconds to wait for the SMTP server to respond.',
            'type'        => 'int',
            'group'       => 'smtp',
            'default'     => 10,
            'sensitive'   => false,
            'config_key'  => null,
            'min'         => 1,
            'max'         => 120,
        ],

        // --- Webhooks ---
        'webhook.retention_days' => [
            'label'       => 'Delivery log retention (days)',
            'description' => 'Webhook delivery log rows older than this are pruned during housekeeping. 0 = keep forever.',
            'type'        => 'int',
            'group'       => 'webhooks',
            'default'     => 30,
            'sensitive'   => false,
            'config_key'  => null,
            'min'         => 0,
        ],
        'webhook.allow_private_ips' => [
            'label'       => 'Allow private IP webhook targets',
            'description' => 'When enabled, outbound webhook deliveries may target RFC-1918 / loopback addresses. Enable only in isolated dev/test environments.',
            'type'        => 'bool',
            'group'       => 'webhooks',
            'default'     => false,
            'sensitive'   => false,
            'config_key'  => null,
        ],
    ];
}

/**
 * Ordered list of setting groups for the admin UI.
 *
 * @return array<string, array<string, mixed>>
 */
function ipam_setting_groups(): array
{
    return [
        'branding'             => ['label' => 'Branding',             'description' => 'Display name and timezone shown across the UI.'],
        'security'             => ['label' => 'Security',             'description' => 'Session lifetime and login lockout policy.'],
        'step_up'              => ['label' => 'Step-up authentication', 'description' => 'Re-authentication policy for sensitive admin actions (vault key, sensitive setting reveal, DB import, API key creation, MFA disable, webhook create/edit/delete, SMTP and backup-notification-recipient settings, custom field definition changes). Decoupled from the login provider so OIDC users can manage these without a local password.'],
        'mfa'                  => ['label' => 'Multi-Factor Authentication', 'description' => 'Available 2FA methods and enforcement policy.'],
        'password_policy'      => ['label' => 'Password policy',      'description' => 'Complexity requirements and rotation for local passwords.'],
        'alert'                => ['label' => 'Alerting',             'description' => 'Subnet utilization email alerts.'],
        'update_check'         => ['label' => 'Update checker',       'description' => 'GitHub release checker for the in-app upgrade banner.'],
        'login_protection'     => ['label' => 'Login protection',     'description' => 'Bot and abuse mitigation on the login form.'],
        'recaptcha_enterprise' => ['label' => 'reCAPTCHA Enterprise', 'description' => "Backend verification via Google's reCAPTCHA Enterprise API."],
        'oidc'                 => ['label' => 'OIDC / SSO',           'description' => 'OpenID Connect single sign-on.'],
        'housekeeping'         => ['label' => 'Housekeeping',         'description' => 'Temp cleanup, log pruning, and alert check intervals.'],
        'backup'               => ['label' => 'Database backup',      'description' => 'Automatic database backup schedule and retention.'],
        'limits'               => ['label' => 'Upload limits',        'description' => 'Maximum file sizes for CSV and SQL imports.'],
        'api'                  => ['label' => 'API',                  'description' => 'Rate limiting and bulk write limits for the REST API.'],
        'display'              => ['label' => 'Display',              'description' => 'Utilization thresholds, auto-reserve defaults, and UI toggles.'],
        'smtp'                 => ['label' => 'SMTP / Email Delivery', 'description' => 'Direct SMTP delivery for utilization alerts. Falls back to native mail() when disabled.'],
        'webhooks'             => ['label' => 'Webhooks',             'description' => 'Outbound HMAC-signed HTTP callbacks on address and subnet changes.'],
    ];
}

/**
 * Look up a value in $GLOBALS['config'] given either a flat key or a nested path.
 * Used by the v2.6.0 back-compat fallback in ipam_setting() and by the settings
 * table seeder. Returns null when the key is not present.
 *
 * @param array<array-key, mixed> $config
 * @param string|array<array-key, mixed>|null $configKey
 */
function ipam_setting_config_fallback(array $config, string|array|null $configKey): mixed
{
    if ($configKey === null) return null;
    if (is_string($configKey)) {
        return array_key_exists($configKey, $config) ? $config[$configKey] : null;
    }
    $cursor = $config;
    foreach ($configKey as $segment) {
        if (!is_string($segment) && !is_int($segment)) return null;
        if (!is_array($cursor) || !array_key_exists($segment, $cursor)) return null;
        $cursor = $cursor[$segment];
    }
    return $cursor;
}

/**
 * Encode a PHP value for storage in the settings.value TEXT column, given a type.
 */
function ipam_setting_encode(mixed $value, string $type): string
{
    switch ($type) {
        case 'bool':
            return ($value === true || $value === 1 || $value === '1' || (is_string($value) && strtolower($value) === 'true')) ? '1' : '0';
        case 'int':
            return (string)(int)(is_numeric($value) ? $value : 0);
        case 'json':
            $encoded = json_encode($value);
            return is_string($encoded) ? $encoded : 'null';
        default:
            return is_scalar($value) ? (string)$value : '';
    }
}

/**
 * Decode a value read from the settings.value column back to its PHP type. On
 * JSON decode failure returns $default and logs a warning.
 */
function ipam_setting_decode(?string $stored, string $type, mixed $default): mixed
{
    if ($stored === null) return $default;
    switch ($type) {
        case 'bool':
            return ($stored === '1' || strtolower($stored) === 'true');
        case 'int':
            return (int)$stored;
        case 'json':
            $decoded = json_decode($stored, true);
            if ($decoded === null && strtolower(trim($stored)) !== 'null') {
                error_log("ipam_setting_decode: invalid JSON in settings row, returning default");
                return $default;
            }
            return $decoded;
        default:
            return $stored;
    }
}

/**
 * Infer a type string from a PHP value. Used when callers write without an
 * explicit type hint.
 */
function ipam_setting_infer_type(mixed $value): string
{
    if (is_bool($value)) return 'bool';
    if (is_int($value))  return 'int';
    if (is_array($value)) return 'json';
    return 'string';
}

/**
 * Read a setting. Fallback chain:
 *   1. Tenant-scoped DB row (only when $tenantId is non-null)
 *   2. Global DB row (tenant_id IS NULL)
 *   3. $GLOBALS['config'] via the registry's config_key path (v2.6 back-compat
 *      for installs that have not yet migrated config.php values to the DB)
 *   4. Registry default → $default argument
 *
 * Never throws. Results are memoised via ipam_setting_cache_storage() keyed
 * by "{tenantId}:{key}" so repeated reads in a single request don't re-query
 * the DB; ipam_setting_set() / ipam_setting_cache_bust() invalidate entries.
 *
 * In v3.x all settings rows have tenant_id = NULL, so callers that do not
 * pass $tenantId continue to work identically to before. The parameter is
 * groundwork for the v4.0.0 multi-tenancy cascade.
 */
function ipam_setting(string $key, mixed $default = null, ?int $tenantId = null): mixed
{
    $cached = ipam_setting_cache_storage($key, false, null, false, $tenantId);
    if ($cached !== '__IPAM_SETTING_MISS__') return $cached;

    $definitions = ipam_setting_definitions();
    $def         = $definitions[$key] ?? null;
    $type        = is_array($def) && is_string($def['type'] ?? null) ? $def['type'] : 'string';
    $fallback = ($def !== null && array_key_exists('default', $def))
        ? $def['default']
        : $default;

    try {
        $db = $GLOBALS['db'] ?? null;
        if ($db instanceof PDO) {
            $kc = ipam_key_col();

            // Step 1: tenant-scoped row (only when a tenantId is provided).
            if ($tenantId !== null) {
                $st = $db->prepare("SELECT value, type FROM settings WHERE tenant_id = :t AND {$kc} = :k");
                $st->execute([':t' => $tenantId, ':k' => $key]);
                $row = $st->fetch();
                if (is_array($row)) {
                    $storedType = is_string($row['type'] ?? null) && $row['type'] !== '' ? $row['type'] : $type;
                    $value      = is_string($row['value'] ?? null) ? $row['value'] : null;
                    $decoded    = ipam_setting_decode($value, $storedType, $fallback);
                    ipam_setting_cache_storage($key, false, $decoded, true, $tenantId);
                    return $decoded;
                }
            }

            // Step 2: global row (tenant_id IS NULL) — always checked.
            $st = $db->prepare("SELECT value, type FROM settings WHERE tenant_id IS NULL AND {$kc} = :k");
            $st->execute([':k' => $key]);
            $row = $st->fetch();
            if (is_array($row)) {
                $storedType = is_string($row['type'] ?? null) && $row['type'] !== '' ? $row['type'] : $type;
                $value      = is_string($row['value'] ?? null) ? $row['value'] : null;
                $decoded    = ipam_setting_decode($value, $storedType, $fallback);
                ipam_setting_cache_storage($key, false, $decoded, true, $tenantId);
                return $decoded;
            }
        }
    } catch (\PDOException $e) {
        // Differentiate "schema not migrated yet" (silent fallback to config)
        // from a real DB error (log + rethrow so the caller sees the failure
        // instead of getting a stale fallback value). PDO surfaces "missing
        // table/column" with SQLSTATE 42S02 / 42703, plus a per-engine
        // human-readable message that we also pattern-match for resilience
        // against driver quirks where SQLSTATE may not be set.
        $sqlstate = $e->getCode();
        $msg      = $e->getMessage();
        $isMissingSchema =
            $sqlstate === '42S02' || $sqlstate === '42703' ||
            // MySQL/MariaDB report 'Unknown column' under SQLSTATE 42S22
            // (CR #1100 review). Pre-migration installs missing tenant_id
            // would otherwise rethrow during bootstrap instead of taking
            // the documented config/default fallback.
            $sqlstate === '42S22' ||
            stripos($msg, 'no such table') !== false ||
            stripos($msg, 'no such column') !== false ||
            stripos($msg, 'undefined table') !== false ||
            stripos($msg, 'undefined column') !== false ||
            stripos($msg, 'unknown column') !== false;
        if (!$isMissingSchema) {
            error_log("ipam_setting: read failed for key {$key}: {$msg}");
            throw $e;
        }
        // Pre-migration fallback path — silently fall through.
    } catch (\Throwable $e) {
        // Non-PDO failure (e.g. cache helper bug). Log and fall through to the
        // config back-compat path; do not rethrow because callers that read
        // settings during bootstrap cannot meaningfully recover.
        error_log("ipam_setting: read failed for key {$key}: " . $e->getMessage());
    }

    // Step 3: $GLOBALS['config'] back-compat — installs that have not yet
    // migrated their config.php values to the settings table still get the
    // correct value here rather than falling through to the registry default.
    $rawConfigKey = is_array($def) ? ($def['config_key'] ?? null) : null;
    $configKey    = (is_string($rawConfigKey) || is_array($rawConfigKey)) ? $rawConfigKey : null;
    $cfg          = $GLOBALS['config'] ?? null;
    if ($configKey !== null && is_array($cfg)) {
        $cfgVal = ipam_setting_config_fallback($cfg, $configKey);
        if ($cfgVal !== null) {
            ipam_setting_cache_storage($key, false, $cfgVal, true, $tenantId);
            return $cfgVal;
        }
    }

    ipam_setting_cache_storage($key, false, $fallback, true, $tenantId);
    return $fallback;
}

/**
 * Write a setting. Infers type from $value unless the registry defines one.
 * Produces a `setting.update` audit entry with old/new values (masked for
 * sensitive keys). Invalidates the per-request cache for the key.
 *
 * When $tenantId is null the row is written to the global layer (tenant_id IS
 * NULL). When non-null it is written to the tenant-scoped layer. In v3.x all
 * callers pass null (the default), so existing behaviour is unchanged.
 */
function ipam_setting_set(PDO $db, string $key, mixed $value, ?int $userId = null, ?int $tenantId = null): void
{
    $definitions = ipam_setting_definitions();
    $def         = $definitions[$key] ?? null;
    $type        = (is_array($def) && is_string($def['type'] ?? null) && $def['type'] !== '')
        ? $def['type']
        : ipam_setting_infer_type($value);
    $sensitive   = is_array($def) && !empty($def['sensitive']);

    $encoded = ipam_setting_encode($value, $type);

    $kc = ipam_key_col();
    $d  = ipam_dialect();
    $tenantWhere = $tenantId === null ? 'tenant_id IS NULL' : 'tenant_id = :tb';
    $oldRaw  = null;
    $oldType = $type;

    // MySQL advisory lock: serialise SELECT→INSERT for this key/scope so that
    // two concurrent writers cannot both see "row does not exist" and both
    // attempt INSERT. SQLite and PostgreSQL enforce uniqueness via partial
    // indexes (uq_settings_global, uq_settings_tenant), but MySQL's composite
    // UNIQUE(tenant_id, key) allows multiple NULL tenant_id values per SQL
    // standard, so a second concurrent INSERT would silently succeed and create
    // duplicate global rows. GET_LOCK blocks until the lock is free (or the
    // 5 s timeout elapses). RELEASE_LOCK runs unconditionally in the finally
    // block so the lock is freed even when an exception is thrown.
    //
    // Cross-references — read together if you change any of the three:
    //   - migrations.php :: 3.13.0-settings-cascade (cross-engine UQ shape)
    //   - tests/SchemaParityTest.php (whitelist of the divergence)
    //   - this lock (the runtime fix MySQL needs to match the partial-index
    //     semantics SQLite/PG get for free)
    // E1 (#884) cross-reference complete.
    $mysqlLockName = null;
    if ($d->driver_name() === 'mysql') {
        // MySQL GET_LOCK names are capped at 64 bytes and silently truncate
        // beyond that — two long keys sharing a 50+ char prefix would both
        // hash to the same lock and deadlock-ish. Hash the composed name to
        // a fixed 32-char digest so length is bounded regardless of key.
        $mysqlLockName = 'ipam_setting:' . md5($key . ':' . ($tenantId === null ? '__GLOBAL__' : (string)$tenantId));
        $db->prepare("SELECT GET_LOCK(:n, 5)")->execute([':n' => $mysqlLockName]);
    }

    // Wrap SELECT+UPDATE/INSERT in a transaction to prevent TOCTOU races only
    // when no outer transaction is already active. settings.php wraps all saves
    // in its own transaction, so starting a nested one here would throw
    // "There is already an active transaction" on every page save.
    $ownTx = !$db->inTransaction();
    if ($ownTx) {
        $db->beginTransaction();
    }
    try {
        // Fetch the existing row for the same scope (tenant or global) to produce
        // a meaningful audit diff. Build the tenant WHERE clause as a literal
        // condition rather than a parameterized NULL so that PostgreSQL can infer
        // the data type (PostgreSQL raises "indeterminate datatype" on bare NULL
        // parameters in prepared statements).
        $st = $db->prepare(
            "SELECT value, type FROM settings
             WHERE {$tenantWhere} AND {$kc} = :k"
        );
        $stParams = [':k' => $key];
        if ($tenantId !== null) { $stParams[':tb'] = $tenantId; }
        $st->execute($stParams);
        $prev = $st->fetch();
        if (is_array($prev)) {
            $oldRaw  = is_string($prev['value'] ?? null) ? $prev['value'] : null;
            $oldType = is_string($prev['type'] ?? null) && $prev['type'] !== '' ? $prev['type'] : $type;
        }

        // Write the new value. We use explicit UPDATE-then-INSERT rather than a
        // dialect upsert because SQLite treats NULL as distinct from NULL in UNIQUE
        // index lookups, so ON CONFLICT(tenant_id, key) never fires for global
        // (tenant_id IS NULL) rows in SQLite. The SELECT above already tells us
        // whether a row exists, so branching on $prev is cheap and portable.
        if (is_array($prev)) {
            // Row exists — update in place.
            $up = $db->prepare(
                "UPDATE settings
                 SET value = :v, type = :ty, updated_at = {$d->now()}, updated_by = :u
                 WHERE {$tenantWhere} AND {$kc} = :k"
            );
            $upParams = [':v' => $encoded, ':ty' => $type, ':u' => $userId, ':k' => $key];
            if ($tenantId !== null) { $upParams[':tb'] = $tenantId; }
            $up->execute($upParams);
        } else {
            // Row does not exist — insert.
            $up = $db->prepare(
                "INSERT INTO settings (tenant_id, {$kc}, value, type, updated_at, updated_by)
                 VALUES (:t, :k, :v, :ty, {$d->now()}, :u)"
            );
            $up->execute([
                ':t'  => $tenantId,
                ':k'  => $key,
                ':v'  => $encoded,
                ':ty' => $type,
                ':u'  => $userId,
            ]);
        }
        // Build and write the audit row inside the transaction so that a
        // failed audit INSERT rolls back the settings write too. The setting
        // change and its audit trail are committed atomically.
        $details = [
            'key' => $key,
            'old' => $sensitive ? '***' : ipam_setting_decode($oldRaw, $oldType, null),
            'new' => $sensitive ? '***' : ipam_setting_decode($encoded, $type, null),
        ];
        $encodedDetails = json_encode($details);
        audit($db, 'setting.update', 'setting', null, is_string($encodedDetails) ? $encodedDetails : $key);

        if ($ownTx) {
            $db->commit();
        }
    } catch (\Throwable $ex) {
        // Best-effort rollback. PHPStan 2.1.54 narrows
        // PDO::inTransaction() to always-false in this catch path
        // (incorrectly — a throw in the SELECT/UPDATE/INSERT block
        // before commit() leaves the transaction open). Wrap rollBack()
        // in its own try/catch so a "no active transaction" PDOException
        // does not mask the original exception we're propagating.
        if ($ownTx) {
            try { $db->rollBack(); } catch (\Throwable) {}
        }
        throw $ex;
    } finally {
        if ($mysqlLockName !== null) {
            try {
                $db->prepare("SELECT RELEASE_LOCK(:n)")->execute([':n' => $mysqlLockName]);
            } catch (\Throwable $_) {
                // Best-effort: the connection close will free it regardless.
            }
        }
    }

    // Bust the per-request cache by forcing a re-read on next call.
    ipam_setting_cache_bust($key);
}

/**
 * Bust the per-request cache for ipam_setting(). Always clears the entire
 * cache, regardless of whether a specific key is passed. Passing a key is
 * accepted for call-site clarity but has no narrowing effect: we cannot
 * enumerate all active tenant IDs to selectively evict only that key's
 * tenant-scoped entries, so a full wipe is the only safe option. The cache
 * is a single-request optimisation and rebuilds cheaply on next access.
 * Also exposed so tests can reset state between assertions.
 */
function ipam_setting_cache_bust(?string $key = null): void
{
    ipam_setting_cache_storage('__CLEAR__', true);
}

/**
 * Internal cache backing store for ipam_setting(). Keeps the static array
 * outside ipam_setting()'s own scope so ipam_setting_set() and
 * ipam_setting_cache_bust() can invalidate entries. Not intended for direct
 * use by application code.
 *
 * The cache key is "{tenantId}:{key}" where tenantId is 'g' for the global
 * (null) tenant and the integer string for tenant-scoped rows. This ensures
 * that tenant-specific reads do not collide with global reads in the same
 * request.
 *
 * Special sentinel: $key === '__CLEAR__' with $reset = true wipes the entire
 * cache, including all tenant-scoped entries. Used by tests between assertions.
 *
 * @internal
 */
function ipam_setting_cache_storage(
    ?string $key = null,
    bool $reset = false,
    mixed $setValue = null,
    bool $doSet = false,
    ?int $tenantId = null
): mixed {
    static $cache = [];

    // Full-cache wipe: __CLEAR__ sentinel used by tests and ipam_setting_cache_bust(null).
    if ($reset && $key === '__CLEAR__') {
        $cache = [];
        return '__IPAM_SETTING_MISS__';
    }

    $cacheKey = ($tenantId === null ? 'g' : (string)$tenantId) . ':' . (string)$key;

    if ($reset) {
        if ($key === null) {
            $cache = [];
        } else {
            unset($cache[$cacheKey]);
        }
        return null;
    }
    if ($doSet && $key !== null) {
        $cache[$cacheKey] = $setValue;
        return $setValue;
    }
    if ($key !== null && array_key_exists($cacheKey, $cache)) {
        return $cache[$cacheKey];
    }
    return '__IPAM_SETTING_MISS__';
}

/**
 * @return array<string, mixed> All known setting keys mapped to their effective
 *                              values via ipam_setting(). Used by the admin UI.
 */
function ipam_setting_all(): array
{
    $out = [];
    foreach (array_keys(ipam_setting_definitions()) as $key) {
        $out[$key] = ipam_setting($key);
    }
    return $out;
}

/**
 * Resolve where a setting's current value is coming from: 'db', 'config', or
 * 'default'. Used to render the source badge on settings.php. Queries the
 * database directly rather than through the cached helper so the badge
 * reflects ground truth.
 *
 * @return 'db'|'config'|'default'
 */
function ipam_setting_source(PDO $db, string $key): string
{
    try {
        $st = $db->prepare("SELECT 1 FROM settings WHERE tenant_id IS NULL AND ".ipam_key_col()." = :k");
        $st->execute([':k' => $key]);
        if ($st->fetchColumn() !== false) return 'db';
    } catch (\Throwable) {
    }
    return 'default';
}

/**
 * v3.0.0: detect non-bootstrap keys still present in config.php after the
 * stub migration. Returns a list of key names that should be removed.
 *
 * @param array<string, mixed> $config
 * @return list<string>
 */
function ipam_config_stale_keys(array $config): array
{
    $bootstrap = [
        'db_driver', 'db_dsn', 'db_user', 'db_pass', 'db_path',
        'session_name', 'session_cookie_path', 'force_https',
        'proxy_trust', 'base_url', 'bootstrap_admin',
        'recovery_mode', 'demo_mode',
        // v3.6.0 security-sensitive keys — must remain in config.php because
        // they are needed before or during the DB open / session start
        // sequence. See docs/configuration.md. These are top-level array keys
        // in config.php; nested members (e.g. session.absolute_lifetime_minutes)
        // live underneath them and are reached via $config['session'][...].
        'app_secret', 'session', 'auth', 'api',
        // v3.24.0 — IPAMBKP3 stored-mode backup encryption key. Lives in
        // config.php (not the DB) for the same reason as app_secret: a key
        // stored inside the data it protects defeats the security model.
        'backup_vault_key',
        // v3.26.0 (#1098) — the vault bootstrap_key. Auto-generated into
        // config.php by ipam_bootstrap_key() and required at runtime to
        // unwrap the backup_vault_key envelope stored in the settings table.
        // Must never be flagged stale: removing it breaks every IPAMBKP3
        // stored-mode backup on the install. See lib/vault.php.
        'bootstrap_key',
    ];
    $stale = [];
    foreach (array_keys($config) as $key) {
        if (!in_array($key, $bootstrap, true)) {
            $stale[] = to_str($key);
        }
    }
    return $stale;
}

/**
 * @deprecated v3.0.0 — config.php fallback removed. Kept only for the
 * 3.0.0-config-stub migration closure which needs to read old config values.
 * Return the list of registered settings that are still being served from
 * $config (config.php) instead of the database. Drives the v2.7.0 deprecation
 * banner in settings.php, the init.php boot-time log warning, and the
 * dashboard admin card that nudges admins to migrate before v3.0.0 removes
 * the fallback.
 *
 * A key is considered deprecated iff **all** of these hold:
 *   - its registry definition exists (bootstrap-only keys like db_driver
 *     are not in the registry so they are never flagged);
 *   - no row exists in the `settings` table for that key;
 *   - the key's `config_key` path resolves to a non-null value in
 *     $GLOBALS['config'];
 *   - that value differs from the registry `default`.
 *
 * The last condition keeps a pristine install with a seeded default
 * config.php from lighting up the banner for every single key — we only
 * surface what the admin has actually customised.
 *
 * On any DB error the helper returns [] (fail-quiet) so the boot path and
 * the dashboard render never break because of this advisory feature.
 *
 * @return list<array{key: string, config_path: string, current: mixed}>
 */
function ipam_setting_deprecated_keys(): array
{
    $db = $GLOBALS['db'] ?? null;
    if (!($db instanceof PDO)) return [];

    try {
        // `key` must be backtick-quoted — it's a MySQL reserved word. SQLite
        // also accepts backticks as identifier delimiters so the same SQL
        // runs on both engines. Without the quotes, MySQL would throw a
        // syntax error that the catch below would silently swallow,
        // returning [] and hiding every deprecation from the UI banner.
        $st   = $db->query("SELECT ".ipam_key_col()." FROM settings WHERE tenant_id IS NULL");
        $rows = $st !== false ? $st->fetchAll(PDO::FETCH_COLUMN) : [];
    } catch (\Throwable) {
        return [];
    }
    $inDb = [];
    foreach ($rows as $k) {
        if (is_string($k)) $inDb[$k] = true;
    }

    $config = $GLOBALS['config'] ?? null;
    if (!is_array($config)) return [];

    $out  = [];
    $defs = ipam_setting_definitions();
    foreach ($defs as $key => $def) {
        if (isset($inDb[$key])) continue;
        // CodeRabbit second sweep on PR #450: skip keys that are flagged
        // deprecated in the registry. Otherwise the deprecation banner would
        // offer an "Import to database" button that silently writes a
        // deprecated value (e.g. alert.email) into the settings table, where
        // the save and render loops would then ignore it forever.
        if (!empty($def['deprecated'])) continue;
        $configKey = $def['config_key'] ?? null;
        if ($configKey === null || (!is_string($configKey) && !is_array($configKey))) continue;

        $current = ipam_setting_config_fallback($config, $configKey);
        if ($current === null) continue;

        // Skip values that match the registry default — a config that still
        // holds the shipped default is not "customised". Loose compares keep
        // '0' vs 0 vs false and '0.5' vs 0.5 from producing spurious banner
        // entries. recaptcha_enterprise.score_threshold is the concrete
        // reason the string branch normalises through (string) casts: the
        // registry default is '0.5' while config_defaults keeps 0.5 (float).
        $default = $def['default'] ?? null;
        $type = is_string($def['type'] ?? null) ? $def['type'] : 'string';
        if ($type === 'bool' && (bool)$current === (bool)$default) continue;
        if ($type === 'int'  && is_numeric($current) && is_numeric($default) && (int)$current === (int)$default) continue;
        if ($type === 'string' && is_scalar($current) && is_scalar($default) && (string)$current === (string)$default) continue;
        if ($type === 'json'   && $current === $default) continue;

        if (is_array($configKey)) {
            $segments   = [];
            foreach ($configKey as $seg) $segments[] = to_str($seg);
            $configPath = implode('.', $segments);
        } else {
            $configPath = $configKey;
        }

        $out[] = [
            'key'         => $key,
            'config_path' => $configPath,
            'current'     => $current,
        ];
    }
    return $out;
}

/**
 * Resolve a setting definition's `options` entry to a `[value => label]` map,
 * or null when the setting is free-form. Supports three registry shapes:
 *
 *   - associative array: returned as-is
 *   - callable: invoked, result must be an associative array
 *   - sentinel string '@timezone': PHP timezone identifiers
 *
 * Unknown sentinels return null so the caller falls back to free-text
 * rendering rather than silently accepting any value.
 *
 * @param array<string, mixed> $def
 * @return array<string, string>|null
 */
function ipam_setting_options(array $def): ?array
{
    if (!array_key_exists('options', $def)) return null;
    $raw = $def['options'];

    if (is_callable($raw)) {
        $resolved = $raw();
    } elseif ($raw === '@timezone') {
        $ids = DateTimeZone::listIdentifiers();
        $resolved = array_combine($ids, $ids);
    } elseif (is_array($raw)) {
        $resolved = $raw;
    } else {
        return null;
    }

    if (!is_array($resolved)) return null;

    // Normalise to string => string for consistent rendering and strict
    // validation with array_key_exists() on the persisted value.
    $out = [];
    foreach ($resolved as $value => $label) {
        $out[(string)$value] = is_scalar($label) ? (string)$label : (string)$value;
    }
    return $out;
}

/* ---------------- History ---------------- */

/**
 * @param array<string, mixed>|null $before
 * @param array<string, mixed>|null $after
 */
function history_log_address(PDO $db, string $action, int $subnetId, string $ip, ?int $addressId, ?array $before, ?array $after): void
{
    $u = current_user();
    $st = $db->prepare("
        INSERT INTO address_history
          (address_id, subnet_id, ip, action, user_id, username, client_ip, user_agent, before_json, after_json)
        VALUES
          (:aid, :sid, :ip, :ac, :uid, :un, :cip, :ua, :bj, :aj)
    ");
    $st->execute([
        ':aid' => $addressId,
        ':sid' => $subnetId,
        ':ip'  => $ip,
        ':ac'  => $action,
        ':uid' => $u['id'] ?: null,
        ':un'  => $u['username'] ?: null,
        ':cip' => client_ip() ?: null,
        ':ua'  => to_str($_SERVER['HTTP_USER_AGENT'] ?? ''),
        ':bj'  => $before ? json_encode($before, JSON_UNESCAPED_SLASHES) : null,
        ':aj'  => $after ? json_encode($after, JSON_UNESCAPED_SLASHES) : null,
    ]);
}

/* ---------------- Migrations ---------------- */

function ensure_migrations_table(PDO $db): void
{
    $d = ipam_dialect();
    // version has a UNIQUE constraint so it must use the indexed text type
    // (VARCHAR on MySQL, TEXT elsewhere).
    $db->exec("CREATE TABLE IF NOT EXISTS schema_migrations (
        id " . $d->autoincrement() . ",
        version " . $d->indexed_text_type() . " NOT NULL UNIQUE,
        applied_at TEXT NOT NULL DEFAULT (" . $d->now() . ")
    )");
}

/** @return list<string> */
function applied_migrations(PDO $db): array
{
    $st = $db->prepare("SELECT version FROM schema_migrations");
    $st->execute();
    /** @var list<array<string, mixed>> $rows */
    $rows = $st->fetchAll();
    return array_map(fn(array $r): string => to_str($r['version']), $rows);
}

/** @return list<string> */
function apply_migrations(PDO $db): array
{
    ensure_migrations_table($db);
    require_once __DIR__ . '/migrations.php';

    $migs = ipam_migrations();
    ksort($migs, SORT_NATURAL);

    $done = array_flip(applied_migrations($db));
    $appliedNow = [];

    foreach ($migs as $ver => $fn) {
        if (isset($done[$ver])) continue;

        // SQLite DDL (DROP TABLE, ALTER TABLE) needs a full exclusive lock —
        // even readers block it. busy_timeout only retries SQLITE_BUSY (5),
        // not SQLITE_LOCKED (6), so we retry at the PHP level: ROLLBACK the
        // transaction, sleep 1 s, and try again. SQLite DDL is fully
        // transactional so ROLLBACK cleanly undoes any partial work.
        $lastErr  = null;
        $applied  = false;
        // Route FK toggling through the dialect so non-SQLite engines (MySQL
        // via SET FOREIGN_KEY_CHECKS, Postgres via null / deferred constraints)
        // get the engine-appropriate statement. Null means the engine has no
        // per-connection FK toggle and we rely on other mechanisms instead.
        $dialect = ipam_dialect();
        $fkOff   = $dialect->pragma_foreign_keys(false);
        $fkOn    = $dialect->pragma_foreign_keys(true);
        $toggleFk = static function (PDO $db, ?string $stmt): void {
            if ($stmt !== null) {
                $db->exec($stmt);
            }
        };
        for ($attempt = 0; $attempt < 60 && !$applied; $attempt++) {
            if ($attempt > 0) {
                sleep(1);
            }

            // FK enforcement must be toggled outside the transaction. On
            // SQLite, PRAGMA foreign_keys cannot be changed inside BEGIN; and
            // with FK ON, DROP TABLE triggers an implicit row-by-row DELETE
            // that cascades ON DELETE CASCADE children (addresses,
            // subnet_tags, etc.), wiping all data. Disabling around each
            // migration prevents the cascade. FK enforcement is restored
            // unconditionally in every exit path.
            $toggleFk($db, $fkOff);

            try {
                // SQLite's `BEGIN EXCLUSIVE` acquires a table-level write
                // lock up front, which is required around DDL to avoid
                // SQLITE_LOCKED mid-migration. MySQL / Postgres don't need
                // (and don't accept) the EXCLUSIVE modifier — their DDL
                // acquires its own metadata locks. Fall back to a plain
                // transaction on non-SQLite engines.
                if ($dialect->driver_name() === 'sqlite') {
                    $db->exec("BEGIN EXCLUSIVE");
                } else {
                    $db->exec("START TRANSACTION");
                }
            } catch (Throwable $e) {
                $toggleFk($db, $fkOn);
                $lastErr = $e;
                if (stripos($e->getMessage(), 'locked') !== false || stripos($e->getMessage(), 'busy') !== false) {
                    continue;
                }
                throw $e;
            }

            try {
                $fn($db);
                $st = $db->prepare("INSERT INTO schema_migrations (version) VALUES (:v)");
                $st->execute([':v' => $ver]);
                $db->exec("COMMIT");
                $applied = true;
                $appliedNow[] = $ver;
                $lastErr = null;
            } catch (Throwable $e) {
                try { $db->exec("ROLLBACK"); } catch (Throwable) {}
                $toggleFk($db, $fkOn);
                $lastErr = $e;
                if (stripos($e->getMessage(), 'locked') !== false || stripos($e->getMessage(), 'busy') !== false) {
                    continue;
                }
                throw $e;
            }
            $toggleFk($db, $fkOn);
        }

        if ($lastErr !== null) {
            throw $lastErr;
        }
    }

    return $appliedNow;
}

/**
 * @deprecated v3.0.0 — ipam_config_sync removed; config.php is now a bootstrap stub.
 * @return array<string, array{default: mixed, comment: string}>
 */
function ipam_config_defaults(): array
{
    return [
        'db_path' => [
            'default' => null, // path-dependent, skip auto-append
            'comment' => '',
        ],
        'session_name' => ['default' => null, 'comment' => ''],
        'base_url'     => [
            'default' => null,
            'comment' => "Canonical HTTPS base URL (e.g. 'https://ipam.example.com'). "
                       . "Used for the HTTP→HTTPS redirect. If null, falls back to HTTP_HOST.",
        ],
        'proxy_trust'  => ['default' => null, 'comment' => ''],
        'app_name' => [
            'default' => 'Simple PHP IPAM',
            'comment' => "Application display name shown in the browser tab, nav bar, and login page. Default: 'Simple PHP IPAM'.",
        ],
        'timezone' => [
            'default' => 'UTC',
            'comment' => "Timezone for displaying timestamps in the UI. Use a PHP timezone identifier, "
                       . "e.g. 'America/Toronto', 'Europe/London', 'UTC'. "
                       . "All timestamps are stored in UTC; this setting converts them for display only.",
        ],
        'bootstrap_admin' => ['default' => null, 'comment' => ''],
        'session_idle_seconds' => ['default' => null, 'comment' => ''],
        'login_max_attempts'   => ['default' => null, 'comment' => ''],
        'login_lockout_seconds'=> ['default' => null, 'comment' => ''],
        'api_max_attempts' => [
            'default' => 20,
            'comment' => 'Max failed API key attempts per IP before lockout.',
        ],
        'api_lockout_seconds' => [
            'default' => 300,
            'comment' => 'Duration (seconds) of API key lockout after too many failed attempts.',
        ],
        'api_bulk_limit' => [
            'default' => 500,
            'comment' => 'Maximum number of records per bulk API write request (POST ?resource=addresses&bulk=1).',
        ],
        'recaptcha_enterprise' => [
            'default' => [
                'enabled'          => false,
                'project_id'       => '',
                'api_key'          => '',
                'expected_action'  => 'login',
                'score_threshold'  => 0.5,
            ],
            'comment' => "reCAPTCHA Enterprise (v3). Set login_protection.method = 'recaptcha' and enable this block to use the Enterprise API for backend verification. project_id: GCP project ID. api_key: server-side API key. expected_action: action name from widget. score_threshold: 0.0–1.0 (default 0.5).",
        ],
        'import_csv_max_mb'    => ['default' => null, 'comment' => ''],
        // v2.9.2: auto-populate import_sql_max_mb on upgrade. The key was
        // missing from the registry, so ipam_config_sync() silently skipped
        // it on upgrades from older releases, and db_tools.php's unguarded
        // read produced an E_WARNING cascade when the key was absent.
        'import_sql_max_mb' => [
            'default' => 200,
            'comment' => 'Maximum SQL import file size (MB). App-level soft cap '
                . 'enforced by db_tools.php. If you raise it above .htaccess '
                . 'post_max_size / upload_max_filesize, raise those values too.',
        ],
        'tmp_cleanup_ttl_seconds' => ['default' => null, 'comment' => ''],
        'audit_log_retention_days' => [
            'default' => 0,
            'comment' => 'Audit log retention (days). Entries older than this are pruned during housekeeping. 0 = keep forever.',
        ],
        'address_history_retention_days' => [
            'default' => 0,
            'comment' => 'Address history retention (days). Entries older than this are pruned during housekeeping. 0 = keep forever.',
        ],
        'housekeeping' => ['default' => null, 'comment' => ''],
        'utilization_warn'     => ['default' => null, 'comment' => ''],
        'utilization_critical' => ['default' => null, 'comment' => ''],
        'update_check' => [
            'default' => [
                'enabled'           => true,
                'ttl_seconds'       => 86400,
                'notify_prerelease' => false,
            ],
            'comment' => 'Update check: fetches releases from GitHub and shows a banner when a newer version is available.',
        ],
        'backup' => [
            'default' => [
                'enabled'   => false,
                'frequency' => 'daily',
                'retention' => 7,
                'dir'       => '',
            ],
            'comment' => "Automatic database backups. frequency: 'daily' | 'weekly'. retention: keep last N backups.",
        ],
        'oidc' => [
            'default' => [
                'enabled'                  => false,
                'display_name'             => 'SSO',
                'client_id'                => '',
                'client_secret'            => '',
                'discovery_url'            => '',
                'redirect_uri'             => '',
                'scopes'                   => 'openid email profile',
                'auto_link'                => false,
                'auto_provision'           => false,
                'default_role'             => 'readonly',
                'disable_local_login'      => false,
                'hide_emergency_link'      => false,
                'disable_emergency_bypass' => false,
            ],
            'comment' => 'OIDC SSO configuration. See docs/oidc.md for full details.',
        ],
        'password_policy' => [
            'default' => [
                'min_length'            => 12,
                'require_uppercase'     => false,
                'require_lowercase'     => false,
                'require_number'        => false,
                'require_symbol'        => false,
                'max_password_age_days' => 0,
            ],
            'comment' => "Password complexity and rotation policy. min_length: minimum chars. require_*: enforce character classes. max_password_age_days: 0 = never expires.",
        ],
        'login_protection' => [
            'default' => [
                'method'      => null,
                'site_key'    => '',
                'secret_key'  => '',
                'min_seconds' => 3,
                'version'     => 2,
            ],
            'comment' => "Login form bot protection. method: null | 'honeypot' | 'time_check' | 'turnstile' | 'hcaptcha' | 'recaptcha' | 'friendly_captcha'. site_key/secret_key required for widget methods.",
        ],
        'demo_mode' => [
            'default' => [
                'enabled'    => false,
                'gate'       => null,
                'site_key'   => '',
                'secret_key' => '',
            ],
            'comment' => "Demo mode: only demo/demo can log in; data resets nightly. gate: optional pre-login bot challenge (null | 'honeypot' | 'turnstile' | 'hcaptcha' | 'recaptcha' | 'friendly_captcha').",
        ],
    ];
}

/**
 * Format a PHP value as clean source code with array [] syntax.
 */
function ipam_php_export(mixed $val, int $indent = 1): string
{
    if (is_null($val))    return 'null';
    if (is_bool($val))    return $val ? 'true' : 'false';
    if (is_int($val))     return (string)$val;
    if (is_float($val))   return rtrim(number_format($val, 10, '.', ''), '0') ?: '0.0';
    if (is_string($val))  return "'" . addcslashes($val, "'\\") . "'";

    if (is_array($val)) {
        if (count($val) === 0) return '[]';
        $pad = str_repeat('    ', $indent);
        $outerPad = str_repeat('    ', $indent - 1);
        $isList = array_keys($val) === range(0, count($val) - 1);
        $out = "[\n";
        foreach ($val as $k => $v) {
            $keyStr = $isList ? '' : "'" . addcslashes((string)$k, "'\\") . "' => ";
            $out .= $pad . $keyStr . ipam_php_export($v, $indent + 1) . ",\n";
        }
        $out .= $outerPad . ']';
        return $out;
    }

    return var_export($val, true);
}

/**
 * Check config.php for missing top-level keys and missing sub-keys within
 * existing nested blocks, and append them with their defaults.
 *
 * Returns list of key names added (top-level as 'key', nested as 'key.subkey').
 * Only keys whose default is not null are auto-appended.
 * The 'bootstrap_admin' block is never deep-merged (admin sets it intentionally).
 */
/**
 * @param array<string, mixed> $loaded
 * @return list<string>
 */
function ipam_config_sync(string $configPath, array $loaded): array
{
    $defaults = ipam_config_defaults();
    $added    = [];

    foreach ($defaults as $key => $meta) {
        if ($meta['default'] === null) continue;

        if (!array_key_exists($key, $loaded)) {
            // --- Top-level key missing: append whole block ---
            $content = @file_get_contents($configPath);
            if ($content === false) break;
            if (!preg_match('/\n\];\s*$/', $content)) break;

            $comment  = to_str($meta['comment']);
            $valuePhp = ipam_php_export($meta['default'], 2);
            $block    = '';
            if ($comment !== '') $block .= "\n    // " . $comment;
            $block .= "\n    '" . addcslashes($key, "'\\") . "' => " . $valuePhp . ",\n";

            $content = preg_replace('/\n\];\s*$/', $block . "\n];", $content);
            if ($content === null) break;
            if (@file_put_contents($configPath, $content) !== false) {
                $added[] = $key;
            } else {
                $_SESSION['config_unwritable'] = true; // #119: surface in page_header()
                break;
            }
        } elseif ($key !== 'bootstrap_admin'
               && is_array($meta['default'])
               && is_array($loaded[$key])) {
            // --- Nested block exists: deep-merge missing sub-keys ---
            $missingSubKeys = array_diff_key($meta['default'], $loaded[$key]);
            foreach ($missingSubKeys as $subKey => $subDefault) {
                $content = @file_get_contents($configPath);
                if ($content === false) break 2;

                $escapedKey = preg_quote($key, '/');
                $subValuePhp = ipam_php_export($subDefault, 3);
                $newLine = "\n        '" . addcslashes((string)$subKey, "'\\") . "' => " . $subValuePhp . ",";

                // Match '    'key' => [  ...content...  \n    ],'
                $pattern = '/(\n    \'' . $escapedKey . '\'\s*=>\s*\[)(.*?)(\n    \],)/s';
                if (!preg_match($pattern, $content)) break;

                $content = preg_replace_callback($pattern, static function (array $m) use ($newLine): string {
                    return $m[1] . $m[2] . $newLine . $m[3];
                }, $content);

                if ($content === null) break;
                if (@file_put_contents($configPath, $content) !== false) {
                    $added[] = $key . '.' . $subKey;
                } else {
                    $_SESSION['config_unwritable'] = true; // #119: surface in page_header()
                    break 2;
                }
            }
        }
    }

    return $added;
}

/**
 * Validate loaded config values and return a list of human-readable warning strings.
 * Logs each warning to the PHP error log as well.
 *
 * @param IpamConfig $config
 * @return list<string>
 */
function ipam_validate_config(array $config): array
{
    $warnings = [];
    $checks = [
        ['security.session_idle_seconds',  60, '>=', 'session_idle_seconds'],
        ['security.login_max_attempts',     1, '>=', 'login_max_attempts'],
        ['security.login_lockout_seconds',  1, '>=', 'login_lockout_seconds'],
        ['housekeeping.audit_log_retention_days', 0, '>=', 'audit_log_retention_days'],
    ];
    foreach ($checks as [$key, $min, $op, $label]) {
        $val = to_int(ipam_setting($key));
        if ($val < $min) {
            $warnings[] = "{$label} is {$val}; minimum is {$min}.";
        }
    }
    foreach ($warnings as $w) {
        error_log("Simple PHP IPAM config warning: {$w}");
    }
    return $warnings;
}

/* ---------------- Housekeeping ---------------- */

function housekeeping_state_path(): string
{
    return __DIR__ . '/data/housekeeping.json';
}

/**
 * @phpstan-impure
 * @param IpamConfig $config
 */
function housekeeping_should_run(array $config): bool
{
    if (!(bool)ipam_setting('housekeeping.enabled')) return false;

    $interval = to_int(ipam_setting('housekeeping.interval_seconds'));
    if ($interval < 3600) $interval = 3600;

    $path = housekeeping_state_path();
    if (!is_file($path)) return true;

    $last = @filemtime($path);
    if ($last === false) return true;

    return (time() - $last) >= $interval;
}

function housekeeping_mark_ran(): void
{
    $path = housekeeping_state_path();
    $dir = dirname($path);
    if (!is_dir($dir)) mkdir($dir, 0700, true);

    @file_put_contents($path, json_encode(['last_run' => time()], JSON_PRETTY_PRINT));
    @chmod($path, 0600);
}

function prune_audit_log(PDO $db, int $retentionDays): int
{
    if ($retentionDays <= 0) return 0;
    $cutoff = date('Y-m-d H:i:s', (int)strtotime("-{$retentionDays} days"));

    // Retention routine must DELETE rows without ever leaving the
    // append-only guarantee observable-violated. v2.10.0 #502 post-review
    // fix: previously this dropped triggers, DELETEd, then recreated the
    // triggers — which exposed a race window where other connections
    // could UPDATE/DELETE audit_log. Two per-engine strategies now close
    // the window without needing a drop/recreate cycle:
    //
    //   SQLite  — wrap the DELETE in BEGIN IMMEDIATE / COMMIT. SQLite DDL
    //             is transactional AND BEGIN IMMEDIATE holds a reserved
    //             write lock the entire time, so no other writer can
    //             touch audit_log. The SQLite RAISE(ABORT) triggers DO
    //             fire on DELETE, so we still have to drop+recreate on
    //             SQLite — but now inside the reserved-lock transaction,
    //             which is atomic from every other connection's point of
    //             view.
    //
    //   MySQL   — set @ipam_bypass_append_only = 1 at session scope. The
    //             MysqlDialect trigger bodies wrap SIGNAL in an IF block
    //             gated on this variable (v2.10.0 #502 change to
    //             MysqlDialect::append_only_trigger). Session variables
    //             are per-connection so the bypass never leaks to other
    //             connections — their SIGNAL continues to fire
    //             unconditionally. DELETE proceeds on this connection,
    //             every other write is still blocked. No drop/recreate
    //             needed; the triggers stay in place the entire time.
    //
    //   Postgres (v2.11.0 #388) — SET LOCAL ipam.bypass_append_only = '1'
    //             inside a transaction. The custom GUC is checked by the
    //             PL/pgSQL trigger function (current_setting('ipam.bypass_
    //             append_only', true) IS DISTINCT FROM '1'). SET LOCAL is
    //             per-transaction so the bypass automatically unsets on
    //             COMMIT/ROLLBACK — no explicit cleanup needed and no leak
    //             risk to other connections or subsequent transactions.
    //
    // Error paths always attempt to restore a safe state: clear the
    // MySQL session variable, recreate SQLite triggers via
    // ensure_audit_log_table() as a fallback.
    $driver = ipam_dialect()->driver_name();
    try {
        if ($driver === 'sqlite') {
            $db->exec("BEGIN IMMEDIATE");
            $db->exec("DROP TRIGGER IF EXISTS audit_log_no_update");
            $db->exec("DROP TRIGGER IF EXISTS audit_log_no_delete");

            $st = $db->prepare("DELETE FROM audit_log WHERE created_at < :cutoff");
            $st->execute([':cutoff' => $cutoff]);
            $pruned = $st->rowCount();

            // Recreate the append-only triggers explicitly. The probe in
            // ensure_audit_log_table() short-circuits when the table is
            // present (it is — we only dropped the triggers, not the
            // table), so we cannot rely on it to put the triggers back.
            ensure_audit_log_triggers($db);
            $db->exec("COMMIT");
        } elseif ($driver === 'mysql') {
            $db->exec("SET @ipam_bypass_append_only = 1");

            $st = $db->prepare("DELETE FROM audit_log WHERE created_at < :cutoff");
            $st->execute([':cutoff' => $cutoff]);
            $pruned = $st->rowCount();

            $db->exec("SET @ipam_bypass_append_only = NULL");
        } elseif ($driver === 'pgsql') {
            $ownTx = !$db->inTransaction();
            if ($ownTx) {
                $db->beginTransaction();
            }
            $db->exec("SET LOCAL ipam.bypass_append_only = '1'");

            $st = $db->prepare("DELETE FROM audit_log WHERE created_at < :cutoff");
            $st->execute([':cutoff' => $cutoff]);
            $pruned = $st->rowCount();

            if ($ownTx) {
                $db->commit();
            }
        } else {
            throw new \RuntimeException("prune_audit_log: unsupported driver '$driver'");
        }

        return $pruned;
    } catch (Throwable $e) {
        if ($driver === 'sqlite') {
            try { $db->exec("ROLLBACK"); } catch (Throwable) {}
            try { ensure_audit_log_table($db); } catch (Throwable) {}
        } elseif ($driver === 'mysql') {
            try { $db->exec("SET @ipam_bypass_append_only = NULL"); } catch (Throwable) {}
        } elseif ($driver === 'pgsql') {
            if (isset($ownTx) && $ownTx && $db->inTransaction()) {
                try { $db->rollBack(); } catch (Throwable) {}
            }
        }
        error_log('audit_log prune failed: ' . $e->getMessage());
        return 0;
    }
}

function prune_address_history(PDO $db, int $retentionDays): int
{
    if ($retentionDays <= 0) return 0;
    $cutoff = date('Y-m-d H:i:s', (int)strtotime("-{$retentionDays} days"));
    $st = $db->prepare("DELETE FROM address_history WHERE created_at < :cutoff");
    $st->execute([':cutoff' => $cutoff]);
    return $st->rowCount();
}

/**
 * Send email utilization alerts for subnets that have crossed warn/crit thresholds.
 * Deduplicates sends using the alert_state table (max one alert per subnet+level per 24 h).
 * Auto-clears alert_state rows when utilization drops back below the threshold.
 *
 * @param IpamConfig $config Unused since v2.7.0 — thresholds and the
 *                           recipient now flow through ipam_setting().
 */
/**
 * #443: resolve the configured `alert.recipient_user_ids` list to a list of
 * current email addresses. Inactive users and users whose email has been
 * cleared since the recipient was selected drop out automatically — no need
 * to re-save the settings page when staffing changes.
 *
 * @return list<string>
 */
function ipam_resolve_alert_recipients(PDO $db): array
{
    $ids = ipam_setting('alert.recipient_user_ids', []);
    return ipam_resolve_recipients_for_user_ids($db, is_array($ids) ? $ids : []);
}

/**
 * v3.25.0 #1078: backup-specific recipient resolution. If the
 * `backup.notify_recipient_user_ids` override is set (non-empty array),
 * resolve against that list; otherwise fall back to the global alert
 * recipients. Combine with any extra free-form addresses from
 * `backup.notify_recipient_email_extra` (CSV, no user account required).
 *
 * @return list<string>
 */
function ipam_resolve_backup_notify_recipients(PDO $db): array
{
    $override = ipam_setting('backup.notify_recipient_user_ids', []);
    $useOverride = is_array($override) && $override !== [];
    $emails = $useOverride
        ? ipam_resolve_recipients_for_user_ids($db, $override)
        : ipam_resolve_alert_recipients($db);

    $extraRaw = ipam_setting('backup.notify_recipient_email_extra', '');
    if (is_string($extraRaw) && trim($extraRaw) !== '') {
        foreach (explode(',', $extraRaw) as $e) {
            $e = trim($e);
            if ($e !== '' && filter_var($e, FILTER_VALIDATE_EMAIL) !== false) {
                $emails[] = $e;
            }
        }
    }
    return array_values(array_unique($emails));
}

/**
 * Resolve a list of user IDs to email addresses. Skips inactive users and
 * users without an email. Accepts a mixed array (JSON-decoded settings
 * value) and coerces each entry to int; non-positive entries are dropped.
 *
 * @param  array<int|string, mixed> $rawIds
 * @return list<string>
 */
function ipam_resolve_recipients_for_user_ids(PDO $db, array $rawIds): array
{
    if ($rawIds === []) return [];
    $intIds = array_values(array_unique(array_map(fn($v) => (int)to_str($v), $rawIds)));
    $intIds = array_values(array_filter($intIds, fn($i) => $i > 0));
    if ($intIds === []) return [];

    $placeholders = implode(',', array_fill(0, count($intIds), '?'));
    $st = $db->prepare(
        "SELECT email FROM users
         WHERE id IN ($placeholders)
           AND is_active = 1
           AND email IS NOT NULL
           AND email != ''
         ORDER BY id"
    );
    $st->execute($intIds);
    /** @var list<string> $out */
    $out = [];
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $email) {
        $email = trim(to_str($email));
        if ($email !== '') $out[] = $email;
    }
    return $out;
}

/**
 * Send an email via SMTP (PHPMailer) or native mail(), based on smtp.enabled setting.
 *
 * @return array{success: bool, error: ?string, transport: string}
 */
function ipam_send_mail(string $to, string $subject, string $bodyText, string $bodyHtml = '', ?string $transportOverride = null): array
{
    // v3.25.0 #1078: optional transport override lets the backup notify
    // dispatcher force SMTP regardless of the global smtp.enabled setting.
    // Accepted values: 'smtp' (force SMTP) or null (use global).
    $smtpEnabled = $transportOverride === 'smtp'
        ? true
        : (bool) ipam_setting('smtp.enabled');

    if ($smtpEnabled) {
        if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
            // Primary: vendor/ bundled inside the web root (release tarball installs).
            // Fallback: vendor/ at the project root, one level above the web root
            // (dev/Docker setups where vendor is mounted outside the web root).
            $autoload = __DIR__ . '/vendor/autoload.php';
            if (!file_exists($autoload)) {
                $autoload = dirname(__DIR__) . '/vendor/autoload.php';
            }
            if (file_exists($autoload)) require_once $autoload;
        }
        if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
            return ['success' => false, 'error' => 'PHPMailer is not available (check vendor/autoload.php)', 'transport' => 'smtp'];
        }

        try {
            $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
            $mail->isSMTP();
            $mail->Host    = to_str(ipam_setting('smtp.host'));
            $mail->Port    = to_int(ipam_setting('smtp.port'));
            $mail->Timeout = to_int(ipam_setting('smtp.timeout_seconds'));

            $enc = to_str(ipam_setting('smtp.encryption'));
            if ($enc === 'ssl') {
                $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
            } elseif ($enc === 'starttls') {
                $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            } else {
                $mail->SMTPSecure = '';
                $mail->SMTPAutoTLS = false;
            }

            $authUser = to_str(ipam_setting('smtp.auth_user'));
            $authPass = to_str(ipam_setting('smtp.auth_pass'));
            if ($authUser !== '') {
                $mail->SMTPAuth = true;
                $mail->Username = $authUser;
                $mail->Password = $authPass;
            }

            if (!(bool) ipam_setting('smtp.verify_peer')) {
                $mail->SMTPOptions = ['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true]];
            }

            $fromAddr = to_str(ipam_setting('smtp.from_address'));
            $fromName = to_str(ipam_setting('smtp.from_name'));
            if ($fromAddr !== '') {
                $mail->setFrom($fromAddr, $fromName ?: $fromAddr);
            }

            // PHPMailer defaults CharSet to ISO-8859-1, which mojibakes any
            // UTF-8 in subject/body (em-dash, smart quotes, accented chars).
            // Encoding stays at the PHPMailer default (8bit) — UTF-8 text bodies
            // travel fine on modern SMTP and stay human-readable in test parsers.
            $mail->CharSet = \PHPMailer\PHPMailer\PHPMailer::CHARSET_UTF8;

            $mail->addAddress($to);
            $mail->Subject = $subject;
            if ($bodyHtml !== '') {
                $mail->isHTML(true);
                $mail->Body    = $bodyHtml;
                $mail->AltBody = $bodyText;
            } else {
                $mail->Body = $bodyText;
            }

            $mail->send();
            return ['success' => true, 'error' => null, 'transport' => 'smtp'];
        } catch (\Throwable $e) {
            return ['success' => false, 'error' => $e->getMessage(), 'transport' => 'smtp'];
        }
    }

    // Native mail() fallback
    $safeSubject = preg_replace('/[\r\n]/', '', $subject) ?? '';
    $safeTo      = preg_replace('/[\r\n]/', '', $to) ?? '';
    error_clear_last();
    $ok = @mail($safeTo, $safeSubject, $bodyText); // nosemgrep
    if (!$ok) {
        $last = error_get_last();
        $err  = $last !== null ? $last['message'] : 'mail() returned false';
        return ['success' => false, 'error' => $err, 'transport' => 'mail'];
    }
    return ['success' => true, 'error' => null, 'transport' => 'mail'];
}

/** @param IpamConfig $config */
function check_utilization_alerts(PDO $db, array $config): void
{
    unset($config);
    $recipients = ipam_resolve_alert_recipients($db);
    if ($recipients === []) return;

    $warnPct = to_int(ipam_setting('alert.util_warn_pct'));
    $critPct = to_int(ipam_setting('alert.util_crit_pct'));
    $appName = to_str(ipam_setting('branding.site_name'));

    // Use the shared utilization function that excludes infrastructure IPs (#566)
    $utilData = ipv4_unassigned_summary($db);

    // Build rows from utilData for the alert loop (#457: skip subnets with alerts_enabled = 0)
    $subnetRows = ($db->query("SELECT id, cidr, prefix FROM subnets WHERE ip_version = 4 AND alerts_enabled = 1")
        ?: throw new \RuntimeException('Query failed'))->fetchAll();
    $rows = [];
    foreach ($subnetRows as $sr) {
        $sid = to_int($sr['id']);
        $u = $utilData[$sid] ?? null;
        $rows[] = [
            'id'     => $sr['id'],
            'cidr'   => $sr['cidr'],
            'prefix' => $sr['prefix'],
            'assigned' => $u !== null ? $u['assigned_assignable'] : 0,
        ];
    }

    // Load existing alert state
    $stateRows = ($db->query("SELECT subnet_id, level, last_alerted_at FROM alert_state")
        ?: throw new \RuntimeException('Query failed'))->fetchAll();
    $alertState = [];
    foreach ($stateRows as $sr) {
        $alertState[to_int($sr['subnet_id'])][to_str($sr['level'])] = to_str($sr['last_alerted_at']);
    }

    $cooldownSeconds = 86400; // 24 hours

    foreach ($rows as $row) {
        $sid    = to_int($row['id']);
        $cidr   = to_str($row['cidr']);
        $prefix = to_int($row['prefix']);
        $assigned = to_int($row['assigned']);

        $assignable = ipv4_assignable_count($prefix);
        if ($assignable <= 0) continue;

        $pct = (int)round($assigned / $assignable * 100);

        // Determine active levels
        $levels = [];
        if ($pct >= $critPct) $levels[] = 'crit';
        elseif ($pct >= $warnPct) $levels[] = 'warn';

        // Auto-clear stale alert_state rows when below thresholds
        foreach (['warn', 'crit'] as $lvl) {
            if (isset($alertState[$sid][$lvl]) && !in_array($lvl, $levels, true)) {
                $db->prepare("DELETE FROM alert_state WHERE subnet_id = :sid AND level = :lvl")
                   ->execute([':sid' => $sid, ':lvl' => $lvl]);
                unset($alertState[$sid][$lvl]);
            }
        }

        foreach ($levels as $lvl) {
            $lastAlerted = $alertState[$sid][$lvl] ?? null;
            if ($lastAlerted !== null) {
                $lastTs = strtotime($lastAlerted);
                if ($lastTs !== false && (time() - $lastTs) < $cooldownSeconds) continue;
            }

            $levelLabel = $lvl === 'crit' ? 'CRITICAL' : 'WARNING';
            $subject    = "[{$appName}] {$levelLabel}: subnet {$cidr} at {$pct}% utilization";
            $body       = "{$levelLabel}: Subnet {$cidr} has reached {$pct}% utilization.\n"
                        . "Assigned: {$assigned} / Assignable: {$assignable}\n\n"
                        . "-- {$appName}";
            $safeSubject = preg_replace('/[\r\n]/', '', $subject) ?? '';

            // #443: loop-per-recipient delivery. Best-effort: a bad address
            // for one recipient does not block delivery to the others, and
            // each send produces its own audit row so failures are debuggable.
            $anyDelivered = false;
            foreach ($recipients as $recipient) {
                $safeEmail   = preg_replace('/[\r\n]/', '', $recipient) ?? '';
                $maskedEmail = preg_replace('/(^.).*(@.*$)/', '$1***$2', $safeEmail) ?? '';
                $result = ipam_send_mail($safeEmail, $safeSubject, $body);
                if ($result['success']) {
                    $anyDelivered = true;
                    audit($db, 'alert.send', 'subnet', $sid, "level={$lvl} pct={$pct} email={$maskedEmail} transport={$result['transport']}");
                } else {
                    audit($db, 'mail.send_failed', 'subnet', $sid, "level={$lvl} pct={$pct} email={$maskedEmail} transport={$result['transport']} error=" . json_encode($result['error']));
                }
            }

            // Only consume the 24h cooldown when at least one delivery succeeded;
            // a fully-failed send must be retried on the next housekeeping run.
            if ($anyDelivered) {
                $now = date('Y-m-d H:i:s');
                // #379: route through the dialect's upsert() so v2.10.0+ can
                // swap to ON DUPLICATE KEY UPDATE / ON CONFLICT DO UPDATE
                // without touching this call site.
                $alertUpsert = ipam_dialect()->upsert('alert_state', ['subnet_id', 'level'], ['last_alerted_at']);
                $db->prepare(
                    "INSERT INTO alert_state (subnet_id, level, last_alerted_at)
                     VALUES (:sid, :lvl, :now)
                     $alertUpsert"
                )->execute([':sid' => $sid, ':lvl' => $lvl, ':now' => $now]);
                $alertState[$sid][$lvl] = $now;
            }
        }
    }
}

/**
 * Run utilization alert check if the alert interval has elapsed.
 * Uses a dedicated state file so it can fire more frequently than main housekeeping.
 *
 * @param IpamConfig $config Unused since v2.7.0 — kept for signature stability.
 */
function alerts_check_if_due(array $config, PDO $db): void
{
    if (ipam_resolve_alert_recipients($db) === []) return;

    $interval = to_int(ipam_setting('alert.interval_seconds'));
    if ($interval < 60) $interval = 60;

    $statePath = __DIR__ . '/data/alerts_last_run.txt';
    if (is_file($statePath)) {
        $last = (int)@file_get_contents($statePath);
        if ((time() - $last) < $interval) return;
    }

    check_utilization_alerts($db, $config);

    @file_put_contents($statePath, (string)time());
    @chmod($statePath, 0600);
}

/** @param IpamConfig $config */
function run_housekeeping_if_due(array $config, ?PDO $db = null): void
{
    if (!housekeeping_should_run($config)) return;

    $lockPath = __DIR__ . '/data/housekeeping.lock';
    $lock = @fopen($lockPath, 'c');
    if (!$lock) return;

    if (!@flock($lock, LOCK_EX | LOCK_NB)) {
        fclose($lock);
        return;
    }

    try {
        if (!housekeeping_should_run($config)) return;

        $ttl = to_int(ipam_setting('housekeeping.tmp_cleanup_ttl_seconds'));
        if ($ttl < 3600) $ttl = 3600;

        cleanup_tmp_import_files($ttl);
        cleanup_tmp_import_plans($ttl);

        if ($db !== null) {
            $retentionDays = to_int(ipam_setting('housekeeping.audit_log_retention_days'));
            if ($retentionDays > 0) {
                prune_audit_log($db, $retentionDays);
            }
            $histRetention = to_int(ipam_setting('housekeeping.address_history_retention_days'));
            if ($histRetention > 0) {
                prune_address_history($db, $histRetention);
            }
            prune_rate_limit_dampener($db);
            capture_utilization_snapshot($db);
        }

        housekeeping_mark_ran();
    } finally {
        @flock($lock, LOCK_UN);
        @fclose($lock);
    }
}

/**
 * Capture a utilization snapshot for every IPv4 subnet (/8–/32).
 * Called from run_housekeeping_if_due() when housekeeping fires.
 * Returns the number of rows inserted.
 */
function capture_utilization_snapshot(PDO $db): int
{
    $utilData = ipv4_unassigned_summary($db);
    $st = $db->prepare("SELECT id, prefix FROM subnets WHERE ip_version = 4 AND prefix BETWEEN 8 AND 32");
    $st->execute();
    /** @var list<array<string, mixed>> $subnets */
    $subnets = $st->fetchAll();

    $today = gmdate('Y-m-d');
    $now   = $today . ' ' . gmdate('H:i:s');
    // Build set of subnet IDs already snapped today to avoid duplicate daily rows.
    $doneStmt = $db->prepare(
        "SELECT DISTINCT subnet_id FROM utilization_snapshots WHERE snapped_at >= :day"
    );
    $doneStmt->execute([':day' => $today . ' 00:00:00']);
    $alreadyDone = array_flip(array_column($doneStmt->fetchAll(), 'subnet_id'));
    $ins = $db->prepare(
        "INSERT INTO utilization_snapshots (subnet_id, snapped_at, used_count, free_count, total_hosts)
         VALUES (:sid, :ts, :used, :free, :total)"
    );
    $count = 0;
    foreach ($subnets as $row) {
        $sid = to_int($row['id']);
        if (isset($alreadyDone[$sid])) continue;
        $u = $utilData[$sid] ?? null;
        if ($u === null) continue;
        $prefix = to_int($row['prefix']);
        $total  = ipv4_assignable_count($prefix);
        if ($total <= 0) continue;
        $used = to_int($u['assigned_assignable']);
        $ins->execute([
            ':sid'   => $sid,
            ':ts'    => $now,
            ':used'  => $used,
            ':free'  => max(0, $total - $used),
            ':total' => $total,
        ]);
        $count++;
    }

    // Prune old snapshots
    $retention = to_int(ipam_setting('housekeeping.snapshot_retention_days'));
    if ($retention > 0) {
        $cutoff = gmdate('Y-m-d H:i:s', time() - $retention * 86400);
        $db->prepare("DELETE FROM utilization_snapshots WHERE snapped_at < :cutoff")
           ->execute([':cutoff' => $cutoff]);
    }

    return $count;
}

/**
 * Demo nightly reset — runs independently of the housekeeping schedule.
 * Called directly from init.php, wrapped in try-catch so a seed failure
 * never crashes the page load (which would leave $_SESSION without a
 * CSRF token and cause "Bad CSRF token" on all subsequent requests).
 */
function run_demo_reset_if_due(PDO $db): void
{
    if (!demo_mode_enabled() || !demo_require_reset()) return;

    $marker = __DIR__ . '/data/demo_last_reset.txt';
    try {
        demo_reset_db($db);
        file_put_contents($marker, (string)time());
    } catch (Throwable $e) {
        // Log but do not re-throw — page must continue so CSRF is initialised
        error_log('Simple PHP IPAM demo reset failed: ' . $e->getMessage());
    }
}

/* ---------------- Database Backups ---------------- */

/**
 * Legacy SQLite/MySQL/PostgreSQL retention prune (#828 / B-P1-15).
 *
 * The legacy v3.7 backup runner globs filesystem dumps named
 * `ipam-YYYY-MM-DD-HHMMSS.{sqlite,sql}` and keeps the most recent N. The
 * pre-#828 implementation used `rsort()` on filenames, which only matches
 * creation order while the timestamp prefix is intact. Operator-renamed
 * files, alternate timestamp formats, or files copied in from another
 * install would silently become "oldest" by lex rule and get pruned first.
 *
 * Sort by filemtime descending so the most recent N (by actual disk
 * timestamp) are kept regardless of filename. Best-effort — files that
 * vanish between glob() and stat() simply sort to the end.
 *
 * Hard-removal of this whole legacy runner is tracked separately in
 * v3.26.0 #1059. Until then, this helper is the correct retention policy.
 */
function ipam_legacy_retention_prune_by_mtime(string $glob, int $retention): void
{
    $files = glob($glob);
    if (!is_array($files) || $files === []) return;

    // Build [path => mtime] then sort path desc by mtime.
    $stamped = [];
    foreach ($files as $f) {
        $m = @filemtime($f);
        $stamped[$f] = $m === false ? 0 : $m;
    }
    arsort($stamped, SORT_NUMERIC);
    $ordered = array_keys($stamped);

    foreach (array_slice($ordered, $retention) as $old) {
        @unlink($old); // nosemgrep: php.lang.security.unlink-use.unlink-use -- $old is a glob() result, not user input
    }
}



/**
 * Write a MySQL [client] defaults-extra-file containing the password and return
 * its absolute path. The file is created with 0600 permissions because it stores
 * the database credential at rest in a temp directory shared with other users
 * on the host (#820). Caller MUST `unlink()` the returned path on every exit
 * path — typically wrapped in try/finally around the proc_open invocation that
 * consumes `--defaults-extra-file=<path>`.
 *
 * The file's `[client]` section is consumed by mysql/mysqldump when passed as
 * the FIRST argument (must come before all other CLI args).
 */

function ipam_backup_write_mysql_defaults_file(string $pass): string
{
    $path = tempnam(sys_get_temp_dir(), 'ipam_dbcred_');
    if ($path === false) {
        throw new RuntimeException('Failed to allocate temp file for MySQL credential');
    }
    // tempnam creates with 0600 on most unixes, but tighten explicitly before
    // writing so the secret is never observable through a wider mode.
    @chmod($path, 0600);
    $contents = "[client]\npassword=" . $pass . "\n";
    if (file_put_contents($path, $contents, LOCK_EX) === false) {
        @unlink($path); // nosemgrep: php.lang.security.unlink-use.unlink-use
        throw new RuntimeException('Failed to write MySQL credential file');
    }
    @chmod($path, 0600);
    return $path;
}

/**
 * Write a Postgres pgpass-format file containing the password and return its
 * absolute path. The file is created with 0600 permissions (libpq REQUIRES
 * mode <= 0600 or it ignores the file). Caller MUST `unlink()` the returned
 * path on every exit path.
 *
 * Format is libpq's documented pgpass syntax: `host:port:database:user:password`
 * with `*` as a wildcard for everything but the password (#820). The path is
 * passed to psql/pg_dump via the `PGPASSFILE` env var, which is the documented
 * Postgres pattern for non-interactive scripts — the env var carries the path,
 * not the secret itself.
 */
function ipam_backup_write_pgpass_file(string $pass): string
{
    $path = tempnam(sys_get_temp_dir(), 'ipam_dbcred_');
    if ($path === false) {
        throw new RuntimeException('Failed to allocate temp file for Postgres credential');
    }
    @chmod($path, 0600);
    // Escape ':' and '\' inside the password per libpq's pgpass rules.
    $escaped = str_replace(['\\', ':'], ['\\\\', '\\:'], $pass);
    $contents = "*:*:*:*:" . $escaped . "\n";
    if (file_put_contents($path, $contents, LOCK_EX) === false) {
        @unlink($path); // nosemgrep: php.lang.security.unlink-use.unlink-use
        throw new RuntimeException('Failed to write Postgres credential file');
    }
    @chmod($path, 0600);
    return $path;
}

/**
 * @param list<string>            $cmd
 * @param array<string,string>    $env
 * @param string                  $errorOut Captured stderr/diagnostic on failure (v3.22.2).
 *                                          Populated even when the function returns false so
 *                                          callers can surface the cause in a backup-run row's
 *                                          `error_message` instead of leaving operators to
 *                                          grep PHP error_log.
 */
function backup_run_dump(array $cmd, array $env, string $destPath, int $timeoutSecs = 120, string &$errorOut = ''): bool
{
    $errorOut = '';
    $pipes = [];
    $bin = $cmd[0] ?? 'dump';
    // $cmd is built from admin config values only (never user input); array-form
    // proc_open bypasses the shell entirely so no injection is possible.
    //
    // PHP 8+ raises Error (not returns false) when an internal function appears
    // in disable_functions, so we catch Throwable and route both failure modes
    // through the same diagnostic surface — otherwise a hardened php.ini with
    // proc_open disabled would skip $errorOut population entirely and leave
    // operators with an empty backup_runs.error_message.
    try {
        $proc = proc_open($cmd, // nosemgrep
            [
                0 => ['pipe', 'r'],
                1 => ['file', $destPath, 'w'],
                2 => ['pipe', 'w'],
            ],
            $pipes,
            null,
            $env
        );
    } catch (Throwable $e) {
        $errorOut = 'proc_open threw ' . get_class($e) . ' starting ' . $bin . ': ' . $e->getMessage();
        error_log('backup_run_dump: ' . $errorOut);
        @unlink($destPath); // nosemgrep: php.lang.security.unlink-use.unlink-use
        return false;
    }
    if (!is_resource($proc)) {
        // Most likely cause: dump binary not on $PATH in the SAPI's restricted
        // environment. Surface the binary name so an operator looking at
        // backup_runs.error_message immediately sees "mysqldump not executable"
        // rather than an empty diagnostic.
        $errorOut = 'proc_open failed to start ' . $bin . ' (not on PATH or disabled)';
        error_log('backup_run_dump: ' . $errorOut);
        @unlink($destPath); // nosemgrep: php.lang.security.unlink-use.unlink-use
        return false;
    }

    fclose($pipes[0]);
    stream_set_blocking($pipes[2], false);

    // Poll for process completion with a hard deadline so a hung mysqldump/pg_dump
    // never blocks a web request thread indefinitely. Non-blocking stderr reads
    // prevent the process from stalling when the pipe buffer fills up.
    $stderr    = '';
    $finalExit = -1;
    $deadline  = time() + $timeoutSecs;
    while (true) {
        $chunk = fread($pipes[2], 4096);
        if ($chunk !== false && $chunk !== '') $stderr .= $chunk;
        $status = proc_get_status($proc);
        if (!$status['running']) {
            // Capture exitcode here BEFORE proc_close — on PHP builds with
            // --enable-sigchild, proc_close returns -1 unconditionally because
            // the SIGCHLD has already been reaped. proc_get_status returns the
            // real code on glibc builds and -1 on sigchild-enabled builds; we
            // treat -1 as "unreliable, fall back to file inspection".
            $finalExit = $status['exitcode'];
            break;
        }
        if (time() > $deadline) {
            proc_terminate($proc);
            fclose($pipes[2]);
            proc_close($proc);
            @unlink($destPath); // nosemgrep: php.lang.security.unlink-use.unlink-use
            $errorOut = 'killed after ' . $timeoutSecs . 's timeout';
            error_log('backup_run_dump: ' . $errorOut);
            return false;
        }
        usleep(100000); // 100ms polling interval
    }
    while (!feof($pipes[2])) {
        $chunk = fread($pipes[2], 4096);
        if ($chunk !== false && $chunk !== '') $stderr .= $chunk;
    }
    fclose($pipes[2]);
    proc_close($proc);

    // Exit-code interpretation:
    //   $finalExit > 0  → definite failure (tool reported error code).
    //   $finalExit == 0 → definite success.
    //   $finalExit == -1 → unreliable (sigchild build); use file-size as
    //                       fallback. mysqldump and pg_dump never produce
    //                       output on auth/connection failure, so a non-empty
    //                       dest file is a strong success signal.
    if ($finalExit > 0) {
        @unlink($destPath); // nosemgrep: php.lang.security.unlink-use.unlink-use
        $errorOut = 'exit=' . $finalExit . ': ' . trim($stderr);
        error_log('backup_run_dump failed (' . $errorOut . ')');
        return false;
    }
    $size = @filesize($destPath);
    if ($size === false || $size === 0) {
        @unlink($destPath); // nosemgrep: php.lang.security.unlink-use.unlink-use
        $errorOut = 'exit=' . $finalExit . ', empty output: ' . trim($stderr);
        error_log('backup_run_dump failed (' . $errorOut . ')');
        return false;
    }
    @chmod($destPath, 0600);
    return true;
}

// v3.26.0 (#1059): the legacy v3.7 backup runner and its helpers were
// removed:
//   ipam_legacy_backup_migrate_if_due()  — init-time conversion helper
//   backup_dir() / backup_state_path()    — single-directory accessors
//   backup_interval_seconds() / backup_is_due() — schedule readers
//   backup_runs_insert_cli()              — CLI-runner row inserter
//   run_db_backup_if_due()                — SQLite/MySQL/Postgres runner
//   backup_info()                         — admin-page status accessor
// Backups are now driven by ipam_backup_run_destination() (further below)
// iterating every active row in backup_destinations + backup_schedules.


// ── Backup encryption constants (Phase 2 / #694) ────────────────────────────
const BACKUP_MAGIC   = 'IPAMBKP1';  // 8-byte magic + version tag
const BACKUP_IV_LEN  = 12;          // AES-256-GCM recommended IV length (12 random
                                    // bytes per RFC 5116; #838 B-P2-46 clarifying note)
const BACKUP_TAG_LEN = 16;          // GCM authentication tag length (16 bytes,
                                    // SP 800-38D Table 1; #838 B-P2-46)
const BACKUP_MAGIC_V2     = 'IPAMBKP2';  // 8-byte streaming format magic
const BACKUP_SALT_LEN     = 16;          // HKDF salt length (v2)
const BACKUP_CTR_IV_LEN   = 16;          // AES-256-CTR initial counter block
const BACKUP_HMAC_LEN     = 32;          // HMAC-SHA256 tag length
const BACKUP_STREAM_CHUNK = 65536;       // 64 KiB; counter step = 4096 blocks per chunk

// ── v3.24.0 IPAMBKP3 / IPAMBKU1 constants (#836) ─────────────────────────────
//
// IPAMBKP3 supersedes IPAMBKP2: it derives keys from `backup_vault_key`
// (stored mode) or an operator-supplied passphrase via Argon2id (transitory
// mode), separating backup-at-rest protection from app_secret. IPAMBKU1 is
// an integrity-only wrapper for trusted-local destinations.
//
// Header layout (big-endian on multi-byte fields):
//
//   IPAMBKP3 (8) | mode (1) | argon_t (4) | argon_m_kib (4) | argon_p (1)
//                | reserved (2 zero) | argon_salt (16) | hkdf_salt (16)
//                | ctr_iv (16) | ciphertext (N) | hmac (32)
//   ── header size: 68 bytes
//
// IPAMBKU1 layout: magic (8) | sha256 (32) | plaintext (N).
//
// Argon2id defaults (OWASP 2024 minimum for password hashing): t=3, m=64 MiB,
// p=1. Header-embedded so callers can tune per install without breaking
// existing backups.
const BACKUP_MAGIC_V3       = 'IPAMBKP3';
const BACKUP_MAGIC_UNENC    = 'IPAMBKU1';
const BACKUP_V3_MODE_STORED      = 1;
const BACKUP_V3_MODE_TRANSITORY  = 2;
const BACKUP_V3_HEADER_LEN  = 68;
const BACKUP_V3_RESERVED_LEN = 2;
const BACKUP_ARGON2_SALT_LEN     = 16;
const BACKUP_ARGON2_TIME_DEFAULT       = 3;
const BACKUP_ARGON2_MEMORY_KIB_DEFAULT = 65536;  // 64 MiB
const BACKUP_ARGON2_PARALLELISM_DEFAULT = 1;
const BACKUP_VAULT_KEY_LEN = 32;

/**
 * Assert that PHP's CSPRNG is functional. Cheap, idempotent (caches first
 * success). Called from every encrypt entry point; addresses #838 B-P1-35.
 *
 * @throws RuntimeException if random_bytes is unavailable or fails.
 */
function ipam_assert_random_bytes_available(): void
{
    static $checked = false;
    if ($checked) {
        return;
    }
    if (!function_exists('random_bytes')) {
        throw new RuntimeException('random_bytes() not available; PHP build is missing CSPRNG');
    }
    try {
        $probe = random_bytes(1);
    } catch (Throwable $e) {
        throw new RuntimeException('CSPRNG probe failed: ' . $e->getMessage(), 0, $e);
    }
    if (strlen($probe) !== 1) {
        throw new RuntimeException('CSPRNG probe returned wrong length');
    }
    $checked = true;
}

/**
 * Derive an Argon2id tag from a passphrase. Used by IPAMBKP3 transitory mode
 * (#836). Wraps libsodium's `sodium_crypto_pwhash` — RFC 9106 / Argon2id v1.3.
 *
 * libsodium constraint: parallelism is fixed at 1; we assert this so the
 * header-recorded value cannot drift from the value used to compute the tag.
 *
 * @param string $passphrase   Operator-typed secret. Must be non-empty.
 * @param string $salt         Per-file random salt (BACKUP_ARGON2_SALT_LEN bytes).
 * @param int    $time         Argon2 t parameter (≥ 1).
 * @param int    $memoryKib    Argon2 m parameter in KiB (≥ 8 × parallelism).
 * @param int    $parallelism  Argon2 p parameter — must be 1 with libsodium.
 * @param int    $outLen       Output tag length in bytes (≥ 16).
 * @throws RuntimeException on any parameter violation or KDF failure.
 */
function ipam_argon2id_derive(
    string $passphrase,
    string $salt,
    int $time,
    int $memoryKib,
    int $parallelism,
    int $outLen
): string {
    if ($passphrase === '') {
        throw new RuntimeException('ipam_argon2id_derive: passphrase must be non-empty');
    }
    if (strlen($salt) !== BACKUP_ARGON2_SALT_LEN) {
        throw new RuntimeException(
            'ipam_argon2id_derive: salt must be exactly ' . BACKUP_ARGON2_SALT_LEN . ' bytes'
        );
    }
    if ($time < 1) {
        throw new RuntimeException('ipam_argon2id_derive: time must be >= 1');
    }
    if ($parallelism !== 1) {
        throw new RuntimeException(
            'ipam_argon2id_derive: parallelism must be 1 (libsodium constraint); ' .
            'tracked for future tuning when sodium exposes the parameter'
        );
    }
    if ($memoryKib < 8 * $parallelism) {
        throw new RuntimeException('ipam_argon2id_derive: memoryKib must be >= 8 * parallelism');
    }
    if ($outLen < 16) {
        throw new RuntimeException('ipam_argon2id_derive: outLen must be >= 16');
    }
    if (!function_exists('sodium_crypto_pwhash')) {
        throw new RuntimeException(
            'ipam_argon2id_derive: libsodium pwhash not available; PHP must be built with --with-sodium'
        );
    }
    try {
        $hash = sodium_crypto_pwhash(
            $outLen,
            $passphrase,
            $salt,
            $time,
            $memoryKib * 1024,
            SODIUM_CRYPTO_PWHASH_ALG_ARGON2ID13
        );
    } catch (SodiumException $e) {
        throw new RuntimeException('ipam_argon2id_derive: Argon2id derivation failed: ' . $e->getMessage(), 0, $e);
    }
    if (strlen($hash) !== $outLen) {
        throw new RuntimeException('ipam_argon2id_derive: Argon2id derivation produced unexpected length');
    }
    return $hash;
}


/**
 * Read-only accessor for the IPAMBKP3 vault key. Returns the 32 raw
 * bytes if config.php holds a well-formed value, NULL otherwise.
 *
 * Read-only accessor: never generates, never writes config.php, never
 * throws on absent / malformed values.
 * Intended for the decrypt path — autogen during a restore would mask
 * the real failure (the key that ENCRYPTED the backup is gone), and we
 * want to surface that as a clear error rather than silently produce a
 * fresh-and-useless key.
 */
function ipam_backup_vault_key_get_raw(): ?string
{
    /** @var array<string,mixed> $config */
    global $config;

    // v3.26.0 (#1098 + CR #1100): DB-resident wrapped envelope is the
    // primary store. Falls back to the legacy config field for one
    // release for downgrade safety, but ONLY when the DB read or unwrap
    // shows the envelope is genuinely absent or malformed — never on a
    // transient PDO failure or a real unwrap error. A blanket Throwable
    // catch would let a flapping settings query silently switch
    // runtime key selection back to a stale config value, producing
    // backups that stop round-tripping once the DB path recovers.
    //
    // - ipam_setting() schema-missing: caught internally and returns
    //   the registry default ('' here). We treat empty-string as
    //   "DB has no row, fall back to config" — this is the legitimate
    //   pre-migration upgrade window.
    // - ipam_setting() throwing: an unexpected condition (e.g. the
    //   helper itself isn't loaded). Treated as "no DB row" so we
    //   don't crash the decrypt path; the legacy fallback applies.
    // - ipam_vault_unwrap() returning a wrong-length plaintext: bail
    //   to legacy. The wrap function never produces a wrong length, so
    //   this would imply ciphertext truncation — surface via error_log.
    // - ipam_vault_unwrap() throwing RuntimeException with the explicit
    //   "authentication failed" message: the envelope is malformed or
    //   the bootstrap_key changed. Surface and bail to legacy (the
    //   operator may have a saved key in config.php to recover with).
    // - Any OTHER throw (PDO transient errors propagated through
    //   ipam_setting bubbling up as Throwable, sodium extension
    //   missing, etc.): rethrow so the caller surfaces a real failure
    //   instead of silently using stale config.
    $envelope = '';
    if (function_exists('ipam_setting')) {
        $envRaw = ipam_setting('backup_vault_key', '');
        $envelope = is_string($envRaw) ? $envRaw : '';
    }
    if ($envelope !== '' && function_exists('ipam_vault_unwrap') && function_exists('ipam_bootstrap_key')) {
        try {
            $raw = ipam_vault_unwrap($envelope, ipam_bootstrap_key());
        } catch (\RuntimeException $e) {
            // RuntimeException is the documented unwrap failure mode
            // (bad envelope / wrong bootstrap key / tampered cipher).
            // Surface and fall through so a saved config-side key can
            // still recover existing backups.
            error_log('backup_vault_key DB unwrap failed: ' . $e->getMessage());
            $raw = '';
        }
        if ($raw !== '' && strlen($raw) === BACKUP_VAULT_KEY_LEN) {
            if (isset($config['backup_vault_key']) && $config['backup_vault_key'] !== '') {
                error_log(
                    'backup_vault_key present in BOTH config.php and the settings table; '
                    . 'using the DB row. Remove the config.php field once you have confirmed '
                    . 'backups continue to round-trip.'
                );
            }
            return $raw;
        }
    }

    $b64 = $config['backup_vault_key'] ?? null;
    if (!is_string($b64) || $b64 === '') {
        return null;
    }
    $raw = base64_decode($b64, true);
    if (!is_string($raw) || strlen($raw) !== BACKUP_VAULT_KEY_LEN) {
        return null;
    }
    return $raw;
}

/**
 * Atomic in-place rewrite of a config.php-style PHP file to set
 * `'$key' => '$valueB64'`. Used by ipam_bootstrap_key() (lib/vault.php)
 * to seed the bootstrap key on first use, and available for any future
 * autogen scenarios.
 *
 * Behaviour:
 *   - Existing single-quoted/double-quoted line for $key → replaced.
 *   - Key absent → injected immediately before the file's last "];".
 *   - Atomic: writes adjacent tempfile, then rename(). Preserves file
 *     mode best-effort.
 *
 * Assumes $valueB64 contains only base64 characters ([A-Za-z0-9+/=]); no
 * additional escaping is performed. Refuses to operate if the value
 * contains a single quote.
 *
 * @throws RuntimeException on any I/O, parse, or atomicity failure.
 */
function ipam_config_inject_or_replace_key(string $configPath, string $key, string $valueB64): void
{
    if (!is_file($configPath)) {
        throw new RuntimeException('config file not found: ' . $configPath);
    }
    if (!is_writable($configPath)) {
        throw new RuntimeException('config file is not writable: ' . $configPath);
    }
    if (str_contains($valueB64, "'") || str_contains($valueB64, "\n") || str_contains($valueB64, "\r")) {
        throw new RuntimeException('refusing to inject value containing quotes or newlines');
    }
    $contents = @file_get_contents($configPath);
    if ($contents === false) {
        throw new RuntimeException('failed to read config file');
    }

    // Match a single-line scalar string literal for $key in either quoting
    // style, anchored to the start of a line (with optional leading
    // whitespace) so commented-out config lines like
    //   //  'backup_vault_key' => '',
    // do NOT match. The line-anchor relies on the first non-whitespace
    // character being a quote; comment prefixes (//, #, *) start with a
    // non-quote character and are naturally rejected. Restricted to no
    // embedded quotes or newlines — sufficient for base64 values which
    // use only [A-Za-z0-9+/=].
    $pattern = sprintf(
        '/^[ \t]*([\'"])%s\1\s*=>\s*([\'"])[A-Za-z0-9+\/=]*\2/m',
        preg_quote($key, '/')
    );
    $replacement = sprintf("'%s' => '%s'", $key, $valueB64);

    $count = 0;
    if (preg_match($pattern, $contents) === 1) {
        $new = preg_replace($pattern, $replacement, $contents, 1, $count);
        if ($new === null || $count !== 1) {
            throw new RuntimeException('regex replacement failed for key: ' . $key);
        }
    } else {
        // Inject just before the LAST occurrence of "];" — the close of the
        // top-level return array. Search RTL so a nested array close cannot
        // win. Newline before injection keeps formatting parseable.
        $lastClosePos = strrpos($contents, '];');
        if ($lastClosePos === false) {
            throw new RuntimeException('config file has no closing "];" — refusing to inject');
        }
        $injection = "    '" . $key . "' => '" . $valueB64 . "',\n";
        $new = substr($contents, 0, $lastClosePos) . $injection . substr($contents, $lastClosePos);
    }

    // Atomic write: tempfile in the same directory + rename().
    $dir = dirname($configPath);
    $tmp = @tempnam($dir, '.config.tmp.');
    if ($tmp === false) {
        throw new RuntimeException('cannot create tempfile next to config file');
    }
    try {
        $written = @file_put_contents($tmp, $new);
        if ($written !== strlen($new)) {
            throw new RuntimeException('short write to tempfile');
        }
        $perms = @fileperms($configPath);
        if ($perms !== false) {
            @chmod($tmp, $perms & 0777);
        }
        if (!@rename($tmp, $configPath)) {
            throw new RuntimeException('rename of tempfile to config file failed');
        }
        $tmp = null; // ownership transferred
    } finally {
        if ($tmp !== null && is_file($tmp)) {
            @unlink($tmp); // nosemgrep: php.lang.security.unlink-use.unlink-use -- $tmp from tempnam(), no user input
        }
    }

    // Best-effort: invalidate opcache so the next require sees the new value.
    if (function_exists('opcache_invalidate')) {
        @opcache_invalidate($configPath, true);
    }
}

/**
 * Derive a fixed-length key from a master secret using HKDF-SHA-256.
 *
 * Thin wrapper around PHP's native hash_hkdf() (PHP 7.1.2+). Keeping this as
 * a named function makes call-sites self-documenting and lets tests verify the
 * RFC 5869 Test Case 1 vector directly. The $salt parameter is optional and
 * defaults to the all-zeros salt that HKDF specifies when salt is omitted.
 *
 * @param string $ikm    Input keying material (e.g. $config['app_secret'])
 * @param string $info   Context string distinguishing key purposes
 * @param int    $length Output length in bytes (1–255 × hash-length for SHA-256)
 * @param string $salt   Optional salt; pass '' to use HKDF's default zero-salt
 */
function ipam_hkdf_sha256(string $ikm, string $info, int $length, string $salt = ''): string
{
    if ($length <= 0) {
        throw new RuntimeException('ipam_hkdf_sha256: length must be positive');
    }
    return hash_hkdf('sha256', $ikm, $length, $info, $salt);
}

/**
 * Encrypt a backup payload with AES-256-GCM.
 *
 * The output format is:
 *   BACKUP_MAGIC (8 bytes) | IV (12 bytes) | GCM tag (16 bytes) | ciphertext
 *
 * The AES key is derived from $appSecret via HKDF-SHA-256 with a fixed
 * purpose string, so a compromise of the ciphertext alone does not expose
 * $appSecret or any other derived key.
 *
 * @throws RuntimeException on openssl failure (should never happen on a
 *         supported PHP build, but we must not silently return bad data)
 */
function backup_encrypt(string $plain, string $appSecret): string
{
    ipam_assert_random_bytes_available(); // #838 B-P1-35
    if ($appSecret === '') {
        throw new RuntimeException('backup encryption requires app_secret to be set in config.php');
    }
    $key = ipam_hkdf_sha256($appSecret, 'ipam-v3:backup', 32);
    // IPAMBKP1 random-IV note (#838 B-P2-5): GCM with a 96-bit random IV is
    // safe for the small message counts a single IPAM install produces with
    // one app_secret-derived key (NIST SP 800-38D allows ~2^32 messages
    // before the birthday bound becomes non-negligible). Operators with
    // legacy IPAMBKP1 archives are advised in docs/upgrading.md to
    // re-encrypt as IPAMBKP3 over time, but no immediate action is needed.
    $iv  = random_bytes(BACKUP_IV_LEN);
    $tag = '';
    $ct  = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, '', BACKUP_TAG_LEN);
    if ($ct === false) {
        throw new RuntimeException('backup encryption failed');
    }
    return BACKUP_MAGIC . $iv . $tag . $ct;
}

/**
 * Stream-encrypt $srcPath into $dstPath using the v2 (IPAMBKP2) format:
 * AES-256-CTR + HMAC-SHA256 in encrypt-then-MAC mode.
 *
 * Memory bound is BACKUP_STREAM_CHUNK + bookkeeping, regardless of input size.
 *
 * @throws RuntimeException on I/O, openssl, or appSecret failure.
 */
function backup_encrypt_stream(string $srcPath, string $dstPath, string $appSecret): void
{
    ipam_assert_random_bytes_available(); // #838 B-P1-35
    if ($appSecret === '') {
        throw new RuntimeException('backup encryption requires app_secret to be set in config.php');
    }
    $salt = random_bytes(BACKUP_SALT_LEN);
    $iv   = random_bytes(BACKUP_CTR_IV_LEN);
    // Per-file salt is passed via HKDF's salt parameter (used in HKDF-Extract)
    // for proper RFC 5869 strengthening. The fixed 'ipam-v3:backup-v2' goes in
    // info for domain separation across purposes.
    $keys = ipam_hkdf_sha256($appSecret, 'ipam-v3:backup-v2', 64, $salt);
    $encKey = substr($keys, 0, 32);
    $macKey = substr($keys, 32, 32);

    $in = @fopen($srcPath, 'rb');
    if ($in === false) {
        throw new RuntimeException('backup_encrypt_stream: cannot open source');
    }
    $out = @fopen($dstPath, 'wb');
    if ($out === false) {
        fclose($in);
        throw new RuntimeException('backup_encrypt_stream: cannot open dest');
    }

    try {
        $header = BACKUP_MAGIC_V2 . $salt . $iv;
        if (fwrite($out, $header) !== strlen($header)) {
            throw new RuntimeException('backup_encrypt_stream: short write on header');
        }
        $hmacCtx = hash_init('sha256', HASH_HMAC, $macKey);
        hash_update($hmacCtx, $header);

        $counter = $iv;
        while (!feof($in)) {
            $chunk = fread($in, BACKUP_STREAM_CHUNK);
            if ($chunk === false) {
                throw new RuntimeException('backup_encrypt_stream: read failed');
            }
            if ($chunk === '') {
                continue;
            }
            $ct = openssl_encrypt($chunk, 'aes-256-ctr', $encKey, OPENSSL_RAW_DATA, $counter);
            if ($ct === false) {
                throw new RuntimeException('backup_encrypt_stream: openssl_encrypt failed');
            }
            if (fwrite($out, $ct) !== strlen($ct)) {
                throw new RuntimeException('backup_encrypt_stream: short write on ciphertext');
            }
            hash_update($hmacCtx, $ct);
            $counter = ipam_backup_advance_ctr($counter, intdiv(strlen($chunk) + 15, 16));
        }

        $tag = hash_final($hmacCtx, true);
        if (fwrite($out, $tag) !== BACKUP_HMAC_LEN) {
            throw new RuntimeException('backup_encrypt_stream: short write on hmac');
        }
    } finally {
        fclose($in);
        fclose($out);
    }
}

/**
 * Stream-decrypt $srcPath (v2 IPAMBKP2 format) into $dstPath.
 *
 * Single-pass: decrypts each ciphertext chunk into a temporary file in the
 * same directory as $dstPath while accumulating an HMAC-SHA256 over the
 * exact bytes that were just decrypted (encrypt-then-MAC verification of
 * the same buffer). The temp file is atomically renamed to $dstPath only
 * after the trailing HMAC tag matches; on any failure path the temp is
 * unlinked, so a failed verification leaves no plaintext file behind at
 * $dstPath. Avoids the TOCTOU window of a two-pass design where the
 * source file could change between verify and decrypt.
 *
 * @throws RuntimeException on bad magic, truncation, openssl failure, or HMAC mismatch.
 */
function backup_decrypt_stream(string $srcPath, string $dstPath, string $appSecret): void
{
    if ($appSecret === '') {
        throw new RuntimeException('backup decryption requires app_secret to be set in config.php');
    }
    $size = @filesize($srcPath);
    if ($size === false) {
        throw new RuntimeException('backup_decrypt_stream: cannot stat source');
    }
    $headerLen = strlen(BACKUP_MAGIC_V2) + BACKUP_SALT_LEN + BACKUP_CTR_IV_LEN;
    $minLen = $headerLen + BACKUP_HMAC_LEN;
    if ($size < $minLen) {
        throw new RuntimeException('backup_decrypt_stream: file too short');
    }
    $ctLen = $size - $minLen;

    $in = @fopen($srcPath, 'rb');
    if ($in === false) {
        throw new RuntimeException('backup_decrypt_stream: cannot open source');
    }

    $tmpPath = $dstPath . '.decrypting.' . bin2hex(random_bytes(4));
    $out = null;
    try {
        $header = (string) fread($in, $headerLen);
        if (strlen($header) !== $headerLen) {
            throw new RuntimeException('backup_decrypt_stream: short header read');
        }
        if (substr($header, 0, 8) !== BACKUP_MAGIC_V2) {
            throw new RuntimeException('backup_decrypt_stream: bad magic');
        }
        $salt = substr($header, 8, BACKUP_SALT_LEN);
        $iv   = substr($header, 8 + BACKUP_SALT_LEN, BACKUP_CTR_IV_LEN);

        // Per-file salt is passed via HKDF's salt parameter (HKDF-Extract).
        $keys = ipam_hkdf_sha256($appSecret, 'ipam-v3:backup-v2', 64, $salt);
        $encKey = substr($keys, 0, 32);
        $macKey = substr($keys, 32, 32);

        $out = @fopen($tmpPath, 'wb');
        if ($out === false) {
            throw new RuntimeException('backup_decrypt_stream: cannot open tmp dst');
        }

        // Single-pass decrypt + HMAC over the exact bytes processed.
        $hmacCtx = hash_init('sha256', HASH_HMAC, $macKey);
        hash_update($hmacCtx, $header);
        $counter = $iv;
        $remaining = $ctLen;
        while ($remaining > 0) {
            $want = (int) min(BACKUP_STREAM_CHUNK, $remaining);
            $buf = fread($in, $want);
            if ($buf === false || strlen($buf) !== $want) {
                throw new RuntimeException('backup_decrypt_stream: short ciphertext read');
            }
            hash_update($hmacCtx, $buf);
            $pt = openssl_decrypt($buf, 'aes-256-ctr', $encKey, OPENSSL_RAW_DATA, $counter);
            if ($pt === false) {
                throw new RuntimeException('backup_decrypt_stream: openssl_decrypt failed');
            }
            if (fwrite($out, $pt) !== strlen($pt)) {
                throw new RuntimeException('backup_decrypt_stream: short write to tmp');
            }
            $counter = ipam_backup_advance_ctr($counter, intdiv(strlen($buf) + 15, 16));
            $remaining -= $want;
        }
        $observed = (string) fread($in, BACKUP_HMAC_LEN);
        if (strlen($observed) !== BACKUP_HMAC_LEN) {
            throw new RuntimeException('backup_decrypt_stream: short hmac read');
        }
        $expected = hash_final($hmacCtx, true);
        if (!hash_equals($expected, $observed)) {
            throw new RuntimeException('backup_decrypt_stream: hmac mismatch');
        }

        // HMAC verified — close out, atomically rename tmp into place.
        fclose($out);
        $out = null;
        if (!@rename($tmpPath, $dstPath)) {
            throw new RuntimeException('backup_decrypt_stream: rename to dst failed');
        }
    } catch (Throwable $e) {
        if (is_resource($out)) {
            fclose($out);
        }
        if (is_file($tmpPath)) {
            @unlink($tmpPath); // nosemgrep: php.lang.security.unlink-use.unlink-use -- $tmpPath built from $dstPath + random suffix; no user input
        }
        throw $e;
    } finally {
        fclose($in);
    }
}

// ── IPAMBKP3 (v3.24.0) — three-mode streaming codec ─────────────────────────
//
// Header packing/unpacking helpers. The wire format is:
//
//   offset  size  field
//        0     8  magic ('IPAMBKP3')
//        8     1  mode (1=STORED, 2=TRANSITORY)
//        9     4  argon_time         (BE uint32)
//       13     4  argon_memory_kib   (BE uint32)
//       17     1  argon_parallelism  (uint8)
//       18     2  reserved (zero)
//       20    16  argon_salt
//       36    16  hkdf_salt
//       52    16  ctr_iv
//   total: 68 bytes — see BACKUP_V3_HEADER_LEN.
//
// Argon parameters are header-embedded so an install can tune memory/time
// later without breaking already-encrypted backups. Bounds checks below
// keep the parameter space sane and the verify cost bounded.

const BACKUP_V3_ARGON_TIME_MAX     = 16;
const BACKUP_V3_ARGON_MEM_KIB_MAX  = 1048576; // 1 GiB
const BACKUP_V3_INFO_STORED        = 'ipam-backup-v3:stored:enc-mac';
const BACKUP_V3_INFO_TRANSITORY    = 'ipam-backup-v3:transitory:enc-mac';

function ipam_backup_v3_pack_header(
    int $mode,
    int $argonTime,
    int $argonMemKib,
    int $argonPar,
    string $argonSalt,
    string $hkdfSalt,
    string $ctrIv
): string {
    if (strlen($argonSalt) !== BACKUP_ARGON2_SALT_LEN
        || strlen($hkdfSalt) !== BACKUP_SALT_LEN
        || strlen($ctrIv) !== BACKUP_CTR_IV_LEN) {
        throw new RuntimeException('ipam_backup_v3_pack_header: salt/iv lengths invalid');
    }
    $hdr = BACKUP_MAGIC_V3
         . chr($mode)
         . pack('N', $argonTime)
         . pack('N', $argonMemKib)
         . chr($argonPar)
         . str_repeat("\x00", BACKUP_V3_RESERVED_LEN)
         . $argonSalt
         . $hkdfSalt
         . $ctrIv;
    if (strlen($hdr) !== BACKUP_V3_HEADER_LEN) {
        throw new RuntimeException('ipam_backup_v3_pack_header: assembled wrong length');
    }
    return $hdr;
}

/**
 * @return array{mode:int,argon_time:int,argon_mem_kib:int,argon_par:int,argon_salt:string,hkdf_salt:string,ctr_iv:string}
 */
function ipam_backup_v3_unpack_header(string $hdr): array
{
    if (strlen($hdr) !== BACKUP_V3_HEADER_LEN) {
        throw new RuntimeException('IPAMBKP3 header: wrong length');
    }
    if (substr($hdr, 0, 8) !== BACKUP_MAGIC_V3) {
        throw new RuntimeException('IPAMBKP3 header: bad magic');
    }
    /** @var array{1:int} $tu */
    $tu = unpack('N', substr($hdr, 9, 4));
    /** @var array{1:int} $mu */
    $mu = unpack('N', substr($hdr, 13, 4));
    return [
        'mode'          => ord($hdr[8]),
        'argon_time'    => $tu[1],
        'argon_mem_kib' => $mu[1],
        'argon_par'     => ord($hdr[17]),
        'argon_salt'    => substr($hdr, 20, BACKUP_ARGON2_SALT_LEN),
        'hkdf_salt'     => substr($hdr, 36, BACKUP_SALT_LEN),
        'ctr_iv'        => substr($hdr, 52, BACKUP_CTR_IV_LEN),
    ];
}

/**
 * Stream-encrypt $srcPath into $dstPath using the IPAMBKP3 format.
 *
 * Modes:
 *   STORED      — server-side `backup_vault_key` (32 raw bytes).
 *                 Passphrase ignored; argon_salt zero-filled.
 *   TRANSITORY  — operator passphrase; Argon2id derives the kdf input.
 *                 vaultKey ignored.
 *
 * Argon2id parameters fall back to BACKUP_ARGON2_*_DEFAULT when null.
 * Bounded by BACKUP_V3_ARGON_TIME_MAX / BACKUP_V3_ARGON_MEM_KIB_MAX.
 *
 * Memory-bounded streaming (BACKUP_STREAM_CHUNK + bookkeeping). HMAC-SHA256
 * is computed over (header || ciphertext) in encrypt-then-MAC order.
 *
 * @throws RuntimeException on bad parameters, I/O, openssl, or KDF failure.
 */
function backup_encrypt_stream_v3(
    string $srcPath,
    string $dstPath,
    int $mode,
    ?string $passphrase,
    ?string $vaultKey,
    ?int $argonTime = null,
    ?int $argonMemKib = null,
    ?int $argonParallelism = null
): void {
    ipam_assert_random_bytes_available();

    if ($mode !== BACKUP_V3_MODE_STORED && $mode !== BACKUP_V3_MODE_TRANSITORY) {
        throw new RuntimeException('backup_encrypt_stream_v3: invalid mode');
    }

    $aTime  = $argonTime        ?? BACKUP_ARGON2_TIME_DEFAULT;
    $aMem   = $argonMemKib      ?? BACKUP_ARGON2_MEMORY_KIB_DEFAULT;
    $aPar   = $argonParallelism ?? BACKUP_ARGON2_PARALLELISM_DEFAULT;
    if ($aTime < 1 || $aTime > BACKUP_V3_ARGON_TIME_MAX) {
        throw new RuntimeException('backup_encrypt_stream_v3: argon time out of bounds');
    }
    if ($aMem < 8 || $aMem > BACKUP_V3_ARGON_MEM_KIB_MAX) {
        throw new RuntimeException('backup_encrypt_stream_v3: argon memory out of bounds');
    }
    // Mirror the decrypt-time constraint: parallelism is fixed at 1 by the
    // libsodium pwhash API (see ipam_argon2id_derive). Reject anything
    // else here so a caller cannot produce an archive whose header records
    // a parallelism the decrypt path will refuse, leaving the archive
    // undecryptable. This is the same check the decrypt path enforces.
    if ($aPar !== 1) {
        throw new RuntimeException('backup_encrypt_stream_v3: argon parallelism must be 1 (libsodium constraint)');
    }

    if ($mode === BACKUP_V3_MODE_TRANSITORY) {
        if ($passphrase === null || $passphrase === '') {
            throw new RuntimeException('backup_encrypt_stream_v3: transitory mode requires passphrase');
        }
        $argonSalt = random_bytes(BACKUP_ARGON2_SALT_LEN);
        $kdfInput  = ipam_argon2id_derive($passphrase, $argonSalt, $aTime, $aMem, $aPar, 32);
        $info      = BACKUP_V3_INFO_TRANSITORY;
    } else {
        if ($vaultKey === null || strlen($vaultKey) !== BACKUP_VAULT_KEY_LEN) {
            throw new RuntimeException(
                'backup_encrypt_stream_v3: stored mode requires ' . BACKUP_VAULT_KEY_LEN . '-byte vaultKey'
            );
        }
        // Stored mode does not run Argon2id — argon_salt is zero-filled in
        // the header but the parameter fields still record the install's
        // current defaults so decryption can reuse them if the mode flag is
        // ever flipped during an upgrade migration.
        $argonSalt = str_repeat("\x00", BACKUP_ARGON2_SALT_LEN);
        $kdfInput  = $vaultKey;
        $info      = BACKUP_V3_INFO_STORED;
    }

    $hkdfSalt = random_bytes(BACKUP_SALT_LEN);
    $ctrIv    = random_bytes(BACKUP_CTR_IV_LEN);
    $keys     = ipam_hkdf_sha256($kdfInput, $info, 64, $hkdfSalt);
    $encKey   = substr($keys, 0, 32);
    $macKey   = substr($keys, 32, 32);

    $header = ipam_backup_v3_pack_header($mode, $aTime, $aMem, $aPar, $argonSalt, $hkdfSalt, $ctrIv);

    $in = @fopen($srcPath, 'rb');
    if ($in === false) {
        throw new RuntimeException('backup_encrypt_stream_v3: cannot open source');
    }
    $out = @fopen($dstPath, 'wb');
    if ($out === false) {
        fclose($in);
        throw new RuntimeException('backup_encrypt_stream_v3: cannot open dest');
    }

    try {
        if (fwrite($out, $header) !== strlen($header)) {
            throw new RuntimeException('backup_encrypt_stream_v3: short write on header');
        }
        $hmacCtx = hash_init('sha256', HASH_HMAC, $macKey);
        hash_update($hmacCtx, $header);

        $counter = $ctrIv;
        while (!feof($in)) {
            $chunk = fread($in, BACKUP_STREAM_CHUNK);
            if ($chunk === false) {
                throw new RuntimeException('backup_encrypt_stream_v3: read failed');
            }
            if ($chunk === '') {
                continue;
            }
            $ct = openssl_encrypt($chunk, 'aes-256-ctr', $encKey, OPENSSL_RAW_DATA, $counter);
            if ($ct === false) {
                throw new RuntimeException('backup_encrypt_stream_v3: openssl_encrypt failed');
            }
            if (fwrite($out, $ct) !== strlen($ct)) {
                throw new RuntimeException('backup_encrypt_stream_v3: short write on ciphertext');
            }
            hash_update($hmacCtx, $ct);
            $counter = ipam_backup_advance_ctr($counter, intdiv(strlen($chunk) + 15, 16));
        }

        $tag = hash_final($hmacCtx, true);
        if (fwrite($out, $tag) !== BACKUP_HMAC_LEN) {
            throw new RuntimeException('backup_encrypt_stream_v3: short write on hmac');
        }
    } finally {
        fclose($in);
        fclose($out);
    }
}

/**
 * Stream-decrypt an IPAMBKP3 file at $srcPath into $dstPath.
 *
 * Re-derives keys from header-embedded params + salts. Verifies HMAC
 * before atomically renaming the tempfile to $dstPath, so a failed
 * verification leaves no plaintext on disk.
 *
 * Constant-time HMAC compare per #838 B-P1-40: a verify-key wrap means
 * the success/fail paths each run a fixed number of HMACs.
 *
 * @throws RuntimeException on bad magic, truncation, openssl failure,
 *         missing key/passphrase, or HMAC mismatch.
 */
function backup_decrypt_stream_v3(
    string $srcPath,
    string $dstPath,
    ?string $passphrase,
    ?string $vaultKey
): void {
    ipam_assert_random_bytes_available();

    $size = @filesize($srcPath);
    if ($size === false) {
        throw new RuntimeException('backup_decrypt_stream_v3: cannot stat source');
    }
    $minLen = BACKUP_V3_HEADER_LEN + BACKUP_HMAC_LEN;
    if ($size < $minLen) {
        throw new RuntimeException('backup_decrypt_stream_v3: file too short');
    }
    $ctLen = $size - $minLen;

    $in = @fopen($srcPath, 'rb');
    if ($in === false) {
        throw new RuntimeException('backup_decrypt_stream_v3: cannot open source');
    }

    $tmpPath = $dstPath . '.decrypting.' . bin2hex(random_bytes(4));
    $out = null;
    try {
        $hdrRaw = (string) fread($in, BACKUP_V3_HEADER_LEN);
        if (strlen($hdrRaw) !== BACKUP_V3_HEADER_LEN) {
            throw new RuntimeException('backup_decrypt_stream_v3: short header read');
        }
        $hdr = ipam_backup_v3_unpack_header($hdrRaw);

        $mode = $hdr['mode'];
        if ($mode !== BACKUP_V3_MODE_STORED && $mode !== BACKUP_V3_MODE_TRANSITORY) {
            throw new RuntimeException('backup_decrypt_stream_v3: unknown mode');
        }
        if ($hdr['argon_time'] < 1 || $hdr['argon_time'] > BACKUP_V3_ARGON_TIME_MAX) {
            throw new RuntimeException('backup_decrypt_stream_v3: argon time out of bounds');
        }
        if ($hdr['argon_mem_kib'] < 8 || $hdr['argon_mem_kib'] > BACKUP_V3_ARGON_MEM_KIB_MAX) {
            throw new RuntimeException('backup_decrypt_stream_v3: argon memory out of bounds');
        }
        if ($hdr['argon_par'] !== 1) {
            throw new RuntimeException('backup_decrypt_stream_v3: argon parallelism != 1');
        }

        if ($mode === BACKUP_V3_MODE_TRANSITORY) {
            if ($passphrase === null || $passphrase === '') {
                throw new RuntimeException('backup_decrypt_stream_v3: transitory mode requires passphrase');
            }
            $kdfInput = ipam_argon2id_derive(
                $passphrase,
                $hdr['argon_salt'],
                $hdr['argon_time'],
                $hdr['argon_mem_kib'],
                $hdr['argon_par'],
                32
            );
            $info = BACKUP_V3_INFO_TRANSITORY;
        } else {
            if ($vaultKey === null || strlen($vaultKey) !== BACKUP_VAULT_KEY_LEN) {
                throw new RuntimeException(
                    'backup_decrypt_stream_v3: stored mode requires ' . BACKUP_VAULT_KEY_LEN . '-byte vaultKey'
                );
            }
            $kdfInput = $vaultKey;
            $info     = BACKUP_V3_INFO_STORED;
        }

        $keys   = ipam_hkdf_sha256($kdfInput, $info, 64, $hdr['hkdf_salt']);
        $encKey = substr($keys, 0, 32);
        $macKey = substr($keys, 32, 32);

        $out = @fopen($tmpPath, 'wb');
        if ($out === false) {
            throw new RuntimeException('backup_decrypt_stream_v3: cannot open tmp dst');
        }

        $hmacCtx = hash_init('sha256', HASH_HMAC, $macKey);
        hash_update($hmacCtx, $hdrRaw);
        $counter   = $hdr['ctr_iv'];
        $remaining = $ctLen;
        while ($remaining > 0) {
            $want = (int) min(BACKUP_STREAM_CHUNK, $remaining);
            $buf  = fread($in, $want);
            if ($buf === false || strlen($buf) !== $want) {
                throw new RuntimeException('backup_decrypt_stream_v3: short ciphertext read');
            }
            hash_update($hmacCtx, $buf);
            $pt = openssl_decrypt($buf, 'aes-256-ctr', $encKey, OPENSSL_RAW_DATA, $counter);
            if ($pt === false) {
                throw new RuntimeException('backup_decrypt_stream_v3: openssl_decrypt failed');
            }
            if (fwrite($out, $pt) !== strlen($pt)) {
                throw new RuntimeException('backup_decrypt_stream_v3: short write to tmp');
            }
            $counter    = ipam_backup_advance_ctr($counter, intdiv(strlen($buf) + 15, 16));
            $remaining -= $want;
        }
        $observed = (string) fread($in, BACKUP_HMAC_LEN);
        if (strlen($observed) !== BACKUP_HMAC_LEN) {
            throw new RuntimeException('backup_decrypt_stream_v3: short hmac read');
        }
        $expected = hash_final($hmacCtx, true);

        // #838 B-P1-40: double-HMAC compare so success/failure paths run the
        // same operations. The verify key is derived from macKey via a fixed
        // sub-purpose so it cannot be swapped for a different signing key.
        $verifyKey = ipam_hkdf_sha256($macKey, 'ipam-backup-v3:verify', 32);
        $expectedTag = hash_hmac('sha256', $expected, $verifyKey, true);
        $observedTag = hash_hmac('sha256', $observed, $verifyKey, true);
        if (!hash_equals($expectedTag, $observedTag)) {
            throw new RuntimeException('backup_decrypt_stream_v3: hmac mismatch');
        }

        fclose($out);
        $out = null;
        if (!@rename($tmpPath, $dstPath)) {
            throw new RuntimeException('backup_decrypt_stream_v3: rename to dst failed');
        }
    } catch (Throwable $e) {
        if (is_resource($out)) {
            fclose($out);
        }
        if (is_file($tmpPath)) {
            @unlink($tmpPath); // nosemgrep: php.lang.security.unlink-use.unlink-use -- $tmpPath built from $dstPath + random suffix
        }
        throw $e;
    } finally {
        fclose($in);
    }
}

// ── IPAMBKU1 (v3.24.0) — integrity-only framing for trusted-local backups ────
//
// Wire format: magic(8 'IPAMBKU1') | sha256(32) | plaintext(N).
// No confidentiality — used only when the operator opts out of encryption
// for a destination they trust (e.g. full-disk-encrypted local volume).
// The SHA-256 catches accidental corruption / disk bit-rot.

const BACKUP_UNENC_HEADER_LEN = 8 + 32; // magic + sha256

/**
 * Stream-wrap a plaintext file with the IPAMBKU1 framing.
 *
 * The SHA-256 is computed incrementally during write so memory stays
 * bounded regardless of input size.
 *
 * @throws RuntimeException on I/O failure.
 */
function backup_unencrypted_wrap_stream(string $srcPath, string $dstPath): void
{
    $in = @fopen($srcPath, 'rb');
    if ($in === false) {
        throw new RuntimeException('backup_unencrypted_wrap_stream: cannot open source');
    }
    $out = @fopen($dstPath, 'wb');
    if ($out === false) {
        fclose($in);
        throw new RuntimeException('backup_unencrypted_wrap_stream: cannot open dest');
    }
    try {
        // Reserve space for the 32-byte SHA-256 by writing zero bytes; we
        // patch this region after the body is fully streamed and hashed.
        $headerStub = BACKUP_MAGIC_UNENC . str_repeat("\x00", 32);
        if (fwrite($out, $headerStub) !== BACKUP_UNENC_HEADER_LEN) {
            throw new RuntimeException('backup_unencrypted_wrap_stream: short write on header');
        }
        $hashCtx = hash_init('sha256');
        while (!feof($in)) {
            $chunk = fread($in, BACKUP_STREAM_CHUNK);
            if ($chunk === false) {
                throw new RuntimeException('backup_unencrypted_wrap_stream: read failed');
            }
            if ($chunk === '') {
                continue;
            }
            hash_update($hashCtx, $chunk);
            if (fwrite($out, $chunk) !== strlen($chunk)) {
                throw new RuntimeException('backup_unencrypted_wrap_stream: short write on body');
            }
        }
        $digest = hash_final($hashCtx, true);
        if (strlen($digest) !== 32) {
            throw new RuntimeException('backup_unencrypted_wrap_stream: digest wrong length');
        }
        // Seek back and patch the digest region.
        if (fseek($out, 8) !== 0) {
            throw new RuntimeException('backup_unencrypted_wrap_stream: seek to digest failed');
        }
        if (fwrite($out, $digest) !== 32) {
            throw new RuntimeException('backup_unencrypted_wrap_stream: short write on digest');
        }
    } finally {
        fclose($in);
        fclose($out);
    }
}

/**
 * Stream-unwrap an IPAMBKU1 file. Verifies the SHA-256 over the body
 * before atomically renaming the tempfile to $dstPath.
 *
 * @throws RuntimeException on bad magic, truncation, I/O failure, or
 *         hash mismatch.
 */
function backup_unencrypted_unwrap_stream(string $srcPath, string $dstPath): void
{
    ipam_assert_random_bytes_available();

    $size = @filesize($srcPath);
    if ($size === false) {
        throw new RuntimeException('backup_unencrypted_unwrap_stream: cannot stat source');
    }
    if ($size < BACKUP_UNENC_HEADER_LEN) {
        throw new RuntimeException('backup_unencrypted_unwrap_stream: file too short');
    }

    $in = @fopen($srcPath, 'rb');
    if ($in === false) {
        throw new RuntimeException('backup_unencrypted_unwrap_stream: cannot open source');
    }

    $tmpPath = $dstPath . '.unwrapping.' . bin2hex(random_bytes(4));
    $out = null;
    try {
        $hdr = (string) fread($in, BACKUP_UNENC_HEADER_LEN);
        if (strlen($hdr) !== BACKUP_UNENC_HEADER_LEN) {
            throw new RuntimeException('backup_unencrypted_unwrap_stream: short header read');
        }
        if (substr($hdr, 0, 8) !== BACKUP_MAGIC_UNENC) {
            throw new RuntimeException('backup_unencrypted_unwrap_stream: bad magic');
        }
        $expected = substr($hdr, 8, 32);

        $out = @fopen($tmpPath, 'wb');
        if ($out === false) {
            throw new RuntimeException('backup_unencrypted_unwrap_stream: cannot open tmp dst');
        }
        $hashCtx = hash_init('sha256');
        $remaining = $size - BACKUP_UNENC_HEADER_LEN;
        while ($remaining > 0) {
            $want = (int) min(BACKUP_STREAM_CHUNK, $remaining);
            $buf  = fread($in, $want);
            if ($buf === false || strlen($buf) !== $want) {
                throw new RuntimeException('backup_unencrypted_unwrap_stream: short body read');
            }
            hash_update($hashCtx, $buf);
            if (fwrite($out, $buf) !== strlen($buf)) {
                throw new RuntimeException('backup_unencrypted_unwrap_stream: short write to tmp');
            }
            $remaining -= $want;
        }
        $observed = hash_final($hashCtx, true);
        if (!hash_equals($expected, $observed)) {
            throw new RuntimeException('backup_unencrypted_unwrap_stream: sha256 mismatch');
        }

        fclose($out);
        $out = null;
        if (!@rename($tmpPath, $dstPath)) {
            throw new RuntimeException('backup_unencrypted_unwrap_stream: rename to dst failed');
        }
    } catch (Throwable $e) {
        if (is_resource($out)) {
            fclose($out);
        }
        if (is_file($tmpPath)) {
            @unlink($tmpPath); // nosemgrep: php.lang.security.unlink-use.unlink-use -- $tmpPath built from $dstPath + random suffix
        }
        throw $e;
    } finally {
        fclose($in);
    }
}

/**
 * Raised by backup_decrypt_to_path() when it recognises an IPAMBKP3 archive
 * but the caller did not supply the credential needed to decrypt it. The
 * `mode` property tells the caller which prompt to render (passphrase for
 * transitory mode, vault-key load for stored mode).
 */
class IpamBackupKeyRequiredException extends RuntimeException
{
    /** @var int BACKUP_V3_MODE_STORED or BACKUP_V3_MODE_TRANSITORY */
    public int $mode;

    public function __construct(int $mode, string $message)
    {
        parent::__construct($message);
        $this->mode = $mode;
    }
}

/**
 * Format-detecting decrypt-to-path. Peeks the 8-byte magic header and
 * dispatches to the matching codec.
 *
 *   IPAMBKP3 → backup_decrypt_stream_v3() (v3.24+; stored or transitory).
 *   IPAMBKU1 → backup_unencrypted_unwrap_stream() (v3.24+; integrity only).
 *   IPAMBKP2 → backup_decrypt_stream()    (v3.19+ streaming, app_secret HKDF).
 *   IPAMBKP1 → backup_decrypt()           (v3.17–v3.18, full-file GCM, legacy).
 *
 * Optional credentials are mode-specific:
 *   - $passphrase  — required for IPAMBKP3 transitory mode; ignored otherwise.
 *   - $vaultKey    — 32 raw bytes; required for IPAMBKP3 stored mode; ignored otherwise.
 *   - $appSecret   — required for IPAMBKP1 / IPAMBKP2 legacy formats; ignored
 *                    for v3 / unencrypted.
 *
 * Missing credentials throw IpamBackupKeyRequiredException so the caller can
 * render a credential prompt without parsing exception text.
 *
 * @throws IpamBackupKeyRequiredException when the archive needs a
 *         credential the caller did not provide.
 * @throws RuntimeException on unknown magic, I/O failure, or codec errors.
 */
function backup_decrypt_to_path(
    string $srcPath,
    string $dstPath,
    string $appSecret,
    ?string $passphrase = null,
    ?string $vaultKey = null
): void {
    $fh = @fopen($srcPath, 'rb');
    if ($fh === false) {
        throw new RuntimeException('backup_decrypt_to_path: cannot open source');
    }
    $magic = (string) fread($fh, 8);
    // For IPAMBKP3 we also need the mode byte at offset 8 to decide which
    // credential is required before delegating.
    $modeByte = (string) fread($fh, 1);
    fclose($fh);

    if ($magic === BACKUP_MAGIC_V3) {
        if (strlen($modeByte) !== 1) {
            throw new RuntimeException('backup_decrypt_to_path: IPAMBKP3 truncated before mode byte');
        }
        $mode = ord($modeByte);
        if ($mode === BACKUP_V3_MODE_TRANSITORY && ($passphrase === null || $passphrase === '')) {
            throw new IpamBackupKeyRequiredException(
                $mode,
                'backup_decrypt_to_path: IPAMBKP3 transitory archive requires a passphrase'
            );
        }
        if ($mode === BACKUP_V3_MODE_STORED && ($vaultKey === null || $vaultKey === '')) {
            throw new IpamBackupKeyRequiredException(
                $mode,
                'backup_decrypt_to_path: IPAMBKP3 stored archive requires backup_vault_key'
            );
        }
        backup_decrypt_stream_v3($srcPath, $dstPath, $passphrase, $vaultKey);
        return;
    }
    if ($magic === BACKUP_MAGIC_UNENC) {
        backup_unencrypted_unwrap_stream($srcPath, $dstPath);
        return;
    }
    if ($magic === BACKUP_MAGIC_V2) {
        backup_decrypt_stream($srcPath, $dstPath, $appSecret);
        return;
    }
    if ($magic === BACKUP_MAGIC) {
        $blob = @file_get_contents($srcPath);
        if ($blob === false) {
            throw new RuntimeException('backup_decrypt_to_path: cannot read v1 blob');
        }
        $plain = backup_decrypt($blob, $appSecret);
        $written = @file_put_contents($dstPath, $plain);
        if ($written !== strlen($plain)) {
            // Partial write (e.g. disk full) — discard truncated plaintext.
            if (is_file($dstPath)) {
                @unlink($dstPath); // nosemgrep: php.lang.security.unlink-use.unlink-use -- $dstPath is caller-supplied tmpfile path, no user input
            }
            throw new RuntimeException('backup_decrypt_to_path: cannot write v1 plaintext');
        }
        return;
    }
    throw new RuntimeException('backup_decrypt_to_path: unknown backup format');
}

/**
 * Advance a 16-byte big-endian counter block by $blocks (treats the whole
 * 16 bytes as a single big-endian integer). Returns the new counter; the
 * input is unchanged.
 */
function ipam_backup_advance_ctr(string $counter, int $blocks): string
{
    $unpacked = unpack('C*', $counter);
    if ($unpacked === false) {
        throw new RuntimeException('ipam_backup_advance_ctr: unpack failed');
    }
    $bytes = array_values($unpacked);
    $carry = $blocks;
    for ($i = 15; $i >= 0 && $carry > 0; $i--) {
        $sum = $bytes[$i] + ($carry & 0xff);
        $bytes[$i] = $sum & 0xff;
        $carry = ($carry >> 8) + ($sum >> 8);
    }
    return pack('C*', ...$bytes);
}

/**
 * Decrypt a backup payload produced by backup_encrypt().
 *
 * Verifies the magic header and GCM authentication tag before returning
 * plaintext. Any tampering with the ciphertext, tag, or IV — or passing
 * a plain-text file instead of an encrypted blob — causes a RuntimeException
 * with a non-leaky message (no oracle information about which part failed).
 *
 * Forward-compat note: future format versions will use a different magic
 * (e.g. "IPAMBKP2") and a newer decoder. The error message on version
 * mismatch is intentionally identical to the bad-magic path so the format
 * version itself is not leaked through the exception text. Callers should
 * surface a user-friendly "backup created by newer version" error when
 * appropriate based on the loaded software version, not by parsing the
 * exception message.
 *
 * @throws RuntimeException on bad magic, truncation, or authentication failure
 */
function backup_decrypt(string $blob, string $appSecret): string
{
    if ($appSecret === '') {
        throw new RuntimeException('backup decryption requires app_secret to be set in config.php');
    }
    $minLen = strlen(BACKUP_MAGIC) + BACKUP_IV_LEN + BACKUP_TAG_LEN;
    if (strlen($blob) < $minLen) {
        throw new RuntimeException('encrypted blob too short');
    }
    if (substr($blob, 0, strlen(BACKUP_MAGIC)) !== BACKUP_MAGIC) {
        throw new RuntimeException('not an IPAM backup blob (bad magic)');
    }
    $offset = strlen(BACKUP_MAGIC);
    $iv  = substr($blob, $offset, BACKUP_IV_LEN);
    $tag = substr($blob, $offset + BACKUP_IV_LEN, BACKUP_TAG_LEN);
    $ct  = substr($blob, $offset + BACKUP_IV_LEN + BACKUP_TAG_LEN);
    $key = ipam_hkdf_sha256($appSecret, 'ipam-v3:backup', 32);
    $pt  = openssl_decrypt($ct, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
    if ($pt === false) {
        throw new RuntimeException('backup decryption failed (auth or key)');
    }
    return $pt;
}

// ── GFS Retention Engine (#695) ───────────────────────────────────────────────

/**
 * Select backup log IDs that should be deleted according to a GFS
 * (Grandfather-Father-Son) retention policy.
 *
 * Algorithm
 * ---------
 * 1. Sort $backups newest-first by created_at.
 * 2. Walk in order, assigning each backup to up to four tier slots:
 *    - hourly  → slot key "Y-m-d H" (UTC)
 *    - daily   → slot key "Y-m-d"   (UTC)
 *    - weekly  → slot key "YYYY-WW"  (ISO 8601 week)
 *    - monthly → slot key "Y-m"     (UTC)
 * 3. For each tier with a positive keep_* count, the FIRST backup encountered
 *    in a given slot (i.e. the newest in that slot) wins the slot until the
 *    tier's capacity is exhausted.
 * 4. A backup is KEPT if it wins at least one slot in any tier.
 * 5. Safety guard: the newest backup overall is always kept, even when all
 *    keep_* counts are zero.
 * 6. Everything else goes into the delete list.
 *
 * Tier promotion note: tiers are independent. A backup that falls outside the
 * hourly window (e.g. yesterday's backup when keep_hourly=1) can still win a
 * daily, weekly, or monthly slot without first winning an hourly slot.
 *
 * @param array<int, array{id: int, created_at: string}> $backups
 *        Flat list of backup records; order does not matter.
 * @param array{keep_hourly: int, keep_daily: int, keep_weekly: int, keep_monthly: int} $config
 *        Retention counts per tier. A count of 0 disables that tier entirely.
 * @return int[]  IDs from $backups that should be deleted.
 */
function ipam_gfs_select_for_deletion(array $backups, array $config): array
{
    if (count($backups) === 0) {
        return [];
    }

    // Sort newest-first; stable sort preserves relative order of ties (not critical,
    // but deterministic across PHP versions).
    usort($backups, static function (array $a, array $b): int {
        return strcmp($b['created_at'], $a['created_at']);
    });

    $newestId = (int) $backups[0]['id'];

    $keepHourly  = max(0, (int) $config['keep_hourly']);
    $keepDaily   = max(0, (int) $config['keep_daily']);
    $keepWeekly  = max(0, (int) $config['keep_weekly']);
    $keepMonthly = max(0, (int) $config['keep_monthly']);

    // Slot tracking per tier: slot_key → count of backups already assigned to that slot.
    $hourlySlots  = [];
    $dailySlots   = [];
    $weeklySlots  = [];
    $monthlySlots = [];

    // Count of unique slots filled so far per tier (used to stop once capacity reached).
    $hourlyFilled  = 0;
    $dailyFilled   = 0;
    $weeklyFilled  = 0;
    $monthlyFilled = 0;

    $keepIds = [];

    foreach ($backups as $backup) {
        $id = (int) $backup['id'];

        // Safety guard: always keep the newest backup.
        if ($id === $newestId) {
            $keepIds[$id] = true;
            // Still run through the tier logic below so it counts toward slot capacity.
        }

        $epoch = strtotime($backup['created_at']);
        if ($epoch === false) {
            // Unparseable timestamp: treat as very old (epoch 0) — should never happen on well-formed data.
            $epoch = 0;
        }

        $kept = isset($keepIds[$id]);

        // Hourly tier
        if ($keepHourly > 0) {
            $slot = gmdate('Y-m-d H', $epoch);
            if (!isset($hourlySlots[$slot])) {
                // First (newest) backup in this slot wins it, if capacity remains.
                if ($hourlyFilled < $keepHourly) {
                    $hourlySlots[$slot] = true;
                    $hourlyFilled++;
                    $keepIds[$id] = true;
                    $kept = true;
                }
                // If capacity exhausted, the slot winner is still recorded as "seen"
                // so later (older) backups in the same slot are not mistakenly counted.
                $hourlySlots[$slot] = true;
            }
            // Subsequent backups in the same slot: slot already claimed; they do not win it.
        }

        // Daily tier
        if ($keepDaily > 0) {
            $slot = gmdate('Y-m-d', $epoch);
            if (!isset($dailySlots[$slot])) {
                if ($dailyFilled < $keepDaily) {
                    $dailySlots[$slot] = true;
                    $dailyFilled++;
                    $keepIds[$id] = true;
                    $kept = true;
                }
                $dailySlots[$slot] = true;
            }
        }

        // Weekly tier (ISO 8601 week: "YYYY-WW")
        if ($keepWeekly > 0) {
            $slot = gmdate('o-W', $epoch); // 'o' = ISO year (may differ from 'Y' at year boundary)
            if (!isset($weeklySlots[$slot])) {
                if ($weeklyFilled < $keepWeekly) {
                    $weeklySlots[$slot] = true;
                    $weeklyFilled++;
                    $keepIds[$id] = true;
                    $kept = true;
                }
                $weeklySlots[$slot] = true;
            }
        }

        // Monthly tier
        if ($keepMonthly > 0) {
            $slot = gmdate('Y-m', $epoch);
            if (!isset($monthlySlots[$slot])) {
                if ($monthlyFilled < $keepMonthly) {
                    $monthlySlots[$slot] = true;
                    $monthlyFilled++;
                    $keepIds[$id] = true;
                    $kept = true;
                }
                $monthlySlots[$slot] = true;
            }
        }

        // Suppress unused variable warning from static analysis: $kept is set for
        // documentation clarity but only $keepIds drives the decision.
        unset($kept);
    }

    // Build delete list: every input ID not in the keep set.
    $delete = [];
    foreach ($backups as $backup) {
        $id = (int) $backup['id'];
        if (!isset($keepIds[$id])) {
            $delete[] = $id;
        }
    }

    return $delete;
}

/**
 * Compute the list of backup_runs IDs to prune for a single destination.
 *
 * Pure-ish: reads from backup_destinations + backup_schedules + backup_runs,
 * but performs no mutations. Wraps ipam_gfs_select_for_deletion() with the
 * DB plumbing — schedule resolution (with conservative defaults if absent),
 * eligible-row filtering (status='success', is_protected=0), and slot
 * assignment via the GFS selector. Testable in isolation against an
 * in-memory SQLite.
 *
 * Reads from backup_runs (v3.21.0 #799 §A1; replaces backup_log).
 *
 * @param PDO $db             Application database connection.
 * @param int $destinationId  ID of the backup_destinations row.
 * @return int[]              backup_runs IDs that GFS retention selects for deletion.
 *                            Empty array means "nothing to prune" (no candidates,
 *                            below capacity, or all candidates protected).
 * @throws \InvalidArgumentException  if the destination row does not exist.
 */
function ipam_retention_compute_deletions(PDO $db, int $destinationId): array
{
    // ── 1. Fetch destination retention — v3.25.0 #846 retention rehome ──────
    // Pre-v3.25.0 retention lived on backup_schedules. v3.25.0 moved it to
    // backup_destinations so it describes "how much to keep at this storage
    // location" rather than "how often we write to it" (per
    // archive/backup_overhaul.md §3 AGREED). The migration backfilled values from
    // any per-schedule rows; the schedule columns remain in place for one
    // release cycle for downgrade safety but are no longer the source of
    // truth.
    //
    // Read from backup_destinations first; fall back to the per-schedule
    // row only if the destination columns are missing (pre-migration
    // upgrade window).
    // Probe whether the v3.25.0 retention columns are present. Pre-migration
    // upgrade windows and minimal-schema unit-test fixtures lack them; the
    // destination read falls back to the legacy schedule read in that case.
    $destRow = null;
    try {
        $destStmt = $db->prepare(
            "SELECT id, retention_hourly, retention_daily, retention_weekly, retention_monthly
               FROM backup_destinations WHERE id = :id"
        );
        $destStmt->execute([':id' => $destinationId]);
        $destRow = $destStmt->fetch();
    } catch (\PDOException $e) {
        // Only swallow undefined-column errors — other PDO failures
        // (deadlock, connection drop, etc.) must propagate so retention
        // doesn't silently fall back to legacy/default values and prune
        // too aggressively. SQLSTATE 42S22 (mysql) and 42703 (pgsql) are
        // "undefined column"; SQLite reports HY000 with the textual
        // 'no such column' fragment in errorInfo[2].
        $sqlstate = (string) ($e->errorInfo[0] ?? '');
        $msg      = (string) ($e->errorInfo[2] ?? '');
        $missingColumn =
            $sqlstate === '42S22'
            || $sqlstate === '42703'
            || ($sqlstate === 'HY000' && str_contains($msg, 'no such column'));
        if (!$missingColumn) {
            throw $e;
        }
        $destRow = null;
    }

    if ($destRow === null || $destRow === false) {
        // Either columns missing or row missing — distinguish by an
        // existence-only probe so we still throw on bad ID.
        $existsStmt = $db->prepare("SELECT id FROM backup_destinations WHERE id = :id");
        $existsStmt->execute([':id' => $destinationId]);
        if (!is_array($existsStmt->fetch())) {
            throw new \InvalidArgumentException("backup_destinations row not found: id={$destinationId}");
        }
    }

    if (is_array($destRow) && array_key_exists('retention_hourly', $destRow)) {
        $gfsConfig = [
            'keep_hourly'  => to_int($destRow['retention_hourly']),
            'keep_daily'   => to_int($destRow['retention_daily']),
            'keep_weekly'  => to_int($destRow['retention_weekly']),
            'keep_monthly' => to_int($destRow['retention_monthly']),
        ];
    } else {
        // Pre-migration: aggregate retention across any active schedules
        // pointing at this destination using MAX() — same most-generous
        // semantics the migration backfill uses (CR #1096 major finding).
        // LIMIT 1 would silently bias to whichever row PDO returned first
        // and could prune more aggressively than intended.
        $schedStmt = $db->prepare(
            "SELECT MAX(retention_hourly)  AS h,
                    MAX(retention_daily)   AS d,
                    MAX(retention_weekly)  AS w,
                    MAX(retention_monthly) AS m
             FROM backup_schedules
             WHERE destination_id = :did AND is_active = 1"
        );
        $schedStmt->execute([':did' => $destinationId]);
        $sched = $schedStmt->fetch();
        if (is_array($sched) && $sched['h'] !== null) {
            $gfsConfig = [
                'keep_hourly'  => to_int($sched['h']),
                'keep_daily'   => to_int($sched['d']),
                'keep_weekly'  => to_int($sched['w']),
                'keep_monthly' => to_int($sched['m']),
            ];
        } else {
            $gfsConfig = [
                'keep_hourly'  => 0,
                'keep_daily'   => 7,
                'keep_weekly'  => 4,
                'keep_monthly' => 3,
            ];
        }
    }

    // ── 3. Fetch successful backup_runs rows for this destination ────────────
    // backup_runs uses started_at for GFS bucketing (no created_at column).
    // CR feedback PR #1054: exclude is_protected=1 rows from the prune set.
    // Retention must respect the manual protection flag the same way the UI
    // delete-action does, otherwise auto-prune can wipe a row the operator
    // explicitly protected.
    $logStmt = $db->prepare(
        "SELECT id, started_at AS created_at
         FROM backup_runs
         WHERE destination_id = :did
           AND status = 'success'
           AND is_protected = 0
         ORDER BY started_at DESC"
    );
    $logStmt->execute([':did' => $destinationId]);
    $rows = $logStmt->fetchAll();

    if (count($rows) === 0) {
        return [];
    }

    return ipam_gfs_select_for_deletion($rows, $gfsConfig);
}

/**
 * Apply a precomputed deletion list: remote-delete each file via $client, and
 * mark each successfully-deleted backup_runs row as 'retention_pruned'. I/O only.
 *
 * Failure model: the row is marked pruned ONLY if the remote delete succeeded
 * (or the client is null and the row had no remote object). A remote-delete
 * failure leaves the row at status='success' so the next retention pass will
 * try again. Exceptions from the client are caught and logged; this function
 * never throws.
 *
 * Audit: a single 'backup.retention_pruned' event is written when count > 0,
 * with details "count=N destination=ID".
 *
 * @param PDO                        $db             Application database connection.
 * @param BackupClientInterface|null $client         Transport client for the
 *                                                   destination, or null if no
 *                                                   client could be constructed
 *                                                   (rows then stay live).
 * @param int                        $destinationId  Destination ID — used in
 *                                                   audit details only.
 * @param int[]                      $ids            backup_runs IDs to prune.
 * @return int                                       Count of rows actually
 *                                                   marked retention_pruned.
 */
function ipam_retention_apply_deletions(PDO $db, ?BackupClientInterface $client, int $destinationId, array $ids): int
{
    if (count($ids) === 0) {
        return 0;
    }

    // Fetch filenames for the IDs we'll attempt to delete remotely.
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $rowStmt = $db->prepare(
        "SELECT id, filename FROM backup_runs WHERE id IN ($placeholders)"
    );
    $rowStmt->execute(array_map('intval', $ids));
    $rowById = [];
    foreach ($rowStmt->fetchAll() as $r) {
        if (is_array($r) && isset($r['id']) && is_numeric($r['id'])) {
            $rowById[(int) $r['id']] = $r;
        }
    }

    $pruned = 0;
    foreach ($ids as $logId) {
        $row = $rowById[(int) $logId] ?? null;
        $filename = is_array($row) && is_string($row['filename'] ?? null) ? $row['filename'] : '';
        $remoteDeleted = false;

        if ($client !== null && $filename !== '') {
            try {
                // BackupClientInterface::delete() returns bool — true = removed, false = not found.
                // Treat both as success for retention purposes (the goal is "no longer present").
                $client->delete($filename);
                $remoteDeleted = true;
            } catch (\Throwable $e) {
                error_log('[ipam_retention_apply_deletions] remote delete failed for log_id=' . $logId . ' file=' . $filename . ': ' . $e->getMessage());
                $remoteDeleted = false;
            }
        }

        if (!$remoteDeleted) {
            continue;
        }

        try {
            $db->prepare(
                "UPDATE backup_runs SET status = 'retention_pruned' WHERE id = :id"
            )->execute([':id' => $logId]);
            $pruned++;
        } catch (\Exception $e) {
            error_log('[ipam_retention_apply_deletions] failed to mark log_id=' . $logId . ': ' . $e->getMessage());
        }
    }

    if ($pruned > 0) {
        // Matches the rest of the destinations.* / backup.* audit events,
        // which all use entity_type='destination'. CR review on PR #1050
        // flagged the prior 'backup_destination' as the outlier.
        audit(
            $db,
            'backup.retention_pruned',
            'destination',
            $destinationId,
            'count=' . $pruned . ' destination=' . $destinationId
        );
    }

    return $pruned;
}

/**
 * Build a typed BackupClientInterface for a destination row, or null if the
 * destination type is unknown or the client constructor throws (e.g. invalid
 * config). Errors are logged but never propagated — retention must remain
 * resilient to one misconfigured destination.
 */
function ipam_retention_build_client(PDO $db, int $destinationId): ?BackupClientInterface
{
    $stmt = $db->prepare("SELECT type, config FROM backup_destinations WHERE id = :id");
    $stmt->execute([':id' => $destinationId]);
    $row = $stmt->fetch();
    if (!is_array($row)) {
        return null;
    }

    $type = is_string($row['type'] ?? null) ? $row['type'] : '';
    $cfgJson = is_string($row['config'] ?? null) ? $row['config'] : '';
    $cfgArr = json_decode($cfgJson, true);
    $typedCfg = [];
    if (is_array($cfgArr)) {
        foreach ($cfgArr as $k => $v) {
            if (is_string($k)) $typedCfg[$k] = $v;
        }
    }

    try {
        return match ($type) {
            's3'    => new S3Client($typedCfg),
            'sftp'  => new SftpClient($typedCfg),
            'local' => new LocalBackupClient($typedCfg),
            default => null,
        };
    } catch (\Throwable $e) {
        error_log('[ipam_retention_build_client] cannot construct client for destination=' . $destinationId . ': ' . $e->getMessage());
        return null;
    }
}

/**
 * DB-aware GFS retention orchestrator for a single backup destination.
 *
 * Thin wrapper that composes ipam_retention_compute_deletions() (pure-ish
 * planning) → ipam_retention_build_client() (client construction) →
 * ipam_retention_apply_deletions() (remote delete + DB mark + audit).
 *
 * Existing call signature is preserved (#826 refactor splits the body into
 * three testable functions; the public surface stays the same so cron.php
 * and lib/backup.php continue to work without changes).
 *
 * @param PDO $db             Application database connection.
 * @param int $destinationId  ID of the backup_destinations row.
 * @return int                Count of backup_runs rows marked as retention_pruned.
 */
function ipam_backup_apply_retention(PDO $db, int $destinationId): int
{
    $ids = ipam_retention_compute_deletions($db, $destinationId);
    if (count($ids) === 0) {
        return 0;
    }
    $client = ipam_retention_build_client($db, $destinationId);
    return ipam_retention_apply_deletions($db, $client, $destinationId, $ids);
}

/**
 * Compute the next clock-aligned run time for a backup schedule.
 *
 * @param array<string,mixed> $schedule schedule row, requires 'frequency'; uses
 *                                       'time_of_day' (HH:MM), 'day_of_week' (0-6, Mon=1),
 *                                       'day_of_month' (1-28).
 * @param ?int $nowEpoch injectable UTC epoch for testing; defaults to time()
 * @return int next-run UTC epoch
 */
function ipam_backup_next_run_at(array $schedule, ?int $nowEpoch = null): int
{
    $now = $nowEpoch ?? time();
    $freq = is_string($schedule['frequency'] ?? null) ? $schedule['frequency'] : 'daily';

    [$hour, $minute] = ipam_backup_parse_time_of_day(
        is_string($schedule['time_of_day'] ?? null) ? $schedule['time_of_day'] : '02:00'
    );

    $utc = new DateTimeZone('UTC');
    $nowDt = (new DateTimeImmutable('@' . $now))->setTimezone($utc);

    if ($freq === 'hourly') {
        // Next exact HH:00 strictly after now (ignores time_of_day).
        return $nowDt
            ->setTime((int) $nowDt->format('H'), 0, 0)
            ->modify('+1 hour')
            ->getTimestamp();
    }

    if ($freq === 'weekly') {
        $schemaDow = isset($schedule['day_of_week']) && is_numeric($schedule['day_of_week'])
            ? ((int) $schedule['day_of_week']) : 1; // Mon default
        $phpDow = ipam_backup_dow_schema_to_php($schemaDow);
        $currentDow = (int) $nowDt->format('N');
        $daysAhead = ($phpDow - $currentDow + 7) % 7;
        $candidate = $nowDt
            ->setTime($hour, $minute, 0)
            ->modify("+{$daysAhead} days");
        if ($candidate->getTimestamp() <= $now) {
            $candidate = $candidate->modify('+7 days');
        }
        return $candidate->getTimestamp();
    }

    if ($freq === 'monthly') {
        $schemaDom = isset($schedule['day_of_month']) && is_numeric($schedule['day_of_month'])
            ? ((int) $schedule['day_of_month']) : 1;
        // Clamp 1..28 — anything higher would risk PHP's month-overflow
        // normalisation pushing 31st in a 30-day month into the next month.
        $targetDom = max(1, min(28, $schemaDom));
        $candidate = $nowDt
            ->setDate((int) $nowDt->format('Y'), (int) $nowDt->format('n'), $targetDom)
            ->setTime($hour, $minute, 0);
        if ($candidate->getTimestamp() <= $now) {
            $candidate = $candidate->modify('+1 month');
        }
        return $candidate->getTimestamp();
    }

    // 'daily' (and any unknown frequency string) — next HH:MM today or tomorrow.
    $candidate = $nowDt->setTime($hour, $minute, 0);
    if ($candidate->getTimestamp() <= $now) {
        $candidate = $candidate->modify('+1 day');
    }
    return $candidate->getTimestamp();
}

/**
 * Convert a schema day_of_week (0=Sun..6=Sat, the convention used by
 * backup_schedules.day_of_week per #690) to PHP's gmdate('N') convention
 * (1=Mon..7=Sun). Out-of-range inputs clamp into [0, 6] before conversion.
 *
 * Pure helper — extracted from ipam_backup_next_run_at during #826/#827
 * refactor so it can be tested in isolation and reused.
 */
function ipam_backup_dow_schema_to_php(int $schemaDow): int
{
    $clamped = max(0, min(6, $schemaDow));
    return $clamped === 0 ? 7 : $clamped;
}

/**
 * Parse a "HH:MM" string into a [hour, minute] tuple, clamping invalid hours
 * to 02 (the project default backup hour) and invalid minutes to 0. A bare
 * "HH" without a colon is accepted; the minute defaults to 0.
 *
 * @return array{0:int,1:int} [hour, minute] in the half-open ranges [0,24) and [0,60).
 */
function ipam_backup_parse_time_of_day(string $timeOfDay): array
{
    $parts = explode(':', $timeOfDay);
    $hour = (int) $parts[0];
    $minute = count($parts) > 1 ? (int) $parts[1] : 0;
    if ($hour < 0 || $hour > 23) $hour = 2;
    if ($minute < 0 || $minute > 59) $minute = 0;
    return [$hour, $minute];
}

/**
 * Merge secrets from an existing destination config into a submitted form payload
 * so that omitted or blank-string secret fields preserve the stored value, and
 * non-empty submitted values replace it (#793).
 *
 * Explicit clear: callers may submit "<postKey>__clear=1" to force a stored
 * secret to be removed. This wins over the preserve-on-blank behaviour and lets
 * operators rotate authentication modes (e.g. switching SFTP from password to
 * key-only) without delete-and-recreate.
 *
 * Pure function — no I/O. Designed for unit testing.
 *
 * @param  array<string, mixed> $post         Submitted form fields ($_POST shape).
 * @param  array<string, mixed> $existingCfg  Decoded JSON config from backup_destinations.config.
 * @param  string               $type         's3'|'sftp'|'local'.
 * @return array<string, mixed>               $post with secret fields backfilled or cleared.
 */
function ipam_destination_merge_secrets(array $post, array $existingCfg, string $type): array
{
    $pairs = [];
    if ($type === 's3') {
        $pairs = [['s3_secret_key', 'secret_key']];
    } elseif ($type === 'sftp') {
        $pairs = [
            ['sftp_password',    'password'],
            ['sftp_private_key', 'private_key'],
        ];
    }
    foreach ($pairs as [$postKey, $cfgKey]) {
        $clearKey = $postKey . '__clear';
        $clearRequested = isset($post[$clearKey])
            && in_array($post[$clearKey], ['1', 1, true, 'true', 'on'], true);
        if ($clearRequested) {
            // Explicit clear: blow away both the submitted value (if any) and the
            // preserved one. collect_config will then treat the field as absent.
            $post[$postKey] = '';
            continue;
        }
        $omitted = !array_key_exists($postKey, $post);
        $blank   = !$omitted && is_string($post[$postKey]) && $post[$postKey] === '';
        if (($omitted || $blank) && isset($existingCfg[$cfgKey])) {
            $post[$postKey] = to_str($existingCfg[$cfgKey]);
        }
    }
    return $post;
}

/**
 * Probe a backup destination for reachability and credential validity.
 *
 * Centralised so test_destination.php (manual click) and the auto-on-save path
 * in destinations.php (#787) share one implementation. Loads the row, decodes
 * config, constructs the typed client, and returns the same JSON-shape the
 * client's test() method produces. Audit-logs result with the supplied
 * triggered_by tag.
 *
 * @param  PDO    $db
 * @param  int    $destId
 * @param  string $triggeredBy 'manual' | 'auto-on-save'
 * @return array{ok:bool,message:string,latency_ms:?int}
 */
function ipam_destination_test_now(PDO $db, int $destId, string $triggeredBy = 'manual'): array
{
    // Audit every failure on the way to the client too — invalid IDs, missing
    // rows, and unparseable config previously slipped past the destination.test
    // audit trail.
    $fail = static function (?int $entityId, string $message) use ($db, $triggeredBy): array {
        audit($db, 'destination.test', 'destination', $entityId, "triggered_by=$triggeredBy fail");
        return ['ok' => false, 'message' => $message, 'latency_ms' => null];
    };

    if ($destId <= 0) {
        return $fail(null, 'Invalid destination id');
    }
    $stmt = $db->prepare("SELECT * FROM backup_destinations WHERE id = :id");
    $stmt->execute([':id' => $destId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!is_array($row)) {
        return $fail($destId, 'Destination not found');
    }
    $type = is_string($row['type'] ?? null) ? $row['type'] : '';
    $cfgJson = is_string($row['config'] ?? null) ? $row['config'] : '{}';
    $cfg = json_decode($cfgJson, true);
    if (!is_array($cfg)) {
        return $fail($destId, 'Destination config invalid');
    }
    /** @var array<string,mixed> $typedCfg */
    $typedCfg = [];
    foreach ($cfg as $k => $v) {
        if (is_string($k)) $typedCfg[$k] = $v;
    }
    try {
        $client = match ($type) {
            's3'    => new S3Client($typedCfg),
            'sftp'  => new SftpClient($typedCfg),
            'local' => new LocalBackupClient($typedCfg),
            default => throw new RuntimeException('Unknown destination type'),
        };
        $result = $client->test();
        audit($db, 'destination.test', 'destination', $destId,
            "triggered_by=$triggeredBy " . ($result['ok'] ? 'ok' : 'fail'));
        return $result;
    } catch (Throwable $e) {
        // Don't log the raw exception message — backup-transport exceptions can
        // include endpoint URLs, access keys, or auth payloads. Log only the
        // class name; the client layer is responsible for surfacing redacted
        // user-facing detail via the returned message.
        error_log('[destination_test] dest=' . $destId . ' exception=' . get_class($e));
        audit($db, 'destination.test', 'destination', $destId, "triggered_by=$triggeredBy fail");
        return [
            'ok'         => false,
            'message'    => 'Connection failed (' . get_class($e) . ')',
            'latency_ms' => null,
        ];
    }
}

/**
 * Email notification dispatcher for backup-subsystem events. Best-effort:
 * failures logged, never thrown. Each event reads its own enable flag from
 * the settings registry and returns early if disabled.
 *
 * Supported events (v3.22.0 §2.4):
 *   - 'success_scheduled'         context: ['dest' => row, 'detail' => string]
 *   - 'success_manual'            context: ['dest' => row, 'detail' => string]
 *   - 'failure_scheduled'         context: ['dest' => row, 'detail' => string]
 *   - 'failure_manual'            context: ['dest' => row, 'detail' => string]
 *   - 'destination_conn_failure'  context: ['dest' => row, 'message' => string]
 *   - 'schedule_overdue'          context: ['schedule_id' => int, 'destination_name' => string,
 *                                            'expected_at' => string, 'overdue_minutes' => int]
 *   - 'retention_prune'           context: ['dest' => row, 'pruned' => int]
 *   - 'encryption_change'         context: ['dest' => row, 'old_mode' => string, 'new_mode' => string]
 *
 * Backwards compatibility: the v3.21.x signature
 *     ipam_backup_notify(PDO $db, array $dest, string $status, string $detail)
 * is preserved — when the second arg is an array, this delegates to the new
 * dispatch path with `$status` mapped to the appropriate event by inspecting
 * `$dest['triggered_by']` if present (defaults to 'scheduled').
 *
 * @param array<string,mixed>|string $eventOrDest  Event slug, or legacy $dest row
 * @param array<string,mixed>|string $contextOrStatus  Event context, or legacy 'success'|'failure'
 * @param string                     $legacyDetail  Legacy detail string when called with old signature
 */
function ipam_backup_notify(
    PDO $db,
    array|string $eventOrDest,
    array|string $contextOrStatus = [],
    string $legacyDetail = ''
): void {
    // ----- Legacy signature shim -------------------------------------------
    // Pre-v3.22.0: ipam_backup_notify($db, $destRow, 'success'|'failure', $detail)
    // The BackupNotifyWiringTest source-scan test still asserts the old
    // call-site shape, so we preserve it. New callers should use the
    // event/context form.
    if (is_array($eventOrDest)) {
        $dest      = $eventOrDest;
        $status    = is_string($contextOrStatus) ? $contextOrStatus : '';
        $triggered = is_string($dest['triggered_by'] ?? null) ? $dest['triggered_by'] : 'scheduled';
        $event = match (true) {
            $status === 'success' && $triggered === 'manual'   => 'success_manual',
            $status === 'success'                              => 'success_scheduled',
            $status === 'failure' && $triggered === 'manual'   => 'failure_manual',
            $status === 'failure'                              => 'failure_scheduled',
            default                                            => '',
        };
        if ($event === '') return;
        ipam_backup_notify_dispatch($db, $event, ['dest' => $dest, 'detail' => $legacyDetail]);
        return;
    }

    // ----- New signature ---------------------------------------------------
    $event   = $eventOrDest;
    $context = is_array($contextOrStatus) ? $contextOrStatus : [];
    ipam_backup_notify_dispatch($db, $event, $context);
}

/**
 * Internal dispatch — looks up the per-event enable flag, formats subject +
 * body, and hands off to the shared mail pipeline.
 *
 * @param array<string,mixed> $context
 */
function ipam_backup_notify_dispatch(PDO $db, string $event, array $context): void
{
    $settingKey = match ($event) {
        'success_scheduled'        => 'backup.notify_success_scheduled',
        'success_manual'           => 'backup.notify_success_manual',
        'failure_scheduled'        => 'backup.notify_failure_scheduled',
        'failure_manual'           => 'backup.notify_failure_manual',
        'destination_conn_failure' => 'backup.notify_destination_conn_failure',
        'schedule_overdue'         => 'backup.notify_schedule_overdue',
        'retention_prune'          => 'backup.notify_retention_prune',
        'encryption_change'        => 'backup.notify_encryption_change',
        default                    => '',
    };
    if ($settingKey === '') return;

    // Per-schedule overrides apply only to scheduled-flow events. The
    // scheduling concept doesn't bind to manual / connection-test / overdue
    // / retention-prune / encryption-change events, which stay global.
    // schedule_id arrives via $dest['schedule_id'] (orchestrator threads it
    // alongside triggered_by; null on manual runs).
    $dest = is_array($context['dest'] ?? null) ? $context['dest'] : [];
    $rawSched = $dest['schedule_id'] ?? null;
    $scheduleId = is_int($rawSched) ? $rawSched
        : (is_numeric($rawSched) ? (int) $rawSched : null);

    $globalEnabled = (bool) ipam_setting($settingKey);
    $shouldSend = match ($event) {
        'failure_scheduled' => ipam_backup_notify_resolve_pref($db, $scheduleId, 'notify_on_failure', $globalEnabled),
        'success_scheduled' => ipam_backup_notify_resolve_pref($db, $scheduleId, 'notify_on_success', $globalEnabled),
        default             => $globalEnabled,
    };
    if (!$shouldSend) return;

    // Recipients: v3.25.0 #1078 backup-specific override takes precedence
    // over the global alert recipients. Empty override falls through to the
    // legacy alert.recipient_user_ids + alert.email path.
    $recipients = ipam_resolve_backup_notify_recipients($db);
    if ($recipients === []) {
        $legacy = trim(to_str(ipam_setting('alert.email')));
        if ($legacy !== '') $recipients = [$legacy];
    }
    // Per-schedule recipient override (v3.23.0 #825): applies on top of the
    // backup-tab override for scheduled-flow events. Manual / system events
    // skip this layer because there's no schedule_id in scope.
    $applyRecipientOverride = $event === 'failure_scheduled' || $event === 'success_scheduled';
    if ($applyRecipientOverride) {
        $recipients = ipam_backup_notify_resolve_recipients($db, $scheduleId, $recipients);
    }
    if ($recipients === []) return;

    $destName = is_string($dest['name'] ?? null) ? $dest['name'] : 'unknown';

    [$subject, $body] = match ($event) {
        'success_scheduled' => [
            sprintf('[IPAM] Backup SUCCESS (scheduled): %s', $destName),
            sprintf("Scheduled backup succeeded for destination \"%s\".\n\nDetail: %s\n",
                $destName, to_str($context['detail'] ?? '')),
        ],
        'success_manual' => [
            sprintf('[IPAM] Backup SUCCESS (manual): %s', $destName),
            sprintf("Manual backup succeeded for destination \"%s\".\n\nDetail: %s\n",
                $destName, to_str($context['detail'] ?? '')),
        ],
        'failure_scheduled' => [
            sprintf('[IPAM] Backup FAILURE (scheduled): %s', $destName),
            sprintf("Scheduled backup FAILED for destination \"%s\".\n\nDetail: %s\n",
                $destName, to_str($context['detail'] ?? '')),
        ],
        'failure_manual' => [
            sprintf('[IPAM] Backup FAILURE (manual): %s', $destName),
            sprintf("Manual backup FAILED for destination \"%s\".\n\nDetail: %s\n",
                $destName, to_str($context['detail'] ?? '')),
        ],
        'destination_conn_failure' => [
            sprintf('[IPAM] Destination connection test failing: %s', $destName),
            sprintf(
                "Periodic connection test for backup destination \"%s\" started failing.\n\nMessage: %s\n\n"
                . "No further alerts will be sent for this destination until it recovers, then fails again.\n",
                $destName, to_str($context['message'] ?? 'unknown')
            ),
        ],
        'schedule_overdue' => [
            sprintf('[IPAM] Backup schedule overdue: %s',
                to_str($context['destination_name'] ?? 'unknown')),
            sprintf(
                "A backup schedule has not fired when expected.\n\n"
                . "Destination: %s\nExpected at: %s\nOverdue by: %d minute(s)\nSchedule ID: %d\n\n"
                . "Likely causes: cron not running, host crashed, or the orchestrator is stuck.\n",
                to_str($context['destination_name'] ?? 'unknown'),
                to_str($context['expected_at'] ?? 'unknown'),
                to_int($context['overdue_minutes'] ?? 0),
                to_int($context['schedule_id'] ?? 0)
            ),
        ],
        'retention_prune' => [
            sprintf('[IPAM] Retention prune ran on %s', $destName),
            sprintf("Retention deleted %d backup blob(s) from destination \"%s\".\n",
                to_int($context['pruned'] ?? 0), $destName),
        ],
        'encryption_change' => [
            sprintf('[IPAM] Destination encryption mode changed: %s', $destName),
            sprintf(
                "An administrator changed the encryption mode on destination \"%s\".\n\n"
                . "Old mode: %s\nNew mode: %s\n",
                $destName, to_str($context['old_mode'] ?? ''), to_str($context['new_mode'] ?? '')
            ),
        ],
        default => ['', ''],
    };
    if ($subject === '') return;

    // v3.25.0 #1078: read the backup-tab delivery method override.
    // 'smtp' forces SMTP regardless of the global mail.transport / smtp.enabled
    // settings; 'inherit' keeps the legacy behaviour. Future values
    // ('webhook', 'slack', 'pushover') will dispatch through different
    // helpers — for now only the inherit/smtp axis is wired.
    $deliveryMethod = is_string(ipam_setting('backup.notify_delivery_method'))
        ? (string) ipam_setting('backup.notify_delivery_method')
        : 'inherit';
    $transportOverride = $deliveryMethod === 'smtp' ? 'smtp' : null;

    foreach ($recipients as $to) {
        try {
            if (function_exists('ipam_send_mail')) {
                $sendResult = ipam_send_mail($to, $subject, $body, '', $transportOverride);
                // ipam_send_mail returns success=false on transport failure
                // without throwing — surface that here so the new
                // forced-SMTP override doesn't fail silently.
                if (!$sendResult['success']) {
                    $err = is_string($sendResult['error']) ? $sendResult['error'] : 'unknown error';
                    error_log('[backup] notify failed for ' . $to . ': ' . $err);
                }
            } else {
                @mail($to, $subject, $body);
            }
        } catch (Throwable $e) {
            error_log('[backup] notify failed for ' . $to . ': ' . $e->getMessage());
        }
    }
}

/**
 * Map the per-field UI tri-state radio value to the storage form for the
 * notify_on_failure / notify_on_success columns:
 *   'on'      → 1   (override-and-enable)
 *   'off'     → 0   (override-and-suppress)
 *   anything else (incl. 'inherit') → null
 *
 * Centralised here so the controller and any future API endpoint share one
 * source of truth for the encoding.
 */
function ipam_admin_notify_tristate_to_db(mixed $raw): ?int
{
    if (!is_string($raw)) return null;
    return match ($raw) {
        'on'  => 1,
        'off' => 0,
        default => null,
    };
}

/**
 * Inverse of ipam_admin_notify_tristate_to_db() — picks the radio value
 * to mark `checked` when rendering the per-schedule override form.
 */
function ipam_admin_notify_tristate_from_db(mixed $raw): string
{
    if ($raw === null) return 'inherit';
    if (is_numeric($raw)) {
        return ((int) $raw) === 1 ? 'on' : 'off';
    }
    return 'inherit';
}

/**
 * Per-schedule resolver for a notification boolean (notify_on_failure /
 * notify_on_success). Returns the schedule's column when notify_override = 1
 * and the column is non-NULL; otherwise the global default.
 *
 * Wired in by E3 alongside the Notifications-tab UI. Pure function — only
 * touches backup_schedules; safe to call from anywhere with a $db handle.
 */
function ipam_backup_notify_resolve_pref(
    PDO $db,
    ?int $scheduleId,
    string $boolCol,
    bool $globalDefault
): bool {
    if (!in_array($boolCol, ['notify_on_failure', 'notify_on_success'], true)) {
        throw new InvalidArgumentException(
            "ipam_backup_notify_resolve_pref: column must be notify_on_failure or notify_on_success, got '$boolCol'"
        );
    }
    if ($scheduleId === null) {
        return $globalDefault;
    }
    $sql = "SELECT notify_override, $boolCol AS pref FROM backup_schedules WHERE id = :id";
    $stmt = $db->prepare($sql);
    $stmt->execute([':id' => $scheduleId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!is_array($row)) {
        return $globalDefault;
    }
    $rawOverride = $row['notify_override'] ?? 0;
    $override = is_numeric($rawOverride) && (int) $rawOverride === 1;
    if (!$override) {
        return $globalDefault;
    }
    $rawPref = $row['pref'] ?? null;
    if ($rawPref === null || !is_numeric($rawPref)) {
        // Override row but this particular preference left NULL — inherit global.
        return $globalDefault;
    }
    return (int) $rawPref === 1;
}

/**
 * Per-schedule resolver for notification recipients. Returns the schedule's
 * CSV recipient list when notify_override = 1 AND notify_recipients is non-NULL
 * AND parses to a non-empty list; otherwise the global recipients.
 *
 * @param  list<string> $globalRecipients
 * @return list<string>
 */
function ipam_backup_notify_resolve_recipients(
    PDO $db,
    ?int $scheduleId,
    array $globalRecipients
): array {
    if ($scheduleId === null) {
        return $globalRecipients;
    }
    $stmt = $db->prepare(
        "SELECT notify_override, notify_recipients FROM backup_schedules WHERE id = :id"
    );
    $stmt->execute([':id' => $scheduleId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!is_array($row)) {
        return $globalRecipients;
    }
    $rawOverride = $row['notify_override'] ?? 0;
    $override = is_numeric($rawOverride) && (int) $rawOverride === 1;
    if (!$override) {
        return $globalRecipients;
    }
    $csv = $row['notify_recipients'] ?? null;
    if (!is_string($csv) || trim($csv) === '') {
        return $globalRecipients;
    }
    $parts = array_values(array_filter(
        array_map('trim', explode(',', $csv)),
        static fn($s) => $s !== ''
    ));
    return $parts === [] ? $globalRecipients : $parts;
}

/**
 * Stream a full SQL dump of the SQLite database to a callable.
 * Each call to $write receives a chunk of SQL text.
 */
function ipam_db_dump_stream(PDO $db, callable $write): void
{
    // SQLite-format dump only. Every query in this function depends on
    // sqlite_master and SQLite-specific PRAGMA output. Cross-engine
    // dump/restore lands in v3.0.0 via migrate_db.php (#392). db_tools.php
    // gates the entry point on driver; this is defence-in-depth for any
    // direct caller that slips past it.
    if (ipam_dialect()->driver_name() !== 'sqlite') {
        throw new \RuntimeException(
            'ipam_db_dump_stream() is SQLite-only. Use engine-native tooling '
            . '(mysqldump / pg_dump) on other drivers until v3.0.0 migrate_db.php.'
        );
    }

    $write("-- Simple PHP IPAM database dump\n");
    $write("-- Generated: " . date('Y-m-d H:i:s') . "\n\n");
    $write("PRAGMA foreign_keys=OFF;\n");
    $write("BEGIN TRANSACTION;\n\n");

    // Tables: schema + data
    $tables = ($db->query(
        "SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
    ) ?: throw new \RuntimeException('Query failed'))->fetchAll();

    foreach ($tables as $t) {
        $name        = to_str($t['name']);
        $quotedName  = '"' . str_replace('"', '""', $name) . '"';
        $write("-- Table: {$name}\n");
        $write(to_str($t['sql']) . ";\n");

        // Dump triggers for this table so they are recreated on import.
        $triggers = ($db->query(
            "SELECT sql FROM sqlite_master WHERE type='trigger' AND tbl_name="
            . $db->quote($name) . " AND sql IS NOT NULL ORDER BY name"
        ) ?: throw new \RuntimeException('Query failed'))->fetchAll();
        foreach ($triggers as $trig) {
            $write(to_str($trig['sql']) . ";\n");
        }

        // Identify BLOB columns so we can always hex-encode raw binary data.
        $colInfo  = ($db->query("PRAGMA table_info({$quotedName})")
            ?: throw new \RuntimeException('Query failed'))->fetchAll();
        $blobCols = [];
        foreach ($colInfo as $ci) {
            if (strtoupper(to_str($ci['type'])) === 'BLOB') {
                $blobCols[to_str($ci['name'])] = true;
            }
        }

        $rows = ($db->query("SELECT * FROM {$quotedName}")
            ?: throw new \RuntimeException('Query failed'))->fetchAll();
        foreach ($rows as $row) {
            $cols = array_map(
                fn($c) => '"' . str_replace('"', '""', (string)$c) . '"',
                array_keys($row)
            );
            $vals = [];
            foreach ($row as $colName => $v) {
                if ($v === null) {
                    $vals[] = 'NULL';
                } elseif (is_int($v) || is_float($v)) {
                    $vals[] = (string)$v;
                } elseif (isset($blobCols[$colName])) {
                    $vals[] = "X'" . bin2hex(to_str($v)) . "'";
                } else {
                    $vals[] = "CAST(X'" . bin2hex(to_str($v)) . "' AS TEXT)";
                }
            }
            $write("INSERT INTO {$quotedName} (" . implode(',', $cols) . ") VALUES ("
                  . implode(',', $vals) . ");\n");
        }
        $write("\n");
    }

    // Indices (non-system)
    $indices = ($db->query(
        "SELECT sql FROM sqlite_master WHERE type='index' AND sql IS NOT NULL AND name NOT LIKE 'sqlite_%' ORDER BY name"
    ) ?: throw new \RuntimeException('Query failed'))->fetchAll();
    if ($indices) {
        $write("-- Indexes\n");
        foreach ($indices as $idx) {
            $write(to_str($idx['sql']) . ";\n");
        }
        $write("\n");
    }

    $write("COMMIT;\n");
    $write("PRAGMA foreign_keys=ON;\n");
}

/**
 * Generate a full SQL dump of the SQLite database suitable for import.
 * Backwards-compatible wrapper around ipam_db_dump_stream().
 */
function ipam_db_dump(PDO $db): string
{
    $out = '';
    ipam_db_dump_stream($db, function(string $chunk) use (&$out) {
        $out .= $chunk;
    });
    return $out;
}

/* ---------------- Pagination ---------------- */

function q_int(string $key, int $default, int $min, int $max): int
{
    $v = $_GET[$key] ?? null;
    if ($v === null || $v === '') return $default;
    if (!is_scalar($v)) return $default;
    if (!preg_match('/^-?\d+$/', (string)$v)) return $default;

    $n = (int)$v;
    if ($n < $min) return $min;
    if ($n > $max) return $max;
    return $n;
}

/**
 * Escape SQL LIKE wildcard characters in a user-supplied search string.
 * Returns the escaped string ready to be wrapped in % delimiters.
 * Use with `LIKE :q ESCAPE '!'` in your SQL.
 *
 * Uses `!` as the escape character because it is a normal character in
 * both SQLite and MySQL string literals — whereas `\\` is parsed as an
 * escape sequence inside single-quoted strings by MySQL (so `ESCAPE '\\'`
 * in PHP source, which renders as `ESCAPE '\'` in SQL text, is a syntax
 * error on MySQL). `!` avoids the cross-engine quoting landmine.
 */
function like_escape(string $q): string
{
    return str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $q);
}

/**
 * Parse and validate ?sort=col&dir=asc|desc from $_GET.
 *
 * @param array<string,string> $allowed  Map of GET param value → SQL column expression (whitelisted)
 * @param string $defaultCol  Key in $allowed to use when no valid sort param is provided
 * @param string $defaultDir  'asc' or 'desc'
 * @return array{col: string, dir: string, sql: string}
 */
function parse_sort(array $allowed, string $defaultCol, string $defaultDir = 'asc'): array
{
    $col = to_str($_GET['sort'] ?? $defaultCol);
    $dir = strtolower(to_str($_GET['dir'] ?? $defaultDir));
    if (!isset($allowed[$col])) $col = $defaultCol;
    if (!in_array($dir, ['asc', 'desc'], true)) $dir = $defaultDir;
    return ['col' => $col, 'dir' => $dir, 'sql' => $allowed[$col] . ' ' . strtoupper($dir)];
}

/**
 * Render a sortable <th> element linking to the current page with sort params applied.
 * $baseQs should be the query string prefix for the page (e.g. '?subnet_id=3&page_size=50').
 */
function sort_th(string $col, string $label, string $currentCol, string $currentDir, string $baseQs, string $dataCol = ''): string
{
    $isActive  = $col === $currentCol;
    $nextDir   = ($isActive && $currentDir === 'asc') ? 'desc' : 'asc';
    $arrow     = $isActive ? ($currentDir === 'asc' ? ' ▲' : ' ▼') : '';
    $sep       = str_contains($baseQs, '?') ? '&' : '?';
    $qs        = $baseQs . $sep . 'sort=' . urlencode($col) . '&dir=' . $nextDir;
    $cls       = $isActive ? ' class="sort-active"' : '';
    $dataAttr  = $dataCol !== '' ? ' data-col="' . e($dataCol) . '"' : '';
    return "<th{$cls}{$dataAttr}><a href='" . e($qs) . "'>" . e($label) . $arrow . '</a></th>';
}

/* ---------------- Login protection (#124) ---------------- */

/**
 * Verify a reCAPTCHA token against the Enterprise Assessment API.
 * Returns null on pass, error string on fail, null on network error (fail-open).
 *
 * @param array{enabled: bool, project_id: string, api_key: string, expected_action: string, score_threshold: float} $cfg
 */
function recaptcha_enterprise_verify(string $token, string $siteKey, array $cfg): ?string
{
    $projectId      = to_str($cfg['project_id']);
    $apiKey         = to_str($cfg['api_key']);
    $expectedAction = to_str($cfg['expected_action']);
    $threshold      = (float)$cfg['score_threshold'];

    if ($projectId === '' || $apiKey === '') {
        error_log('reCAPTCHA Enterprise: project_id and api_key must be configured.');
        return null; // fail open — misconfiguration should not block users
    }

    $url     = 'https://recaptchaenterprise.googleapis.com/v1/projects/' . rawurlencode($projectId) . '/assessments?key=' . rawurlencode($apiKey);
    $payload = (string)json_encode(['event' => ['token' => $token, 'expectedAction' => $expectedAction, 'siteKey' => $siteKey]]);
    $ctx = stream_context_create([
        'http' => [
            'method'        => 'POST',
            'header'        => "Content-Type: application/json\r\nContent-Length: " . strlen($payload) . "\r\n",
            'content'       => $payload,
            'timeout'       => 10,
            'ignore_errors' => true,
        ],
        'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
    ]);

    try {
        $raw = @file_get_contents($url, false, $ctx, 0, 1048576);
        if ($raw === false) {
            error_log('reCAPTCHA Enterprise: HTTP request failed.');
            return null;
        }
        $resp = json_decode($raw, true);
        if (!is_array($resp)) {
            error_log('reCAPTCHA Enterprise: Invalid JSON response.');
            return null;
        }
        /** @var array<string, mixed> $resp */
        $tokenProps  = is_array($resp['tokenProperties'] ?? null) ? $resp['tokenProperties'] : [];
        $riskAnalysis = is_array($resp['riskAnalysis'] ?? null)   ? $resp['riskAnalysis']   : [];

        if (!empty($tokenProps['invalid'])) return 'Security check failed. Please try again.';
        if ($expectedAction !== '' && isset($tokenProps['action']) && to_str($tokenProps['action']) !== $expectedAction) {
            return 'Security check failed. Please try again.';
        }

        $score = (isset($riskAnalysis['score']) && is_numeric($riskAnalysis['score'])) ? (float)$riskAnalysis['score'] : 0.0;
        return $score >= $threshold ? null : 'Security check failed. Please try again.';
    } catch (Throwable $e) {
        error_log('reCAPTCHA Enterprise verify error: ' . $e->getMessage());
        return null;
    }
}

/**
 * Resolve the reCAPTCHA v3 expected action name, honouring the legacy
 * top-level $config['recaptcha_action'] key (documented since #289) before
 * falling back to the v2.6.0 registry key recaptcha_enterprise.expected_action.
 * Both the widget render and the Enterprise verify path must go through this
 * helper so the action emitted in the hidden input matches the action checked
 * during verification — otherwise valid Enterprise tokens fail action matching.
 */
function recaptcha_expected_action_resolved(): string
{
    $legacyCfg    = $GLOBALS['config'] ?? null;
    $legacyAction = is_array($legacyCfg) ? ($legacyCfg['recaptcha_action'] ?? null) : null;
    $resolved = (is_string($legacyAction) && $legacyAction !== '')
        ? $legacyAction
        : to_str(ipam_setting('recaptcha_enterprise.expected_action'));
    return $resolved !== '' ? $resolved : 'login';
}

/**
 * Verify the login form protection token/field for the current POST request.
 *
 * Returns null on pass, '' for a silent honeypot rejection (no error shown),
 * or a non-empty error string that should be shown to the user.
 * Fails open on network errors so a broken CAPTCHA provider never blocks login.
 *
 * @param array<string, mixed> $config Stub config (demo_gate) or empty array (login.php); falls back to ipam_setting().
 * @param array<string, mixed> $post
 */
function login_protection_verify(array $config, array $post): ?string
{
    // demo_gate.php passes its own stub; fall back to ipam_setting() for login.php
    $raw = $config['login_protection'] ?? [];
    $lp  = is_array($raw) ? $raw : [];
    $cfg = fn(string $k): mixed => array_key_exists($k, $lp) ? $lp[$k] : ipam_setting("login_protection.{$k}");

    $method = to_str($cfg('method'));
    if ($method === '' || $method === 'null') return null;

    if ($method === 'honeypot') {
        return ($post['website'] ?? '') !== '' ? '' : null;
    }

    if ($method === 'time_check') {
        $min = max(1, to_int($cfg('min_seconds')));
        $ts  = to_int($_SESSION['login_form_at'] ?? 0);
        unset($_SESSION['login_form_at']);
        if ($ts === 0 || (time() - $ts) < $min) {
            return 'Form submission was too fast. Please wait a moment and try again.';
        }
        return null;
    }

    $secretKey = to_str($cfg('secret_key'));
    $siteKey   = to_str($cfg('site_key'));

    if ($method === 'turnstile') {
        $token = to_str($post['cf-turnstile-response'] ?? '');
        if ($token === '') return 'Please complete the security check.';
        try {
            $resp = oidc_http_post('https://challenges.cloudflare.com/turnstile/v0/siteverify', [
                'secret'   => $secretKey,
                'response' => $token,
                'remoteip' => client_ip(),
            ]);
        } catch (Throwable $e) {
            error_log('Turnstile verify error: ' . $e->getMessage());
            return null; // fail open
        }
        return !empty($resp['success']) ? null : 'Security check failed. Please try again.';
    }

    if ($method === 'hcaptcha') {
        $token = to_str($post['h-captcha-response'] ?? '');
        if ($token === '') return 'Please complete the security check.';
        try {
            $resp = oidc_http_post('https://hcaptcha.com/siteverify', [
                'secret'   => $secretKey,
                'response' => $token,
                'remoteip' => client_ip(),
            ]);
        } catch (Throwable $e) {
            error_log('hCaptcha verify error: ' . $e->getMessage());
            return null; // fail open
        }
        return !empty($resp['success']) ? null : 'Security check failed. Please try again.';
    }

    if ($method === 'recaptcha') {
        $token = to_str($post['g-recaptcha-response'] ?? '');
        if ($token === '') return 'Please complete the security check.';

        // Use Enterprise API if configured; fall back to standard reCAPTCHA API
        if ((bool)ipam_setting('recaptcha_enterprise.enabled')) {
            $rawThreshold = ipam_setting('recaptcha_enterprise.score_threshold');
            $enterprise = [
                'enabled'         => true,
                'project_id'      => to_str(ipam_setting('recaptcha_enterprise.project_id')),
                'api_key'         => to_str(ipam_setting('recaptcha_enterprise.api_key')),
                // Must match the action the widget emits (see
                // recaptcha_expected_action_resolved for the precedence rules).
                'expected_action' => recaptcha_expected_action_resolved(),
                'score_threshold' => is_numeric($rawThreshold) ? (float)$rawThreshold : 0.5,
            ];
            return recaptcha_enterprise_verify($token, $siteKey, $enterprise);
        }

        try {
            $resp = oidc_http_post('https://www.google.com/recaptcha/api/siteverify', [
                'secret'   => $secretKey,
                'response' => $token,
                'remoteip' => client_ip(),
            ]);
        } catch (Throwable $e) {
            error_log('reCAPTCHA verify error: ' . $e->getMessage());
            return null; // fail open
        }
        return !empty($resp['success']) ? null : 'Security check failed. Please try again.';
    }

    if ($method === 'friendly_captcha') {
        $token = to_str($post['frc-captcha-solution'] ?? '');
        if ($token === '' || $token === '.UNSTARTED') return 'Please complete the security check.';
        if ($token === '.FETCHING') return null; // in-progress, fail open
        try {
            $resp = oidc_http_post('https://api.friendlycaptcha.com/api/v1/siteverify', [
                'secret'  => $secretKey,
                'solution'=> $token,
                'sitekey' => $siteKey,
            ]);
        } catch (Throwable $e) {
            error_log('FriendlyCaptcha verify error: ' . $e->getMessage());
            return null; // fail open
        }
        return !empty($resp['success']) ? null : 'Security check failed. Please try again.';
    }

    return null; // unknown method — pass through
}

/**
 * Return the HTML widget snippet to embed in the login/gate form.
 * For time_check, also sets the session timestamp on GET requests.
 *
 * @param array<string, mixed> $config Stub config (demo_gate) or empty array (login.php); falls back to ipam_setting().
 */
function login_protection_widget_html(array $config): string
{
    $raw = $config['login_protection'] ?? [];
    $lp  = is_array($raw) ? $raw : [];
    $cfg = fn(string $k): mixed => array_key_exists($k, $lp) ? $lp[$k] : ipam_setting("login_protection.{$k}");

    $method  = to_str($cfg('method'));
    $siteKey = e(to_str($cfg('site_key')));

    switch ($method) {
        case 'honeypot':
            return "<input type='text' name='website' autocomplete='off' tabindex='-1' aria-hidden='true' class='hidden'>";
        case 'time_check':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                $_SESSION['login_form_at'] = time();
            }
            return ''; // no visible widget
        case 'turnstile':
            return "<script src='https://challenges.cloudflare.com/turnstile/v0/api.js' async defer></script>"
                 . "<div class='cf-turnstile' data-sitekey='{$siteKey}'></div>";
        case 'hcaptcha':
            return "<script src='https://js.hcaptcha.com/1/api.js' async defer></script>"
                 . "<div class='h-captcha' data-sitekey='{$siteKey}'></div>";
        case 'recaptcha':
            $ver   = to_int($cfg('version'));
            $isEnt = (bool)ipam_setting('recaptcha_enterprise.enabled');
            if ($ver === 3) {
                $scriptSrc    = $isEnt
                    ? "https://www.google.com/recaptcha/enterprise.js?render={$siteKey}"
                    : "https://www.google.com/recaptcha/api.js?render={$siteKey}";
                $entAttr      = $isEnt ? " data-recaptcha-enterprise='1'" : '';
                $action       = e(recaptcha_expected_action_resolved());
                $actionAttr   = " data-recaptcha-action='{$action}'";
                return "<script src='{$scriptSrc}' async defer></script>"
                     . "<input type='hidden' name='g-recaptcha-response' id='g-recaptcha-response' data-recaptcha-v3-key='{$siteKey}'{$entAttr}{$actionAttr}>";
            }
            return "<script src='https://www.google.com/recaptcha/api.js' async defer></script>"
                 . "<div class='g-recaptcha' data-sitekey='{$siteKey}'></div>";
        case 'friendly_captcha':
            return "<script src='https://cdn.jsdelivr.net/npm/friendly-challenge@latest/widget.module.min.js' async defer></script>"
                 . "<div class='frc-captcha' data-sitekey='{$siteKey}'></div>";
        default:
            return '';
    }
}

/**
 * Return extra CSP directives needed for the active login protection method.
 * Returns ['script_src' => '...', 'frame_src' => '...'] — either may be empty.
 * Turnstile, hCaptcha, and reCAPTCHA render inside an iframe so frame_src must
 * be explicitly allowed; Friendly Captcha uses Web Components (no iframe needed).
 */
/**
 * @param array<string, mixed> $config Stub config (demo_gate) or empty array (login.php); falls back to ipam_setting().
 * @return array{script_src: string, style_src: string, frame_src: string}
 */
function login_protection_extra_csp(array $config): array
{
    $raw = $config['login_protection'] ?? [];
    $lp  = is_array($raw) ? $raw : [];
    $method = to_str(array_key_exists('method', $lp) ? $lp['method'] : ipam_setting('login_protection.method'));
    return match ($method) {
        'turnstile'        => [
            'script_src' => 'https://challenges.cloudflare.com',
            'style_src'  => "'unsafe-inline'",
            'frame_src'  => 'https://challenges.cloudflare.com',
        ],
        'hcaptcha'         => [
            'script_src' => 'https://hcaptcha.com https://assets.hcaptcha.com',
            'style_src'  => '',
            'frame_src'  => 'https://newassets.hcaptcha.com',
        ],
        'recaptcha'        => [
            'script_src' => 'https://www.google.com https://www.gstatic.com',
            'style_src'  => '',
            'frame_src'  => 'https://www.google.com',
        ],
        'friendly_captcha' => [
            'script_src' => 'https://cdn.jsdelivr.net',
            'style_src'  => '',
            'frame_src'  => '',
        ],
        default            => ['script_src' => '', 'style_src' => '', 'frame_src' => ''],
    };
}

/* ---------------- Auto-reserve IPs ---------------- */

/**
 * Auto-reserve the network address, broadcast address (IPv4), and optionally
 * a gateway IP immediately after a subnet is created.
 *
 * IPv4: reserves network (x.x.x.0) and broadcast (x.x.x.255) as status=reserved.
 * IPv6: reserves network address only (broadcast concept does not apply).
 * Gateway (if provided): reserved as status=reserved with hostname 'gateway'.
 *
 * Skips any IP that is already assigned (INSERT OR IGNORE).
 */
function auto_reserve_subnet_ips(PDO $db, int $subnetId, string $cidr, ?string $gateway): void
{
    $p = parse_cidr($cidr);
    if (!$p) return;

    // Wrap the (up to) three INSERT + audit pairs in a transaction so a failure
    // partway through doesn't leave the subnet half-reserved (e.g. network +
    // broadcast committed, gateway audit dies, original v3.25.0 behaviour left
    // a row without its audit trail). Honour an outer transaction if one is
    // already open — callers like subnet create/update wrap their own.
    $owns = !$db->inTransaction();
    if ($owns) $db->beginTransaction();

    try {
    // #379/#410: bind ip_bin via ipam_bind_binary() (PARAM_LOB) so the stored
    // affinity is BLOB on SQLite and bytes round-trip safely on MySQL/Postgres.
    // The scalar params still come through bindValue so we can mix the two
    // binding styles on a single statement.
    $ignoreClause = ipam_dialect()->upsert_or_ignore('addresses', ['subnet_id', 'ip']);
    $ins = $db->prepare(
        "INSERT INTO addresses (subnet_id, ip, ip_bin, hostname, status, owner, note, grp, mac)
         VALUES (:sid, :ip, :ipbin, :host, 'reserved', '', 'Auto-reserved', '', '') $ignoreClause"
    );
    // Returns the new row's id on a fresh insert, or 0 when the row was
    // ignored by the upsert-or-ignore clause. Using rowCount() instead of
    // lastInsertId() is critical: on MySQL, lastInsertId() after a
    // duplicate-key no-op returns the previous successful insert id, which
    // would otherwise produce a bogus address.create audit entry.
    $reserveBind = function (int $sid, string $ip, string $bin, string $host) use ($ins, $db): int {
        $ins->bindValue(':sid',  $sid,  PDO::PARAM_INT);
        $ins->bindValue(':ip',   $ip,   PDO::PARAM_STR);
        ipam_bind_binary($ins, ':ipbin', $bin);
        $ins->bindValue(':host', $host, PDO::PARAM_STR);
        $ins->execute();
        return $ins->rowCount() > 0 ? ipam_last_insert_id($db, 'addresses') : 0;
    };

    // Network address
    $netIp  = $p['network'];
    $netBin = $p['net_bin'];
    $newId = $reserveBind($subnetId, $netIp, $netBin, 'network');
    if ($newId > 0) {
        audit($db, 'address.create', 'address', $newId, "auto-reserve network $netIp in subnet $subnetId");
    }

    if ($p['version'] === 4) {
        // Broadcast address for IPv4 — uses the same helper as the scanner so
        // /31 (RFC 3021 point-to-point) and /32 correctly reserve no broadcast
        // and the UI agrees with the scanner's reserved set.
        $bcastBin = ipam_compute_broadcast_bin($netBin, $p['prefix']);
        if ($bcastBin !== null) {
            $bcastIp = inet_ntop($bcastBin) ?: '';
            if ($bcastIp !== '' && $bcastIp !== $netIp) {
                $newId = $reserveBind($subnetId, $bcastIp, $bcastBin, 'broadcast');
                if ($newId > 0) {
                    audit($db, 'address.create', 'address', $newId, "auto-reserve broadcast $bcastIp in subnet $subnetId");
                }
            }
        }
    }

    // Gateway (optional, any version)
    if ($gateway !== null && $gateway !== '') {
        $gwNorm = normalize_ip($gateway);
        if ($gwNorm && ip_in_cidr($gwNorm['ip'], $p['network'], $p['prefix'])) {
            $newId = $reserveBind($subnetId, $gwNorm['ip'], $gwNorm['bin'], 'gateway');
            if ($newId > 0) {
                audit($db, 'address.create', 'address', $newId, "auto-reserve gateway {$gwNorm['ip']} in subnet $subnetId");
            }
        }
    }
        if ($owns) $db->commit();
    } catch (\Throwable $e) {
        // Same PHPStan 2.1.54 narrowing as ipam_setting_set above:
        // wrap rollBack() in try/catch so a "no active transaction"
        // PDOException does not mask the original exception.
        if ($owns) {
            try { $db->rollBack(); } catch (\Throwable) {}
        }
        throw $e;
    }
}

/* ---------------- Tags ---------------- */

/**
 * Return tags for a given entity (subnet or address).
 * @return array<array{id: int, name: string, colour: string}>
 */
function get_tags_for_entity(PDO $db, string $type, int $id): array
{
    if ($type === 'subnet') {
        $sql = "SELECT t.id, t.name, t.colour FROM tags t JOIN subnet_tags st ON st.tag_id = t.id WHERE st.subnet_id = :id ORDER BY t.name";
    } elseif ($type === 'address') {
        $sql = "SELECT t.id, t.name, t.colour FROM tags t JOIN address_tags at ON at.tag_id = t.id WHERE at.address_id = :id ORDER BY t.name";
    } else {
        return [];
    }
    $st = $db->prepare($sql);
    $st->execute([':id' => $id]);
    return array_map(fn($r) => ['id' => to_int($r['id']), 'name' => to_str($r['name']), 'colour' => to_str($r['colour'])], $st->fetchAll());
}

/**
 * Replace all tags for a given entity with the supplied tag IDs.
 * @param list<int> $tagIds
 */
function save_tags_for_entity(PDO $db, string $type, int $id, array $tagIds): void
{
    if ($type === 'subnet') {
        $db->prepare("DELETE FROM subnet_tags WHERE subnet_id = :id")->execute([':id' => $id]);
        $ins = $db->prepare("INSERT INTO subnet_tags (subnet_id, tag_id) VALUES (:eid, :tid) " . ipam_dialect()->upsert_or_ignore("subnet_tags", ["subnet_id", "tag_id"]) . "");
    } elseif ($type === 'address') {
        $db->prepare("DELETE FROM address_tags WHERE address_id = :id")->execute([':id' => $id]);
        $ins = $db->prepare("INSERT INTO address_tags (address_id, tag_id) VALUES (:eid, :tid) " . ipam_dialect()->upsert_or_ignore("address_tags", ["address_id", "tag_id"]) . "");
    } else {
        return;
    }
    foreach ($tagIds as $tid) {
        $ins->execute([':eid' => $id, ':tid' => $tid]);
    }
}

/**
 * Get contacts assigned to a site or subnet.
 * @return list<array{id: int, name: string, email: string, role: string}>
 */
function get_contacts_for_entity(PDO $db, string $type, int $id): array
{
    if ($type === 'site') {
        $sql = "SELECT c.id, c.name, c.email, sc.role FROM contacts c JOIN site_contacts sc ON sc.contact_id = c.id WHERE sc.site_id = :id ORDER BY c.name";
    } elseif ($type === 'subnet') {
        $sql = "SELECT c.id, c.name, c.email, sc.role FROM contacts c JOIN subnet_contacts sc ON sc.contact_id = c.id WHERE sc.subnet_id = :id ORDER BY c.name";
    } else {
        return [];
    }
    $st = $db->prepare($sql);
    $st->execute([':id' => $id]);
    /** @var list<array<string, mixed>> $rows */
    $rows = $st->fetchAll();
    return array_map(fn($r) => [
        'id'    => to_int($r['id']),
        'name'  => to_str($r['name']),
        'email' => to_str($r['email']),
        'role'  => to_str($r['role']),
    ], $rows);
}

/**
 * Replace all contact assignments for a site or subnet.
 * @param list<array{contact_id: int, role: string}> $contacts
 */
function save_contacts_for_entity(PDO $db, string $type, int $id, array $contacts): void
{
    if ($type === 'site') {
        $delSql = "DELETE FROM site_contacts WHERE site_id = :id";
        $insSql = "INSERT INTO site_contacts (site_id, contact_id, role) VALUES (:eid, :cid, :role)";
    } elseif ($type === 'subnet') {
        $delSql = "DELETE FROM subnet_contacts WHERE subnet_id = :id";
        $insSql = "INSERT INTO subnet_contacts (subnet_id, contact_id, role) VALUES (:eid, :cid, :role)";
    } else {
        return;
    }
    $seen = [];
    $deduped = [];
    foreach ($contacts as $c) {
        $cid = $c['contact_id'];
        if (isset($seen[$cid])) continue;
        $seen[$cid] = true;
        $deduped[] = $c;
    }
    $wasInTxn = $db->inTransaction();
    if (!$wasInTxn) $db->beginTransaction();
    try {
        $db->prepare($delSql)->execute([':id' => $id]);
        $ins = $db->prepare($insSql);
        foreach ($deduped as $c) {
            $ins->execute([':eid' => $id, ':cid' => $c['contact_id'], ':role' => $c['role']]);
        }
        if (!$wasInTxn) $db->commit();
    } catch (\Throwable $e) {
        if (!$wasInTxn && $db->inTransaction()) $db->rollBack();
        throw $e;
    }
}

/** Render contact badges for a site or subnet (HTML-safe). */
function render_contact_badges(PDO $db, string $type, int $id): string
{
    $contacts = get_contacts_for_entity($db, $type, $id);
    if (!$contacts) return '';
    $out = '<span class="contact-badges">';
    foreach ($contacts as $c) {
        $label = e($c['name']);
        if ($c['role'] !== '') $label .= ' <span class="muted">(' . e($c['role']) . ')</span>';
        $out .= '<a href="#" class="badge contact-badge contact-card-trigger" data-contact-id="' . $c['id'] . '">' . $label . '</a> ';
    }
    return $out . '</span>';
}

/**
 * Parse contact_id[] and contact_role[] from POST data.
 * @param array<string, mixed> $post
 * @return list<array{contact_id: int, role: string}>
 */
function parse_contact_assignments(array $post): array
{
    $ids   = (array)($post['contact_id'] ?? []);
    $roles = (array)($post['contact_role'] ?? []);
    $out = [];
    foreach ($ids as $i => $raw) {
        $cid = to_int($raw);
        if ($cid <= 0) continue;
        $out[] = ['contact_id' => $cid, 'role' => trim(to_str($roles[$i] ?? ''))];
    }
    return $out;
}

/** Render coloured tag badges for a list of tags (HTML-safe). */
function render_tag_badges(PDO $db, string $type, int $id): string
{
    $tags = get_tags_for_entity($db, $type, $id);
    if (!$tags) return '';
    $out = '';
    foreach ($tags as $tag) {
        // #869 + CR #1100: defence in depth against tag.colour CSS
        // injection. e() only HTML-escapes — it does not enforce CSS
        // syntax — so we ALSO validate the value as a strict #RRGGBB
        // hex literal at render time. Anything else falls back to the
        // muted default colour. The custom-property indirection
        // (--tag-bg) is a second layer: even a payload that leaks past
        // this validation cannot append a second CSS declaration
        // because CSS variables refuse ';' and '}' in their values.
        $colourRaw = to_str($tag['colour']);
        $colour = preg_match('/^#[0-9A-Fa-f]{6}$/', $colourRaw) === 1
            ? $colourRaw
            : '#6c757d';
        $bg   = e($colour);
        $name = e($tag['name']);
        $out .= "<span class='tag-badge' style='--tag-bg:$bg'>$name</span>";
    }
    return $out;
}

/* ---------------- Demo mode ---------------- */

function demo_mode_enabled(): bool
{
    /** @var IpamConfig $gConf */
    $gConf = $GLOBALS['config'];
    return !empty($gConf['demo_mode']['enabled']);
}

function demo_require_reset(): bool
{
    $marker = __DIR__ . '/data/demo_last_reset.txt';
    if (!is_file($marker)) return true;
    $lastReset = (int)file_get_contents($marker);
    $midnight  = mktime(0, 0, 0);
    return $lastReset < $midnight;
}

/** @return array<string, int> */
function paginate(int $total, int $page, int $pageSize): array
{
    $page = max(1, $page);
    $pageSize = max(1, min(500, $pageSize));
    $pages = (int)max(1, (int)ceil($total / $pageSize));
    if ($page > $pages) $page = $pages;

    return [
        'page' => $page,
        'page_size' => $pageSize,
        'pages' => $pages,
        'offset' => ($page - 1) * $pageSize,
        'limit' => $pageSize,
    ];
}

/* ---------------- CSV export helpers ---------------- */

function safe_export_filename(string $base): string
{
    // Preserve original extension (e.g. .conf, .json) — strip it, sanitize
    // the stem, then re-attach so non-CSV downloads keep the right extension.
    $ext  = pathinfo($base, PATHINFO_EXTENSION);
    $stem = pathinfo($base, PATHINFO_FILENAME);
    $ext  = $ext !== '' ? '.' . strtolower(preg_replace('/[^a-z0-9]+/i', '', $ext) ?? '') : '.csv';
    $stem = strtolower($stem);
    $stem = preg_replace('/[^a-z0-9._-]+/', '-', $stem) ?? 'export';
    $stem = trim($stem, '-.');
    if ($stem === '') $stem = 'export';
    return $stem . '-' . date('Y-m-d-His') . $ext;
}

function csv_download_headers(string $filename): void
{
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    echo "\xEF\xBB\xBF"; // UTF-8 BOM for Excel compatibility
}

/** @return resource */
function csv_output_handle()
{
    static $fh = null;
    if ($fh === null) {
        $fh = fopen('php://output', 'wb');
        if (!$fh) throw new RuntimeException('Cannot open php://output');
    }
    return $fh;
}

/** @param list<string> $row */
function csv_out(array $row): void
{
    $fh = csv_output_handle();
    // CodeRabbit C1 (PR #450): defuse spreadsheet formula injection. Excel /
    // LibreOffice / Numbers treat any cell starting with =, +, -, @, TAB, CR
    // or LF as a formula. Prefix offending cells with a single quote so they
    // render as literal text. Applies to every CSV export site-wide because
    // every export goes through this helper.
    $sanitized = array_map(static function (string $cell): string {
        if ($cell === '') return $cell;
        $first = $cell[0];
        if ($first === '=' || $first === '+' || $first === '-' || $first === '@'
            || $first === "\t" || $first === "\r" || $first === "\n") {
            return "'" . $cell;
        }
        return $cell;
    }, $row);
    fputcsv($fh, $sanitized, ',', '"', '');
}

/* ---------------- Security warning banner ---------------- */

/**
 * Render a dismissible per-session security warning banner.
 *
 * Call this immediately after page_header() on sensitive admin pages.
 * The banner is hidden for the rest of the session once the user dismisses it.
 *
 * @param string $context  Short identifier for this banner, e.g. 'db_tools', 'import_csv'
 * @param string $message  Warning text to display (HTML-escaped before output)
 */
function render_security_banner(string $context, string $message): void
{
    // Handle dismiss: clicking the link adds ?dismiss_warning=<context> to the URL.
    // We process it here (before any HTML output from this function) and store in session.
    if (isset($_GET['dismiss_warning']) && $_GET['dismiss_warning'] === $context) {
        $dw = is_array($_SESSION['dismissed_warnings'] ?? null) ? $_SESSION['dismissed_warnings'] : [];
        $dw[$context] = true;
        $_SESSION['dismissed_warnings'] = $dw;
    }

    $dw = is_array($_SESSION['dismissed_warnings'] ?? null) ? $_SESSION['dismissed_warnings'] : [];
    if (!empty($dw[$context])) {
        return;
    }

    // Build dismiss URL: current URL with dismiss_warning param added, page reset removed
    $params = array_merge($_GET, ['dismiss_warning' => $context]);
    $dismissUrl = '?' . http_build_query($params);

    echo '<div class="security-banner">'
       . '<span>⚠ <strong>Security notice:</strong> ' . e($message) . '</span>' // nosemgrep: php.lang.security.tainted-user-input-in-php-script.tainted-user-input-in-php-script
       . '<a class="dismiss-link" href="' . e($dismissUrl) . '">Dismiss</a>'
       . '</div>';
}

/**
 * v3.28.2 #1178 — render the admin-only "install key auto-generated" banner.
 *
 * Companion to `ipam_install_key_announce_record()` which sets the
 * `install_keys_announce.<key>` flag in the `settings` table when an
 * install-root secret is lazily generated on first use. This helper renders a
 * dismissible alert until the operator acknowledges it; dismissal clears the
 * flag (engine-portable via `ipam_setting_set()`) so it persists across
 * sessions rather than the per-session `render_security_banner()` pattern.
 *
 * Dismissal is via a POST to whichever admin page page_header() runs on.
 * `$_POST['action'] === 'dismiss_install_key_banner'` with `$_POST['key']`
 * allowlisted to the two known secret names. CSRF-protected through
 * `csrf_require()`.
 *
 * Safe to call when `$role !== 'admin'` (early return). Safe to call before
 * the settings table is reachable (silently no-ops via try/catch).
 */
/**
 * v3.28.2 #1178 — handle the install-key banner dismiss POST.
 *
 * Must run BEFORE any HTML output: csrf_require() emits a 403 response
 * (status + body) on a bad/missing token, which is impossible once
 * page_header() has flushed `<!doctype html>`. Called from the top of
 * page_header() so every admin page can be the dismiss target without
 * each entry script having to wire it explicitly.
 *
 * On a successful dismiss, the function redirects to the same URL via
 * GET so a refresh of the resulting page does not re-POST the dismiss
 * action.
 */
function ipam_install_key_banner_handle_dismiss(PDO $db, string $role): void
{
    if ($role !== 'admin') {
        return;
    }
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST'
        || (($_POST['action'] ?? '') !== 'dismiss_install_key_banner')) {
        return;
    }
    csrf_require();
    $postedKey = is_string($_POST['key'] ?? null) ? $_POST['key'] : '';
    if ($postedKey !== 'app_secret' && $postedKey !== 'bootstrap_key') {
        return;
    }
    try {
        _ipam_install_key_announce_write($db, 'install_keys_announce.' . $postedKey, '0');
    } catch (\Throwable $e) {
        error_log('[ipam_install_key_banner_handle_dismiss] ' . $postedKey . ': ' . $e->getMessage());
    }
    // Redirect to the same URL via GET so the dismiss is idempotent on
    // refresh (no stale POST in the navigation history) and the banner
    // is gone on the next render. Reflecting raw REQUEST_URI into
    // Location would accept a protocol-relative target like
    // `//attacker.example/...` and redirect cross-origin; rebuild the
    // target from a parsed path/query that's guaranteed same-origin.
    // Also reject backslashes (browsers normalise `/\evil.example` to
    // `//evil.example` cross-origin) and CR/LF (header-injection).
    $self  = to_str($_SERVER['REQUEST_URI'] ?? '/');
    $parts = parse_url($self);
    $path  = is_array($parts)
        && is_string($parts['path'] ?? null)
        && ($parts['path'][0] ?? '') === '/'
        && !str_starts_with($parts['path'], '//')
        && !str_contains($parts['path'], '\\')
        && preg_match('/[\r\n]/', $parts['path']) !== 1
        ? $parts['path']
        : '/';
    $query = is_array($parts)
        && is_string($parts['query'] ?? null)
        && $parts['query'] !== ''
        && preg_match('/[\r\n]/', $parts['query']) !== 1
        ? '?' . $parts['query']
        : '';
    header('Location: ' . $path . $query, true, 303);
    exit;
}

function render_install_key_banner(PDO $db, string $role): void
{
    if ($role !== 'admin') {
        return;
    }

    $messages = [
        'app_secret' => [
            'headline' => 'A new <code>app_secret</code> was generated',
            'body'     => "It's the key for your 2FA secrets and restore-staging tokens. "
                        . 'Back up <code>config.php</code> now — if it ever changes, all 2FA enrollments break.',
        ],
        'bootstrap_key' => [
            'headline' => 'A new <code>bootstrap_key</code> was generated',
            'body'     => 'It wraps the <code>backup_vault_key</code> in the database. '
                        . "Back up <code>config.php</code> now — without it, encrypted backups can't be decrypted.",
        ],
    ];

    foreach ($messages as $key => $text) {
        try {
            $flag = ipam_setting('install_keys_announce.' . $key, '0');
        } catch (\Throwable) {
            continue;
        }
        $shouldShow = ($flag === '1' || $flag === 1 || $flag === true);
        if (!$shouldShow) {
            continue;
        }

        $csrf = e(csrf_token());
        $keyAttr = e($key);
        echo "<div class='admin-notice admin-notice--warning' role='alert'>"
           . '&#9888; <strong>' . $text['headline'] . '.</strong> ' // nosemgrep: php.lang.security.tainted-user-input-in-php-script.tainted-user-input-in-php-script
           . $text['body']
           . ' See <a href="https://github.com/seanmousseau/Simple-PHP-IPAM/blob/main/docs/backups.md#disaster-recovery">'
           . 'backups.md &rarr; Disaster recovery</a>'
           . ' or the <a href="settings.php#install-keys">Install keys panel</a>.'
           . ' <form method="post" action="" style="display:inline;margin-left:0.5rem;">'
           . "<input type='hidden' name='csrf' value='{$csrf}'>"
           . "<input type='hidden' name='action' value='dismiss_install_key_banner'>"
           . "<input type='hidden' name='key' value='{$keyAttr}'>"
           . '<button type="submit" class="button-secondary btn-sm">Dismiss</button>'
           . '</form>'
           . '</div>';
    }
}

/* ---------------- Demo mode seed/reset ---------------- */

function demo_reset_db(PDO $db): void
{
    $driver = ipam_dialect()->driver_name();

    // audit_log has append-only triggers that block DELETE, so bypass via rename+drop,
    // then immediately recreate the table and triggers.
    $db->exec("ALTER TABLE audit_log RENAME TO audit_log_old");
    $db->exec("DROP TABLE audit_log_old");
    ensure_audit_log_table($db);

    // Clear in FK-safe order; CASCADE removes subnet_tags, address_tags, alert_state.
    // schema_migrations is only wiped on SQLite, where the historical migration
    // closures are expected to re-run after the reset. On MySQL / Postgres,
    // schema.{engine}.sql pre-seeds schema_migrations with every historical
    // version row at fresh-install time (v2.10.0 #484 decision), and the
    // historical closures use SQLite-specific PRAGMA / sqlite_master queries
    // that would fail on other engines. Keep the pre-seed intact so
    // apply_migrations() remains a no-op.
    $tables = ['address_history', 'login_attempts', 'api_keys',
               'addresses', 'subnets', 'vlans', 'vrfs', 'contacts', 'tags',
               'sites', 'users'];
    if ($driver === 'sqlite') {
        $tables[] = 'schema_migrations';
    }
    foreach ($tables as $t) {
        $db->exec("DELETE FROM $t");
        // Rewind the table's auto-increment counter so subsequent inserts
        // start at 1 and the fixture IDs that demo_seed_data passes
        // explicitly land deterministically on every reset. Critical on
        // MySQL: DELETE alone does NOT rewind AUTO_INCREMENT, so on a
        // second reset any row inserted WITHOUT an explicit id (e.g. the
        // audit rows written by audit()) would carry a drifted id and
        // break fixtures that reference it by id.
        if ($driver === 'sqlite') {
            $db->exec("DELETE FROM sqlite_sequence WHERE name='$t'");
        } elseif ($driver === 'mysql') {
            $db->exec("ALTER TABLE $t AUTO_INCREMENT = 1");
        } elseif ($driver === 'pgsql') {
            $db->exec("ALTER SEQUENCE {$t}_id_seq RESTART WITH 1");
        }
    }
    if ($driver === 'sqlite') {
        $db->exec("DELETE FROM sqlite_sequence WHERE name='audit_log'");
    } elseif ($driver === 'mysql') {
        $db->exec("ALTER TABLE audit_log AUTO_INCREMENT = 1");
    } elseif ($driver === 'pgsql') {
        $db->exec("ALTER SEQUENCE audit_log_id_seq RESTART WITH 1");
    }
    apply_migrations($db);
    demo_seed_data($db);
}

function demo_seed_data(PDO $db): void
{
    // --- Sites (id=5,6 are region parents inserted first for self-referential FK) ---
    $si = $db->prepare("INSERT INTO sites (id, name, description, parent_id) VALUES (?,?,?,?)");
    foreach ([
        [5, 'EMEA Region',     'Europe, Middle East & Africa', null],
        [6, 'Americas Region', 'North & South America',        null],
        [1, 'London HQ',       'Primary headquarters',         5],
        [2, 'New York DC',     'East coast data centre',       6],
        [3, 'Sydney Office',   'APAC regional office',         null],
        [4, 'AWS eu-west-1',   'Cloud infrastructure',         5],
        ] as $s) $si->execute($s);

    // --- VRFs ---
    $vr = $db->prepare("INSERT INTO vrfs (id, name, description, rd) VALUES (?,?,?,?)");
    foreach ([
        [1, 'DEFAULT',  'Default global routing table', '65000:0'],
        [2, 'MGMT-VRF', 'Management plane VRF',         '65000:100'],
        ] as $v) $vr->execute($v);

    // --- VLANs ---
    $vl = $db->prepare("INSERT INTO vlans (id, vlan_id, name, description, site_id) VALUES (?,?,?,?,?)");
    foreach ([
        [1, 10,  'Management',    'Out-of-band management VLAN',    1],
        [2, 20,  'Servers',       'Server infrastructure VLAN',      1],
        [3, 30,  'DMZ',           'Demilitarised zone',              1],
        [4, 100, 'Cloud-Connect', 'AWS Direct Connect peering VLAN', 4],
        ] as $v) $vl->execute($v);

    // --- Contacts ---
    $ct = $db->prepare("INSERT INTO contacts (id, name, email, phone, org, note) VALUES (?,?,?,?,?,?)");
    foreach ([
        [1, 'Alice Smith', 'alice@example.com', '+44 20 7946 0001', 'NetOps',   'Primary network contact'],
        [2, 'Bob Jones',   'bob@example.com',   '+44 20 7946 0002', 'DBA',      'Database team lead'],
        [3, 'Carol Wu',    'carol@example.com', '+1 212 555 0103',  'Security', 'Security operations engineer'],
        ] as $c) $ct->execute($c);

    // --- Tags ---
    $tg = $db->prepare("INSERT INTO tags (id, name, colour) VALUES (?,?,?)");
    foreach ([
        [1, 'Production',  '#28a745'],
        [2, 'Development', '#17a2b8'],
        [3, 'Critical',    '#dc3545'],
        [4, 'Monitored',   '#6c757d'],
        ] as $t) $tg->execute($t);

    // #379/#410: helper that binds the ten subnet columns onto a prepared
    // INSERT, routing network_bin through ipam_bind_binary() (PARAM_LOB) so
    // every demo-seeded row is BLOB-affinity from the start. Positional ? in
    // the prepare maps to 1-based bindValue indexes.
    $bindSubnetRow = function (PDOStatement $stmt, int $id, string $cidr, string $netNorm, string $netBin, int $pfx, string $desc, ?int $siteId, ?int $vlanFk, ?int $vrfId): void {
        $stmt->bindValue(1,  $id,      PDO::PARAM_INT);
        $stmt->bindValue(2,  $cidr,    PDO::PARAM_STR);
        $stmt->bindValue(3,  $netNorm, PDO::PARAM_STR);
        ipam_bind_binary($stmt, 4, $netBin);
        $stmt->bindValue(5,  $pfx,     PDO::PARAM_INT);
        $stmt->bindValue(6,  $desc,    PDO::PARAM_STR);
        $stmt->bindValue(7,  $siteId,  $siteId === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
        $stmt->bindValue(8,  $vlanFk,  $vlanFk === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
        $stmt->bindValue(9,  $vrfId,   $vrfId  === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
        $stmt->execute();
    };

    // --- Subnets (IPv4) ---
    // [id, cidr, site_id, vlan_fk, vrf_id, description]
    $sn = $db->prepare(
        "INSERT INTO subnets (id, cidr, ip_version, network, network_bin, prefix, description, site_id, vlan_fk, vrf_id)
         VALUES (?,?,4,?,?,?,?,?,?,?)"
    );
    foreach ([
        [1,  '10.0.0.0/8',    null, null, null, 'RFC-1918 supernet (informational)'],
        [2,  '10.10.0.0/16',  1,    null, null, 'London HQ corporate'],
        [3,  '10.10.1.0/24',  1,    1,    2,    'London management'],
        [4,  '10.10.2.0/24',  1,    2,    null, 'London servers'],
        [5,  '10.10.3.0/27',  1,    3,    null, 'London DMZ'],
        [6,  '10.20.0.0/16',  2,    null, null, 'New York DC corporate'],
        [7,  '10.20.1.0/24',  2,    null, null, 'New York servers'],
        [8,  '10.20.2.0/24',  2,    null, null, 'New York management'],
        [9,  '172.16.0.0/16', 3,    null, null, 'Sydney corporate'],
        [10, '172.16.1.0/24', 3,    null, null, 'Sydney servers'],
        ] as [$id, $cidr, $siteId, $vlanFk, $vrfId, $desc]) {
        [$net, $pfx] = explode('/', $cidr);
        $rawBin  = inet_pton($net) ?: throw new \RuntimeException("Invalid IP: $net");
        $netNorm = inet_ntop(apply_prefix_mask($rawBin, (int)$pfx)) ?: throw new \RuntimeException("inet_ntop failed");
        $netBin  = inet_pton($netNorm) ?: throw new \RuntimeException("inet_pton failed on $netNorm");
        $bindSubnetRow($sn, $id, $cidr, $netNorm, $netBin, (int)$pfx, $desc, $siteId, $vlanFk, $vrfId);
    }

    // --- Subnets (IPv6) ---
    $sn6 = $db->prepare(
        "INSERT INTO subnets (id, cidr, ip_version, network, network_bin, prefix, description, site_id, vlan_fk, vrf_id)
         VALUES (?,?,6,?,?,?,?,?,?,?)"
    );
    foreach ([
        [11, '2001:db8::/32',   1, null, null, 'London HQ IPv6 allocation'],
        [12, '2001:db8:1::/48', 1, null, null, 'London servers IPv6'],
        [13, '2001:db8:2::/64', 2, null, null, 'New York IPv6 segment'],
        ] as [$id, $cidr, $siteId, $vlanFk, $vrfId, $desc]) {
        [$net, $pfx] = explode('/', $cidr);
        $rawBin6  = inet_pton($net) ?: throw new \RuntimeException("Invalid IP: $net");
        $netNorm6 = inet_ntop(apply_prefix_mask($rawBin6, (int)$pfx)) ?: throw new \RuntimeException("inet_ntop failed");
        $netBin6  = inet_pton($netNorm6) ?: throw new \RuntimeException("inet_pton failed on $netNorm6");
        $bindSubnetRow($sn6, $id, $cidr, $netNorm6, $netBin6, (int)$pfx, $desc, $siteId, $vlanFk, $vrfId);
    }

    // --- Subnet tags ---
    $st = $db->prepare("INSERT INTO subnet_tags (subnet_id, tag_id) VALUES (?,?)");
    foreach ([
        [4, 1], [4, 4],   // London servers: Production, Monitored
        [5, 1], [5, 3],   // London DMZ: Production, Critical
        [12, 2],          // London servers IPv6: Development
        ] as $t) $st->execute($t);

    // --- Users ---
    // demo: admin, password 'demo' | readonly-user / netops-user: locked accounts for display
    $us = $db->prepare(
        "INSERT INTO users (username, password_hash, role, is_active, name, email) VALUES (?,?,?,?,?,?)"
    );
    foreach ([
        ['demo',          password_hash('demo', PASSWORD_DEFAULT), 'admin',    1, 'Demo Admin',  'demo@example.com'],
        ['readonly-user', '!disabled',                              'readonly', 1, 'Read Only',   'readonly@example.com'],
        ['netops-user',   '!disabled',                              'netops',   1, 'NetOps User', 'netops@example.com'],
        ] as $u) $us->execute($u);

    // --- Addresses ---
    // [subnet_id, ip, hostname, owner, status, note, mac, expires_at, owner_contact_id]
    // Address IDs assigned sequentially: subnet 3 = 1–9, subnet 4 = 10–27,
    // subnet 5 = 28–37, subnet 7 = 38–45, subnet 8 = 46–49, subnet 10 = 50–54.
    $ai = $db->prepare(
        "INSERT INTO addresses (subnet_id, ip, ip_bin, hostname, owner, status, note, mac, expires_at, owner_contact_id)
         VALUES (?,?,?,?,?,?,?,?,?,?)"
    );
    foreach ([
        // 10.10.1.0/24 — London management (id=1..9)
        [3, '10.10.1.1',   'gw-lon-mgmt',    'NetOps',   'used',     'Default gateway',        'aa:bb:cc:00:01:01', null,         1],
        [3, '10.10.1.2',   'sw-lon-core-01', 'NetOps',   'used',     'Core switch',            'aa:bb:cc:00:01:02', null,         1],
        [3, '10.10.1.3',   'sw-lon-core-02', 'NetOps',   'used',     'Core switch redundant',  'aa:bb:cc:00:01:03', null,         1],
        [3, '10.10.1.10',  'mon-lon-01',     'NetOps',   'used',     'Monitoring server',      '',                  null,         null],
        [3, '10.10.1.20',  'ntp-lon-01',     'NetOps',   'used',     'NTP server',             '',                  null,         null],
        [3, '10.10.1.30',  'dns-lon-01',     'NetOps',   'used',     'Primary DNS',            '',                  null,         null],
        [3, '10.10.1.31',  'dns-lon-02',     'NetOps',   'used',     'Secondary DNS',          '',                  null,         null],
        [3, '10.10.1.50',  '',               '',         'reserved', 'Reserved for IPMI',      '',                  null,         null],
        [3, '10.10.1.51',  '',               '',         'reserved', 'Reserved for IPMI',      '',                  null,         null],
        // 10.10.2.0/24 — London servers (id=10..27)
        [4, '10.10.2.1',   'gw-lon-srv',     'NetOps',   'used',     'Server gateway',         'aa:bb:cc:00:02:01', null,         1],
        [4, '10.10.2.10',  'web-lon-01',     'WebTeam',  'used',     'Web frontend 1',         'de:ad:be:ef:00:01', '2027-06-30', null],
        [4, '10.10.2.11',  'web-lon-02',     'WebTeam',  'used',     'Web frontend 2',         'de:ad:be:ef:00:02', '2027-06-30', null],
        [4, '10.10.2.12',  'web-lon-03',     'WebTeam',  'used',     'Web frontend 3',         'de:ad:be:ef:00:03', '2027-06-30', null],
        [4, '10.10.2.20',  'app-lon-01',     'AppTeam',  'used',     'Application server 1',   '',                  null,         null],
        [4, '10.10.2.21',  'app-lon-02',     'AppTeam',  'used',     'Application server 2',   '',                  null,         null],
        [4, '10.10.2.22',  'app-lon-03',     'AppTeam',  'used',     'Application server 3',   '',                  null,         null],
        [4, '10.10.2.30',  'db-lon-01',      'DBA',      'used',     'Primary database',       'fa:ce:b0:00:00:01', null,         2],
        [4, '10.10.2.31',  'db-lon-02',      'DBA',      'used',     'Replica database',       'fa:ce:b0:00:00:02', null,         2],
        [4, '10.10.2.32',  'db-lon-03',      'DBA',      'used',     'Backup database',        'fa:ce:b0:00:00:03', null,         2],
        [4, '10.10.2.40',  'cache-lon-01',   'AppTeam',  'used',     'Redis cache 1',          '',                  null,         null],
        [4, '10.10.2.41',  'cache-lon-02',   'AppTeam',  'used',     'Redis cache 2',          '',                  null,         null],
        [4, '10.10.2.50',  'storage-lon-01', 'Infra',    'used',     'NFS storage',            '',                  null,         null],
        [4, '10.10.2.51',  'storage-lon-02', 'Infra',    'used',     'NFS storage replica',    '',                  null,         null],
        [4, '10.10.2.100', 'backup-lon-01',  'Infra',    'used',     'Backup server',          '',                  null,         null],
        [4, '10.10.2.200', '',               '',         'free',     '',                        '',                  null,         null],
        [4, '10.10.2.201', '',               '',         'free',     '',                        '',                  null,         null],
        [4, '10.10.2.202', '',               '',         'free',     '',                        '',                  null,         null],
        // 10.10.3.0/27 — London DMZ (id=28..37)
        [5, '10.10.3.1',   'fw-lon-dmz',     'Security', 'used',     'DMZ firewall inside',    '00:50:56:a1:b2:c3', null,         3],
        [5, '10.10.3.2',   'proxy-lon-01',   'Security', 'used',     'Squid proxy',            '00:50:56:a1:b2:c4', null,         3],
        [5, '10.10.3.3',   'proxy-lon-02',   'Security', 'used',     'Squid proxy standby',    '00:50:56:a1:b2:c5', null,         3],
        [5, '10.10.3.4',   'waf-lon-01',     'Security', 'used',     'WAF node 1',             '',                  '2026-12-31', null],
        [5, '10.10.3.5',   'waf-lon-02',     'Security', 'used',     'WAF node 2',             '',                  '2026-12-31', null],
        [5, '10.10.3.6',   'mailgw-lon-01',  'Infra',    'used',     'Mail gateway',           '',                  null,         null],
        [5, '10.10.3.10',  'vpn-lon-01',     'NetOps',   'used',     'VPN concentrator',       '',                  null,         1],
        [5, '10.10.3.20',  '',               '',         'reserved', 'Future load balancer',   '',                  null,         null],
        [5, '10.10.3.21',  '',               '',         'reserved', 'Future load balancer',   '',                  null,         null],
        [5, '10.10.3.30',  '',               '',         'free',     '',                        '',                  null,         null],
        // 10.20.1.0/24 — New York servers (id=38..45)
        [7, '10.20.1.1',   'gw-nyc-srv',     'NetOps',   'used',     'NY server gateway',      '',                  null,         null],
        [7, '10.20.1.10',  'web-nyc-01',     'WebTeam',  'used',     'Web server NY 1',        '',                  '2027-03-31', null],
        [7, '10.20.1.11',  'web-nyc-02',     'WebTeam',  'used',     'Web server NY 2',        '',                  '2027-03-31', null],
        [7, '10.20.1.20',  'app-nyc-01',     'AppTeam',  'used',     'App server NY 1',        '',                  null,         null],
        [7, '10.20.1.21',  'app-nyc-02',     'AppTeam',  'used',     'App server NY 2',        '',                  null,         null],
        [7, '10.20.1.30',  'db-nyc-01',      'DBA',      'used',     'NY database',            '',                  null,         2],
        [7, '10.20.1.40',  'backup-nyc-01',  'Infra',    'used',     'NY backup server',       '',                  null,         null],
        [7, '10.20.1.200', '',               '',         'free',     '',                        '',                  null,         null],
        // 10.20.2.0/24 — New York management (id=46..49)
        [8, '10.20.2.1',   'gw-nyc-mgmt',   'NetOps',   'used',     'NY mgmt gateway',        '',                  null,         1],
        [8, '10.20.2.10',  'mon-nyc-01',    'NetOps',   'used',     'NY monitoring',           '',                  null,         null],
        [8, '10.20.2.20',  'ntp-nyc-01',    'NetOps',   'used',     'NY NTP',                  '',                  null,         null],
        [8, '10.20.2.30',  'dns-nyc-01',    'NetOps',   'used',     'NY DNS primary',          '',                  null,         null],
        // 172.16.1.0/24 — Sydney servers (id=50..54)
        [10, '172.16.1.1',  'gw-syd-srv',   'NetOps',   'used',     'Sydney server gateway',  '',                  null,         null],
        [10, '172.16.1.10', 'web-syd-01',   'WebTeam',  'used',     'Sydney web server',      '',                  null,         null],
        [10, '172.16.1.20', 'app-syd-01',   'AppTeam',  'used',     'Sydney app server',      '',                  null,         null],
        [10, '172.16.1.30', 'db-syd-01',    'DBA',      'used',     'Sydney database',        '',                  null,         null],
        [10, '172.16.1.100','',             '',          'free',     '',                        '',                  null,         null],
        ] as [$sid, $ip, $hn, $ow, $st, $nt, $mac, $exp, $cid]) {
        $bin = inet_pton($ip);
        if ($bin === false) throw new \RuntimeException("inet_pton failed on $ip");
        // #379/#410: bind ip_bin via ipam_bind_binary() (PARAM_LOB) so demo
        // seed rows are BLOB affinity from the start. Other params use
        // bindValue with explicit PARAM_* so the prepare's positional ?
        // placeholders bind cleanly (no execute(array) shorthand).
        $ai->bindValue(1,  $sid, PDO::PARAM_INT);
        $ai->bindValue(2,  $ip,  PDO::PARAM_STR);
        ipam_bind_binary($ai, 3, $bin);
        $ai->bindValue(4,  $hn,  PDO::PARAM_STR);
        $ai->bindValue(5,  $ow,  PDO::PARAM_STR);
        $ai->bindValue(6,  $st,  PDO::PARAM_STR);
        $ai->bindValue(7,  $nt,  PDO::PARAM_STR);
        $ai->bindValue(8,  $mac, PDO::PARAM_STR);
        $ai->bindValue(9,  $exp, $exp === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
        $ai->bindValue(10, $cid, $cid === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
        $ai->execute();
    }

    // --- Address tags ---
    // db-lon-01 id=17: Critical(3), Monitored(4) | db-lon-02 id=18: Monitored(4) | fw-lon-dmz id=28: Critical(3)
    //
    // We look up the target IDs by IP rather than hard-coding them because
    // MySQL and SQLite can disagree on the starting value and increment of
    // AUTO_INCREMENT under some configurations (especially when a schema
    // file has pre-populated another table with explicit IDs — which is
    // exactly what v2.10.0 schema.mysql.sql does for schema_migrations).
    // Locking the address_tags fixtures to the actual inserted row IDs
    // keeps the demo fixture engine-agnostic.
    $idByIp = [];
    $idSt = $db->prepare("SELECT id, ip FROM addresses WHERE ip IN ('10.10.2.30','10.10.2.31','10.10.3.1')");
    $idSt->execute();
    /** @var list<array<string, mixed>> $idRows */
    $idRows = $idSt->fetchAll();
    foreach ($idRows as $r) {
        $idByIp[to_str($r['ip'])] = to_int($r['id']);
    }
    $at = $db->prepare("INSERT INTO address_tags (address_id, tag_id) VALUES (?,?)");
    foreach ([
        // db-lon-01 → Critical + Monitored
        [$idByIp['10.10.2.30'] ?? 0, 3],
        [$idByIp['10.10.2.30'] ?? 0, 4],
        // db-lon-02 → Monitored
        [$idByIp['10.10.2.31'] ?? 0, 4],
        // fw-lon-dmz → Critical
        [$idByIp['10.10.3.1']  ?? 0, 3],
        ] as $t) {
        if ($t[0] > 0) $at->execute($t);
    }

    // --- API Keys ---
    $ak = $db->prepare(
        "INSERT INTO api_keys (name, key_hash, is_active, created_by) VALUES (?,?,?,?)"
    );
    $ak->execute(['Monitoring (active)',   hash('sha256', 'demo-api-key-monitoring-1234567890abcdef'), 1, 'demo']);
    $ak->execute(['Old script (inactive)', hash('sha256', 'demo-api-key-old-script-0987654321fedcba'), 0, 'demo']);

    // --- Audit log (backdated) ---
    // Compute the backdated created_at timestamp in PHP so the SQL stays
    // engine-agnostic. The last tuple element remains a human-readable
    // offset string ('-30 days', '-5 days', '-0 seconds', etc.) that
    // strtotime() parses directly, and we format the result as ISO
    // 'YYYY-MM-DD HH:MM:SS' UTC which both SQLite TEXT storage and
    // MySQL DATETIME accept.
    $al = $db->prepare(
        "INSERT INTO audit_log (action, entity_type, entity_id, username, ip, details, created_at)
         VALUES (?,?,?,?,?,?,?)"
    );
    foreach ([
        ['auth.login',        'user',    1,    'demo',          '192.168.1.100', 'login ok',                               '-30 days'],
        ['subnet.create',     'subnet',  3,    'demo',          '192.168.1.100', 'cidr=10.10.1.0/24',                      '-29 days'],
        ['subnet.create',     'subnet',  4,    'demo',          '192.168.1.100', 'cidr=10.10.2.0/24',                      '-29 days'],
        ['address.create',    'address', 1,    'demo',          '192.168.1.100', 'ip=10.10.1.1 subnet_id=3',               '-28 days'],
        ['address.create',    'address', 2,    'demo',          '192.168.1.100', 'ip=10.10.1.2 subnet_id=3',               '-28 days'],
        ['user.create',       'user',    2,    'demo',          '192.168.1.100', 'username=readonly-user role=readonly',   '-27 days'],
        ['user.create',       'user',    3,    'demo',          '192.168.1.100', 'username=netops-user role=netops',        '-27 days'],
        ['auth.login',        'user',    2,    'readonly-user', '10.10.1.55',    'login ok',                               '-26 days'],
        ['address.update',    'address', 11,   'demo',          '192.168.1.100', 'hostname=web-lon-01',                    '-25 days'],
        ['address.update',    'address', 12,   'demo',          '192.168.1.100', 'hostname=web-lon-02',                    '-25 days'],
        ['subnet.create',     'subnet',  5,    'demo',          '192.168.1.100', 'cidr=10.10.3.0/27',                      '-24 days'],
        ['address.create',    'address', 28,   'demo',          '192.168.1.100', 'ip=10.10.3.1 subnet_id=5',               '-23 days'],
        ['apikey.create',     'api_key', 1,    'demo',          '192.168.1.100', 'name=Monitoring (active)',                '-22 days'],
        ['apikey.create',     'api_key', 2,    'demo',          '192.168.1.100', 'name=Old script (inactive)',              '-22 days'],
        ['apikey.deactivate', 'api_key', 2,    'demo',          '192.168.1.100', '',                                       '-21 days'],
        ['site.create',       'site',    2,    'demo',          '192.168.1.100', 'name=New York DC',                       '-20 days'],
        ['site.create',       'site',    3,    'demo',          '192.168.1.100', 'name=Sydney Office',                     '-20 days'],
        ['auth.login',        'user',    3,    'netops-user',   '10.20.1.55',    'login ok',                               '-19 days'],
        ['address.create',    'address', 38,   'demo',          '192.168.1.100', 'ip=10.20.1.1 subnet_id=7',               '-18 days'],
        ['address.create',    'address', 50,   'demo',          '192.168.1.100', 'ip=172.16.1.1 subnet_id=10',             '-17 days'],
        ['vlan.create',       'vlan',    1,    'demo',          '192.168.1.100', 'vlan_id=10 name=Management',             '-16 days'],
        ['vrf.create',        'vrf',     2,    'demo',          '192.168.1.100', 'name=MGMT-VRF rd=65000:100',             '-16 days'],
        ['contact.create',    'contact', 1,    'demo',          '192.168.1.100', 'name=Alice Smith',                       '-15 days'],
        ['contact.create',    'contact', 2,    'demo',          '192.168.1.100', 'name=Bob Jones',                         '-15 days'],
        ['auth.login_failed', 'user',    null, '',              '203.0.113.50',  'username=hacker',                        '-15 days'],
        ['auth.login_failed', 'user',    null, '',              '203.0.113.50',  'username=hacker',                        '-15 days'],
        ['auth.login_blocked','user',    null, '',              '203.0.113.50',  'ip=203.0.113.50',                        '-15 days'],
        ['tag.create',        'tag',     1,    'demo',          '192.168.1.100', 'name=Production colour=#28a745',         '-14 days'],
        ['address.update',    'address', 35,   'demo',          '192.168.1.100', 'status=reserved',                        '-10 days'],
        ['export.csv',        'address', null, 'demo',          '192.168.1.100', 'subnet_id=4',                            '-8 days'],
        ['address.create',    'address', 51,   'demo',          '192.168.1.100', 'ip=172.16.1.10 subnet_id=10',            '-5 days'],
        ['auth.login',        'user',    1,    'demo',          '192.168.1.100', 'login ok',                               '-3 days'],
        ['address.bulk_update','address',null, 'demo',          '192.168.1.100', 'subnet_id=4 selected=3 affected=3',      '-2 days'],
        ['auth.login',        'user',    1,    'demo',          '192.168.1.100', 'login ok',                               '-1 day'],
        ['auth.login',        'user',    1,    'demo',          '192.168.1.100', 'login ok',                               '-0 seconds'],
        ] as $e) {
        // Replace the human-readable offset (last element) with an
        // absolute 'YYYY-MM-DD HH:MM:SS' UTC timestamp computed in PHP.
        $offset = array_pop($e);
        $ts = strtotime((string)$offset);
        $e[] = ($ts !== false) ? gmdate('Y-m-d H:i:s', $ts) : gmdate('Y-m-d H:i:s');
        $al->execute($e);
    }

    // --- Address history ---
    // Address IDs looked up by IP so we don't hardcode AUTO_INCREMENT
    // positions (same rationale as the address_tags block above).
    // Backdated created_at timestamps computed in PHP because the SQLite
    // relative-time modifier syntax is not portable to MySQL.
    $histIds = [];
    $histIdSt = $db->prepare("SELECT id, ip FROM addresses WHERE ip IN ('10.10.1.1','10.10.2.10','10.10.2.12','10.10.2.20','10.10.3.1','10.10.3.20')");
    $histIdSt->execute();
    /** @var list<array<string, mixed>> $histIdRows */
    $histIdRows = $histIdSt->fetchAll();
    foreach ($histIdRows as $r) {
        $histIds[to_str($r['ip'])] = to_int($r['id']);
    }

    $hist = $db->prepare(
        "INSERT INTO address_history (address_id, subnet_id, ip, action, username, client_ip, before_json, after_json, created_at)
         VALUES (?,?,?,?,?,?,?,?,?)"
    );
    foreach ([
        // gw-lon-mgmt
        [$histIds['10.10.1.1']  ?? 0, 3, '10.10.1.1',  'create', 'demo', '192.168.1.100', null,
         '{"hostname":"gw-lon-mgmt","owner":"NetOps","status":"used","note":"Default gateway","mac":"aa:bb:cc:00:01:01"}',
         '-28 days'],
        // web-lon-01
        [$histIds['10.10.2.10'] ?? 0, 4, '10.10.2.10', 'create', 'demo', '192.168.1.100', null,
         '{"hostname":"","owner":"WebTeam","status":"used","note":"","mac":""}',
         '-28 days'],
        [$histIds['10.10.2.10'] ?? 0, 4, '10.10.2.10', 'update', 'demo', '192.168.1.100',
         '{"hostname":"","owner":"WebTeam","status":"used","note":"","mac":""}',
         '{"hostname":"web-lon-01","owner":"WebTeam","status":"used","note":"Web frontend 1","mac":"de:ad:be:ef:00:01","expires_at":"2027-06-30"}',
         '-25 days'],
        // web-lon-03
        [$histIds['10.10.2.12'] ?? 0, 4, '10.10.2.12', 'create', 'demo', '192.168.1.100', null,
         '{"hostname":"web-lon-03","owner":"WebTeam","status":"used","note":"Web frontend 3","mac":"de:ad:be:ef:00:03"}',
         '-28 days'],
        // app-lon-01
        [$histIds['10.10.2.20'] ?? 0, 4, '10.10.2.20', 'create', 'demo', '192.168.1.100', null,
         '{"hostname":"app-lon-01","owner":"AppTeam","status":"used","note":"Application server 1","mac":""}',
         '-28 days'],
        // fw-lon-dmz
        [$histIds['10.10.3.1']  ?? 0, 5, '10.10.3.1',  'create', 'demo', '192.168.1.100', null,
         '{"hostname":"fw-lon-dmz","owner":"Security","status":"used","note":"DMZ firewall inside","mac":"00:50:56:a1:b2:c3"}',
         '-23 days'],
        // 10.10.3.20 (future load balancer)
        [$histIds['10.10.3.20'] ?? 0, 5, '10.10.3.20', 'create', 'demo', '192.168.1.100', null,
         '{"hostname":"","owner":"","status":"free","note":"","mac":""}',
         '-23 days'],
        [$histIds['10.10.3.20'] ?? 0, 5, '10.10.3.20', 'update', 'demo', '192.168.1.100',
         '{"hostname":"","owner":"","status":"free","note":"","mac":""}',
         '{"hostname":"","owner":"","status":"reserved","note":"Future load balancer","mac":""}',
         '-10 days'],
        ] as $h) {
        if ($h[0] === 0) continue;
        // Replace the human-readable offset with an absolute UTC timestamp.
        $offset = array_pop($h);
        $ts = strtotime((string)$offset);
        $h[] = ($ts !== false) ? gmdate('Y-m-d H:i:s', $ts) : gmdate('Y-m-d H:i:s');
        $hist->execute($h);
    }

    // v2.11.0 #388: advance every identity sequence past the explicit IDs
    // the seed just inserted. Postgres `GENERATED BY DEFAULT AS IDENTITY`
    // columns accept explicit ids at INSERT time, but do NOT auto-advance
    // the backing sequence — so a subsequent implicit insert would pick
    // id=1 and collide against our fixture ids. SQLite and MySQL handle
    // this automatically via ROWID / AUTO_INCREMENT.
    if (ipam_dialect()->driver_name() === 'pgsql') {
        $seedTables = [
            'sites', 'vrfs', 'vlans', 'vlan_ranges', 'subnets', 'contacts',
            'tags', 'addresses', 'api_keys', 'users', 'aggregates',
            'pd_pools', 'pd_delegations', 'scan_schedules', 'scan_results',
            'address_history', 'audit_log',
        ];
        foreach ($seedTables as $t) {
            $db->exec(
                "SELECT setval(pg_get_serial_sequence('$t', 'id'), "
                . "COALESCE((SELECT MAX(id) FROM $t), 1), "
                . "(SELECT MAX(id) FROM $t) IS NOT NULL)"
            );
        }
    }
}

/* ---------------- IP helpers ---------------- */

/** @return array{version: int, network: string, prefix: int, net_bin: string}|null */
function parse_cidr(string $cidr): ?array
{
    $cidr = trim($cidr);
    if (strpos($cidr, '/') === false) return null;
    [$ip, $prefixStr] = explode('/', $cidr, 2);

    $ip = trim($ip);
    $prefixStr = trim($prefixStr);

    $ipBin = @inet_pton($ip);
    if ($ipBin === false) return null;

    $len = strlen($ipBin);
    $version = ($len === 4) ? 4 : (($len === 16) ? 6 : 0);
    if ($version === 0) return null;

    if (!ctype_digit($prefixStr)) return null;
    $prefix = (int)$prefixStr;
    $max = ($version === 4) ? 32 : 128;
    if ($prefix < 0 || $prefix > $max) return null;

    $netBin = apply_prefix_mask($ipBin, $prefix);
    $network = inet_ntop($netBin);
    if ($network === false) return null;

    return [
        'version' => $version,
        'network' => $network,
        'prefix' => $prefix,
        'net_bin' => $netBin,
    ];
}

function apply_prefix_mask(string $ipBin, int $prefix): string
{
    $len = strlen($ipBin);
    $maxBits = ($len === 4) ? 32 : 128;
    $prefix = max(0, min($prefix, $maxBits));

    $fullBytes = intdiv($prefix, 8);
    $remBits = $prefix % 8;

    $out = '';
    for ($i = 0; $i < $len; $i++) {
        $b = ord($ipBin[$i]);
        if ($i < $fullBytes) $out .= chr($b);
        elseif ($i === $fullBytes && $remBits !== 0) {
            $mask = (0xFF << (8 - $remBits)) & 0xFF;
            $out .= chr($b & $mask);
        } else $out .= chr(0);
    }
    return $out;
}

/**
 * Compute the IPv4 broadcast address (binary) for a given network+prefix.
 *
 * Returns null when the concept does not apply:
 *   - IPv6 networks (no broadcast)
 *   - /32 (single host)
 *   - /31 (RFC 3021 point-to-point; both addresses are usable)
 *
 * @param string $netBin 4-byte IPv4 network address (output of apply_prefix_mask)
 */
function ipam_compute_broadcast_bin(string $netBin, int $prefix): ?string
{
    if (strlen($netBin) !== 4) return null;       // IPv6 has no broadcast
    if ($prefix < 0 || $prefix >= 31) return null; // /31, /32 have no broadcast
    $hostBits = 32 - $prefix;
    $out = '';
    for ($i = 0; $i < 4; $i++) {
        $byteIdx = 3 - $i; // little-endian walk from LSB
        $n = ord($netBin[$byteIdx]);
        if ($hostBits >= 8) {
            $out = chr(0xFF) . $out;
            $hostBits -= 8;
        } elseif ($hostBits > 0) {
            $lowMask = (1 << $hostBits) - 1;
            $out = chr($n | $lowMask) . $out;
            $hostBits = 0;
        } else {
            $out = chr($n) . $out;
        }
    }
    return $out;
}

function ipam_compute_gateway_bin(string $netBin, int $prefix): ?string
{
    if (strlen($netBin) !== 4) return null;
    if ($prefix < 0 || $prefix > 30) return null;
    $int = ipv4_bin_to_int($netBin);
    return ipv4_int_to_bin($int + 1);
}

function ip_in_cidr(string $ip, string $network, int $prefix): bool
{
    $ipBin = @inet_pton(trim($ip));
    $netBin = @inet_pton(trim($network));
    if ($ipBin === false || $netBin === false) return false;
    if (strlen($ipBin) !== strlen($netBin)) return false;
    return hash_equals(apply_prefix_mask($ipBin, $prefix), $netBin);
}

/** @return array{ip: string, bin: string, version: int}|null */
function normalize_ip(string $ip): ?array
{
    $bin = @inet_pton(trim($ip));
    if ($bin === false) return null;
    $normalized = inet_ntop($bin);
    if ($normalized === false) return null;
    return ['ip' => $normalized, 'bin' => $bin, 'version' => (strlen($bin) === 4) ? 4 : 6];
}

function normalize_status(?string $s): string
{
    $s = strtolower(trim((string)$s));
    if ($s === '') return 'used';
    if (in_array($s, ['used','reserved','free'], true)) return $s;
    if (in_array($s, ['inuse','in-use','active'], true)) return 'used';
    if (in_array($s, ['res','reservation'], true)) return 'reserved';
    if (in_array($s, ['avail','available','unused'], true)) return 'free';
    return 'used';
}

/* ---------------- IPv4 helpers ---------------- */

function ipv4_bin_to_int(string $bin): int
{
    $unpacked = unpack('N', $bin);
    $n = $unpacked !== false ? $unpacked[1] : 0;
    return to_int($n & 0xFFFFFFFF);
}

function ipv4_int_to_bin(int $n): string
{
    $n = $n & 0xFFFFFFFF;
    return pack('N', $n);
}

function ipv4_int_to_text(int $n): string
{
    return inet_ntop(ipv4_int_to_bin($n)) ?: '';
}

function ipv4_assignable_count(int $prefix): int
{
    if ($prefix >= 32) return 1;
    if ($prefix === 31) return 2;
    $hostBits = 32 - $prefix;
    $total = ($hostBits === 32) ? 4294967296 : (1 << $hostBits);
    $assignable = $total - 2;
    return ($assignable > 0) ? (int)$assignable : 0;
}

/* ── Subnet tree + utilization helpers (shared by subnets.php, dashboard, API) ── */

function subnet_contains_bin(string $parentNetBin, int $parentPrefix, string $childNetBin): bool
{
    $masked = apply_prefix_mask($childNetBin, $parentPrefix);
    return hash_equals($masked, $parentNetBin);
}

/**
 * @param array<int, array<string, mixed>> $rows
 * @return array{roots: list<int>, children: array<int, list<int>>, byId: array<int, array<string, mixed>>}
 */
function build_subnet_tree(array $rows): array
{
    $byId = [];
    foreach ($rows as $r) $byId[to_int($r['id'])] = $r;

    $sorted = $byId;
    uasort($sorted, function(array $a, array $b): int {
        $vrfa = $a['vrf_id'] !== null ? to_int($a['vrf_id']) : 0;
        $vrfb = $b['vrf_id'] !== null ? to_int($b['vrf_id']) : 0;
        if ($vrfa !== $vrfb) return $vrfa <=> $vrfb;
        $va = to_int($a['ip_version']); $vb = to_int($b['ip_version']);
        if ($va !== $vb) return $va <=> $vb;
        $pa = to_int($a['prefix']); $pb = to_int($b['prefix']);
        if ($pa !== $pb) return $pa <=> $pb;
        return strcmp(to_str($a['network_bin']), to_str($b['network_bin']));
    });

    $children = [];
    $roots = [];
    $stack = [];

    foreach ($sorted as $id => $row) {
        $ver    = to_int($row['ip_version']);
        $prefix = to_int($row['prefix']);
        $netBin = to_str($row['network_bin']);
        $curVrf = $row['vrf_id'] !== null ? to_int($row['vrf_id']) : 0;

        while (!empty($stack)) {
            $top    = end($stack);
            $topVrf = $top['vrf_id'] !== null ? to_int($top['vrf_id']) : 0;
            if ($topVrf !== $curVrf || to_int($top['ip_version']) !== $ver) {
                $stack = [];
                break;
            }
            if (to_int($top['prefix']) < $prefix
                && subnet_contains_bin(to_str($top['network_bin']), to_int($top['prefix']), $netBin)) {
                break;
            }
            array_pop($stack);
        }

        if (!empty($stack)) {
            $parent = end($stack);
            $children[to_int($parent['id'])][] = $id;
        } else {
            $roots[] = $id;
        }

        $stack[] = ['id' => $id, 'ip_version' => $ver, 'prefix' => $prefix, 'network_bin' => $netBin, 'vrf_id' => $row['vrf_id']];
    }

    $cmpFn = function(int $a, int $b) use ($byId): int {
        $ra = $byId[$a]; $rb = $byId[$b];
        $va = to_int($ra['ip_version']); $vb = to_int($rb['ip_version']);
        if ($va !== $vb) return $va <=> $vb;
        $c = strcmp(to_str($ra['network_bin']), to_str($rb['network_bin']));
        if ($c !== 0) return $c;
        return to_int($ra['prefix']) <=> to_int($rb['prefix']);
    };

    usort($roots, $cmpFn);
    foreach ($children as $pid => $arr) {
        usort($arr, $cmpFn);
        $children[$pid] = $arr;
    }

    return ['roots' => $roots, 'children' => $children, 'byId' => $byId];
}

/** @return array<int, array{used: int, reserved: int, free: int, total: int}> */
function subnet_direct_counts(PDO $db): array
{
    $st = $db->prepare("SELECT subnet_id, status, COUNT(*) AS c FROM addresses GROUP BY subnet_id, status");
    $st->execute();
    $out = [];
    foreach ($st->fetchAll() as $r) {
        $sid = to_int($r['subnet_id']);
        $status = to_str($r['status']);
        $c = to_int($r['c']);
        $out[$sid] ??= ['used'=>0,'reserved'=>0,'free'=>0,'total'=>0];
        if (isset($out[$sid][$status])) $out[$sid][$status] += $c;
        $out[$sid]['total'] += $c;
    }
    return $out;
}

/**
 * @param array{roots: list<int>, children: array<int, list<int>>, byId: array<int, array<string, mixed>>} $tree
 * @param array<int, array{used: int, reserved: int, free: int, total: int}> $directCounts
 * @return array<int, array{used: int, reserved: int, free: int, total: int}>
 */
function subnet_aggregated_counts(array $tree, array $directCounts): array
{
    $children = $tree['children'];
    $agg = [];

    $sumNode = function(int $id) use (&$sumNode, &$agg, $children, $directCounts): array {
        if (isset($agg[$id])) return $agg[$id];

        $base = $directCounts[$id] ?? ['used'=>0,'reserved'=>0,'free'=>0,'total'=>0];
        $sum = $base;

        foreach (($children[$id] ?? []) as $cid) {
            $c = $sumNode((int)$cid);
            $sum['used'] += $c['used'];
            $sum['reserved'] += $c['reserved'];
            $sum['free'] += $c['free'];
            $sum['total'] += $c['total'];
        }
        return $agg[$id] = $sum;
    };

    foreach ($tree['byId'] as $id => $_row) $sumNode((int)$id);
    return $agg;
}

function ipv4_broadcast_bin(string $netBin, int $prefix): string
{
    $hostBits = 32 - $prefix;
    if ($hostBits <= 0) return $netBin;

    $unpacked = unpack('N', $netBin);
    $n = $unpacked !== false ? $unpacked[1] : 0;
    $hostMask = ($hostBits === 32) ? 0xFFFFFFFF : ((1 << $hostBits) - 1);
    $b = ($n | $hostMask) & 0xFFFFFFFF;

    return pack('N', $b);
}

/** @return array<int, array{assignable_total: int, assigned_assignable: int, unassigned_assignable: int}> */
function ipv4_unassigned_summary(PDO $db): array
{
    $st = $db->prepare("SELECT id, prefix, network_bin FROM subnets WHERE ip_version=4");
    $st->execute();
    /** @var list<array<string, mixed>> $subs */
    $subs = $st->fetchAll();
    if (!$subs) return [];

    $cntSt = $db->prepare(
        "SELECT a.subnet_id, COUNT(*) AS c
         FROM addresses a JOIN subnets s ON s.id = a.subnet_id
         WHERE s.ip_version = 4 AND a.status IN ('used','reserved')
         GROUP BY a.subnet_id"
    );
    $cntSt->execute();
    $countBySubnet = [];
    foreach ($cntSt->fetchAll() as $r) {
        $countBySubnet[to_int($r['subnet_id'])] = to_int($r['c']);
    }

    $excludedBySubnet = [];

    $netExcl = $db->query(
        "SELECT a.subnet_id, COUNT(*) AS c
         FROM addresses a
         JOIN subnets s ON s.id = a.subnet_id
         WHERE s.ip_version = 4 AND s.prefix <= 30
           AND a.status IN ('used','reserved')
           AND a.ip_bin = s.network_bin
         GROUP BY a.subnet_id"
    );
    if ($netExcl !== false) {
        foreach ($netExcl->fetchAll() as $r) {
            $excludedBySubnet[to_int($r['subnet_id'])] = to_int($r['c']);
        }
    }

    /** @var array<int, string> $bcastBins */
    $bcastBins = [];
    foreach ($subs as $s) {
        $sid    = to_int($s['id']);
        $prefix = to_int($s['prefix']);
        if ($prefix <= 30 && isset($countBySubnet[$sid])) {
            $bcastBins[$sid] = ipv4_broadcast_bin(to_str($s['network_bin']), $prefix);
        }
    }
    if ($bcastBins !== []) {
        $binType = ipam_dialect()->binary_type(4);
        $db->exec("CREATE TEMPORARY TABLE IF NOT EXISTS _bcast_excl (subnet_id INTEGER NOT NULL, bcast_bin $binType NOT NULL)");
        $db->exec("DELETE FROM _bcast_excl");
        $ins = $db->prepare("INSERT INTO _bcast_excl (subnet_id, bcast_bin) VALUES (:s, :b)");
        foreach ($bcastBins as $sid => $bcast) {
            $ins->bindValue(':s', $sid, PDO::PARAM_INT);
            ipam_bind_binary($ins, ':b', $bcast);
            $ins->execute();
        }
        $bcastExcl = $db->query(
            "SELECT a.subnet_id, COUNT(*) AS c
             FROM addresses a
             JOIN _bcast_excl t ON t.subnet_id = a.subnet_id AND t.bcast_bin = a.ip_bin
             WHERE a.status IN ('used','reserved')
             GROUP BY a.subnet_id"
        );
        if ($bcastExcl !== false) {
            foreach ($bcastExcl->fetchAll() as $r) {
                $sid = to_int($r['subnet_id']);
                $excludedBySubnet[$sid] = ($excludedBySubnet[$sid] ?? 0) + to_int($r['c']);
            }
        }
    }

    $out = [];
    foreach ($subs as $s) {
        $sid    = to_int($s['id']);
        $prefix = to_int($s['prefix']);

        $assignableTotal = ipv4_assignable_count($prefix);
        $assignedCount   = $countBySubnet[$sid] ?? 0;

        if ($prefix <= 30 && $assignedCount > 0) {
            $excluded = $excludedBySubnet[$sid] ?? 0;
            $assignedAssignable = $assignedCount - $excluded;
        } else {
            $assignedAssignable = $assignedCount;
        }

        if ($assignedAssignable < 0) $assignedAssignable = 0;
        $unassigned = $assignableTotal - $assignedAssignable;
        if ($unassigned < 0) $unassigned = 0;

        $out[$sid] = [
            'assignable_total'      => (int)$assignableTotal,
            'assigned_assignable'   => (int)$assignedAssignable,
            'unassigned_assignable' => (int)$unassigned,
        ];
    }
    return $out;
}

/**
 * @param array{roots: list<int>, children: array<int, list<int>>, byId: array<int, array<string, mixed>>} $tree
 * @param array<int, array{assignable_total: int, assigned_assignable: int, unassigned_assignable: int}> $directUnassigned
 * @return array<int, array{assignable_total: int, assigned_assignable: int, unassigned_assignable: int}>
 */
function ipv4_unassigned_aggregated(array $tree, array $directUnassigned): array
{
    $children = $tree['children'];
    $agg = [];

    $sumNode = function(int $id) use (&$sumNode, &$agg, $children, $directUnassigned, $tree): array {
        if (isset($agg[$id])) return $agg[$id];

        $ipVer = to_int($tree['byId'][$id]['ip_version'] ?? 0);
        $base = ($ipVer === 4 && isset($directUnassigned[$id]))
            ? $directUnassigned[$id]
            : ['assignable_total' => 0, 'assigned_assignable' => 0, 'unassigned_assignable' => 0];

        $sum = $base;
        foreach (($children[$id] ?? []) as $cid) {
            $c = $sumNode((int)$cid);
            $sum['assignable_total']      += $c['assignable_total'];
            $sum['assigned_assignable']   += $c['assigned_assignable'];
            $sum['unassigned_assignable'] += $c['unassigned_assignable'];
        }
        return $agg[$id] = $sum;
    };

    foreach ($tree['byId'] as $id => $_row) $sumNode((int)$id);
    return $agg;
}

/**
 * Find the first unassigned IPv4 host address in a subnet.
 * Returns the IP as text, or null if none available.
 */
function find_next_available_ipv4(PDO $db, int $subnetId, string $network, int $prefix): ?string
{
    if ($prefix > 32 || $prefix < 8) return null;
    $networkBin = inet_pton($network);
    if ($networkBin === false) return null;
    $netInt = ipv4_bin_to_int($networkBin);
    $first  = ($prefix >= 31) ? $netInt : $netInt + 1;
    $last   = ($prefix >= 31) ? $netInt + ((1 << (32 - $prefix)) - 1)
                              : $netInt + ((1 << (32 - $prefix)) - 1) - 1;

    // Fetch all used IPs in this subnet as a set
    $st = $db->prepare("SELECT ip FROM addresses WHERE subnet_id = :sid");
    $st->execute([':sid' => $subnetId]);
    $used = [];
    foreach ($st->fetchAll() as $r) $used[to_str($r['ip'])] = true;

    for ($i = $first; $i <= $last; $i++) {
        $ip = ipv4_int_to_text($i);
        if (!isset($used[$ip])) return $ip;
    }
    return null;
}

function ipv4_broadcast_int(int $networkInt, int $prefix): int
{
    $hostBits = 32 - $prefix;
    if ($hostBits <= 0) return $networkInt;
    $hostMask = ($hostBits === 32) ? 0xFFFFFFFF : ((1 << $hostBits) - 1);
    return to_int(($networkInt | $hostMask) & 0xFFFFFFFF);
}

/* ---------------- IPv6 enumeration helpers ---------------- */

/**
 * Increment a 16-byte IPv6 binary address by 1.
 * Returns all-zeros if the address overflows (all-0xFF).
 */
function ipv6_bin_increment(string $bin): string
{
    /** @var array<int, int> $bytes */
    $bytes = array_values(unpack('C16', $bin) ?: []);
    for ($i = 15; $i >= 0; $i--) {
        if ($bytes[$i] < 255) {
            $bytes[$i]++;
            return pack('C16', ...$bytes);
        }
        $bytes[$i] = 0;
    }
    return pack('C16', ...array_fill(0, 16, 0));
}

/**
 * Return the first $n unassigned IPv6 host addresses in a subnet.
 * Scans at most ($n + count(assigned) + 1) candidates from the first host address.
 *
 * @return list<string>
 */
function ipv6_enumerate_first_n(PDO $db, int $subnetId, string $networkBin, int $prefix, int $n): array
{
    if ($prefix >= 128) {
        $ip = inet_ntop($networkBin) ?: '';
        $st = $db->prepare("SELECT id FROM addresses WHERE subnet_id = :sid AND ip = :ip LIMIT 1");
        $st->execute([':sid' => $subnetId, ':ip' => $ip]);
        return ($ip !== '' && $st->fetch() === false) ? [$ip] : [];
    }

    $st = $db->prepare("SELECT ip FROM addresses WHERE subnet_id = :sid");
    $st->execute([':sid' => $subnetId]);
    $assigned = [];
    foreach ($st->fetchAll() as $r) $assigned[to_str($r['ip'])] = true;

    $current = ipv6_bin_increment($networkBin);
    $scanLimit = $n + count($assigned) + 1;
    $result = [];

    for ($i = 0; $i < $scanLimit && count($result) < $n; $i++) {
        $ip = inet_ntop($current) ?: '';
        if ($ip !== '' && !isset($assigned[$ip])) {
            $result[] = $ip;
        }
        $current = ipv6_bin_increment($current);
    }

    return $result;
}

/* ---------------- CSV import helpers ---------------- */

/** @param IpamConfig $config */
function import_max_bytes(array $config): int
{
    $mb = to_int(ipam_setting('limits.import_csv_max_mb'));
    if ($mb < 5) $mb = 5;
    if ($mb > 50) $mb = 50;
    return $mb * 1024 * 1024;
}

function tmp_dir(): string
{
    return __DIR__ . '/data/tmp';
}

function ensure_tmp_dir(): void
{
    $d = tmp_dir();
    if (!is_dir($d)) mkdir($d, 0700, true);
}

function cleanup_tmp_import_files(int $ttlSeconds): int
{
    ensure_tmp_dir();
    $now = time();
    $deleted = 0;

    foreach (new DirectoryIterator(tmp_dir()) as $f) {
        if ($f->isDot() || !$f->isFile()) continue;
        $name = $f->getFilename();
        if (!preg_match('~^import-[a-f0-9]{16}\.csv$~', $name)) continue;

        $age = $now - $f->getMTime();
        if ($age > $ttlSeconds) {
            @unlink($f->getPathname()); // nosemgrep: php.lang.security.unlink-use.unlink-use
            $deleted++;
        }
    }
    return $deleted;
}

/* -------- Import plan helpers -------- */

function import_plan_dir(): string
{
    return tmp_dir();
}

/** @param array<string, mixed> $plan */
function save_import_plan(array $plan): string
{
    ensure_tmp_dir();
    $path = import_plan_dir() . '/import-plan-' . bin2hex(random_bytes(8)) . '.json';
    $json = json_encode($plan, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    if ($json === false) throw new RuntimeException('Failed to encode import plan');
    if (file_put_contents($path, $json) === false) {
        throw new RuntimeException('Failed to write import plan');
    }
    @chmod($path, 0600);
    return $path;
}

/** @return array<string, mixed> */
function load_import_plan(string $path): array
{
    if (!is_file($path)) throw new RuntimeException('Import plan file not found');
    $json = file_get_contents($path);
    if ($json === false) throw new RuntimeException('Failed to read import plan');
    $data = json_decode($json, true);
    if (!is_array($data)) throw new RuntimeException('Invalid import plan');
    /** @var array<string, mixed> $data */
    return $data;
}

function delete_import_plan(string $path): void
{
    if ($path !== '' && is_file($path)) {
        @unlink($path); // nosemgrep: php.lang.security.unlink-use.unlink-use
    }
}

function cleanup_tmp_import_plans(int $ttlSeconds): int
{
    ensure_tmp_dir();
    $now = time();
    $deleted = 0;

    foreach (new DirectoryIterator(tmp_dir()) as $f) {
        if ($f->isDot() || !$f->isFile()) continue;
        $name = $f->getFilename();
        if (!preg_match('~^import-plan-[a-f0-9]{16}\.json$~', $name)) continue;

        $age = $now - $f->getMTime();
        if ($age > $ttlSeconds) {
            @unlink($f->getPathname()); // nosemgrep: php.lang.security.unlink-use.unlink-use
            $deleted++;
        }
    }
    return $deleted;
}

function detect_csv_delimiter(string $sample): string
{
    $candidates = ["," , ";" , "\t" , "|"];
    $best = ",";
    $bestCount = -1;

    foreach ($candidates as $d) {
        $lines = preg_split("/\r\n|\n|\r/", $sample) ?: [];
        $counts = [];
        foreach (array_slice($lines, 0, 10) as $line) {
            if ($line === '') continue;
            $counts[] = count(str_getcsv($line, $d, '"', ''));
        }
        if (!$counts) continue;
        $avg = array_sum($counts) / count($counts);
        if ($avg > $bestCount) {
            $bestCount = $avg;
            $best = $d;
        }
    }
    return $best;
}

/** @return list<list<string>> */
function csv_read_preview(string $path, string $delimiter, int $maxRows = 20): array
{
    $fh = fopen($path, 'rb');
    if (!$fh) throw new RuntimeException("Cannot open upload");
    $rows = [];
    while (!feof($fh) && count($rows) < $maxRows) {
        $row = fgetcsv($fh, 0, $delimiter, '"', '');
        if ($row === false) break;
        $row = array_map('strval', $row);
        if (count($row) === 1 && trim($row[0]) === '') continue;
        $rows[] = $row;
    }
    fclose($fh);
    return $rows;
}

function netmask_to_prefix(string $mask): ?int
{
    $bin = @inet_pton(trim($mask));
    if ($bin === false || strlen($bin) !== 4) return null;

    $unpacked = unpack('N', $bin);
    $n = $unpacked !== false ? $unpacked[1] : 0;
    $prefix = 0;
    $seenZero = false;

    for ($i = 31; $i >= 0; $i--) {
        $bit = ($n >> $i) & 1;
        if ($bit === 1) {
            if ($seenZero) return null;
            $prefix++;
        } else {
            $seenZero = true;
        }
    }
    return $prefix;
}

/**
 * @param array{ip: string, bin: string, version: int} $normIp
 * @return array<string, mixed>|null
 */
function find_containing_subnet(PDO $db, array $normIp): ?array
{
    static $cache = [];
    $ver = to_int($normIp['version']);
    if (!isset($cache[$ver])) {
        $st = $db->prepare("SELECT id, network, prefix, ip_version FROM subnets WHERE ip_version = :v ORDER BY prefix DESC");
        $st->execute([':v' => $ver]);
        $cache[$ver] = $st->fetchAll();
    }
    foreach ($cache[$ver] as $s) {
        if (ip_in_cidr($normIp['ip'], to_str($s['network']), to_int($s['prefix']))) return $s;
    }
    return null;
}

function ensure_subnet_exists(PDO $db, string $cidr, string $description = ''): int
{
    $p = parse_cidr($cidr);
    if (!$p) throw new RuntimeException("Invalid CIDR to create: $cidr");

    $normalized = $p['network'] . '/' . $p['prefix'];

    $st = $db->prepare("SELECT id FROM subnets WHERE cidr = :c");
    $st->execute([':c' => $normalized]);
    /** @var array<string, mixed>|false $row */
    $row = $st->fetch();
    if ($row) return to_int($row['id']);

    // #379/#410: bind network_bin via ipam_bind_binary() (PARAM_LOB).
    $ins = $db->prepare("INSERT INTO subnets (cidr, ip_version, network, network_bin, prefix, description)
                         VALUES (:cidr,:ver,:net,:nb,:pre,:d)");
    $ins->bindValue(':cidr', $normalized,    PDO::PARAM_STR);
    $ins->bindValue(':ver',  $p['version'],  PDO::PARAM_INT);
    $ins->bindValue(':net',  $p['network'],  PDO::PARAM_STR);
    ipam_bind_binary($ins, ':nb', $p['net_bin']);
    $ins->bindValue(':pre',  $p['prefix'],   PDO::PARAM_INT);
    $ins->bindValue(':d',    $description,   PDO::PARAM_STR);
    $ins->execute();

    return ipam_last_insert_id($db, 'subnets');
}

/** @param array{ip: string, bin: string, version: int} $normIp */
function cidr_from_ip_and_prefix(array $normIp, int $prefix): string
{
    $max = ($normIp['version'] === 4) ? 32 : 128;
    if ($prefix < 0 || $prefix > $max) throw new RuntimeException("Bad prefix");
    $netBin = apply_prefix_mask($normIp['bin'], $prefix);
    return inet_ntop($netBin) . '/' . $prefix;
}

/* ---------------- Subnet overlap detection ---------------- */

/**
 * Detect parent/child relationships for a proposed CIDR against existing subnets.
 *
 * In valid CIDR math, two subnets of different prefix lengths either have a strict
 * parent/child containment relationship or are completely disjoint — partial overlap
 * is impossible. Exact duplicates are prevented by the DB UNIQUE constraint on cidr.
 *
 * Returns:
 *   'parents'  — existing subnets that contain the proposed CIDR (new is a child)
 *   'children' — existing subnets that fall inside the proposed CIDR (new is a parent)
 *
 * Both are informational warnings; neither case blocks the operation, as hierarchical
 * nesting is the expected use-case. Pass $excludeId when checking an update so the
 * subnet being edited is not compared against itself.
 *
 * @return array{parents: list<string>, children: list<string>}
 */
function detect_subnet_overlaps(PDO $db, string $cidr, ?int $excludeId = null, ?int $vrfId = null): array
{
    $p = parse_cidr($cidr);
    if (!$p) return ['parents' => [], 'children' => []];

    $ver    = to_int($p['version']);
    $prefix = to_int($p['prefix']);
    $netBin = to_str($p['net_bin']);

    // Scope overlap detection to the same VRF (NULL = global routing table).
    // SQLite's IS operator handles NULL equality correctly.
    $sql    = "SELECT id, cidr, prefix, network_bin FROM subnets WHERE ip_version = :v AND " . ipam_dialect()->null_safe_eq("vrf_id", ":vrf") . "";
    $params = [':v' => $ver, ':vrf' => $vrfId];
    if ($excludeId !== null) {
        $sql .= " AND id != :excl";
        $params[':excl'] = $excludeId;
    }
    $st = $db->prepare($sql);
    $st->execute($params);
    /** @var list<array<string, mixed>> $rows */
    $rows = $st->fetchAll();

    $parents  = [];
    $children = [];

    foreach ($rows as $row) {
        $rowPrefix = to_int($row['prefix']);
        $rowNetBin = to_str($row['network_bin']);

        if ($rowPrefix < $prefix) {
            // Candidate parent: does the existing broader subnet contain our new one?
            if (hash_equals(apply_prefix_mask($netBin, $rowPrefix), $rowNetBin)) {
                $parents[] = to_str($row['cidr']);
            }
        } elseif ($rowPrefix > $prefix) {
            // Candidate child: does our new broader subnet contain the existing one?
            if (hash_equals(apply_prefix_mask($rowNetBin, $prefix), $netBin)) {
                $children[] = to_str($row['cidr']);
            }
        }
        // Same prefix: exact duplicate — handled by DB UNIQUE constraint on cidr
    }

    return ['parents' => $parents, 'children' => $children];
}

/** @param array{parents: list<string>, children: list<string>} $overlaps */
function subnet_overlap_warning_text(array $overlaps): string
{
    $parts = [];
    if (!empty($overlaps['parents'])) {
        $list = implode(', ', $overlaps['parents']);
        $parts[] = 'nested inside: ' . $list;
    }
    if (!empty($overlaps['children'])) {
        $list = implode(', ', $overlaps['children']);
        $parts[] = 'parent of: ' . $list;
    }
    return 'Hierarchy notice — this subnet is ' . implode('; and ', $parts) . '. Verify this nesting is intentional.';
}

/* ---------------- Webhook helpers ---------------- */

/**
 * Validate a webhook target URL for SSRF safety.
 * Returns false if the URL scheme is not http/https, the hostname cannot be
 * resolved, or the resolved IP falls in a private/loopback range (unless
 * webhook.allow_private_ips is true in settings).
 *
 * @param array<string, mixed> $config
 */
function ipam_validate_webhook_url(string $url, array $config = []): bool
{
    $parts = parse_url($url);
    if ($parts === false || !isset($parts['scheme'], $parts['host'])) {
        return false;
    }
    if (!in_array(strtolower($parts['scheme']), ['http', 'https'], true)) {
        return false;
    }
    $host = $parts['host'];
    // Strip IPv6 brackets
    if (str_starts_with($host, '[') && str_ends_with($host, ']')) {
        $host = substr($host, 1, -1);
    }
    // Resolve hostname to all addresses (A + AAAA) for dual-stack SSRF safety.
    // gethostbyname() is IPv4-only; use dns_get_record() to cover AAAA records.
    if (filter_var($host, FILTER_VALIDATE_IP)) {
        $ips = [$host];
    } else {
        $ips      = [];
        $aRecs    = @dns_get_record($host, DNS_A);
        $aaaaRecs = @dns_get_record($host, DNS_AAAA);
        foreach ((array)$aRecs as $r) { if (isset($r['ip']))   $ips[] = $r['ip']; }
        foreach ((array)$aaaaRecs as $r) { if (isset($r['ipv6'])) $ips[] = $r['ipv6']; }
        if (empty($ips)) {
            return false; // DNS resolution failed / NXDOMAIN
        }
    }

    $settingVal   = ipam_setting('webhook.allow_private_ips');
    $configVal    = is_array($config['webhook'] ?? null) ? ($config['webhook']['allow_private_ips'] ?? false) : false;
    $allowPrivate = (bool)($settingVal ?? $configVal);
    if ($allowPrivate) {
        return true;
    }

    // Block RFC-1918, loopback, link-local, IPv6 ULA/loopback, "this network"
    // (#872 — 0.0.0.0/8), CGNAT (100.64.0.0/10), multicast (224.0.0.0/4 and
    // ff00::/8), the IPv6 unspecified address (::/128), and the IPv4-mapped
    // IPv6 prefix (::ffff:0:0/96 — defence in depth alongside the explicit
    // unwrap below). ALL resolved addresses must be public (blocks DNS
    // rebinding).
    $privateRangesV4 = [
        ['0.0.0.0',     8],   // "this network" — covers 0.0.0.0 itself
        ['10.0.0.0',    8],
        ['100.64.0.0', 10],   // CGNAT (RFC 6598)
        ['127.0.0.0',   8],
        ['169.254.0.0',16],
        ['172.16.0.0', 12],
        ['192.168.0.0',16],
        ['224.0.0.0',   4],   // multicast + reserved (224.0.0.0–255.255.255.255)
    ];
    $privateRangesV6 = [
        ['::',         128],  // unspecified
        ['::1',        128],  // loopback
        ['::ffff:0:0', 96],   // IPv4-mapped IPv6 (defence in depth)
        ['64:ff9b::',  96],   // NAT64 well-known (RFC 6052)
        ['fc00::',      7],   // ULA
        ['fe80::',     10],   // link-local
        ['ff00::',      8],   // multicast
    ];
    foreach ($ips as $ip) {
        $bin = @inet_pton($ip);
        if ($bin === false) {
            // Resolver returned something that doesn't parse — treat as
            // unresolvable (i.e. unsafe) rather than silently passing it.
            return false;
        }
        // If we resolved an IPv4-mapped IPv6 address (::ffff:a.b.c.d), test
        // both the v6 prefix list AND the unwrapped IPv4 against the v4
        // list. Otherwise an attacker controlling DNS could route 127.0.0.1
        // past the v4 check by encoding it as ::ffff:127.0.0.1.
        if (strlen($bin) === 16) {
            $prefix = "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff";
            if (str_starts_with($bin, $prefix)) {
                $v4 = inet_ntop(substr($bin, 12));
                if (is_string($v4)) {
                    foreach ($privateRangesV4 as [$net, $p]) {
                        if (ip_in_cidr($v4, $net, $p)) {
                            return false;
                        }
                    }
                }
            }
            foreach ($privateRangesV6 as [$net, $p]) {
                if (ip_in_cidr($ip, $net, $p)) {
                    return false;
                }
            }
        } else {
            foreach ($privateRangesV4 as [$net, $p]) {
                if (ip_in_cidr($ip, $net, $p)) {
                    return false;
                }
            }
        }
    }
    return true;
}

/**
 * Build the audit_log.details string for a webhook test-fire row.
 *
 * Records the webhook id and host only — never the full URL — so query
 * strings carrying tokens/secrets and any XSS-shaped path or fragment
 * never land in the audit details column. (#1152, S-001)
 */
function ipam_webhook_test_fire_audit_detail(int $id, string $url): string
{
    $host = parse_url($url, PHP_URL_HOST);
    // parse_url returns a host *token*, not a validated hostname/IP. A
    // malformed URL can still leave attacker-controlled bytes here, which
    // would keep the S-001 sink partly open. Require a syntactically valid
    // IPv4/IPv6 address or RFC 1123 hostname; otherwise '(invalid)'.
    if (!is_string($host) || $host === '') {
        $host = '(invalid)';
    } else {
        $isIp     = filter_var($host, FILTER_VALIDATE_IP) !== false;
        $isDomain = filter_var($host, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME) !== false;
        if (!$isIp && !$isDomain) {
            $host = '(invalid)';
        }
    }
    if (strlen($host) > 100) {
        $host = substr($host, 0, 100);
    }
    return "id={$id} host={$host}";
}

/** Sign a webhook payload with HMAC-SHA256. */
function ipam_webhook_sign(string $payload, string $secret): string
{
    return 'sha256=' . hash_hmac('sha256', $payload, $secret);
}

/**
 * v3.27.7 (F-S3-01): encrypt a webhook signing secret for at-rest storage.
 *
 * Pre-v3.27.7, webhooks.secret was stored as plaintext. A DB dump (legitimate
 * backup, replication snapshot, db_tools export) leaked every outbound webhook
 * URL and its HMAC signing key, enabling forged deliveries. Mirrors the TOTP
 * envelope shape (ipam_totp_encrypt_secret) — AES-256-GCM with 12-byte IV +
 * 16-byte tag, '$2W$' prefix to namespace from TOTP's '$2$'.
 *
 * Key derived via SHA-256 of app_secret (same derivation as TOTP). Webhook
 * signing is HMAC-SHA256 (not AES), so the encrypted secret is only ever
 * unwrapped in memory at delivery time and re-encrypted on any save.
 *
 * @param string $secret  Plaintext HMAC signing secret. Empty string returns
 *                        empty (unsigned webhook).
 * @param string $key     app_secret string from config.php.
 * @return string         '$2W$' + base64(iv || tag || ciphertext), or empty.
 */
function ipam_webhook_encrypt_secret(string $secret, string $key): string
{
    if ($secret === '') {
        // Empty signing secret means the webhook is unsigned. Store empty
        // verbatim so the reader can distinguish "no secret" from "encrypted
        // blob that fails to decrypt". CR review (PR #1148): this fast path
        // runs BEFORE the $key check so save/migration of an intentionally-
        // unsigned webhook works on installs without app_secret configured.
        return '';
    }
    if ($key === '') {
        throw new \RuntimeException('Webhook secret encryption requires a non-empty app_secret');
    }
    $iv  = random_bytes(12);
    $tag = '';
    $enc = openssl_encrypt($secret, 'aes-256-gcm', hash('sha256', $key, true), OPENSSL_RAW_DATA, $iv, $tag, '', 16);
    if ($enc === false) {
        throw new \RuntimeException('Webhook secret encryption failed');
    }
    return '$2W$' . base64_encode($iv . $tag . $enc);
}

/**
 * v3.27.7: decrypt a webhook signing secret previously written by
 * ipam_webhook_encrypt_secret(). Returns empty string on decrypt failure so
 * callers signing an HMAC always get a usable string (the HMAC will fail
 * receiver-side verification, surfacing the misconfig there).
 *
 * Accepts both encrypted ('$2W$...') and plaintext values; the plaintext
 * branch exists because the 3.27.7-webhook-secret-encrypt migration is
 * defensive — an install upgrading from pre-v3.27.7 with existing rows must
 * keep delivering until the migration completes. (All deployed targets at
 * v3.27.6 had webhooks count = 0 so the migration is no-op in practice, but
 * the branch keeps the code safe for any future install restoring an older
 * backup and then upgrading.)
 */
/**
 * Return contract (CR review PR #1148):
 *   - '' (empty string)        — stored row was empty (intentionally unsigned)
 *                                 OR a legacy plaintext row that just happened
 *                                 to be empty. Caller may sign with empty key.
 *   - string (non-empty)       — successful decrypt (or legacy plaintext pass-
 *                                 through). Caller signs with this secret.
 *   - null                     — decrypt FAILURE: malformed envelope, wrong
 *                                 app_secret, or GCM tag mismatch. Caller
 *                                 MUST treat this as a delivery failure
 *                                 (persist an error row, do NOT sign with an
 *                                 empty key — that would silently produce a
 *                                 verifiably-wrong HMAC at the receiver).
 *   - throws \RuntimeException — caller passed an empty $key but the stored
 *                                 value is a real '$2W$' envelope. This is a
 *                                 config-time misconfig (app_secret missing);
 *                                 surface it to the operator.
 */
function ipam_webhook_decrypt_secret(string $stored, string $key): ?string
{
    if ($stored === '') {
        return '';
    }
    if (!str_starts_with($stored, '$2W$')) {
        // Legacy plaintext row — return as-is so the existing webhook keeps
        // signing correctly until the migration encrypts it.
        return $stored;
    }
    if ($key === '') {
        throw new \RuntimeException('Webhook secret decryption requires a non-empty app_secret');
    }
    $raw = base64_decode(substr($stored, 4), true);
    if ($raw === false || strlen($raw) < 29) {
        return null;
    }
    $iv      = substr($raw, 0, 12);
    $tag     = substr($raw, 12, 16);
    $payload = substr($raw, 28);
    $decrypted = openssl_decrypt($payload, 'aes-256-gcm', hash('sha256', $key, true), OPENSSL_RAW_DATA, $iv, $tag);
    if ($decrypted === false) {
        return null;
    }
    return $decrypted;
}

/**
 * Attempt a single HTTP delivery of a webhook payload via ext-curl.
 * Returns ['status' => int|null, 'body' => string, 'error' => string|null].
 *
 * @param array<string, mixed> $webhook  Row from the webhooks table
 * @return array{status: int|null, body: string, error: string|null}
 */
function ipam_webhook_deliver(array $webhook, string $eventType, string $payload, string $signature): array
{
    require_once __DIR__ . '/version.php';
    $ch = curl_init();
    if ($ch === false) {
        return ['status' => null, 'body' => '', 'error' => 'curl_init() failed'];
    }
    $url = to_str($webhook['url']);
    if ($url === '') {
        return ['status' => null, 'body' => '', 'error' => 'empty webhook URL'];
    }
    curl_setopt($ch, CURLOPT_URL,            $url);
    curl_setopt($ch, CURLOPT_POST,           true);
    curl_setopt($ch, CURLOPT_POSTFIELDS,     $payload);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT,        5);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_MAXREDIRS,      3);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_HTTPHEADER,     [
        'Content-Type: application/json',
        'X-IPAM-Signature: ' . $signature,
        'X-IPAM-Event: ' . $eventType,
        'User-Agent: SimpleIPAM/' . IPAM_VERSION,
    ]);
    $body   = (string)curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE) ?: null;
    $err    = curl_errno($ch) ? curl_error($ch) : null;
    // Truncate response body to 2KB for storage
    return ['status' => $status ?: null, 'body' => substr($body, 0, 2048), 'error' => $err];
}

/**
 * Dispatch a webhook event to all active subscribers.
 * Never throws — dispatch failures are silently swallowed so the triggering
 * action always succeeds.
 *
 * @param array<string, mixed> $data    Entity snapshot to include in payload
 * @param array<string, mixed> $config
 */
function ipam_webhook_dispatch(PDO $db, string $event, array $data, array $config = []): void
{
    try {
        require_once __DIR__ . '/version.php';
        $u = current_user();

        // Find active webhooks subscribed to this event. `events` is a JSON
        // array of strings written by webhooks.php. Use engine-native JSON
        // containment where available (MySQL JSON_CONTAINS, Postgres @>) and
        // fall back to a quote-anchored LIKE on SQLite, which lacks a
        // guaranteed json1 build. The quote anchors prevent substring
        // confusion between e.g. 'subnet.create' and 'subnet.create.bulk'.
        $driver = ipam_dialect()->driver_name();
        if ($driver === 'mysql') {
            $sqlFrag = 'JSON_CONTAINS(events, :ev)';
            $bindEv  = (string)json_encode($event);
        } elseif ($driver === 'pgsql') {
            $sqlFrag = '(events::jsonb) @> :ev::jsonb';
            $bindEv  = (string)json_encode($event);
        } else {
            $sqlFrag = 'events LIKE :ev';
            $bindEv  = '%"' . $event . '"%';
        }
        $hooks = $db->prepare(
            "SELECT id, url, secret FROM webhooks
             WHERE is_active = 1 AND $sqlFrag"
        );
        $hooks->execute([':ev' => $bindEv]);
        $rows = $hooks->fetchAll();
        if (!$rows) {
            return;
        }

        $payload = json_encode([
            'event'     => $event,
            'timestamp' => gmdate('Y-m-d\TH:i:s\Z'),
            'version'   => IPAM_VERSION,
            'actor'     => ['user_id' => $u['id'] ?? null, 'username' => $u['username'] ?? 'system'],
            'data'      => $data,
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($payload === false) {
            return;
        }

        // CR review (PR #1148): on every terminal-failure `continue` below
        // (SSRF blocked, decrypt throw, decrypt null), update the parent
        // webhook's last_delivery_at + clear last_delivery_status so the row
        // doesn't continue to advertise an old success after a local failure.
        // Matches the shape used at the successful-delivery path below
        // (lib.php :: $wUpd) where status is the integer HTTP code on a real
        // attempt — NULL here means "we never got far enough to make an
        // HTTP request."
        $touchLastDelivery = $db->prepare(
            "UPDATE webhooks
             SET last_delivery_at = :now, last_delivery_status = NULL
             WHERE id = :id"
        );

        foreach ($rows as $hook) {
            $now = gmdate('Y-m-d H:i:s');
            if (!ipam_validate_webhook_url((string)$hook['url'], $config)) {
                // Log a permanently-failed delivery row (attempt=3 prevents retries)
                $db->prepare(
                    "INSERT INTO webhook_deliveries
                        (webhook_id, event_type, payload, signature, attempt, error, created_at)
                     VALUES (:wid, :ev, :pl, :sig, 3, :err, :now)"
                )->execute([
                    ':wid' => $hook['id'], ':ev' => $event,
                    ':pl'  => $payload,    ':sig' => '',
                    ':err' => 'URL blocked: failed SSRF validation',
                    ':now' => $now,
                ]);
                $touchLastDelivery->execute([':id' => $hook['id'], ':now' => $now]);
                continue;
            }
            // v3.27.7 (F-S3-01): decrypt the stored secret before signing.
            // The plaintext only lives in this local scope long enough to
            // compute the HMAC for this single dispatch. CR review (PR #1148):
            //   - null means decrypt failure (wrong app_secret, tampered
            //     envelope); do NOT sign with empty key — record an attempt=3
            //     error row and skip dispatch so the receiver doesn't see a
            //     wrong HMAC.
            //   - The helper *throws* RuntimeException when $key is empty and
            //     the stored value is a real '$2W$' envelope. That throw is a
            //     per-webhook config issue (one row references an envelope but
            //     this install has no app_secret) — it must NOT kill the whole
            //     dispatch batch. Wrap in try/catch + record-and-continue per
            //     PR #1148 CR.
            // CR review (PR #1148): the function signature defaults
            // $config to [] for older 3-arg call sites. Fall back to the
            // global bootstrap config (set by init.php) so app_secret is
            // available — it's a config.php-only key, never in the
            // settings table, per CLAUDE.md.
            $appSecret = to_str($config['app_secret']
                ?? (is_array($GLOBALS['config'] ?? null)
                    ? ($GLOBALS['config']['app_secret'] ?? '')
                    : ''));
            try {
                $secretPlain = ipam_webhook_decrypt_secret(
                    (string)$hook['secret'],
                    $appSecret
                );
            } catch (\RuntimeException $e) {
                $db->prepare(
                    "INSERT INTO webhook_deliveries
                        (webhook_id, event_type, payload, signature, attempt, error, created_at)
                     VALUES (:wid, :ev, :pl, :sig, 3, :err, :now)"
                )->execute([
                    ':wid' => $hook['id'], ':ev' => $event,
                    ':pl'  => $payload,    ':sig' => '',
                    ':err' => 'Webhook secret decrypt threw: ' . $e->getMessage(),
                    ':now' => $now,
                ]);
                $touchLastDelivery->execute([':id' => $hook['id'], ':now' => $now]);
                continue;
            }
            if ($secretPlain === null) {
                $db->prepare(
                    "INSERT INTO webhook_deliveries
                        (webhook_id, event_type, payload, signature, attempt, error, created_at)
                     VALUES (:wid, :ev, :pl, :sig, 3, :err, :now)"
                )->execute([
                    ':wid' => $hook['id'], ':ev' => $event,
                    ':pl'  => $payload,    ':sig' => '',
                    ':err' => 'Secret decryption failed (wrong app_secret or tampered ciphertext)',
                    ':now' => $now,
                ]);
                $touchLastDelivery->execute([':id' => $hook['id'], ':now' => $now]);
                continue;
            }
            $sig = ipam_webhook_sign($payload, $secretPlain);

            // Insert pending delivery row
            $ins = $db->prepare(
                "INSERT INTO webhook_deliveries
                    (webhook_id, event_type, payload, signature, attempt, created_at)
                 VALUES (:wid, :ev, :pl, :sig, 1, :now)"
            );
            $ins->execute([':wid' => $hook['id'], ':ev' => $event, ':pl' => $payload, ':sig' => $sig, ':now' => $now]);
            $delId = ipam_last_insert_id($db, 'webhook_deliveries');

            // Attempt synchronous delivery
            $result = ipam_webhook_deliver($hook, $event, $payload, $sig);

            $ok = $result['status'] !== null && $result['status'] >= 200 && $result['status'] < 300;
            $upd = $db->prepare(
                "UPDATE webhook_deliveries
                 SET http_status   = :st,
                     response_body = :body,
                     error         = :err,
                     delivered_at  = CASE WHEN :ok THEN :now ELSE NULL END
                 WHERE id = :id"
            );
            $upd->execute([
                ':st'   => $result['status'],
                ':body' => $result['body'],
                ':err'  => $result['error'],
                ':ok'   => $ok ? 1 : 0,
                ':id'   => $delId,
                ':now'  => gmdate('Y-m-d H:i:s'),
            ]);

            // Update webhook last-delivery metadata
            $wUpd = $db->prepare(
                "UPDATE webhooks
                 SET last_delivery_at = :now, last_delivery_status = :st
                 WHERE id = :id"
            );
            $wUpd->execute([':st' => $result['status'], ':id' => $hook['id'], ':now' => gmdate('Y-m-d H:i:s')]);
        }
    } catch (\Throwable $e) {
        // Dispatch must never surface to the user, but a swallowed throwable
        // here masks PDO/JSON failures and future regressions. Leave an
        // operator-recoverable signal in the server log (Pass C F-S6/S-006).
        error_log('[webhook_dispatch] ' . $e->getMessage());
    }
}

/**
 * Retry pending webhook deliveries (called from cron.php).
 * Backoff: attempt 2 at T+1min, attempt 3 at T+6min (5 min after attempt 2).
 * Returns count of delivery rows attempted.
 *
 * @param array<string, mixed> $config
 */
function ipam_webhook_retry_pending(PDO $db, array $config = []): int
{
    $cutoff1min  = gmdate('Y-m-d H:i:s', time() - 60);
    $cutoff6min  = gmdate('Y-m-d H:i:s', time() - 360);
    $due = $db->prepare(
        "SELECT d.id, d.webhook_id, d.event_type, d.payload, d.signature, d.attempt,
                w.url, w.secret
         FROM webhook_deliveries d
         JOIN webhooks w ON w.id = d.webhook_id
         WHERE d.delivered_at IS NULL
           AND d.attempt < 3
           AND w.is_active = 1
           AND (
               (d.attempt = 1 AND d.created_at <= :c1)
            OR (d.attempt = 2 AND d.created_at <= :c6)
           )"
    );
    $due->execute([':c1' => $cutoff1min, ':c6' => $cutoff6min]);
    if ($due === false) {
        return 0;
    }
    $rows  = $due->fetchAll();
    $count = 0;
    foreach ($rows as $row) {
        if (!ipam_validate_webhook_url((string)$row['url'], $config)) {
            // Mark row exhausted so it is not retried again
            $db->prepare(
                "UPDATE webhook_deliveries SET attempt = 3, error = :err WHERE id = :id"
            )->execute([':err' => 'URL blocked: failed SSRF validation', ':id' => $row['id']]);
            continue;
        }
        $hook    = ['url' => $row['url'], 'secret' => $row['secret'], 'id' => $row['webhook_id']];
        $result  = ipam_webhook_deliver($hook, (string)$row['event_type'], (string)$row['payload'], (string)$row['signature']);
        $attempt = (int)$row['attempt'] + 1;
        $ok      = $result['status'] !== null && $result['status'] >= 200 && $result['status'] < 300;

        $upd = $db->prepare(
            "UPDATE webhook_deliveries
             SET attempt       = :att,
                 http_status   = :st,
                 response_body = :body,
                 error         = :err,
                 delivered_at  = CASE WHEN :ok THEN :now ELSE NULL END
             WHERE id = :id"
        );
        $upd->execute([
            ':att'  => $attempt,
            ':st'   => $result['status'],
            ':body' => $result['body'],
            ':err'  => $result['error'],
            ':ok'   => $ok ? 1 : 0,
            ':id'   => $row['id'],
            ':now'  => gmdate('Y-m-d H:i:s'),
        ]);

        $wUpd = $db->prepare(
            "UPDATE webhooks SET last_delivery_at=:now, last_delivery_status=:st WHERE id=:id"
        );
        $wUpd->execute([':st' => $result['status'], ':id' => $row['webhook_id'], ':now' => gmdate('Y-m-d H:i:s')]);
        $count++;
    }
    return $count;
}

/**
 * Prune old webhook delivery rows. Returns count deleted.
 */
function ipam_webhook_prune(PDO $db, int $days): int
{
    if ($days <= 0) {
        return 0;
    }
    $cutoff = gmdate('Y-m-d H:i:s', time() - $days * 86400);
    $st = $db->prepare(
        "DELETE FROM webhook_deliveries WHERE created_at < :cutoff"
    );
    $st->execute([':cutoff' => $cutoff]);
    return $st->rowCount();
}

/* ---------------- UI helpers ---------------- */

/** @param array<string, mixed> $opts */
function page_header(string $title, array $opts = []): void
{
    // Still needed for the bootstrap_admin default-password warning below —
    // that is a pre-registry config-only check that stays on config.php
    // forever (see below). Everything else in this function reads through
    // ipam_setting() as of v2.7.0.
    global $config, $db;
    require_once __DIR__ . '/version.php';
    $u = to_str($_SESSION['username'] ?? '');
    $role = to_str($_SESSION['role'] ?? '');
    // v3.28.2 #1178 — handle the install-key banner dismiss POST before
    // any HTML or header() output so csrf_require() can still send 403
    // on a bad/missing token. A successful dismiss redirects to the
    // same URL via GET and exits, so the rest of this function is
    // skipped on the dismiss request.
    if ($db instanceof PDO) {
        ipam_install_key_banner_handle_dismiss($db, $role);
    }
    $appName = trim(to_str(ipam_setting('branding.site_name'))) ?: 'Simple PHP IPAM';

    $noSidebar      = !empty($opts['no_sidebar']);
    $extraScriptSrc = isset($opts['extra_script_src']) && $opts['extra_script_src'] !== '' ? ' ' . to_str($opts['extra_script_src']) : '';
    $extraStyleSrc  = isset($opts['extra_style_src'])  && $opts['extra_style_src']  !== '' ? ' ' . to_str($opts['extra_style_src'])  : '';
    $frameSrc       = isset($opts['extra_frame_src'])  && $opts['extra_frame_src']  !== '' ? " frame-src 'self' " . to_str($opts['extra_frame_src']) . ';' : '';
    header("Content-Security-Policy: default-src 'self'; script-src 'self'{$extraScriptSrc}; style-src 'self'{$extraStyleSrc}; style-src-attr 'unsafe-inline'; img-src 'self' data:;{$frameSrc} frame-ancestors 'none'");
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');

    echo "<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>";
    echo "<title>" . e($appName) . " \u{2014} " . e($title) . "</title>";
    $av = e(IPAM_VERSION);
    // Append file mtime to JS/CSS cache busters so in-version edits invalidate
    // the browser cache without requiring an IPAM_VERSION bump.
    $cssMtime = (int)@filemtime(__DIR__ . '/assets/app.css');
    $jsMtime  = (int)@filemtime(__DIR__ . '/assets/app.js');
    $cssV     = $av . ($cssMtime > 0 ? '.' . $cssMtime : '');
    $jsV      = $av . ($jsMtime  > 0 ? '.' . $jsMtime  : '');
    echo "<link rel='icon' type='image/webp' sizes='32x32' href='assets/favicon-32.webp?v={$av}'>";
    echo "<link rel='icon' type='image/png' sizes='32x32' href='assets/favicon-32.png?v={$av}'>";
    echo "<link rel='apple-touch-icon' type='image/webp' sizes='180x180' href='assets/apple-touch-icon.webp?v={$av}'>";
    echo "<link rel='apple-touch-icon' sizes='180x180' href='assets/apple-touch-icon.png?v={$av}'>";
    echo "<link rel='stylesheet' href='assets/vendor/open-props.min.css?v={$av}'>";
    echo "<link rel='stylesheet' href='assets/app.css?v={$cssV}'>";
    // Expose server-side theme via meta tag so app.js can seed localStorage (CSP-safe)
    $userTheme = to_str($_SESSION['user_theme'] ?? 'auto');
    echo "<meta name='ipam-server-theme' content='" . e($userTheme) . "'>";
    // Expose CSRF token for fetch-based POSTs from app.js (e.g. set_theme.php).
    echo "<meta name='ipam-csrf' content='" . e(csrf_token()) . "'>";
    echo "<script defer src='assets/app.js?v={$jsV}'></script>";
    $pageAttr = isset($opts['page']) && $opts['page'] !== ''
        ? " data-page='" . e(to_str($opts['page'])) . "'"
        : '';
    echo "</head><body{$pageAttr}>";
    // Inline SVG sprite once per page (display:none in the SVG itself)
    static $__spritePrinted = false;
    if (!$__spritePrinted) {
        $__spritePrinted = true;
        $__spritePath = __DIR__ . '/assets/icons.svg';
        if (is_file($__spritePath)) {
            readfile($__spritePath);
        }
    }
    echo "<a class='skip-link' href='#main-content'>Skip to main content</a>";

    /** @var IpamConfig $gConf */
    $gConf = $GLOBALS['config'];
    if (recovery_mode_enabled($gConf)) {
        echo "<div class='recovery-banner'>RECOVERY MODE ACTIVE &mdash; disable <code>recovery_mode</code> in config.php after use</div>";
    }

    // Active page detection for sidebar highlighting
    $activePage = basename(to_str($_SERVER['SCRIPT_NAME'] ?? ''), '.php');

    $GLOBALS['__ipam_no_sidebar'] = $noSidebar;

    if ($noSidebar) {
        echo "<div class='layout-root layout-root--no-sidebar'>";
        echo "<main id='main-content' class='layout-main'>";
    } else {
        echo "<div class='layout-root'>";

        // Sidebar — desktop: always visible; mobile: off-canvas
        echo "<aside id='sidebar' class='sidebar' aria-label='Main navigation'>";
        echo "<div class='sidebar-logo'>";
        echo "<a href='dashboard.php' class='sidebar-logo-link'>" . icon('server-stack', 'icon-xl') . " " . e($appName) . "</a>";
        echo "<button id='sidebar-close' class='sidebar-close' aria-label='Close menu'>" . icon('x') . "</button>";
        echo "</div>";
        echo "<nav class='sidebar-nav' aria-label='Primary'>";

        if ($u) {
            // Primary group
            echo "<div class='sidebar-group'>";
            echo "<a class='sidebar-link" . ($activePage === 'dashboard' ? ' is-active' : '') . "' href='dashboard.php'>" . icon('home') . " Dashboard</a>";
            echo "<a class='sidebar-link" . ($activePage === 'subnets' ? ' is-active' : '') . "' href='subnets.php'>" . icon('server-stack') . " Subnets</a>";
            echo "<a class='sidebar-link" . ($activePage === 'addresses' ? ' is-active' : '') . "' href='addresses.php'>" . icon('map-pin') . " Addresses</a>";
            echo "<a class='sidebar-link nav-search-link" . ($activePage === 'search' ? ' is-active' : '') . "' href='search.php'>" . icon('magnifying-glass') . " Search</a>";
            echo "<a class='sidebar-link" . ($activePage === 'audit' ? ' is-active' : '') . "' href='audit.php'>" . icon('audit') . " Audit</a>";
            echo "<a class='sidebar-link" . ($activePage === 'unassigned' ? ' is-active' : '') . "' href='unassigned.php'>" . icon('unassigned') . " Unassigned</a>";
            echo "</div>";

            if ($role === 'admin') {
                echo "<div class='sidebar-group'>";
                echo "<span class='sidebar-group-label'>Admin</span>";
                echo "<a class='sidebar-link" . ($activePage === 'dhcp_pool' ? ' is-active' : '') . "' href='dhcp_pool.php'>" . icon('dhcp') . " DHCP Pools</a>";
                echo "<a class='sidebar-link" . ($activePage === 'sites' ? ' is-active' : '') . "' href='sites.php'>" . icon('building') . " Sites</a>";
                echo "<a class='sidebar-link" . ($activePage === 'vrfs' ? ' is-active' : '') . "' href='vrfs.php'>" . icon('globe') . " VRFs</a>";
                echo "<a class='sidebar-link" . ($activePage === 'vlans' ? ' is-active' : '') . "' href='vlans.php'>" . icon('link') . " VLANs</a>";
                echo "<a class='sidebar-link" . ($activePage === 'aggregates' ? ' is-active' : '') . "' href='aggregates.php'>" . icon('aggregates') . " Aggregates</a>";
                echo "<a class='sidebar-link" . ($activePage === 'pd_pools' ? ' is-active' : '') . "' href='pd_pools.php'>" . icon('pd-pools') . " PD Pools</a>";
                echo "<a class='sidebar-link" . ($activePage === 'tags' ? ' is-active' : '') . "' href='tags.php'>" . icon('tag') . " Tags</a>";
                echo "<a class='sidebar-link" . ($activePage === 'devices' ? ' is-active' : '') . "' href='devices.php'>" . icon('server') . " Devices</a>";
                echo "<a class='sidebar-link" . ($activePage === 'contacts' ? ' is-active' : '') . "' href='contacts.php'>" . icon('phone') . " Contacts</a>";
                echo "<a class='sidebar-link" . ($activePage === 'custom_fields' ? ' is-active' : '') . "' href='custom_fields.php'>" . icon('custom-fields') . " Custom Fields</a>";
                echo "<a class='sidebar-link" . ($activePage === 'users' ? ' is-active' : '') . "' href='users.php'>" . icon('users') . " Users</a>";
                echo "<a class='sidebar-link" . ($activePage === 'api_keys' ? ' is-active' : '') . "' href='api_keys.php'>" . icon('key') . " API Keys</a>";
                echo "<a class='sidebar-link" . ($activePage === 'webhooks' ? ' is-active' : '') . "' href='webhooks.php'>" . icon('webhook') . " Webhooks</a>";
                // v3.21.0 Wave 4 #797: unified Backup & Restore admin surface replaces
                // the four prior entries (destinations, backup_history, remote_backups,
                // restore_web). The legacy pages remain reachable as thin wrappers so
                // existing bookmarks and Playwright specs keep working.
                $isBackupAdmin = in_array($activePage, ['backup_admin', 'destinations', 'backup_history', 'remote_backups', 'restore_web'], true);
                echo "<a class='sidebar-link" . ($isBackupAdmin ? ' is-active' : '') . "' href='backup_admin.php'>" . icon('server-stack') . " Backup &amp; Restore</a>";
                echo "<a class='sidebar-link" . ($activePage === 'import_csv' ? ' is-active' : '') . "' href='import_csv.php'>" . icon('upload') . " Import CSV</a>";
                echo "<a class='sidebar-link" . ($activePage === 'import_arp' ? ' is-active' : '') . "' href='import_arp.php'>" . icon('arp') . " ARP Import</a>";
                echo "<a class='sidebar-link" . ($activePage === 'reports' ? ' is-active' : '') . "' href='reports.php'>" . icon('reports') . " Reports</a>";
                // v3.21.0 Wave 4 #798: db_tools.php Database admin entry retires. The
                // file stays functional for direct access (data-export flows live there
                // until they relocate); the sidebar link is gone.
                echo "<a class='sidebar-link" . ($activePage === 'health' ? ' is-active' : '') . "' href='health.php'>" . icon('health') . " Health</a>";
                echo "<a class='sidebar-link" . ($activePage === 'settings' ? ' is-active' : '') . "' href='settings.php'>" . icon('settings') . " Settings</a>";
                echo "</div>";
            }

            // Account group
            echo "<div class='sidebar-group sidebar-group--account'>";
            echo "<span class='sidebar-group-label'>Account</span>";
            echo "<button type='button' class='sidebar-link' id='theme-toggle'>" . icon('theme') . " <span class='theme-label'>Theme</span></button>";
            echo "<a class='sidebar-link" . ($activePage === 'change_password' ? ' is-active' : '') . "' href='change_password.php'>" . icon('account') . " Account <span class='badge badge-role-" . e($role) . "'>" . e($u) . "</span></a>";
            echo "<a class='sidebar-link' href='logout.php'>" . icon('logout') . " Logout</a>";
            echo "</div>";
        } else {
            echo "<div class='sidebar-group'>";
            echo "<a class='sidebar-link" . ($activePage === 'login' ? ' is-active' : '') . "' href='login.php'>" . icon('login') . " Login</a>";
            echo "</div>";
        }

        echo "</nav>";
        echo "</aside>";

        // Main content area
        echo "<div class='layout-main'>";

        // Mobile topbar — hamburger + app name
        echo "<header class='topbar topbar--mobile'>";
        echo "<button id='sidebar-open' class='hamburger' aria-label='Open menu' aria-expanded='false'>" . icon('bars') . "</button>";
        echo "<span class='topbar-title'>" . e($appName) . "</span>";
        echo "</header>";

        // ⌘K / Ctrl+K command palette (#516)
        echo "<div id='cmd-palette-bg' class='cmd-palette-bg' role='dialog' aria-modal='true' aria-label='Command palette'>";
        echo "  <div class='cmd-palette'>";
        echo "    <div class='cmd-input-wrap'>";
        echo "      <input id='cmd-input' class='cmd-input' type='search' placeholder='Search pages, actions, addresses\xe2\x80\xa6' autocomplete='off' spellcheck='false' aria-label='Command palette search'>";
        echo "    </div>";
        echo "    <div id='cmd-results' class='cmd-results'></div>";
        echo "  </div>";
        echo "</div>";

        echo "<main id='main-content' class='page-content'>";
    }

    // Demo mode banner (non-dismissible)
    if (demo_mode_enabled()) {
        echo "<div class='admin-notice admin-notice--info text-center' role='alert'>"
           . "🧪 <strong>Demo mode</strong> — Explore freely. Destructive actions are disabled. Data resets nightly at midnight."
           . "</div>";
    }

    // Default bootstrap admin password warning (admin only)
    if ($role === 'admin') {
        if (($config['bootstrap_admin']['password'] ?? '') === 'ChangeMeNow!12345') {
            echo "<div class='admin-notice admin-notice--danger' role='alert'>"
               . "⚠ <strong>Security warning:</strong> The default bootstrap admin password is still set in <code>config.php</code>. "
               . "<a href='change_password.php'>Change your password</a> and update <code>config.php</code> before this site receives any traffic."
               . "</div>";
        }
    }

    // v3.28.2 #1178 — admin-only install-key auto-gen banner. Helper
    // gates on $role itself; the global $db is opened by init.php and is
    // the same handle audit() / ipam_setting_set() expect.
    if ($role === 'admin') {
        global $db;
        if (isset($db) && $db instanceof PDO) {
            render_install_key_banner($db, $role);
        }
    }

    // Config auto-population notice (shown once per session, admin only)
    if (!empty($_SESSION['config_notice']) && $role === 'admin') {
        $notice = e(to_str($_SESSION['config_notice']));
        echo "<div class='admin-notice admin-notice--info' role='alert'>"
           . "⚙ Config updated: {$notice} Review and adjust values in config.php."
           . "</div>";
        unset($_SESSION['config_notice']);
    }

    // Config write failure notice — shown when config.php is not writable (#119)
    if (!empty($_SESSION['config_unwritable']) && $role === 'admin') {
        echo "<div class='admin-notice admin-notice--danger' role='alert'>"
           . "&#9888; config.php is not writable — new configuration keys could not be saved. "
           . "Check file permissions."
           . "</div>";
        unset($_SESSION['config_unwritable']);
    }

    // Config validation warnings — shown to admins when config.php has invalid values (#236)
    if ($role === 'admin' && !empty($GLOBALS['config_warnings']) && is_array($GLOBALS['config_warnings'])) {
        foreach ($GLOBALS['config_warnings'] as $cfgWarn) {
            echo "<div class='admin-notice admin-notice--danger' role='alert'>"
               . "&#9888; <strong>Config warning:</strong> " . e(to_str($cfgWarn))
               . " Review <code>config.php</code>."
               . "</div>";
        }
    }

    // General flash messages (success, warning, danger)
    $flash = flash_get();
    if ($flash) {
        $flashClass = match ($flash['type']) {
            'success' => 'success',
            'warning' => 'warning',
            'error', 'danger' => 'danger',
            default => 'success',
        };
        echo "<p class='{$flashClass}'>" . e($flash['msg']) . "</p>";
    }

    // Update-available dismissible banner (admin only, client-side dismiss via localStorage)
    if ($role === 'admin') {
        $update = ipam_update_check($config);
        if ($update) {
            $uv  = e(to_str($update['version']));
            $url = e(to_str($update['url']));
            echo "<div class='admin-notice admin-notice--update' id='ipam-update-banner' data-version='{$uv}' role='alert'>"
               . "🚀 Simple PHP IPAM v{$uv} is available. "
               . "<a href='{$url}' target='_blank' rel='noopener'>View release</a>"
               . " &nbsp;<button type='button' class='button-secondary btn-sm' "
               . "data-dismiss-update='{$uv}'>Dismiss</button>"
               . "</div>";
        }
    }
}

function ipam_skeleton_flush(int $rows = 8): void
{
    echo '<div id="skeleton-shell" class="skeleton-shell" aria-hidden="true">';
    for ($i = 0; $i < $rows; $i++) echo '<div class="skeleton-row"></div>';
    echo '</div>';
    if (ob_get_level() > 0) ob_flush();
    flush();
}

function ipam_skeleton_remove(): void
{
    // Skeleton removal is handled by app.js (CSP-safe, no inline script).
}

function page_footer(): void
{
    global $config;
    require_once __DIR__ . '/version.php';

    $noSidebar = !empty($GLOBALS['__ipam_no_sidebar']);

    echo "</main><footer role='contentinfo'><hr><div class='muted footer-meta'>";
    echo "<a href='https://simplephpipam.com' target='_blank' rel='noopener' class='nav-brand footer-brand link-plain'>"
       . "Simple<span class='nav-brand-php'>PHP</span>IPAM"
       . "</a> v" . e(IPAM_VERSION)
       . " &middot; <a href='https://simplephpipam.com/docs/' target='_blank' rel='noopener'>Docs</a>";

    $update = ipam_update_check($config ?? []);
    if ($update) {
        $uv  = e(to_str($update['version']));
        $url = e(to_str($update['url']));
        echo " <a href='{$url}' target='_blank' rel='noopener' class='badge badge-update'>"
           . "Update available v{$uv}</a>";
    }

    if ($noSidebar) {
        echo "</div></footer></div>"; // close footer-meta div + footer + layout-root (main used as layout-main)
    } else {
        echo "</div></footer></div></div>"; // close footer-meta div + footer + layout-main (div) + layout-root
    }

    // Slide-in form drawer container (populated by JS openFormDrawer())
    echo "<div id='form-drawer' role='dialog' aria-modal='true' aria-labelledby='drawer-title-text'>";
    echo "<div class='drawer-header'>";
    echo "<span class='drawer-title' id='drawer-title-text'></span>";
    echo "<button class='drawer-close-btn' aria-label='Close'>&times;</button>";
    echo "</div>";
    echo "<div id='form-drawer-body'></div>";
    echo "</div>";
    echo "<div class='form-drawer-overlay'></div>";

    echo "</body></html>";
}

/**
 * Normalise a version string to three dot-separated segments so that
 * version_compare('1.2', '1.2.0') and version_compare('1.2.1', '1.2') work
 * as expected regardless of how many segments the installed version has.
 *
 * Examples: '1.2' → '1.2.0',  'v1.2.1' → '1.2.1',  '0.15' → '0.15.0'
 */
function ipam_normalise_version(string $v): string
{
    $v = ltrim($v, 'v');
    $parts = explode('.', $v);
    while (count($parts) < 3) $parts[] = '0';
    return implode('.', $parts);
}

/**
 * Check GitHub for a newer release. Results are cached in data/tmp/ for the
 * configured TTL (default 6 hours). Network failures are silently ignored.
 *
 * Returns ['version' => '1.2.1', 'url' => 'https://...'] if newer, otherwise null.
 */
/**
 * @param IpamConfig $config Unused since v2.7.0 — kept for signature stability.
 * @return array{version: string, url: string}|null
 */
function ipam_update_check(array $config): ?array
{
    unset($config);
    // Memoize within a single request — page_header() and page_footer() both call this
    static $memo = false;
    if ($memo !== false) return $memo;

    if (!(bool)ipam_setting('update_check.enabled')) { $memo = null; return null; }

    $ttl              = max(3600, to_int(ipam_setting('update_check.ttl_seconds')));
    $notifyPrerelease = (bool)ipam_setting('update_check.notify_prerelease');

    ensure_tmp_dir();
    $cache = tmp_dir() . '/update-check.json';

    if (is_file($cache) && (time() - (int)filemtime($cache)) < $ttl) {
        $d = json_decode((string)file_get_contents($cache), true);
        if (is_array($d) && array_key_exists('checked', $d)) {
            // If the cached update version is <= the running version, we've already
            // upgraded — invalidate so the next check fetches fresh data from GitHub
            require_once __DIR__ . '/version.php';
            if (isset($d['update']['version'])
                && version_compare(ipam_normalise_version(to_str($d['update']['version'])), ipam_normalise_version(IPAM_VERSION), '<=')) {
                @unlink($cache); // nosemgrep: php.lang.security.unlink-use.unlink-use
            } else {
                $u = isset($d['update']) && is_array($d['update']) ? $d['update'] : null;
                $memo = ($u !== null && isset($u['version'], $u['url']))
                    ? ['version' => to_str($u['version']), 'url' => to_str($u['url'])]
                    : null;
                return $memo;
            }
        }
    }

    require_once __DIR__ . '/version.php';
    $result = null;

    try {
        // Fetch list of releases (up to 10) so we can honour notify_prerelease.
        // /releases/latest skips pre-releases entirely, so we use /releases instead.
        $url = 'https://api.github.com/repos/seanmousseau/Simple-PHP-IPAM/releases?per_page=10';
        $ctx = stream_context_create(['http' => [
            'timeout' => 5,
            'ignore_errors' => true,
            'header' => "User-Agent: Simple-PHP-IPAM/" . IPAM_VERSION . "\r\n"
                      . "Accept: application/vnd.github+json\r\n",
        ]]);
        $raw = @file_get_contents($url, false, $ctx);
        if ($raw !== false && $raw !== '') {
            $releases = json_decode($raw, true);
            if (is_array($releases)) {
                foreach ($releases as $rel) {
                    if (!is_array($rel)) continue;
                    if (!empty($rel['draft'])) continue;
                    if (!empty($rel['prerelease']) && !$notifyPrerelease) continue;
                    if (empty($rel['tag_name'])) continue;

                    $latest = ltrim(to_str($rel['tag_name']), 'v');
                    if (version_compare(ipam_normalise_version($latest), ipam_normalise_version(IPAM_VERSION), '>')) {
                        $result = [
                            'version'    => $latest,
                            'url'        => to_str($rel['html_url'] ?? ''),
                            'prerelease' => !empty($rel['prerelease']),
                        ];
                    }
                    break; // releases are newest-first; first match wins
                }
            }
        }
    } catch (Throwable) {
        // Non-critical — silently skip on network failure
    }

    @file_put_contents($cache, json_encode(['checked' => time(), 'update' => $result]));
    @chmod($cache, 0600);
    $memo = $result;
    return $result;
}

/**
 * Find the site_id a subnet should inherit from its tightest parent.
 * Returns null if no parent exists or no parent has a site assigned.
 */
function find_parent_site_id(PDO $db, string $cidr, ?int $excludeId = null, ?int $vrfId = null): ?int
{
    $overlaps = detect_subnet_overlaps($db, $cidr, $excludeId, $vrfId);
    if (empty($overlaps['parents'])) return null;

    $placeholders = implode(',', array_fill(0, count($overlaps['parents']), '?'));
    $vrfEq = ipam_dialect()->null_safe_eq('vrf_id', '?');
    $st = $db->prepare(
        "SELECT site_id FROM subnets
         WHERE cidr IN ($placeholders) AND site_id IS NOT NULL AND $vrfEq
         ORDER BY prefix DESC LIMIT 1"
    );
    $st->execute(array_merge($overlaps['parents'], [$vrfId]));
    /** @var array<string, mixed>|false $row */
    $row = $st->fetch();
    return $row ? to_int($row['site_id']) : null;
}

/* ============================================================
 * OIDC — Authorization Code + PKCE (pure PHP, no dependencies)
 * ============================================================ */

/**
 * @param IpamConfig $config Unused since v2.7.0 — kept for back-compat with
 *                           existing callers. Reads go through ipam_setting()
 *                           which falls back to $GLOBALS['config'] on a miss,
 *                           so legacy config.php-only installs still work.
 */
function oidc_enabled(array $config): bool
{
    unset($config); // keep the signature stable; body now reads through ipam_setting()
    return (bool)ipam_setting('oidc.enabled')
        && to_str(ipam_setting('oidc.client_id'))     !== ''
        && to_str(ipam_setting('oidc.client_secret')) !== ''
        && to_str(ipam_setting('oidc.discovery_url')) !== ''
        && to_str(ipam_setting('oidc.redirect_uri'))  !== '';
}

/**
 * Fetch and cache the IdP's OpenID Connect discovery document.
 * Appends /.well-known/openid-configuration if the URL doesn't already
 * contain that path.
 */
/**
 * @param IpamConfig $config Unused since v2.7.0 — kept for signature stability.
 * @return array<string, mixed>
 */
function oidc_discovery(array $config): array
{
    unset($config);
    $base = rtrim(to_str(ipam_setting('oidc.discovery_url')), '/');
    if ($base === '') throw new RuntimeException('OIDC discovery_url not set');

    $url = (str_contains($base, '.well-known')) ? $base : $base . '/.well-known/openid-configuration';

    ensure_tmp_dir();
    $cache = tmp_dir() . '/oidc-disc-' . md5($url) . '.json';

    if (is_file($cache) && (time() - (int)filemtime($cache)) < 3600) {
        $d = json_decode((string)file_get_contents($cache), true);
        if (is_array($d) && !empty($d['authorization_endpoint'])) {
            /** @var array<string, mixed> $d */
            return $d;
        }
    }

    $raw = oidc_http_get($url);
    $d   = json_decode($raw, true);
    if (!is_array($d) || empty($d['authorization_endpoint'])) {
        throw new RuntimeException('Invalid OIDC discovery document from ' . $url);
    }
    /** @var array<string, mixed> $d */

    file_put_contents($cache, json_encode($d));
    @chmod($cache, 0600);
    return $d;
}

/**
 * Fetch and cache the IdP's JSON Web Key Set.
 * Pass $forceRefresh = true to bypass the cache (used after a verify failure
 * to handle key rotation).
 */
/** @return list<mixed> */
function oidc_jwks(string $jwksUri, bool $forceRefresh = false): array
{
    ensure_tmp_dir();
    $cache = tmp_dir() . '/oidc-jwks-' . md5($jwksUri) . '.json';

    if (!$forceRefresh && is_file($cache) && (time() - (int)filemtime($cache)) < 3600) {
        $d = json_decode((string)file_get_contents($cache), true);
        if (is_array($d) && !empty($d['keys'])) return array_values((array)$d['keys']);
    }

    $raw = oidc_http_get($jwksUri);
    $d   = json_decode($raw, true);
    if (!is_array($d) || !isset($d['keys'])) {
        throw new RuntimeException('Invalid JWKS from ' . $jwksUri);
    }

    file_put_contents($cache, json_encode($d));
    @chmod($cache, 0600);
    return array_values((array)$d['keys']);
}

/** HTTP GET via file_get_contents with a short timeout. */
function oidc_http_get(string $url): string
{
    $ctx = stream_context_create([
        'http' => ['timeout' => 10, 'ignore_errors' => true],
        'ssl'  => ['verify_peer' => true, 'verify_peer_name' => true],
    ]);
    $raw = @file_get_contents($url, false, $ctx, 0, 1048576);
    if ($raw === false || $raw === '') {
        throw new RuntimeException('HTTP GET failed for ' . $url);
    }
    return $raw;
}

/**
 * POST application/x-www-form-urlencoded and return decoded JSON array.
 *
 * @param array<string, string> $params
 * @return array<string, mixed>
 */
function oidc_http_post(string $url, array $params): array
{
    $body = http_build_query($params);
    $ctx  = stream_context_create([
        'http' => [
            'method'        => 'POST',
            'header'        => "Content-Type: application/x-www-form-urlencoded\r\n"
                             . "Content-Length: " . strlen($body) . "\r\n",
            'content'       => $body,
            'timeout'       => 15,
            'ignore_errors' => true,
        ],
        'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
    ]);
    $raw = @file_get_contents($url, false, $ctx, 0, 1048576);
    if ($raw === false) throw new RuntimeException('Token endpoint request failed');
    $d = json_decode($raw, true);
    if (!is_array($d)) throw new RuntimeException('Invalid JSON from token endpoint');
    /** @var array<string, mixed> $d */
    if (!empty($d['error'])) {
        throw new RuntimeException('Token endpoint error: ' . to_str($d['error'])
            . (isset($d['error_description']) ? ' — ' . to_str($d['error_description']) : ''));
    }
    return $d;
}

/* ---- PKCE ---- */

function base64url_encode(string $bytes): string
{
    return rtrim(strtr(base64_encode($bytes), '+/', '-_'), '=');
}

function base64url_decode(string $s): string
{
    $s = strtr($s, '-_', '+/');
    $pad = strlen($s) % 4;
    if ($pad) $s .= str_repeat('=', 4 - $pad);
    $result = base64_decode($s, true);
    if ($result === false) throw new RuntimeException('Invalid base64url string');
    return $result;
}

/**
 * Generate a PKCE verifier and S256 challenge pair.
 * @return array{verifier: string, challenge: string}
 */
function oidc_pkce_pair(): array
{
    $verifier  = base64url_encode(random_bytes(32));
    $challenge = base64url_encode(hash('sha256', $verifier, true));
    return ['verifier' => $verifier, 'challenge' => $challenge];
}

/* ---- JWT / JWK verification ---- */

/**
 * Decode and verify an RS256/RS384/RS512 signed ID token.
 * Returns the verified payload claims array.
 *
 * @param list<mixed> $jwks                  Keys from the IdP's JWKS endpoint
 * @param array<string, string> $expect       Claims to validate: iss, aud, nonce
 * @return array<string, mixed>
 */
function oidc_verify_id_token(string $idToken, array $jwks, array $expect): array
{
    $parts = explode('.', $idToken);
    if (count($parts) !== 3) throw new RuntimeException('Malformed JWT');

    [$hdrB64, $payB64, $sigB64] = $parts;

    $header  = json_decode(base64url_decode($hdrB64), true);
    $payload = json_decode(base64url_decode($payB64), true);
    if (!is_array($header) || !is_array($payload)) {
        throw new RuntimeException('JWT header/payload decoding failed');
    }

    $alg = to_str($header['alg'] ?? '');
    $algMap = ['RS256' => OPENSSL_ALGO_SHA256, 'RS384' => OPENSSL_ALGO_SHA384, 'RS512' => OPENSSL_ALGO_SHA512];
    if (!isset($algMap[$alg])) {
        throw new RuntimeException("Unsupported JWT alg: $alg");
    }

    // Find the matching JWK
    $kid = $header['kid'] ?? null;
    $jwk = null;
    foreach ($jwks as $k) {
        if (!is_array($k) || ($k['kty'] ?? '') !== 'RSA') continue;
        if ($kid !== null && ($k['kid'] ?? '') !== $kid) continue;
        $jwk = $k;
        break;
    }
    if ($jwk === null) {
        throw new RuntimeException('No matching RSA JWK for kid=' . to_str($kid ?? 'none'));
    }

    $pem    = jwk_rsa_to_pem($jwk);
    $pubKey = openssl_pkey_get_public($pem);
    if ($pubKey === false) throw new RuntimeException('Failed to import JWK public key');

    $sig    = base64url_decode($sigB64);
    $result = openssl_verify($hdrB64 . '.' . $payB64, $sig, $pubKey, $algMap[$alg]);
    if ($result !== 1) throw new RuntimeException('JWT signature invalid');

    // Standard claim validation
    $now = time();
    if (isset($payload['exp']) && to_int($payload['exp']) < $now - 60) {
        throw new RuntimeException('ID token has expired');
    }
    if (isset($payload['iat']) && to_int($payload['iat']) > $now + 60) {
        throw new RuntimeException('ID token iat is in the future');
    }
    if (isset($expect['iss']) && ($payload['iss'] ?? '') !== $expect['iss']) {
        throw new RuntimeException('ID token issuer mismatch');
    }
    if (isset($expect['aud'])) {
        $aud   = $payload['aud'] ?? '';
        $audOk = (is_string($aud) && $aud === $expect['aud'])
              || (is_array($aud)  && in_array($expect['aud'], $aud, true));
        if (!$audOk) throw new RuntimeException('ID token audience mismatch');
    }
    if (isset($expect['nonce']) && ($payload['nonce'] ?? '') !== $expect['nonce']) {
        throw new RuntimeException('ID token nonce mismatch');
    }

    return $payload;
}

/**
 * Convert an RSA JWK (n, e fields) to a PEM-encoded public key.
 * Builds the DER SubjectPublicKeyInfo structure manually so we have
 * no dependency on ext-gmp or any JOSE library.
 */
/** @param array<string, mixed> $jwk */
function jwk_rsa_to_pem(array $jwk): string
{
    $n = base64url_decode(to_str($jwk['n'] ?? ''));
    $e = base64url_decode(to_str($jwk['e'] ?? ''));
    if ($n === '' || $e === '') throw new RuntimeException('JWK missing n or e');

    // DER integers must not have a leading 1-bit (would be interpreted as negative)
    if (ord($n[0]) & 0x80) $n = "\x00" . $n;
    if (ord($e[0]) & 0x80) $e = "\x00" . $e;

    $intN   = "\x02" . der_len(strlen($n)) . $n;
    $intE   = "\x02" . der_len(strlen($e)) . $e;
    $rsaSeq = "\x30" . der_len(strlen($intN) + strlen($intE)) . $intN . $intE;

    // AlgorithmIdentifier for rsaEncryption (OID 1.2.840.113549.1.1.1) with NULL params
    $oid   = "\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x01\x05\x00";
    $algId = "\x30" . der_len(strlen($oid)) . $oid;

    // BIT STRING: 0x00 unused-bits prefix + DER RSAPublicKey
    $bitStr = "\x03" . der_len(strlen($rsaSeq) + 1) . "\x00" . $rsaSeq;

    // SubjectPublicKeyInfo SEQUENCE
    $spki = "\x30" . der_len(strlen($algId) + strlen($bitStr)) . $algId . $bitStr;

    return "-----BEGIN PUBLIC KEY-----\n"
         . chunk_split(base64_encode($spki), 64, "\n")
         . "-----END PUBLIC KEY-----\n";
}

/** Encode an ASN.1 DER length. */
function der_len(int $len): string
{
    if ($len < 0x80) return chr($len);
    if ($len < 0x100) return "\x81" . chr($len);
    return "\x82" . chr($len >> 8) . chr($len & 0xFF);
}

// ---------------------------------------------------------------------------
// Network scanning — v2.3.0 (#319, #320, #321, #322, #323, #324)
// ---------------------------------------------------------------------------

/**
 * Probe a single IP via ICMP ping.
 *
 * Uses the system `ping` binary (available on Linux, macOS, BSD).
 * The IP MUST be validated by normalize_ip() before this call is made.
 *
 * @return int|null  Round-trip latency in milliseconds parsed from ping output,
 *                   or null if the host did not respond or ICMP is unavailable.
 *                   Returns null and emits an error_log entry when CAP_NET_RAW
 *                   is missing (ping exit code 2 — permission denied).
 */
function ipam_probe_icmp(string $ip, int $timeoutMs = 1000): ?int
{
    // Detect OS for the correct timeout flag
    $isWindows = stripos(PHP_OS, 'WIN') === 0;
    if ($isWindows) return null; // not supported

    $isMac = stripos(PHP_OS, 'Darwin') === 0;
    $timeoutSec = max(1, (int) round($timeoutMs / 1000));

    if ($isMac) {
        // macOS: -W <milliseconds>
        $cmd = ['ping', '-c1', '-W' . $timeoutMs, $ip];
    } else {
        // Linux/BSD: -W <seconds>
        $cmd = ['ping', '-c1', '-W' . $timeoutSec, $ip];
    }

    $desc = [1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
    $proc = @proc_open($cmd, $desc, $pipes); // nosemgrep: php.lang.security.exec-use.exec-use
    if (!is_resource($proc)) return null;

    // Read stdout/stderr to EOF *before* closing pipes. Closing the read end
    // while ping is still writing causes SIGPIPE, which makes ping exit non-zero
    // even when the host responded — producing false "host down" results.
    $stdout = (string) stream_get_contents($pipes[1]);
    stream_get_contents($pipes[2]); // drain stderr
    fclose($pipes[1]);
    fclose($pipes[2]);

    $exitCode = proc_close($proc);

    if ($exitCode === 2) {
        // Permission denied — CAP_NET_RAW capability not available (common in
        // Docker containers). Log once so operators know; return null so the
        // scan records the address as non-responsive rather than silently
        // masking the capability failure.
        error_log('ipam_probe_icmp: ping exited with code 2 (permission denied) — '
            . 'ensure CAP_NET_RAW is available (e.g. cap_add: [NET_RAW] in Docker Compose)');
        return null;
    }

    if ($exitCode !== 0) return null; // host did not respond or timed out

    // Parse actual RTT from ping stdout: matches "time=1.23 ms" or "time<1.23 ms"
    // This is the true round-trip time, not wall-clock process duration.
    if (preg_match('/time[=<]([\d.]+)\s*ms/i', $stdout, $m)) {
        return max(0, (int) round((float) $m[1]));
    }

    // Ping reported success but stdout had no RTT line (unusual) — return 0.
    return 0;
}

/**
 * Probe a single IP via TCP connection.
 *
 * The IP MUST be validated by normalize_ip() before this call is made.
 *
 * @return int|null  Connection latency in milliseconds, or null on failure.
 */
function ipam_probe_tcp(string $ip, int $port, int $timeoutMs = 1000): ?int
{
    $timeout = $timeoutMs / 1000.0;
    $start = microtime(true);
    $sock = @fsockopen($ip, $port, $errno, $errstr, $timeout);
    if (!is_resource($sock)) return null;
    $latency = (int) round((microtime(true) - $start) * 1000);
    fclose($sock);
    return $latency;
}

/**
 * Scan all registered addresses in a subnet and persist the results.
 *
 * @param  string   $method   'icmp' | 'tcp' | 'both'
 * @param  int|null $tcpPort  TCP port to probe when method is 'tcp' or 'both'
 * @param  int      $staleThreshold  Consecutive misses before marking address stale (default: 3)
 * @return array{scanned:int, up:int, down:int, stale_marked:int}
 */
/**
 * Return the reserved binary IPs for a subnet (network + IPv4 broadcast).
 *
 * @return array{network:?string, broadcast:?string}
 */
function ipam_subnet_reserved_bins(PDO $db, int $subnetId): array
{
    $st = $db->prepare("SELECT cidr FROM subnets WHERE id = :id");
    $st->execute([':id' => $subnetId]);
    $row = $st->fetch();
    if (!is_array($row)) {
        return ['network' => null, 'broadcast' => null];
    }
    $cidr = to_str($row['cidr'] ?? '');
    if ($cidr === '') {
        return ['network' => null, 'broadcast' => null];
    }
    $parsed = parse_cidr($cidr);
    if ($parsed === null) {
        return ['network' => null, 'broadcast' => null];
    }
    return [
        'network'   => $parsed['net_bin'],
        'broadcast' => ipam_compute_broadcast_bin($parsed['net_bin'], $parsed['prefix']),
    ];
}

/**
 * @return array{scanned:int, up:int, down:int, skipped:int, stale_marked:int}
 */
function ipam_scan_subnet(PDO $db, int $subnetId, string $method, ?int $tcpPort, int $staleThreshold = 3): array
{
    // Normalise and validate inputs
    if (!in_array($method, ['icmp', 'tcp', 'both'], true)) $method = 'icmp';
    if (in_array($method, ['tcp', 'both'], true) && ($tcpPort === null || $tcpPort < 1 || $tcpPort > 65535)) {
        // Invalid TCP port — fall back to ICMP-only to avoid false-stale marking
        $method = 'icmp';
        $tcpPort = null;
    }
    // After validation: if method needs TCP, $tcpPort is a valid port integer
    $validTcpPort = ($method === 'tcp' || $method === 'both') ? (int) $tcpPort : 0;

    // Reserved IPs for this subnet (network + IPv4 broadcast). Excluded from scan
    // targets: probing network/broadcast produces misleading results and some hosts
    // respond to broadcast pings. IPv6 and IPv4 /31, /32 have no reserved set.
    $reserved = ipam_subnet_reserved_bins($db, $subnetId);

    // Load all addresses in the subnet
    $st = $db->prepare("SELECT id, ip, ip_bin FROM addresses WHERE subnet_id = :sid ORDER BY ip_bin");
    $st->execute([':sid' => $subnetId]);
    $addresses = $st->fetchAll();

    $stats = ['scanned' => 0, 'up' => 0, 'down' => 0, 'skipped' => 0, 'stale_marked' => 0];
    $insert = $db->prepare("
        INSERT INTO scan_results (subnet_id, address_id, ip, method, is_up, latency_ms, scanned_at)
        VALUES (:sid, :aid, :ip, :method, :is_up, :lat, " . ipam_dialect()->now() . ")
    ");
    $updateSeen = $db->prepare("
        UPDATE addresses SET last_seen_at = " . ipam_dialect()->now() . ", is_stale = 0 WHERE id = :id
    ");

    foreach ($addresses as $row) {
        $ip = is_string($row['ip']) ? $row['ip'] : '';
        $addrId = is_int($row['id']) ? $row['id'] : (int) $row['id'];
        $ipBin = isset($row['ip_bin']) && is_string($row['ip_bin']) ? $row['ip_bin'] : '';

        // Skip the subnet's reserved IPs (network + IPv4 broadcast). These must
        // never be probed — some hosts respond to broadcast ICMP, producing
        // misleading up/down results.
        if ($ipBin !== '') {
            if ($reserved['network']   !== null && hash_equals($reserved['network'],   $ipBin)) { $stats['skipped']++; continue; }
            if ($reserved['broadcast'] !== null && hash_equals($reserved['broadcast'], $ipBin)) { $stats['skipped']++; continue; }
        }

        // Validate IP before any system call
        $norm = normalize_ip($ip);
        if ($norm === null) continue;
        $validIp = $norm['ip'];

        $latency = null;
        $isUp = false;

        if ($method === 'icmp' || $method === 'both') {
            $lat = ipam_probe_icmp($validIp);
            if ($lat !== null) { $latency = $lat; $isUp = true; }
        }
        if (($method === 'tcp' || $method === 'both') && $validTcpPort > 0 && !$isUp) {
            $lat = ipam_probe_tcp($validIp, $validTcpPort);
            if ($lat !== null) { $latency = $lat; $isUp = true; }
        }

        $insert->execute([
            ':sid'    => $subnetId,
            ':aid'    => $addrId,
            ':ip'     => $validIp,
            ':method' => $method,
            ':is_up'  => $isUp ? 1 : 0,
            ':lat'    => $latency,
        ]);

        if ($isUp) {
            $updateSeen->execute([':id' => $addrId]);
            $stats['up']++;
        } else {
            $stats['down']++;
        }
        $stats['scanned']++;
    }

    $stats['stale_marked'] = ipam_mark_stale_addresses($db, $subnetId, $staleThreshold);
    return $stats;
}

/**
 * Mark addresses stale when they missed N consecutive scans.
 * Clears is_stale when the most recent scan result is up.
 *
 * @return int  Number of addresses whose is_stale flag changed.
 */
function ipam_mark_stale_addresses(PDO $db, int $subnetId, int $missThreshold = 3): int
{
    // Defensive clamp — caller threshold comes from a tenant setting that
    // operators can mis-edit. 0/negative produces nonsense SQL (LIMIT 0
    // means no stale marking ever happens; negative errors on some engines).
    // Very large values fan out scan_results reads. Bound to [1, 50].
    // (#1162, PASS-C F-S2-05)
    if ($missThreshold < 1)  $missThreshold = 1;
    if ($missThreshold > 50) $missThreshold = 50;

    // Reserved IPs (network, IPv4 broadcast) are excluded from stale marking so
    // they don't accrue a stale flag from historical scan_results rows.
    $reserved = ipam_subnet_reserved_bins($db, $subnetId);

    // Fetch per-address: count of recent consecutive down results
    $st = $db->prepare("
        SELECT a.id,
               a.ip_bin,
               a.is_stale,
               (
                 SELECT COALESCE(SUM(CASE WHEN r.is_up = 0 THEN 1 ELSE 0 END), 0)
                 FROM (
                   SELECT is_up
                   FROM scan_results
                   WHERE address_id = a.id
                   ORDER BY scanned_at DESC
                   LIMIT :thresh
                 ) r
               ) AS recent_misses,
               (SELECT is_up FROM scan_results WHERE address_id = a.id ORDER BY scanned_at DESC LIMIT 1) AS last_up
        FROM addresses a
        WHERE a.subnet_id = :sid
    ");
    $st->bindValue(':sid', $subnetId, PDO::PARAM_INT);
    $st->bindValue(':thresh', $missThreshold, PDO::PARAM_INT);
    $st->execute();
    $rows = $st->fetchAll();

    $changed = 0;
    $updates = [];

    foreach ($rows as $row) {
        $id = (int) $row['id'];
        $currentlyStale = (int) $row['is_stale'];
        $misses = (int) $row['recent_misses'];
        $lastUp = $row['last_up'];
        $ipBin = isset($row['ip_bin']) && is_string($row['ip_bin']) ? $row['ip_bin'] : '';

        // Skip reserved IPs — they are never probed, so any historical scan data
        // should not drive their stale flag.
        if ($ipBin !== '') {
            if ($reserved['network']   !== null && hash_equals($reserved['network'],   $ipBin)) continue;
            if ($reserved['broadcast'] !== null && hash_equals($reserved['broadcast'], $ipBin)) continue;
        }

        $shouldBeStale = ($misses >= $missThreshold && $lastUp !== null && (int) $lastUp === 0) ? 1 : 0;

        if ($shouldBeStale !== $currentlyStale) {
            $updates[] = ['id' => $id, 'stale' => $shouldBeStale];
        }
    }

    if ($updates !== []) {
        $db->beginTransaction();
        try {
            $setStale = $db->prepare("UPDATE addresses SET is_stale = :stale, updated_at = " . ipam_dialect()->now() . " WHERE id = :id");
            foreach ($updates as $u) {
                $setStale->execute([':stale' => $u['stale'], ':id' => $u['id']]);
            }
            $changed = count($updates);
            // Audit with system actor (works in CLI and web contexts)
            $u = current_user();
            $db->prepare("INSERT INTO audit_log (user_id, username, action, entity_type, entity_id, details)
                          VALUES (:uid, :un, 'scan.stale_update', 'subnet', :eid, :dt)")
               ->execute([
                   ':uid' => $u['id'] ?: null,
                   ':un'  => $u['username'] !== '' ? $u['username'] : 'system',
                   ':eid' => $subnetId,
                   ':dt'  => "marked=$changed threshold=$missThreshold",
               ]);
            $db->commit();
        } catch (\Throwable $e) {
            $db->rollBack();
            throw $e;
        }
    }

    return $changed;
}

/**
 * Parse a pasted ARP / neighbour table into IP+MAC pairs.
 *
 * Accepts common dump formats:
 *   - `ip mac`         (space-separated, one per line)
 *   - `ip\tmac`        (tab-separated)
 *   - `ip,mac`         (CSV)
 *   - `ip mac iface`   (extra columns ignored)
 *
 * @return list<array{ip:string, mac:string}>
 */
function ipam_parse_arp_table(string $raw): array
{
    $results = [];
    $lines = preg_split('/\r?\n/', trim($raw));
    if ($lines === false) return [];

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) continue;

        // Split on whitespace or commas
        $parts = preg_split('/[\s,]+/', $line);
        if ($parts === false || count($parts) < 2) continue;

        // Find the first valid IP and first valid MAC in the parts.
        // Strip parentheses to handle Linux `arp -a` format: hostname (ip) at mac ...
        $foundIp = null;
        $foundMac = null;
        foreach ($parts as $part) {
            $bare = trim($part, '()');
            if ($foundIp === null && filter_var($bare, FILTER_VALIDATE_IP) !== false) {
                $foundIp = $bare;
            } elseif ($foundMac === null && preg_match('/^([0-9a-fA-F]{2}[:\-.]){5}[0-9a-fA-F]{2}$/', $part)) {
                $foundMac = $part;
            }
            if ($foundIp !== null && $foundMac !== null) break;
        }

        if ($foundIp === null || $foundMac === null) continue;

        // Validate IP through normalize_ip for canonicalization
        $norm = normalize_ip($foundIp);
        if ($norm === null) continue;

        $results[] = ['ip' => $norm['ip'], 'mac' => $foundMac];
    }
    return $results;
}

/**
 * Apply parsed ARP entries: update addresses.mac for matching IPs in a subnet.
 *
 * @param  list<array{ip:string, mac:string}> $entries
 * @return array{matched:int, updated:int, skipped:int}
 */
function ipam_apply_arp_import(PDO $db, array $entries, int $subnetId): array
{
    $stats = ['matched' => 0, 'updated' => 0, 'skipped' => 0];
    $find = $db->prepare("SELECT id, mac FROM addresses WHERE subnet_id = :sid AND ip = :ip LIMIT 1");
    $update = $db->prepare("UPDATE addresses SET mac = :mac, updated_at = " . ipam_dialect()->now() . " WHERE id = :id");

    foreach ($entries as $entry) {
        $ip  = $entry['ip'];
        $mac = $entry['mac'];
        if ($ip === '' || $mac === '') { $stats['skipped']++; continue; }

        $find->execute([':sid' => $subnetId, ':ip' => $ip]);
        /** @var array<string, mixed>|false $addr */
        $addr = $find->fetch();
        if (!$addr) { $stats['skipped']++; continue; }

        $stats['matched']++;
        if (to_str($addr['mac']) === $mac) { $stats['skipped']++; continue; }

        $update->execute([':mac' => $mac, ':id' => to_int($addr['id'])]);
        $stats['updated']++;
    }
    return $stats;
}

// ── Password reset + email verification helpers (v3.2.0) ─────────────────────

/**
 * Return the canonical HTTPS base URL of this install (no trailing slash).
 * Used to build absolute links in emails.
 */
function ipam_app_base_url(): string
{
    $cfg  = $GLOBALS['config'] ?? null;
    $base = is_array($cfg) ? rtrim(to_str($cfg['base_url'] ?? ''), '/') : '';
    $parsed = parse_url($base);
    if ($base === '' || ($parsed['scheme'] ?? '') !== 'https' || empty($parsed['host'])) {
        throw new RuntimeException('config.base_url must be set to an https:// URL for email links.');
    }
    return $base;
}

/**
 * Create a password-reset token for the given user.
 * Returns the raw (unhashed) token to embed in the reset link.
 *
 * Enforces max 3 active tokens per user per hour (rate limit).
 * Token hash is stored with 1-hour expiry; raw token is returned to caller.
 */
function ipam_create_reset_token(PDO $db, int $userId): ?string
{
    $rawToken  = bin2hex(random_bytes(32));
    $tokenHash = hash('sha256', $rawToken);
    $expiresAt = gmdate('Y-m-d H:i:s', time() + 3600);
    $rateWindowStart = gmdate('Y-m-d H:i:s', time() - 3600);

    $db->beginTransaction();
    try {
        // On MySQL/Postgres, lock the user row so concurrent reset requests for
        // the same user are serialized. SQLite serializes via its write lock.
        if ($db->getAttribute(\PDO::ATTR_DRIVER_NAME) !== 'sqlite') {
            $db->prepare("SELECT id FROM users WHERE id = :uid FOR UPDATE")
               ->execute([':uid' => $userId]);
        }

        $rateSt = $db->prepare(
            "SELECT COUNT(*) FROM password_reset_tokens
              WHERE user_id = :uid AND created_at > :window AND used_at IS NULL"
        );
        $rateSt->execute([':uid' => $userId, ':window' => $rateWindowStart]);
        if ((int)$rateSt->fetchColumn() >= 3) {
            $db->rollBack();
            return null;
        }

        $db->prepare(
            "INSERT INTO password_reset_tokens (user_id, token_hash, expires_at)
             VALUES (:uid, :hash, :exp)"
        )->execute([':uid' => $userId, ':hash' => $tokenHash, ':exp' => $expiresAt]);

        $db->commit();
    } catch (\Exception $e) {
        $db->rollBack();
        throw $e;
    }

    return $rawToken;
}

/**
 * Validate and consume a password-reset token.
 * Returns the user_id if the token is valid, not expired, and not used.
 * Marks the token as used (single-use).
 */
function ipam_consume_reset_token(PDO $db, string $rawToken): ?int
{
    $tokenHash = hash('sha256', $rawToken);
    $now       = gmdate('Y-m-d H:i:s');

    $db->beginTransaction();
    try {
        $st = $db->prepare(
            "SELECT id, user_id FROM password_reset_tokens
              WHERE token_hash = :hash
                AND used_at IS NULL
                AND expires_at > :now"
        );
        $st->execute([':hash' => $tokenHash, ':now' => $now]);
        /** @var array<string, mixed>|false $row */
        $row = $st->fetch();

        if (!$row) {
            $db->rollBack();
            return null;
        }

        $upd = $db->prepare(
            "UPDATE password_reset_tokens SET used_at = " . ipam_dialect()->now() . " WHERE id = :id AND used_at IS NULL"
        );
        $upd->execute([':id' => to_int($row['id'])]);

        if ($upd->rowCount() !== 1) {
            $db->rollBack();
            return null;
        }

        $db->commit();
        return to_int($row['user_id']);
    } catch (\Throwable $e) {
        $db->rollBack();
        throw $e;
    }
}

/**
 * Send a password-reset link email to the given address.
 * Returns true on success.
 */
function ipam_send_reset_email(string $toAddress, string $toName, string $rawToken): bool
{
    $appName = trim(to_str(ipam_setting('branding.site_name'))) ?: 'Simple PHP IPAM';
    try {
        $base = ipam_app_base_url();
    } catch (\RuntimeException) {
        return false;
    }
    $link    = $base . '/reset_password.php?token=' . rawurlencode($rawToken);

    $subject = $appName . ' — Password Reset';

    $text = "Hi " . ($toName ?: $toAddress) . ",\n\n"
        . "A password reset was requested for your " . $appName . " account.\n\n"
        . "Reset link (valid for 1 hour):\n" . $link . "\n\n"
        . "If you did not request this, you can safely ignore this email.\n\n"
        . "— " . $appName;

    $html = "<p>Hi " . e($toName ?: $toAddress) . ",</p>"
        . "<p>A password reset was requested for your <strong>" . e($appName) . "</strong> account.</p>"
        . "<p><a href=\"" . e($link) . "\">Reset your password</a> (link valid for 1 hour).</p>"
        . "<p>If you did not request this, you can safely ignore this email.</p>"
        . "<p>— " . e($appName) . "</p>";

    $result = ipam_send_mail($toAddress, $subject, $text, $html);
    return $result['success'];
}

/**
 * Initiate an email-change verification for $userId.
 * Stores pending_email + token hash + expiry on the user row and sends
 * a verification email to the NEW address.
 */
/**
 * @return array{success: bool, error: string}
 */
function ipam_send_email_verification(PDO $db, int $userId, string $newEmail): array
{
    $appName = trim(to_str(ipam_setting('branding.site_name'))) ?: 'Simple PHP IPAM';
    try {
        $base = ipam_app_base_url();
    } catch (\RuntimeException $e) {
        error_log('ipam_send_email_verification: ' . $e->getMessage());
        return ['success' => false, 'error' => $e->getMessage()];
    }

    $rawToken  = bin2hex(random_bytes(32));
    $tokenHash = hash('sha256', $rawToken);
    $expiresAt = gmdate('Y-m-d H:i:s', time() + 3600);
    $link      = $base . '/change_password.php?verify_email=' . rawurlencode($rawToken);

    $subject = $appName . ' — Verify your new email address';

    $text = "Please verify your new email address for " . $appName . ".\n\n"
        . "Verification link (valid for 1 hour):\n" . $link . "\n\n"
        . "If you did not request this change, you can safely ignore this email.\n\n"
        . "— " . $appName;

    $html = "<p>Please verify your new email address for <strong>" . e($appName) . "</strong>.</p>"
        . "<p><a href=\"" . e($link) . "\">Verify email address</a> (link valid for 1 hour).</p>"
        . "<p>If you did not request this change, you can safely ignore this email.</p>"
        . "<p>— " . e($appName) . "</p>";

    $db->prepare(
        "UPDATE users SET pending_email = :email,
                          pending_email_token_hash = :hash,
                          pending_email_expires_at = :exp
          WHERE id = :id"
    )->execute([':email' => $newEmail, ':hash' => $tokenHash, ':exp' => $expiresAt, ':id' => $userId]);

    $result = ipam_send_mail($newEmail, $subject, $text, $html);
    if (!$result['success']) {
        $err = to_str($result['error'] ?? 'Email send failed.');
        error_log('ipam_send_email_verification: ' . $err);
        $db->prepare(
            "UPDATE users SET pending_email = NULL,
                              pending_email_token_hash = NULL,
                              pending_email_expires_at = NULL
              WHERE id = :id"
        )->execute([':id' => $userId]);
        return ['success' => false, 'error' => $err];
    }

    return ['success' => true, 'error' => ''];
}

// ---------------------------------------------------------------------------
// DHCP config renderers — v3.4.0 #403
// ---------------------------------------------------------------------------

/**
 * Render an ISC dhcpd.conf snippet for the given (or all) IPv4 subnets.
 *
 * @param int[] $subnetIds Leave empty to include all IPv4 subnets.
 */
function ipam_render_dhcpd_conf(PDO $db, array $subnetIds): string
{
    require_once __DIR__ . '/version.php';
    $subnets = ipam_dhcp_load_subnets($db, $subnetIds);
    $lines   = [
        '# Generated by Simple PHP IPAM v' . IPAM_VERSION
            . ' on ' . gmdate('Y-m-d H:i:s') . ' UTC',
        '# Subnets: ' . count($subnets),
        '',
    ];

    foreach ($subnets as $s) {
        $netmask = ipam_prefix_to_netmask(to_int($s['prefix']));
        $lines[] = 'subnet ' . to_str($s['network']) . ' netmask ' . $netmask . ' {';

        if (!empty($s['dhcp_routers'])) {
            $safeIps = implode(', ', array_filter(
                array_map('trim', explode(',', to_str($s['dhcp_routers']))),
                fn($t) => $t !== '' && filter_var($t, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false
            ));
            if ($safeIps !== '') $lines[] = '  option routers ' . $safeIps . ';';
        }
        if (!empty($s['dhcp_dns_servers'])) {
            $safeIps = implode(', ', array_filter(
                array_map('trim', explode(',', to_str($s['dhcp_dns_servers']))),
                fn($t) => $t !== '' && filter_var($t, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false
            ));
            if ($safeIps !== '') $lines[] = '  option domain-name-servers ' . $safeIps . ';';
        }
        if (!empty($s['dhcp_domain_name'])) {
            $domain = trim(to_str($s['dhcp_domain_name']));
            if (preg_match('/^[a-zA-Z0-9]([a-zA-Z0-9\-.]{0,253}[a-zA-Z0-9])?$/', $domain)) {
                $quoted  = str_replace(['\\', '"'], ['\\\\', '\\"'], $domain);
                $lines[] = '  option domain-name "' . $quoted . '";';
            }
        }
        if ($s['dhcp_lease_default'] !== null && $s['dhcp_lease_default'] !== '') {
            $lines[] = '  default-lease-time ' . to_int($s['dhcp_lease_default']) . ';';
        }
        if ($s['dhcp_lease_max'] !== null && $s['dhcp_lease_max'] !== '') {
            $lines[] = '  max-lease-time ' . to_int($s['dhcp_lease_max']) . ';';
        }
        if (!empty($s['dhcp_next_server'])) {
            $nextSrv = trim(to_str($s['dhcp_next_server']));
            if (filter_var($nextSrv, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
                $lines[] = '  next-server ' . $nextSrv . ';';
            }
        }
        if (!empty($s['dhcp_boot_filename'])) {
            $bootFile = preg_replace('/[;\n\r{}]/', '', trim(to_str($s['dhcp_boot_filename']))) ?? '';
            if ($bootFile !== '') {
                $quoted  = str_replace(['\\', '"'], ['\\\\', '\\"'], $bootFile);
                $lines[] = '  filename "' . $quoted . '";';
            }
        }

        foreach (ipam_dhcp_load_reservations($db, to_int($s['id'])) as $r) {
            $mac  = ipam_normalize_mac_for_dhcp(to_str($r['mac']));
            if ($mac === null) continue;
            $rawHost = to_str($r['hostname']);
            $label   = ipam_dhcp_normalize_hostname($rawHost) ?? 'host';
            $suffix  = str_replace('.', '-', to_str($r['ip']));
            $name    = $label . '-' . $suffix;
            $lines[] = '  host ' . $name . ' {';
            $lines[] = '    hardware ethernet ' . $mac . ';';
            $lines[] = '    fixed-address ' . to_str($r['ip']) . ';';
            $lines[] = '  }';
        }

        $lines[] = '}';
        $lines[] = '';
    }

    return implode("\n", $lines);
}

/**
 * Render a Kea 2.x JSON config fragment for the given (or all) IPv4 subnets.
 *
 * @param int[] $subnetIds Leave empty to include all IPv4 subnets.
 */
function ipam_render_kea_json(PDO $db, array $subnetIds): string
{
    $subnets = ipam_dhcp_load_subnets($db, $subnetIds);
    $subnet4 = [];

    foreach ($subnets as $s) {
        /** @var array<string,mixed> $entry */
        $entry = ['subnet' => to_str($s['cidr'])];

        $optionData = [];
        if (!empty($s['dhcp_routers'])) {
            $safeRouters = implode(',', array_filter(
                array_map('trim', explode(',', to_str($s['dhcp_routers']))),
                fn($t) => $t !== '' && filter_var($t, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false
            ));
            if ($safeRouters !== '') $optionData[] = ['name' => 'routers', 'data' => $safeRouters];
        }
        if (!empty($s['dhcp_dns_servers'])) {
            $safeDns = implode(',', array_filter(
                array_map('trim', explode(',', to_str($s['dhcp_dns_servers']))),
                fn($t) => $t !== '' && filter_var($t, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false
            ));
            if ($safeDns !== '') $optionData[] = ['name' => 'domain-name-servers', 'data' => $safeDns];
        }
        if (!empty($s['dhcp_domain_name'])) {
            $optionData[] = ['name' => 'domain-name', 'data' => trim(to_str($s['dhcp_domain_name']))];
        }
        if (!empty($s['dhcp_next_server'])) {
            $optionData[] = ['name' => 'tftp-server-name', 'data' => trim(to_str($s['dhcp_next_server']))];
        }
        if (!empty($s['dhcp_boot_filename'])) {
            $optionData[] = ['name' => 'boot-file-name', 'data' => trim(to_str($s['dhcp_boot_filename']))];
        }
        if (!empty($optionData)) {
            $entry['option-data'] = $optionData;
        }

        if ($s['dhcp_lease_default'] !== null && $s['dhcp_lease_default'] !== '') {
            $entry['valid-lifetime'] = to_int($s['dhcp_lease_default']);
        }
        if ($s['dhcp_lease_max'] !== null && $s['dhcp_lease_max'] !== '') {
            $entry['max-valid-lifetime'] = to_int($s['dhcp_lease_max']);
        }

        $reservations = ipam_dhcp_load_reservations($db, to_int($s['id']));
        if (!empty($reservations)) {
            $resArr = [];
            foreach ($reservations as $r) {
                $mac = ipam_normalize_mac_for_dhcp(to_str($r['mac']));
                if ($mac === null) continue;
                /** @var array<string,mixed> $resEntry */
                $resEntry = [
                    'hw-address' => $mac,
                    'ip-address' => to_str($r['ip']),
                ];
                $label = ipam_dhcp_normalize_hostname(to_str($r['hostname']));
                if ($label !== null) {
                    $resEntry['hostname'] = $label;
                }
                $resArr[] = $resEntry;
            }
            $entry['reservations'] = $resArr;
        }

        $subnet4[] = $entry;
    }

    $doc = ['Dhcp4' => ['subnet4' => $subnet4]];
    $json = json_encode($doc, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    if ($json === false) throw new RuntimeException('json_encode failed: ' . json_last_error_msg());
    return $json;
}

/**
 * Load IPv4 subnets with DHCP option columns, ordered by network_bin.
 *
 * @param int[] $subnetIds If non-empty, restrict to these IDs.
 * @return list<array<string,mixed>>
 */
function ipam_dhcp_load_subnets(PDO $db, array $subnetIds): array
{
    $sql = "SELECT id, cidr, network, prefix,
                   dhcp_routers, dhcp_dns_servers, dhcp_domain_name,
                   dhcp_lease_default, dhcp_lease_max,
                   dhcp_next_server, dhcp_boot_filename
            FROM subnets
            WHERE ip_version = 4";

    if (empty($subnetIds)) {
        $st = $db->query($sql . " ORDER BY network_bin");
        if ($st === false) return [];
        /** @var list<array<string,mixed>> */
        return $st->fetchAll();
    }

    $placeholders = implode(',', array_fill(0, count($subnetIds), '?'));
    $st = $db->prepare($sql . " AND id IN ({$placeholders}) ORDER BY network_bin");
    $st->execute(array_values(array_map('intval', $subnetIds)));
    /** @var list<array<string,mixed>> */
    return $st->fetchAll();
}

/**
 * Load reserved addresses with a non-empty MAC for a subnet.
 *
 * @return list<array<string,mixed>>
 */
function ipam_dhcp_load_reservations(PDO $db, int $subnetId): array
{
    $st = $db->prepare(
        "SELECT ip, mac, hostname FROM addresses
         WHERE subnet_id = :sid AND status = 'reserved' AND mac != ''
         ORDER BY ip_bin"
    );
    $st->execute([':sid' => $subnetId]);
    /** @var list<array<string,mixed>> */
    return $st->fetchAll();
}

/** Convert a CIDR prefix length to a dotted-decimal netmask string. */
function ipam_prefix_to_netmask(int $prefix): string
{
    if ($prefix === 0) return '0.0.0.0';
    $mask = (int)((0xFFFFFFFF << (32 - $prefix)) & 0xFFFFFFFF);
    return (string)(inet_ntop(pack('N', $mask)) ?: '0.0.0.0');
}

/** Normalise any MAC address format to colon-separated lowercase octets. */
function ipam_normalize_mac_for_dhcp(string $mac): ?string
{
    $hex = preg_replace('/[^0-9a-fA-F]/', '', $mac);
    if (!is_string($hex) || strlen($hex) !== 12) return null;
    return implode(':', str_split(strtolower($hex), 2));
}

/**
 * Normalise a DHCP reservation hostname for both Kea and ISC dhcpd output.
 * Returns null if no usable label can be derived; caller falls back to
 * 'host' synthesis.
 *
 * Single-label, RFC 1123 letter-digit-hyphen, leading alpha (after trimming
 * leading digits/hyphens), max 63 chars per label. Dotted inputs take the
 * leftmost label — multi-label FQDNs are out of scope; neither current
 * renderer supports them well.
 *
 * (#1163, PASS-C F-S6-01) — both renderers must agree on what's emitted.
 */
function ipam_dhcp_normalize_hostname(string $raw): ?string
{
    $raw = trim($raw);
    if ($raw === '') return null;
    $label = explode('.', $raw, 2)[0];
    $label = preg_replace('/[^a-zA-Z0-9-]/', '-', $label) ?? '';
    $label = ltrim($label, '0123456789-');
    $label = rtrim($label, '-');
    if ($label === '') return null;
    if (strlen($label) > 63) {
        $label = substr($label, 0, 63);
        // Truncation can land on a hyphen; re-trim so the emitted label
        // still conforms to RFC 1123 (no trailing '-').
        $label = rtrim($label, '-');
        if ($label === '') return null;
    }
    return $label;
}

// ── Custom field definitions (v3.5.0, #313/#596) ──────────────────────────

/**
 * Return all non-deleted custom field definitions, ordered by entity_type,
 * sort_order, then key. When $entityType is provided only that entity's
 * definitions are returned.
 *
 * @return list<array<string,mixed>>
 */
function custom_field_def_list(PDO $db, ?string $entityType = null): array
{
    $k = ipam_key_col();
    if ($entityType !== null) {
        $st = $db->prepare(
            "SELECT * FROM custom_field_defs WHERE is_deleted = 0 AND entity_type = :et
             ORDER BY sort_order, $k"
        );
        $st->execute([':et' => $entityType]);
    } else {
        $st = $db->query(
            "SELECT * FROM custom_field_defs WHERE is_deleted = 0
             ORDER BY entity_type, sort_order, $k"
        );
        if ($st === false) throw new \RuntimeException('Query failed');
    }
    /** @var list<array<string,mixed>> */
    return $st->fetchAll();
}

/**
 * Return true if any row in the table that corresponds to $entityType has a
 * non-null JSON value stored for $key.  Uses dialect-specific JSON extraction
 * so it works on SQLite, MySQL 8.0+, and PostgreSQL 14+.
 *
 * $key is validated to match ^[a-z][a-z0-9_]{0,62}$ before this is called,
 * so it is safe to embed in the JSON path string.
 */
function custom_field_in_use(PDO $db, string $key, string $entityType): bool
{
    $tbl    = $entityType === 'subnet' ? 'subnets' : 'addresses';
    $driver = ipam_dialect()->driver_name();

    if ($driver === 'sqlite') {
        $st = $db->prepare(
            "SELECT EXISTS(SELECT 1 FROM {$tbl} WHERE json_extract(custom_fields, '$.' || :k) IS NOT NULL)"
        );
    } elseif ($driver === 'mysql') {
        $st = $db->prepare(
            "SELECT EXISTS(SELECT 1 FROM {$tbl} WHERE JSON_EXTRACT(custom_fields, CONCAT('$.', :k)) IS NOT NULL)"
        );
    } else {
        $st = $db->prepare(
            "SELECT EXISTS(SELECT 1 FROM {$tbl} WHERE (custom_fields::json)->>:k IS NOT NULL)"
        );
    }
    $st->execute([':k' => $key]);
    return (bool)$st->fetchColumn();
}

/**
 * Decode a JSON custom_fields column value into an associative array.
 * Returns [] on empty, null, or malformed JSON.
 *
 * @return array<string,mixed>
 */
function parse_custom_fields_row(string $json): array
{
    if ($json === '' || $json === 'null') return [];
    $decoded = json_decode($json, true);
    return is_array($decoded) ? $decoded : [];
}

/**
 * Canonical JSON serialization for the custom_fields column.
 * Null values are stripped so the stored JSON stays compact.
 *
 * @param array<mixed,mixed> $values
 */
function serialize_custom_fields_row(array $values): string
{
    $filtered = array_filter($values, fn($v) => $v !== null);
    return json_encode($filtered, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '{}';
}

/**
 * Validate a raw POST payload against the active custom field definitions.
 * Returns the typed values array (ready for serialize_custom_fields_row).
 * Throws InvalidArgumentException on the first type mismatch or missing required field.
 *
 * @param list<array<string,mixed>> $defs     Output of custom_field_def_list()
 * @param array<mixed,mixed>        $payload  Flat key→raw-value map from $_POST or json_decode (keys without the 'cf_' prefix)
 * @return array<string,mixed>
 */
function validate_custom_fields_payload(array $defs, array $payload): array
{
    $result = [];
    foreach ($defs as $def) {
        $key      = to_str($def['key']);
        $type     = to_str($def['type']);
        $required = (bool)$def['is_required'];

        // Boolean: checkbox presence = true, absence = false; required does not apply
        if ($type === 'boolean') {
            $result[$key] = isset($payload[$key]) && $payload[$key] !== '' && $payload[$key] !== '0';
            continue;
        }

        $raw = isset($payload[$key]) ? to_str($payload[$key]) : '';

        if ($raw === '') {
            if ($required) {
                throw new \InvalidArgumentException($key . ': this field is required');
            }
            $result[$key] = null;
            continue;
        }

        switch ($type) {
            case 'text':
                $result[$key] = $raw;
                break;
            case 'number':
                if (!is_numeric($raw)) {
                    throw new \InvalidArgumentException($key . ': expected a number');
                }
                $result[$key] = str_contains($raw, '.') ? (float)$raw : (int)$raw;
                break;
            case 'date':
                if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw)) {
                    throw new \InvalidArgumentException($key . ': expected YYYY-MM-DD format');
                }
                $result[$key] = $raw;
                break;
            case 'select':
                $options = json_decode(to_str($def['options'] ?? '[]'), true);
                $options = is_array($options) ? $options : [];
                if (!in_array($raw, $options, true)) {
                    throw new \InvalidArgumentException($key . ': not a valid option');
                }
                $result[$key] = $raw;
                break;
        }
    }
    return $result;
}

/**
 * Validate a custom_fields payload arriving from the JSON API.
 * Values are already typed (int, float, bool, string, null) — no coercion is done.
 * Unknown keys are rejected. Required fields must be non-null.
 *
 * @param list<array<string,mixed>> $defs     Output of custom_field_def_list()
 * @param array<mixed,mixed>        $payload  Decoded JSON object (key→typed value)
 * @return array<string,mixed>
 * @throws \InvalidArgumentException on the first type mismatch, unknown key, or missing required field
 */
function validate_custom_fields_api_payload(array $defs, array $payload): array
{
    $defKeys = [];
    foreach ($defs as $def) {
        $defKeys[to_str($def['key'])] = $def;
    }

    // Reject unknown keys
    foreach (array_keys($payload) as $k) {
        if (!isset($defKeys[$k])) {
            throw new \InvalidArgumentException($k . ': unknown custom field key');
        }
    }

    $result = [];
    foreach ($defs as $def) {
        $key      = to_str($def['key']);
        $type     = to_str($def['type']);
        $required = (bool)$def['is_required'];

        $present = array_key_exists($key, $payload);
        $val     = $present ? $payload[$key] : null;

        if ($val === null) {
            if ($required) {
                throw new \InvalidArgumentException($key . ': this field is required');
            }
            $result[$key] = null;
            continue;
        }

        switch ($type) {
            case 'text':
                if (!is_string($val)) {
                    throw new \InvalidArgumentException($key . ': expected string, got ' . gettype($val));
                }
                $result[$key] = $val;
                break;
            case 'number':
                if (!is_int($val) && !is_float($val)) {
                    throw new \InvalidArgumentException($key . ': expected number, got ' . gettype($val));
                }
                $result[$key] = $val;
                break;
            case 'date':
                if (!is_string($val) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $val)) {
                    throw new \InvalidArgumentException($key . ': expected YYYY-MM-DD string');
                }
                $result[$key] = $val;
                break;
            case 'boolean':
                if (!is_bool($val)) {
                    throw new \InvalidArgumentException($key . ': expected boolean, got ' . gettype($val));
                }
                $result[$key] = $val;
                break;
            case 'select':
                if (!is_string($val)) {
                    throw new \InvalidArgumentException($key . ': expected string, got ' . gettype($val));
                }
                $options = json_decode(to_str($def['options'] ?? '[]'), true);
                $options = is_array($options) ? $options : [];
                if (!in_array($val, $options, true)) {
                    throw new \InvalidArgumentException($key . ': not a valid option');
                }
                $result[$key] = $val;
                break;
        }
    }
    return $result;
}

/**
 * Render HTML form inputs for a set of custom field definitions.
 * The name of each input is "{$namePrefix}{$key}".
 * Returns '' when $defs is empty (no heading rendered).
 *
 * @param list<array<string,mixed>> $defs       Output of custom_field_def_list()
 * @param array<string,mixed>       $values     Current stored values (from parse_custom_fields_row)
 * @param string                    $namePrefix Form input name prefix (default 'cf_')
 */
function render_custom_field_inputs(array $defs, array $values, string $namePrefix = 'cf_'): string
{
    if (empty($defs)) return '';

    $html  = '<div class="custom-field-group">';
    $html .= '<h4 class="custom-field-heading">Custom fields</h4>';

    foreach ($defs as $def) {
        $key      = to_str($def['key']);
        $label    = e(to_str($def['label']));
        $type     = to_str($def['type']);
        $required = (bool)$def['is_required'];
        $name     = e($namePrefix . $key);
        $inputId  = 'cf-inp-' . e($key);
        $val      = $values[$key] ?? null;
        $reqAttr  = $required ? ' required' : '';
        $reqMark  = $required ? '<span class="cf-required" aria-hidden="true">*</span>' : '';
        $cfKey    = ' data-cf-key="' . e($key) . '"';

        $html .= '<div class="custom-field-row">';

        if ($type === 'boolean') {
            $checked = ($val === true || $val === 1 || $val === '1') ? ' checked' : '';
            $html .= '<label class="form-check" for="' . $inputId . '">';
            $html .= '<input id="' . $inputId . '" type="checkbox" name="' . $name . '" value="1"' . $cfKey . $checked . '>';
            $html .= ' ' . $label . $reqMark;
            $html .= '</label>';
        } else {
            $html .= '<label for="' . $inputId . '">' . $label . ' ' . $reqMark . '<br>';
            switch ($type) {
                case 'text':
                    $html .= '<input id="' . $inputId . '" type="text" name="' . $name . '" value="' . e(to_str($val)) . '"' . $cfKey . $reqAttr . '>';
                    break;
                case 'number':
                    $html .= '<input id="' . $inputId . '" type="number" step="any" name="' . $name . '" value="' . e(to_str($val)) . '"' . $cfKey . $reqAttr . '>';
                    break;
                case 'date':
                    $html .= '<input id="' . $inputId . '" type="date" name="' . $name . '" value="' . e(to_str($val)) . '"' . $cfKey . $reqAttr . '>';
                    break;
                case 'select':
                    $options = json_decode(to_str($def['options'] ?? '[]'), true);
                    $options = is_array($options) ? $options : [];
                    $html .= '<select id="' . $inputId . '" name="' . $name . '"' . $cfKey . $reqAttr . '>';
                    $html .= '<option value="">(none)</option>';
                    foreach ($options as $opt) {
                        $optE = e(to_str($opt));
                        $sel  = to_str($val) === to_str($opt) ? ' selected' : '';
                        $html .= '<option value="' . $optE . '"' . $sel . '>' . $optE . '</option>';
                    }
                    $html .= '</select>';
                    break;
            }
            $html .= '</label>';
        }

        $html .= '</div>';
    }

    $html .= '</div>';
    return $html;
}

// ============================================================
// TOTP 2FA helpers (v3.6.0, #418)
// ============================================================

function ipam_totp_tfa(): \RobThree\Auth\TwoFactorAuth {
    static $tfa = null;
    if ($tfa === null) {
        $tfa = new \RobThree\Auth\TwoFactorAuth(null, 6, 30, \RobThree\Auth\Algorithm::Sha1);
    }
    return $tfa;
}

function ipam_totp_generate_secret(): string {
    return ipam_totp_tfa()->createSecret(160);
}

function ipam_totp_get_uri(string $secret, string $issuer, string $accountName): string {
    return ipam_totp_tfa()->getQRText($issuer . ':' . $accountName, $secret);
}

function ipam_totp_verify(string $secret, string $code, int $discrepancy = 1): bool {
    return ipam_totp_tfa()->verifyCode($secret, $code, $discrepancy);
}

function ipam_totp_encrypt_secret(string $secret, string $key): string {
    if ($key === '') {
        throw new \RuntimeException('TOTP encryption requires a non-empty app_secret');
    }
    $iv  = random_bytes(12);
    $tag = '';
    $enc = openssl_encrypt($secret, 'aes-256-gcm', hash('sha256', $key, true), OPENSSL_RAW_DATA, $iv, $tag, '', 16);
    if ($enc === false) {
        throw new \RuntimeException('TOTP secret encryption failed');
    }
    // Prefix '$2$' distinguishes GCM (authenticated) from legacy CBC blobs.
    return '$2$' . base64_encode($iv . $tag . $enc);
}

function ipam_totp_decrypt_secret(string $encSecret, string $key): string {
    if ($key === '') {
        throw new \RuntimeException('TOTP decryption requires a non-empty app_secret');
    }
    if (str_starts_with($encSecret, '$2$')) {
        // GCM path (v3.6.0+)
        $raw = base64_decode(substr($encSecret, 3), true);
        if ($raw === false || strlen($raw) < 29) {
            return '';
        }
        $iv      = substr($raw, 0, 12);
        $tag     = substr($raw, 12, 16);
        $payload = substr($raw, 28);
        $decrypted = openssl_decrypt($payload, 'aes-256-gcm', hash('sha256', $key, true), OPENSSL_RAW_DATA, $iv, $tag);
        if ($decrypted === false) {
            return '';
        }
        return $decrypted;
    }
    // Legacy CBC path — decrypt secrets enrolled before the GCM migration.
    $raw = base64_decode($encSecret, true);
    if ($raw === false || strlen($raw) < 17) {
        return '';
    }
    $iv        = substr($raw, 0, 16);
    $payload   = substr($raw, 16);
    $decrypted = openssl_decrypt($payload, 'aes-256-cbc', hash('sha256', $key, true), OPENSSL_RAW_DATA, $iv);
    if ($decrypted === false) {
        return '';
    }
    return $decrypted;
}

/** @return list<string> */
function ipam_totp_generate_backup_codes(int $count = 8): array {
    $codes = [];
    for ($i = 0; $i < $count; $i++) {
        $codes[] = strtoupper(bin2hex(random_bytes(4))) . '-' . strtoupper(bin2hex(random_bytes(4)));
    }
    return $codes;
}

/** @param list<string> $codes */
function ipam_totp_save_backup_codes(PDO $db, int $userId, array $codes): void {
    $db->beginTransaction();
    try {
        $db->prepare("DELETE FROM totp_backup_codes WHERE user_id = :uid")->execute([':uid' => $userId]);
        $stmt = $db->prepare("INSERT INTO totp_backup_codes (user_id, code_hash) VALUES (:uid, :hash)");
        foreach ($codes as $code) {
            $stmt->execute([':uid' => $userId, ':hash' => password_hash($code, PASSWORD_DEFAULT)]);
        }
        $db->commit();
    } catch (\Throwable $e) {
        $db->rollBack();
        throw $e;
    }
}

function ipam_totp_verify_backup_code(PDO $db, int $userId, string $code): bool {
    $stmt = $db->prepare(
        "SELECT id, code_hash FROM totp_backup_codes WHERE user_id = :uid AND used_at IS NULL"
    );
    $stmt->execute([':uid' => $userId]);
    $nowExpr = $db->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite' ? "datetime('now')" : "NOW()";
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        if (password_verify($code, (string)$row['code_hash'])) {
            $consume = $db->prepare(
                "UPDATE totp_backup_codes SET used_at = {$nowExpr} WHERE id = :id AND used_at IS NULL"
            );
            $consume->execute([':id' => $row['id']]);
            return $consume->rowCount() === 1;
        }
    }
    return false;
}

// ============================================================
// API per-key rate limiting (v3.6.0, #419)
// ============================================================

/**
 * Returns 0 when the request is allowed, or the number of seconds until the
 * sliding window unblocks when it is denied.
 */
function ipam_api_key_rate_limit_check(PDO $db, string $bucketKey, int $windowSec, int $max): int {
    if ($windowSec < 1) {
        throw new \InvalidArgumentException('windowSec must be >= 1');
    }
    if ($max < 1) {
        throw new \InvalidArgumentException('max must be >= 1');
    }
    $now              = time();
    $windowStartEpoch = (int)($now / $windowSec) * $windowSec;
    $prevWindowEpoch  = $windowStartEpoch - $windowSec;
    $windowStart      = date('Y-m-d H:i:s', $windowStartEpoch);
    $prevWindowStart  = date('Y-m-d H:i:s', $prevWindowEpoch);
    $cutoff           = date('Y-m-d H:i:s', $prevWindowEpoch - $windowSec);

    // Prune buckets older than 2 windows ago
    $db->prepare("DELETE FROM rate_limit_buckets WHERE window_start < :cutoff")
       ->execute([':cutoff' => $cutoff]);

    // Increment current window
    $driver = $db->getAttribute(PDO::ATTR_DRIVER_NAME);
    if ($driver === 'mysql') {
        $db->prepare(
            "INSERT INTO rate_limit_buckets (bucket_key, window_start, count) VALUES (:k, :w, 1)
             ON DUPLICATE KEY UPDATE count = count + 1"
        )->execute([':k' => $bucketKey, ':w' => $windowStart]);
    } else {
        $db->prepare(
            "INSERT INTO rate_limit_buckets (bucket_key, window_start, count) VALUES (:k, :w, 1)
             ON CONFLICT(bucket_key, window_start) DO UPDATE SET count = rate_limit_buckets.count + 1"
        )->execute([':k' => $bucketKey, ':w' => $windowStart]);
    }

    // Sliding-window approximation: weight previous bucket by fraction remaining in current window
    $stmt = $db->prepare(
        "SELECT count FROM rate_limit_buckets WHERE bucket_key = :k AND window_start = :w"
    );
    $stmt->execute([':k' => $bucketKey, ':w' => $windowStart]);
    $currentCount = (int)($stmt->fetchColumn() ?: 0);

    $stmt->execute([':k' => $bucketKey, ':w' => $prevWindowStart]);
    $prevCount = (int)($stmt->fetchColumn() ?: 0);

    $elapsed  = $now - $windowStartEpoch;
    $weight   = ($windowSec - $elapsed) / $windowSec;
    $weighted = $currentCount + ($prevCount * $weight);

    if ($weighted <= $max) {
        return 0; // allowed
    }

    // Calculate when the weighted count will drop to <= max (assuming no new requests).
    //
    // Case A: currentCount < max — overflow is driven by prevCount weight.
    //   Solve: currentCount + prevCount*(windowSec - elapsed - t)/windowSec = max
    //   => t = (windowSec - elapsed) - (max - currentCount)*windowSec/prevCount
    if ($currentCount < $max && $prevCount > 0) {
        $tWithin = ($windowSec - $elapsed) - ((float)($max - $currentCount) * $windowSec / $prevCount);
        if ($tWithin > 0) {
            return max(1, (int)ceil($tWithin));
        }
    }

    // Case B: currentCount >= max — need to survive into the next window.
    //   In next window: weighted ≈ currentCount*(windowSec - t')/windowSec
    //   Solve for t' when weighted = max, then add remaining time in current window.
    $remainInWindow = $windowStartEpoch + $windowSec - $now;
    if ($currentCount > 0) {
        $intoNext = (int)ceil($windowSec * (1.0 - (float)$max / $currentCount));
        return max(1, $remainInWindow + max(0, $intoNext));
    }
    return max(1, $remainInWindow + 1);
}

// ============================================================
// Session absolute lifetime (v3.6.0, #420)
// ============================================================

/** @param IpamConfig $config */
function ipam_session_enforce_absolute_lifetime(array $config): void {
    $lifetimeMin = (int)(($config['session']['absolute_lifetime_minutes'] ?? 480));
    if ($lifetimeMin <= 0) {
        return; // Disabled
    }
    if (!isset($_SESSION['_abs_expires'])) {
        return; // Not yet seeded — pre-auth request; seeding happens in login_user()
    }
    $expires    = $_SESSION['_abs_expires'];
    $expiresInt = is_int($expires) ? $expires : (is_numeric($expires) ? (int)$expires : 0);
    if (time() > $expiresInt) {
        // Stash REQUEST_URI before destroying the session so users who follow
        // an authenticated link (e.g. email-verification) with a stale cookie
        // are returned to that URL after re-login rather than dumped on the
        // dashboard.
        $stashUri = to_str($_SERVER['REQUEST_URI'] ?? '');
        $_SESSION = [];
        session_destroy();
        if ($stashUri !== '') {
            session_start();
            ipam_post_login_redirect_stash($stashUri);
            session_write_close();
        }
        header('Location: login.php?reason=session_expired');
        exit;
    }
}

// ============================================================
// Persistent account lockout helpers (v3.6.0, #421)
// ============================================================

function ipam_is_persistently_locked(PDO $db, int $uid): bool {
    $stmt = $db->prepare("SELECT locked_until FROM users WHERE id = :id");
    $stmt->execute([':id' => $uid]);
    $lockedUntil = $stmt->fetchColumn();
    return $lockedUntil !== false && $lockedUntil !== null && strtotime((string)$lockedUntil . ' UTC') > time();
}

/** @param IpamConfig $config */
function ipam_record_2fa_failure(PDO $db, int $uid, array $config): void {
    $threshold   = (int)($config['auth']['lockout_after_failures'] ?? 10);
    $lockMinutes = (int)($config['auth']['lockout_duration_minutes'] ?? 30);

    $db->prepare("UPDATE users SET failed_auth_count = failed_auth_count + 1 WHERE id = :id")
       ->execute([':id' => $uid]);

    $stmt = $db->prepare("SELECT failed_auth_count FROM users WHERE id = :id");
    $stmt->execute([':id' => $uid]);
    $count = (int)$stmt->fetchColumn();

    if ($count >= $threshold) {
        $until = date('Y-m-d H:i:s', time() + ($lockMinutes * 60));
        $db->prepare("UPDATE users SET locked_until = :until, lock_reason = 'failed_2fa' WHERE id = :id")
           ->execute([':until' => $until, ':id' => $uid]);
    }
}

function ipam_clear_persistent_lockout(PDO $db, int $uid): void {
    $db->prepare(
        "UPDATE users SET failed_auth_count = 0, locked_until = NULL, lock_reason = NULL WHERE id = :id"
    )->execute([':id' => $uid]);
}

// ============================================================
// Email OTP helpers (#684)
// ============================================================

/**
 * Generate a 6-digit email OTP for the given user, store a bcrypt hash,
 * set a TTL-based expiry, reset the attempt counter, and return the
 * plaintext code for delivery via email.
 *
 * Expiry is computed in PHP (date('Y-m-d H:i:s', time() + $ttlMinutes * 60))
 * so no dialect-specific SQL expression is needed.
 */
function ipam_email_otp_generate(PDO $db, int $userId, int $ttlMinutes = 10): string
{
    $code    = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $hash    = password_hash($code, PASSWORD_DEFAULT);
    $expires = gmdate('Y-m-d H:i:s', time() + $ttlMinutes * 60);

    $db->prepare(
        "UPDATE users
            SET email_otp_hash       = :hash,
                email_otp_expires_at = :expires,
                email_otp_attempts   = 0
          WHERE id = :id"
    )->execute([':hash' => $hash, ':expires' => $expires, ':id' => $userId]);

    audit($db, 'mfa.otp.generate', 'user', $userId, "expires={$expires}");
    return $code;
}

/**
 * Verify a submitted email OTP code for the given user.
 *
 * Returns true only when:
 *   - a hash and expiry exist in the DB
 *   - fewer than 5 failed attempts have been recorded
 *   - the OTP has not expired
 *   - the code matches the stored bcrypt hash
 *
 * On success the OTP columns are cleared.
 * On failure the attempt counter is incremented.
 */
function ipam_email_otp_verify(PDO $db, int $userId, string $code): bool
{
    $stmt = $db->prepare(
        "SELECT email_otp_hash, email_otp_expires_at, email_otp_attempts
           FROM users WHERE id = :id"
    );
    $stmt->execute([':id' => $userId]);
    /** @var array<string,mixed>|false $row */
    $row = $stmt->fetch();

    if (!$row) {
        return false;
    }

    $hash     = is_string($row['email_otp_hash']       ?? null) ? $row['email_otp_hash']       : '';
    $expires  = is_string($row['email_otp_expires_at'] ?? null) ? $row['email_otp_expires_at'] : '';
    $attempts = to_int($row['email_otp_attempts'] ?? 0);

    if ($hash === '' || $expires === '') {
        return false;
    }

    if ($attempts >= 5) {
        ipam_email_otp_clear($db, $userId);
        audit($db, 'mfa.otp.locked', 'user', $userId, 'OTP locked: max attempts exceeded');
        return false;
    }

    // ISO datetime strings sort correctly as plain string comparison (both UTC)
    if ($expires < gmdate('Y-m-d H:i:s')) {
        ipam_email_otp_clear($db, $userId);
        audit($db, 'mfa.otp.expired', 'user', $userId, 'OTP expired');
        return false;
    }

    if (!password_verify($code, $hash)) {
        // #874 + CR #1100: increment unconditionally and use the
        // post-increment value via RETURNING (pgsql) or a follow-up
        // SELECT (sqlite/mysql) so EVERY concurrent failed attempt is
        // counted. The previous compare-and-swap version dropped
        // increments when two requests raced from the same baseline:
        // only one CAS won and the loser merely re-read the counter
        // without recording its own failure, so an attacker could
        // stretch the 5-strike lockout by firing N concurrent bad
        // codes against a single OTP. UPDATE … SET col = col + 1
        // is atomic at the row level on every supported engine.
        $upd = $db->prepare(
            "UPDATE users
                SET email_otp_attempts = email_otp_attempts + 1
              WHERE id = :id"
        );
        $upd->execute([':id' => $userId]);
        $reSt = $db->prepare("SELECT email_otp_attempts FROM users WHERE id = :id");
        $reSt->execute([':id' => $userId]);
        $current = to_int($reSt->fetchColumn() ?: 0);
        if ($current >= 5) {
            ipam_email_otp_clear($db, $userId);
            audit($db, 'mfa.otp.locked', 'user', $userId, 'OTP locked: max attempts exceeded');
        } else {
            audit($db, 'mfa.otp.fail', 'user', $userId, "attempt={$current}");
        }
        return false;
    }

    // Success — consume the OTP
    $db->prepare(
        "UPDATE users
            SET email_otp_hash       = NULL,
                email_otp_expires_at = NULL,
                email_otp_attempts   = 0
          WHERE id = :id"
    )->execute([':id' => $userId]);

    audit($db, 'mfa.otp.verify_ok', 'user', $userId, 'Email OTP verified successfully');
    return true;
}

/**
 * Clear all email OTP state for the given user (used on logout, password
 * change, or administrative reset). Pass a non-empty $reason to emit an
 * audit entry for the clear event (omit when the caller already audits).
 */
function ipam_email_otp_clear(PDO $db, int $userId, string $reason = ''): void
{
    $db->prepare(
        "UPDATE users
            SET email_otp_hash       = NULL,
                email_otp_expires_at = NULL,
                email_otp_attempts   = 0
          WHERE id = :id"
    )->execute([':id' => $userId]);
    if ($reason !== '') {
        audit($db, 'mfa.otp.clear', 'user', $userId, $reason);
    }
}

/**
 * Send a plaintext email OTP code to the given user's email address via ipam_send_mail().
 * Call this immediately after ipam_email_otp_generate() with the returned plaintext code.
 * Returns true on success, false on failure (SMTP not configured, no email set, etc.).
 */
function ipam_email_otp_send(PDO $db, int $userId, string $code, int $ttlMinutes = 10): bool
{
    $stmt = $db->prepare("SELECT email, username FROM users WHERE id = :id");
    $stmt->execute([':id' => $userId]);
    /** @var array<string, mixed>|false $user */
    $user = $stmt->fetch();
    if (!$user || to_str($user['email'] ?? '') === '') {
        return false;
    }

    $appName = str_replace(["\r", "\n"], '', trim(to_str(ipam_setting('branding.site_name'))) ?: 'Simple PHP IPAM');
    $to      = to_str($user['email']);
    $subject = '[' . $appName . '] Your verification code';
    $body    = "Your one-time verification code is:\n\n    {$code}\n\nThis code expires in {$ttlMinutes} minutes. Do not share it with anyone.\n\nIf you did not request this, please contact your administrator.";

    $result = ipam_send_mail($to, $subject, $body);
    if (!$result['success']) {
        $errMsg = $result['error'] ?? 'unknown';
        error_log('ipam_email_otp_send: failed to send OTP to user ' . $userId . ': ' . $errMsg);
        audit($db, 'mfa.otp.send_fail', 'user', $userId, substr(strip_tags($errMsg), 0, 200));
        return false;
    }
    $masked = preg_replace('/^(.).*(@.+)$/', '$1***$2', $to) ?: '***';
    audit($db, 'mfa.otp.send', 'user', $userId, "to={$masked}");
    return true;
}

// ── Passkeys (WebAuthn) ───────────────────────────────────────────────────────

function ipam_passkey_webauthn(?string $rpName = null): \lbuchs\WebAuthn\WebAuthn
{
    // Default rpName to the configured site name so password managers
    // (LastPass, 1Password, Bitwarden) display the install's friendly name
    // rather than the generic "Simple PHP IPAM" or the bare hostname.
    if ($rpName === null || $rpName === '') {
        $rpName = trim(to_str(ipam_setting('branding.site_name'))) ?: 'Simple PHP IPAM';
    }
    // Load Composer autoloader if lbuchs\WebAuthn is not already available.
    // Primary: vendor/ bundled inside the web root (release tarball installs).
    // Fallback: vendor/ at the project root (dev/Docker setups, e.g. playwright matrix).
    if (!class_exists('lbuchs\\WebAuthn\\WebAuthn')) {
        $autoload = __DIR__ . '/vendor/autoload.php';
        if (!file_exists($autoload)) {
            $autoload = dirname(__DIR__) . '/vendor/autoload.php';
        }
        if (file_exists($autoload)) require_once $autoload;
        // PHPStan can't see that require_once may have loaded the class.
        // @phpstan-ignore-next-line booleanNot.alwaysTrue
        if (!class_exists('lbuchs\\WebAuthn\\WebAuthn')) {
            throw new \RuntimeException(
                'Passkeys are unavailable because the WebAuthn library is not installed. Run "composer install" or deploy the release tarball which bundles vendor/.'
            );
        }
    }
    // Strip port from HTTP_HOST — rpId must be hostname only, no port.
    $host = to_str($_SERVER['HTTP_HOST'] ?? 'localhost');
    $rpId = (string)preg_replace('/:\d+$/', '', $host) ?: 'localhost';
    // Strip brackets from IPv6 literals: "[::1]" → "::1", "[::1]:8443" → "::1".
    $rpId = (string)preg_replace('/^\[(.+)\]$/', '$1', $rpId);
    // IP addresses are not valid WebAuthn RP IDs per the W3C spec; only the
    // loopback addresses are permitted (mapped to 'localhost' for dev/test).
    // All other IP literals are rejected early — the browser would raise a
    // SecurityError anyway, and this surfaces a clear config error.
    if (filter_var($rpId, FILTER_VALIDATE_IP) !== false) {
        if ($rpId === '127.0.0.1' || $rpId === '::1') {
            $rpId = 'localhost';
        } else {
            throw new \RuntimeException(
                'Passkeys require a hostname; IP addresses are not valid WebAuthn RP IDs.'
            );
        }
    }
    return new \lbuchs\WebAuthn\WebAuthn($rpName, $rpId, allowedFormats: ['none', 'packed', 'apple', 'fido-u2f', 'android-key', 'android-safetynet', 'tpm']);
}

/**
 * Generate a WebAuthn assertion challenge for $userId, store it in the
 * session, and return true. Used by login.php for the initial dispatch and
 * by the MFA-method-switch links on totp_verify.php / email_otp_verify.php.
 * Returns false if the user has no registered credentials.
 */
function ipam_passkey_dispatch_challenge(PDO $db, int $userId): bool
{
    if (!ipam_passkey_has_credentials($db, $userId)) return false;

    $creds         = ipam_passkey_get_credentials($db, $userId);
    $credentialIds = array_map(
        static function (array $c): \lbuchs\WebAuthn\Binary\ByteBuffer {
            return new \lbuchs\WebAuthn\Binary\ByteBuffer(to_str($c['credential_id']));
        },
        $creds
    );

    $webAuthn     = ipam_passkey_webauthn();
    $assertArgs   = $webAuthn->getGetArgs($credentialIds, 60);
    $challengeBin = $webAuthn->getChallenge()->getBinaryString();

    $pk            = $assertArgs->publicKey;
    $pk->challenge = rtrim(strtr(base64_encode($challengeBin), '+/', '-_'), '=');
    if (!empty($pk->allowCredentials)) {
        foreach ($pk->allowCredentials as &$ac) {
            if (isset($ac->id) && ($ac->id instanceof \lbuchs\WebAuthn\Binary\ByteBuffer)) {
                $ac->id = rtrim(strtr(base64_encode($ac->id->getBinaryString()), '+/', '-_'), '=');
            }
        }
        unset($ac);
    }

    $_SESSION['passkey_pending_uid']         = $userId;
    $_SESSION['passkey_challenge']           = $challengeBin;
    $_SESSION['passkey_challenge_issued_at'] = time();
    $_SESSION['passkey_assertion_options']   = json_encode($pk);
    return true;
}

/** @return list<array<string,mixed>> */
function ipam_passkey_get_credentials(PDO $db, int $userId): array
{
    $st = $db->prepare(
        "SELECT id, credential_id, public_key, sign_count, name, created_at, last_used_at
           FROM webauthn_credentials
          WHERE user_id = :uid
          ORDER BY created_at"
    );
    $st->execute([':uid' => $userId]);
    /** @var list<array<string,mixed>> $rows */
    $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    return $rows;
}

function ipam_passkey_has_credentials(PDO $db, int $userId): bool
{
    $st = $db->prepare("SELECT COUNT(*) FROM webauthn_credentials WHERE user_id = :uid");
    $st->execute([':uid' => $userId]);
    return (int)$st->fetchColumn() > 0;
}

function ipam_passkey_count(PDO $db, int $userId): int
{
    $st = $db->prepare("SELECT COUNT(*) FROM webauthn_credentials WHERE user_id = :uid");
    $st->execute([':uid' => $userId]);
    return (int)$st->fetchColumn();
}

function ipam_passkey_delete(PDO $db, int $credentialDbId, int $userId): bool
{
    $st = $db->prepare("DELETE FROM webauthn_credentials WHERE id = :id AND user_id = :uid");
    $st->execute([':id' => $credentialDbId, ':uid' => $userId]);
    return $st->rowCount() > 0;
}

function ipam_passkey_delete_all(PDO $db, int $userId): void
{
    $db->prepare("DELETE FROM webauthn_credentials WHERE user_id = :uid")->execute([':uid' => $userId]);
}

/**
 * Look up a credential by its binary credential_id; returns DB row or null.
 * @return array<string,mixed>|null
 */
function ipam_passkey_find_by_credential_id(PDO $db, string $credentialIdBin): ?array
{
    $st = $db->prepare(
        "SELECT id, user_id, credential_id, public_key, sign_count, name
           FROM webauthn_credentials
          WHERE credential_id = :cid"
    );
    $st->bindValue(':cid', $credentialIdBin, PDO::PARAM_LOB);
    $st->execute();
    /** @var array<string,mixed>|false $row */
    $row = $st->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function ipam_passkey_update_sign_count(PDO $db, int $credentialDbId, int $signCount): void
{
    /** @var string $driver */
    $driver = $db->getAttribute(PDO::ATTR_DRIVER_NAME);
    $nowExpr = match($driver) {
        'sqlite' => "datetime('now')",
        'mysql'  => "UTC_TIMESTAMP()",
        default  => "(NOW() AT TIME ZONE 'utc')",
    };
    $db->prepare("UPDATE webauthn_credentials SET sign_count = :sc, last_used_at = $nowExpr WHERE id = :id")
       ->execute([':sc' => $signCount, ':id' => $credentialDbId]);
}

// ============================================================
// Preferred MFA method dispatch (v3.16.0, #746)
// ============================================================

/**
 * Return the user's currently usable MFA methods. A method is "usable" only
 * if the user has it enrolled AND the admin has it globally enabled.
 *
 * Ordering matches the legacy v3.x dispatch chain (TOTP → Email OTP →
 * Passkey) so that existing installs see no behaviour change when no
 * preferred_mfa_method is set. The user-facing "most-recently-enrolled
 * default" semantics live in change_password.php's picker UI, where we
 * have signal to make a smart default; the dispatch helper itself is a
 * deterministic, stable fallback.
 *
 * The returned list is the canonical fallback chain for login dispatch.
 *
 * @return list<string>  Subset of {'totp','email_otp','passkey'}.
 */
function ipam_user_available_mfa_methods(PDO $db, int $userId): array
{
    $totpGlobal      = (bool)to_int(ipam_setting('mfa.totp_enabled', true));
    $emailOtpGlobal  = (bool)to_int(ipam_setting('mfa.email_otp_enabled', false));
    $passkeysGlobal  = (bool)to_int(ipam_setting('mfa.passkeys_enabled', false));

    $st = $db->prepare("SELECT totp_enabled, email_otp_enabled FROM users WHERE id = :id");
    $st->execute([':id' => $userId]);
    /** @var array<string,mixed>|false $row */
    $row = $st->fetch();
    if (!$row) {
        return [];
    }

    $totpEnrolled     = to_int($row['totp_enabled'] ?? 0) === 1;
    $emailOtpEnrolled = to_int($row['email_otp_enabled'] ?? 0) === 1;
    $passkeyEnrolled  = ipam_passkey_has_credentials($db, $userId);

    $methods = [];
    if ($totpGlobal && $totpEnrolled) {
        $methods[] = 'totp';
    }
    if ($emailOtpGlobal && $emailOtpEnrolled) {
        $methods[] = 'email_otp';
    }
    if ($passkeysGlobal && $passkeyEnrolled) {
        $methods[] = 'passkey';
    }
    return $methods;
}

/**
 * Resolve the user's effective preferred MFA method for login dispatch.
 *
 * Returns the value stored in users.preferred_mfa_method when that method
 * is currently usable (enrolled by the user AND globally enabled). Returns
 * null otherwise — the caller should then fall back to
 * ipam_user_available_mfa_methods()[0].
 *
 * Tolerates absence of the preferred_mfa_method column (e.g. on partial
 * test DBs that pre-date the 3.16.0 migration) by returning null.
 */
function ipam_user_preferred_mfa(PDO $db, int $userId): ?string
{
    try {
        $st = $db->prepare("SELECT preferred_mfa_method FROM users WHERE id = :id");
        $st->execute([':id' => $userId]);
    } catch (\PDOException $e) {
        // Tolerate ONLY "column does not exist" — partial test DBs that pre-date
        // the v3.16.0 migration. SQLSTATE codes per driver:
        //   MySQL:      42S22 (column not found)
        //   PostgreSQL: 42703 (undefined_column)
        //   SQLite:     HY000 with errorInfo[2] containing "no such column"
        // Any other PDO error (transient connection, lock timeout, etc.) is a
        // real problem and must propagate — silently coercing every DB error
        // to "no preference" hides outages.
        $sqlstate = (string)($e->errorInfo[0] ?? '');
        $msg      = (string)($e->errorInfo[2] ?? '');
        if ($sqlstate === '42S22'
            || $sqlstate === '42703'
            || ($sqlstate === 'HY000' && str_contains($msg, 'no such column'))) {
            return null;
        }
        throw $e;
    }
    $val = $st->fetchColumn();
    if (!is_string($val) || $val === '') {
        return null;
    }
    if (!in_array($val, ['totp', 'email_otp', 'passkey'], true)) {
        return null;
    }
    $available = ipam_user_available_mfa_methods($db, $userId);
    if (!in_array($val, $available, true)) {
        return null;
    }
    return $val;
}

// ============================================================
// Dashboard KPI helpers (v3.8.0, #514)
// ============================================================

/**
 * @return array{subnets:int,addresses:int,used:int,pct_used:float,alerts:int}
 */
function ipam_dashboard_kpis(PDO $db): array {
    $stmtTotals = $db->query(
        "SELECT COUNT(*) AS subnets,
                (SELECT COUNT(*) FROM addresses) AS addresses,
                (SELECT COUNT(*) FROM addresses WHERE status='used') AS used
         FROM subnets"
    );
    /** @var array<string, mixed>|false $totals */
    $totals = $stmtTotals ? $stmtTotals->fetch() : false;
    $stmtAlerts = $db->query(
        "SELECT COUNT(*) AS cnt FROM alert_state WHERE level='crit'"
    );
    /** @var array<string, mixed>|false $alerts */
    $alerts = $stmtAlerts ? $stmtAlerts->fetch() : false;
    $subnets   = is_array($totals) ? to_int($totals['subnets'])   : 0;
    $addresses = is_array($totals) ? to_int($totals['addresses']) : 0;
    $used      = is_array($totals) ? to_int($totals['used'])      : 0;
    return [
        'subnets'   => $subnets,
        'addresses' => $addresses,
        'used'      => $used,
        'pct_used'  => $addresses > 0 ? round($used / $addresses * 100, 1) : 0.0,
        'alerts'    => is_array($alerts) ? to_int($alerts['cnt']) : 0,
    ];
}

/**
 * @return list<array<string,mixed>>
 */
function ipam_dashboard_growth(PDO $db, int $days = 30): array {
    $days  = max(1, $days);
    $now   = time();
    $start = gmdate('Y-m-d', $now - ($days - 1) * 86400) . ' 00:00:00';
    $st = $db->prepare(
        "SELECT DATE(created_at) AS d, COUNT(*) AS n
         FROM addresses
         WHERE created_at >= :start
         GROUP BY DATE(created_at)
         ORDER BY d"
    );
    $st->execute([':start' => $start]);

    $counts = [];
    foreach ($st->fetchAll() as $row) {
        $counts[to_str($row['d'])] = to_int($row['n']);
    }

    $series = [];
    for ($i = $days - 1; $i >= 0; $i--) {
        $day      = gmdate('Y-m-d', $now - $i * 86400);
        $series[] = ['d' => $day, 'n' => $counts[$day] ?? 0];
    }
    return $series;
}

/**
 * Renders the drawer body partial for a single backup_runs row.
 * Used by backup_run_detail.php (#803). Returns null when the id does
 * not resolve so the endpoint can return 404.
 *
 * Disabled-state matrix is the source of truth for both the rendered
 * UI and the BackupRunDetailTest contract:
 *   - status='running'                         → all three actions disabled
 *   - status!='success' OR filename empty      → verify/download disabled
 *   - is_protected=1                           → delete disabled
 *
 * @return string|null
 */
function ipam_render_backup_run_detail(\PDO $db, int $id): ?string
{
    $st = $db->prepare(
        "SELECT r.*, d.name AS dest_name, d.type AS dest_type
           FROM backup_runs r
           LEFT JOIN backup_destinations d ON d.id = r.destination_id
          WHERE r.id = :id"
    );
    $st->execute([':id' => $id]);
    $row = $st->fetch(\PDO::FETCH_ASSOC);
    if (!is_array($row)) {
        return null;
    }

    $status      = to_str($row['status'] ?? '');
    $filename    = to_str($row['filename'] ?? '');
    $destId      = to_int($row['destination_id'] ?? 0);
    $hasArtifact = ($status === 'success') && $filename !== '';
    $isRunning   = ($status === 'running');
    $isProtected = to_int($row['is_protected'] ?? 0) === 1;
    // backup_runs.destination_id is ON DELETE SET NULL — an orphan row with a
    // success status still has a filename but no destination to fetch from,
    // so Download must be disabled (the POST endpoint rejects destId <= 0).
    $hasDest     = $destId > 0;

    $disabled = [
        'verify'   => !$hasArtifact || $isRunning || !$hasDest,
        'download' => !$hasArtifact || $isRunning || !$hasDest,
        'delete'   => $isRunning || $isProtected,
    ];
    $tooltip = [
        'verify'   => $isRunning ? 'Run not finished' : (!$hasArtifact ? 'No artifact at destination' : (!$hasDest ? 'Destination deleted' : '')),
        'download' => $isRunning ? 'Run not finished' : (!$hasArtifact ? 'No artifact at destination' : (!$hasDest ? 'Destination deleted' : '')),
        'delete'   => $isRunning
            ? 'Cannot delete a run in progress'
            : ($isProtected ? 'This run is protected. Unprotect it from the schedule\'s retention settings before deleting.' : ''),
    ];

    ob_start();
    require __DIR__ . '/views/_backup_run_detail_body.php';
    return (string) ob_get_clean();
}

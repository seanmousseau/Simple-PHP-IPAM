<?php
declare(strict_types=1);

/**
 * Return array of migrations keyed by version string.
 * Each migration is a callable(PDO $db): void
 *
 * Add future migrations here, e.g.:
 * '0.2' => function(PDO $db) { ... };
 */
function ipam_migrations(): array
{
    return [
        // '0.2' => function(PDO $db) { ... },
    ];
}

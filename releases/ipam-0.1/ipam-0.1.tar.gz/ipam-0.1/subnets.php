<?php
declare(strict_types=1);
require __DIR__ . '/init.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();
}

$err = '';
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');

    if ($action === 'create') {
        require_write_access();
        $cidr = trim((string)($_POST['cidr'] ?? ''));
        $desc = trim((string)($_POST['description'] ?? ''));

        $p = parse_cidr($cidr);
        if (!$p) {
            $err = 'Invalid CIDR. Examples: 192.168.1.0/24 or 2001:db8::/64';
        } else {
            $normalized = $p['network'] . '/' . $p['prefix'];
            try {
                $st = $db->prepare("INSERT INTO subnets (cidr, ip_version, network, prefix, description)
                                    VALUES (:cidr,:ver,:net,:pre,:d)");
                $st->execute([
                    ':cidr' => $normalized,
                    ':ver' => $p['version'],
                    ':net' => $p['network'],
                    ':pre' => $p['prefix'],
                    ':d' => $desc
                ]);
                $id = (int)$db->lastInsertId();
                audit($db, 'subnet.create', 'subnet', $id, $normalized);
                header('Location: subnets.php');
                exit;
            } catch (PDOException $e) {
                $err = 'Could not create subnet (duplicate?).';
            }
        }
    } elseif ($action === 'update') {
        require_write_access();
        $id = (int)($_POST['id'] ?? 0);
        $cidr = trim((string)($_POST['cidr'] ?? ''));
        $desc = trim((string)($_POST['description'] ?? ''));

        $p = parse_cidr($cidr);
        if (!$p) {
            $err = 'Invalid CIDR.';
        } else {
            $normalized = $p['network'] . '/' . $p['prefix'];
            try {
                $st = $db->prepare("UPDATE subnets
                                    SET cidr=:cidr, ip_version=:ver, network=:net, prefix=:pre, description=:d
                                    WHERE id=:id");
                $st->execute([
                    ':cidr' => $normalized,
                    ':ver' => $p['version'],
                    ':net' => $p['network'],
                    ':pre' => $p['prefix'],
                    ':d' => $desc,
                    ':id' => $id
                ]);
                audit($db, 'subnet.update', 'subnet', $id, $normalized);
                $msg = 'Subnet updated.';
            } catch (PDOException $e) {
                $err = 'Could not update subnet (duplicate?).';
            }
        }
    } elseif ($action === 'delete') {
        require_write_access();
        $id = (int)($_POST['id'] ?? 0);
        $st = $db->prepare("DELETE FROM subnets WHERE id = :id");
        $st->execute([':id' => $id]);
        audit($db, 'subnet.delete', 'subnet', $id, '');
        header('Location: subnets.php');
        exit;
    }
}

$st = $db->prepare("SELECT id, cidr, ip_version, description, created_at, updated_at
                    FROM subnets ORDER BY ip_version ASC, cidr ASC");
$st->execute();
$list = $st->fetchAll();

page_header('Subnets');
?>
<h1>Subnets</h1>
<?php if ($err): ?><p class="danger"><?= e($err) ?></p><?php endif; ?>
<?php if ($msg): ?><p><?= e($msg) ?></p><?php endif; ?>

<h2>Add subnet</h2>
<form method="post" action="subnets.php">
  <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
  <input type="hidden" name="action" value="create">
  <div class="row">
    <label>CIDR<br><input name="cidr" placeholder="10.0.0.0/24 or 2001:db8::/64" required></label>
    <label>Description<br><input name="description" placeholder="Office LAN"></label>
    <button type="submit" <?= (current_user()['role']==='readonly')?'disabled':'' ?>>Add</button>
  </div>
  <?php if (current_user()['role']==='readonly'): ?><p class="muted">Read-only account.</p><?php endif; ?>
</form>

<h2>Existing</h2>
<table>
  <thead>
    <tr>
      <th>CIDR</th><th>IP ver</th><th>Description</th><th>Updated</th><th>Actions</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach ($list as $s): ?>
    <tr>
      <td><?= e($s['cidr']) ?></td>
      <td><?= (int)$s['ip_version'] ?></td>
      <td><?= e($s['description']) ?></td>
      <td class="muted"><?= e($s['updated_at']) ?></td>
      <td>
        <details>
          <summary>Edit/Delete</summary>

          <form method="post" action="subnets.php" class="row" style="margin-top:8px">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
            <label>CIDR<br><input name="cidr" value="<?= e($s['cidr']) ?>" required></label>
            <label>Description<br><input name="description" value="<?= e($s['description']) ?>"></label>
            <button type="submit" <?= (current_user()['role']==='readonly')?'disabled':'' ?>>Save</button>
          </form>

          <form method="post" action="subnets.php" onsubmit="return confirm('Delete subnet and all its addresses?');" style="margin-top:8px">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
            <button type="submit" <?= (current_user()['role']==='readonly')?'disabled':'' ?>>Delete</button>
          </form>

          <?php if (current_user()['role']==='readonly'): ?><p class="muted">Read-only account.</p><?php endif; ?>
        </details>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php page_footer();

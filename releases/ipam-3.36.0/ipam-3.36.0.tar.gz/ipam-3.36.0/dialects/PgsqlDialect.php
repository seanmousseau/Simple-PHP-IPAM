<?php
declare(strict_types=1);

/**
 * PostgreSQL 14+ implementation of the Dialect interface (#386).
 *
 * Stateless — every method is a pure function over its arguments. Mirrors
 * SqliteDialect and MysqlDialect structurally. v2.11.0 is the first release
 * to ship this class; users opt in via `db_driver = 'pgsql'` in config.php.
 * The driver is labelled experimental in v2.11.0 and promoted to stable in
 * v3.0.0 alongside MySQL.
 *
 * Postgres minimum version: 14. Lower versions are rejected at connection
 * time with a clear error — see the version check in lib.php::ipam_db().
 * Reasons for the 14 floor:
 *
 *   - CREATE OR REPLACE TRIGGER (added in PG14) for idempotent trigger
 *     bootstrap without drop-and-recreate races
 *   - MERGE support on the roadmap (PG15) is nice-to-have but we use
 *     ON CONFLICT which is stable since 9.5
 *   - Modern default parallel query planning and btree index deduping
 *
 * Storage conventions (match SQLite and MySQL for cross-engine
 * compatibility):
 *
 *   - ip_bin / network_bin: BYTEA, native length (4 bytes for IPv4, 16
 *     bytes for IPv6, never left-padded). All three engines do byte-wise
 *     memcmp ordering on native-length binary values, so ORDER BY ip_bin
 *     is equivalent across engines. Locked in during v2.8.0 planning
 *     (#410). `ipam_bind_binary()` uses PDO::PARAM_LOB so nulls and high
 *     bytes round-trip cleanly through pdo_pgsql.
 *   - Indexed text columns: TEXT. Postgres btree indexes on TEXT have no
 *     key length limit so the interface's $maxLen argument is ignored.
 *   - Case-sensitive columns: default collation is case-sensitive so no
 *     explicit COLLATE clause is needed.
 *
 * No namespace is used; see CLAUDE.md "When to use classes vs functions".
 */
final class PgsqlDialect implements Dialect
{
    /**
     * (NOW() AT TIME ZONE 'utc') resolves to a UTC timestamp regardless of
     * the session's timezone setting, matching SQLite's datetime('now') and
     * MySQL's UTC_TIMESTAMP(). Plain NOW() respects session timezone and
     * would drift across deployments, so avoid it.
     */
    public function now(): string
    {
        return "(NOW() AT TIME ZONE 'utc')";
    }

    /**
     * Postgres's INSERT ... ON CONFLICT (cols) DO UPDATE SET col = EXCLUDED.col
     * is a direct match for SQLite's syntax — EXCLUDED is the pseudo-table
     * referencing the would-be-inserted row, equivalent to SQLite's
     * `excluded.col` form.
     *
     * @param string[] $conflictCols
     * @param string[] $updateCols
     */
    public function upsert(string $table, array $conflictCols, array $updateCols): string
    {
        if ($conflictCols === []) {
            throw new InvalidArgumentException('upsert() requires at least one conflict column');
        }
        if ($updateCols === []) {
            throw new InvalidArgumentException('upsert() requires at least one update column');
        }
        $target = '(' . implode(', ', $conflictCols) . ')';
        $assignments = [];
        foreach ($updateCols as $col) {
            $assignments[] = "$col = EXCLUDED.$col";
        }
        return "ON CONFLICT $target DO UPDATE SET " . implode(', ', $assignments);
    }

    /**
     * Postgres native `INSERT ... ON CONFLICT (...) DO UPDATE SET c = t.c + 1`.
     * The conflict target is scoped to $keyCols (unlike MySQL). The `t.c`
     * table-qualified form disambiguates the existing-row column from the
     * EXCLUDED pseudo-table inside the DO UPDATE.
     *
     * @param list<string> $keyCols
     */
    public function increment_or_insert(string $table, array $keyCols, string $counterCol): string
    {
        if ($keyCols === []) {
            throw new InvalidArgumentException('increment_or_insert() requires at least one key column');
        }
        DialectValidator::assertBareIdentifiers($keyCols, 'PgsqlDialect::increment_or_insert');
        DialectValidator::assertBareIdentifiers([$table, $counterCol], 'PgsqlDialect::increment_or_insert');
        $cols         = implode(', ', $keyCols);
        $placeholders = implode(', ', array_map(static fn (string $c): string => ':' . $c, $keyCols));
        return "INSERT INTO $table ($cols, $counterCol) VALUES ($placeholders, 1) "
            . "ON CONFLICT ($cols) DO UPDATE SET $counterCol = $table.$counterCol + 1";
    }

    /**
     * Postgres's ON CONFLICT (cols) DO NOTHING is the direct native idiom,
     * identical in shape to SQLite's. Unlike MySQL, the conflict target is
     * scoped to the listed columns.
     *
     * @param string[] $conflictCols
     */
    public function upsert_or_ignore(string $table, array $conflictCols): string
    {
        if ($conflictCols === []) {
            throw new InvalidArgumentException('upsert_or_ignore() requires at least one conflict column');
        }
        DialectValidator::assertBareIdentifiers($conflictCols, 'PgsqlDialect::upsert_or_ignore');
        return 'ON CONFLICT (' . implode(', ', $conflictCols) . ') DO NOTHING';
    }

    /**
     * GENERATED BY DEFAULT AS IDENTITY is the modern Postgres idiom for
     * auto-incrementing PKs (SQL standard, available since PG10). Chosen
     * over BIGSERIAL because IDENTITY columns don't leave orphan sequences
     * behind on table drop and integrate better with pg_dump. BIGINT gives
     * the same 64-bit opaque row-handle range as SQLite's INTEGER PRIMARY
     * KEY and MySQL's BIGINT UNSIGNED.
     */
    public function autoincrement(): string
    {
        return 'BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY';
    }

    /**
     * Postgres btree indexes on TEXT have no key length limit so $maxLen
     * is ignored on this engine, matching SQLite's behaviour. Keep the
     * argument in the signature for cross-dialect symmetry.
     */
    public function indexed_text_type(int $maxLen = 191): string
    {
        return 'TEXT';
    }

    /**
     * BYTEA is Postgres's variable-length binary type. Unlike MySQL's
     * VARBINARY, BYTEA has no declared length — the $length argument is
     * informational only and ignored here. Binding must go through
     * ipam_bind_binary() (PDO::PARAM_LOB) so null bytes and high bytes
     * round-trip through pdo_pgsql without string-escaping.
     */
    public function binary_type(int $length): string
    {
        return 'BYTEA';
    }

    /**
     * Postgres's default collation inherits from the database's LC_COLLATE,
     * which on the initdb defaults (UTF-8, C / POSIX / en_US.UTF-8) is
     * case-sensitive and byte-comparable for ASCII. No extra clause is
     * needed on correctly-initialised clusters. Installations that run on
     * a case-insensitive ICU collation are out of scope for v2.11.0 —
     * documented in the install notes.
     */
    public function case_sensitive_collation(): ?string
    {
        return null;
    }

    /**
     * One PL/pgSQL function plus two CREATE OR REPLACE TRIGGER statements
     * (PG14+). The function is per-table so multiple append-only tables
     * can coexist without name collisions.
     *
     * Bypass mechanism: housekeeping routines that need to prune (e.g.
     * prune_audit_log) set a custom GUC via
     * `SET LOCAL ipam.bypass_append_only = '1'` inside a transaction,
     * perform the DELETE, and the GUC unsets on transaction end. Other
     * connections see NULL and continue to be blocked by RAISE EXCEPTION.
     * GUCs scoped with SET LOCAL are per-transaction so the bypass never
     * leaks. Matches the v2.10.0 #502 design for MySQL
     * (@ipam_bypass_append_only session variable).
     *
     * Custom GUCs need a dotted name (namespace.param) to be accepted
     * without a server-level configuration entry. `current_setting(..., true)`
     * returns NULL for unset GUCs instead of raising, so the IS DISTINCT
     * FROM comparison handles the unset case cleanly.
     *
     * CREATE OR REPLACE TRIGGER (PG14+) is idempotent, so bootstrap can
     * re-apply the trigger set on every ensure_audit_log_table() call
     * without a drop-and-recreate race window. This is the primary reason
     * for the PG14 floor.
     *
     * @return list<string>
     */
    public function append_only_trigger(string $table): array
    {
        $fn = "{$table}_append_only_fn";
        $msg = "$table is append-only";
        // PL/pgSQL function bodies are quoted with $$ ... $$ dollar-quoted
        // string literals. No quote escaping needed inside the body.
        // Postgres BEFORE trigger functions suppress the row when they
        // return NULL, so in the bypass path we must return OLD (for
        // DELETE) or NEW (for UPDATE) to let the operation proceed. A
        // plain `RETURN NULL` would silently drop the housekeeping
        // DELETE on the floor, not block-and-raise. See #387
        // schema.pgsql.sql smoke test that surfaced this.
        $fnDdl = <<<SQL
            CREATE OR REPLACE FUNCTION {$fn}() RETURNS TRIGGER AS \$\$
            BEGIN
                IF current_setting('ipam.bypass_append_only', true) IS DISTINCT FROM '1' THEN
                    RAISE EXCEPTION '{$msg}';
                END IF;
                IF TG_OP = 'DELETE' THEN
                    RETURN OLD;
                END IF;
                RETURN NEW;
            END;
            \$\$ LANGUAGE plpgsql
            SQL;

        return [
            $fnDdl,

            "CREATE OR REPLACE TRIGGER {$table}_no_update "
            . "BEFORE UPDATE ON {$table} FOR EACH ROW EXECUTE FUNCTION {$fn}()",

            "CREATE OR REPLACE TRIGGER {$table}_no_delete "
            . "BEFORE DELETE ON {$table} FOR EACH ROW EXECUTE FUNCTION {$fn}()",
        ];
    }

    /**
     * Postgres has no per-connection FK-enforcement toggle equivalent to
     * SQLite's PRAGMA or MySQL's SET FOREIGN_KEY_CHECKS. The closest
     * options are deferred constraints or session_replication_role =
     * 'replica' (superuser only). Callers must check for null and use
     * engine-appropriate strategies — see migrations.php for the pattern.
     */
    public function pragma_foreign_keys(bool $on): ?string
    {
        return null;
    }

    /**
     * IS NOT DISTINCT FROM is the SQL-standard null-safe equality operator.
     * Postgres implements it natively; no spaceship or PRAGMA-style
     * alternative is needed.
     */
    public function null_safe_eq(string $column, string $placeholder): string
    {
        return "$column IS NOT DISTINCT FROM $placeholder";
    }

    public function driver_name(): string
    {
        return 'pgsql';
    }

    public function lower_expr(string $column): string
    {
        // Text columns use COLLATE "C" for byte-comparable equality (matching
        // SQLite default and MySQL utf8mb4_bin). Under COLLATE "C", LOWER()
        // only folds ASCII A–Z. Overriding the collation only for the LOWER()
        // call gives consistent Unicode case folding without changing how the
        // column is stored or compared elsewhere. See #750.
        return "LOWER($column COLLATE \"default\")";
    }

    public function case_fold_value(string $value): string
    {
        return mb_strtolower($value);
    }

    /**
     * The Postgres append-only trigger function checks the custom GUC
     * ipam.bypass_append_only via current_setting(..., true). SET LOCAL sets
     * it for the duration of the current transaction only, so it auto-unsets
     * on COMMIT/ROLLBACK — no explicit cleanup and no leak to other
     * connections or later transactions.
     *
     * The helper opens its own transaction only if the caller is not already
     * inside one ($ownTx); SET LOCAL requires a transaction context. On error,
     * a helper-owned transaction is rolled back.
     *
     * @template T
     * @param callable():T $work
     * @return T
     */
    public function with_append_only_bypass(PDO $db, callable $work): mixed
    {
        // $ownTx tracks whether THIS call opened the transaction. It is only
        // set true once beginTransaction() has actually succeeded, so the
        // error path can safely roll back exactly the transaction we own and
        // never one the caller started.
        $ownTx = false;
        try {
            if (!$db->inTransaction()) {
                $db->beginTransaction();
                $ownTx = true;
            }
            $db->exec("SET LOCAL ipam.bypass_append_only = '1'");
            try {
                $result = $work();
            } finally {
                // SET LOCAL is transaction-scoped: when the caller owns the
                // transaction ($ownTx=false), the bypass would otherwise stay
                // open for the rest of that outer transaction. Reset it at
                // $work() return regardless of who owns the tx — parity with
                // MysqlDialect, which resets its session variable after $work().
                try { $db->exec("SET LOCAL ipam.bypass_append_only = '0'"); } catch (\Throwable) {}
            }
            if ($ownTx) {
                $db->commit();
            }
            return $result;
        } catch (\Throwable $e) {
            if ($ownTx && $db->inTransaction()) {
                try { $db->rollBack(); } catch (\Throwable) {}
            }
            throw $e;
        }
    }
}

<?php
declare(strict_types=1);
require __DIR__ . '/init.php';

// Already passed the gate — go straight to login
if (!empty($_SESSION['demo_gate_passed'])) {
    header('Location: login.php');
    exit;
}

// Gate not configured — nothing to do
if (empty($config['demo_mode']['enabled']) || empty($config['demo_mode']['gate'])) {
    header('Location: login.php');
    exit;
}

// Build a config stub that maps demo_mode gate settings to the login_protection format
// so we can reuse login_protection_verify() and login_protection_widget_html().
$gateConfig = [
    'login_protection' => [
        'method'      => to_str($config['demo_mode']['gate'] ?? ''),
        'site_key'    => to_str($config['demo_mode']['site_key']   ?? ''),
        'secret_key'  => to_str($config['demo_mode']['secret_key'] ?? ''),
        'min_seconds' => 3,
        'version'     => 2,
    ],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = to_str($_POST['_gate_csrf'] ?? '');
    if (!hash_equals(to_str($_SESSION['gate_csrf'] ?? ''), $token) || $token === '') {
        header('Location: demo_gate.php');
        exit;
    }
    unset($_SESSION['gate_csrf']);

    $result = login_protection_verify($gateConfig, $_POST);
    if ($result === null) {
        // Passed
        $_SESSION['demo_gate_passed'] = true;
        header('Location: login.php');
        exit;
    }
    $gateError = $result !== '' ? $result : ''; // '' = honeypot (silent — re-render)
} else {
    $gateError = '';
}

// Generate a one-time CSRF token for the gate form
$_SESSION['gate_csrf'] = bin2hex(random_bytes(16));

$widgetHtml = login_protection_widget_html($gateConfig);
$gateCsp    = login_protection_extra_csp($gateConfig);

$extraScriptSrc = $gateCsp['script_src'] !== '' ? ' ' . $gateCsp['script_src'] : '';
$extraStyleSrc  = $gateCsp['style_src']  !== '' ? ' ' . $gateCsp['style_src'] : '';
$extraFrameSrc  = $gateCsp['frame_src']  !== '' ? " frame-src 'self' " . $gateCsp['frame_src'] . ';' : '';
header("Content-Security-Policy: default-src 'self'; script-src 'self'{$extraScriptSrc}; style-src 'self'{$extraStyleSrc}; img-src 'self' data:;{$extraFrameSrc} frame-ancestors 'none'");
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');

require_once __DIR__ . '/version.php';
$appName = trim(to_str(ipam_setting('branding.site_name'))) ?: 'Simple PHP IPAM';
// v3.29.0 #897: cache-buster values centralised in ipam_asset_buster()
// (lib.php) so demo_gate.php and page_header() stay in lockstep without
// per-call-site duplication. demo_gate.php has its own <head> (does NOT
// call page_header) so it still renders the values inline — but the
// derivation lives in lib.php and any future scheme change happens in
// one place.
$av   = e(ipam_asset_buster());
$cssV = e(ipam_asset_buster('assets/app.css'));
// v3.34.0 #939 + #1047 (landing in v3.34.0): demo_gate.php has its own
// <head> (does NOT call page_header), so it carries a parallel $jsModules
// list. Keep this list byte-identical to the one in lib/presentation.php —
// the Playwright spec at testing/playwright/tests/frontend-modules.spec.ts
// asserts both emit sites match its canonical EXPECTED_MODULES array.
$jsModules = [
    '00-bootstrap',
    '10-theme-banner',
    '15-site-group-collapse',
    '20-drawer',
    '25-ping-shortcuts',
    '30-forms-core',
    '35-forms-confirm-bulk',
    '40-search-validation',
    '50-sidebar',
    '60-fill-ip-spinners',
    '65-contact-typeahead',
    '70-dashboard-prefs',
    '75-subnet-addr-grids',
    '80-command-palette',
    '81-tooltips',
    '82-audit-expand',
    '83-subnet-edit-drawer',
    '84-subnet-stats',
    '85-contact-browse',
    '86-contact-card',
    '87-contact-picker',
    '90-dhcp-export',
    '91-custom-fields-preview',
    '92-totp-verify-toggle',
    '93-smtp-test',
    '95-backups-modals',
    '96-totp-enroll-qr',
    '97-uplot-chart',
    '98-backup-history-actions',
    '99-subnets-site-filter',
    'b0-addresses-bulk-bar',
    'b1-addresses-site-cascade',
    'b2-webhooks-page',
    'b3-addresses-device-cascade',
    'b4-collapsible-rows',
    'b5-passkey-verify',
    'b6-step-up-prompt',
    'b7-passkey-register',
    'b8-settings-anchor-redirect',
    'b9-settings-rail-nav',
    'c0-destinations-admin',
    'c1-restore-confirm-typing',
    'c2-remote-backups-delete',
    'c3-destinations-verify-all',
    'c4-skeleton-toggle',
    'c5-sudo-replay-resume',
];
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= e($appName) ?> — Access Check</title>
  <link rel="icon" type="image/webp" sizes="32x32" href="assets/favicon-32.webp?v=<?= $av ?>">
  <link rel="icon" type="image/png" sizes="32x32" href="assets/favicon-32.png?v=<?= $av ?>">
  <link rel="apple-touch-icon" sizes="180x180" href="assets/apple-touch-icon.png?v=<?= $av ?>">
  <link rel="stylesheet" href="assets/vendor/open-props.min.css?v=<?= $av ?>">
  <link rel="stylesheet" href="assets/app.css?v=<?= $cssV ?>">
  <?php foreach ($jsModules as $mod): $v = e(ipam_asset_buster("assets/modules/{$mod}.js")); ?>
  <script defer src="assets/modules/<?= e($mod) ?>.js?v=<?= $v ?>"></script>
  <?php endforeach; ?>
</head>
<body>
<div class="gate-wrap">
  <div style="text-align:center;margin-bottom:12px;">
    <div class="nav-brand" style="font-size:var(--text-2xl);display:block;">Simple<span class="nav-brand-php">PHP</span>IPAM</div>
  </div>
  <h1>Almost there…</h1>
  <?php render_security_banner('demo_gate', 'This is a demo environment. Do not enter real IP data or credentials.'); ?>
  <p class="muted">Please complete the check below to continue to the demo.</p>

  <?php if ($gateError !== ''): ?>
    <p class="danger"><?= e($gateError) ?></p>
  <?php endif; ?>

  <form method="post" action="demo_gate.php">
    <input type="hidden" name="_gate_csrf" value="<?= e(to_str($_SESSION['gate_csrf'])) ?>">
    <?php if ($widgetHtml !== ''): ?>
      <div class="mt-10"><?= $widgetHtml ?></div>
    <?php endif; ?>
    <p class="mt-10"><button type="submit">Continue</button></p>
  </form>
</div>
</body>
</html>
